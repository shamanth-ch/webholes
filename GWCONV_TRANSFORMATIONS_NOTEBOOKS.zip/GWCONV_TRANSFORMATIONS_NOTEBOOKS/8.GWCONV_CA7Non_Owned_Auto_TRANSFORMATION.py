# Databricks notebook source
import logging
import sys
import os

LOG_FILE = 'etl_logfile.log'
LOG_FORMAT = '%(asctime)s %(levelname)s: %(message)s'

def get_etl_logger(name):
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    if logger.hasHandlers():
        logger.handlers.clear()
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.INFO)
    formatter = logging.Formatter(LOG_FORMAT)
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)
    file_handler = logging.FileHandler(LOG_FILE, mode='a')
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    return logger

logger = get_etl_logger('ca7noa_data')
logger.info(f"Logging initialized. Log file location: {os.path.abspath(LOG_FILE)}")

def log_info_to_file(message):
    with open(LOG_FILE, 'a') as f:
        import datetime
        timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        f.write(f"{timestamp} INFO: {message}\n")

# COMMAND ----------

# Cell Purpose: Set up Databricks widgets and retrieve job context for tracking ETL runs.
# Business Context: Enables parameterization and job tracking for the ETL pipeline, supporting both interactive and scheduled job runs in Databricks.
"""
This cell creates widgets for job_id and job_run_id, retrieves the current notebook context, and extracts job and run IDs for logging and audit purposes.
"""
# Create widgets for job_id and job_run_id for parameterization and job tracking
# These widgets allow passing parameters when running as a Databricks job
# The job_id is used to identify the specific job, while job_run_id is used to track the execution of that job.

dbutils.widgets.text("job_id", "")
dbutils.widgets.text("job_run_id", "")

# Get the current notebook context for extracting job and run metadata
# This context provides information about the job execution environment, including job IDs and notebook path.
context = dbutils.notebook.entry_point.getDbutils().notebook().getContext()

# Extract jobId and jobRunId objects from context (may be Option types)
# These IDs are crucial for tracking the execution of the ETL process.
job_id_obj = context.jobId()          # Option type: may or may not be defined
job_run_id_obj = context.jobRunId()   # Option type: may or may not be defined

# Retrieve the full path to the current notebook for logging purposes
notebook_path = context.notebookPath().get() # Full path to the current notebook
# Extract the notebook name from the path for easier identification in logs
notebook_name = notebook_path.split('/')[-1]   # Extract the notebook name from the path

def safe_get_option(option_obj):
    """
    Safely extract a value from a Databricks Option object.
    Parameters:
        option_obj: Option (Databricks Java/Scala Option type)
            The object to extract the value from.
    Returns:
        value or None: The value if defined, else None.
    Exceptions:
        Catches all exceptions to avoid breaking job context extraction.
        This ensures that even if an error occurs, the job can continue running without interruption.
    """
    try:
        if option_obj.isDefined():
            return option_obj.get()  # Return the value if defined
        else:
            return None  # Return None if not defined
    except Exception:
        return None  # Return None in case of any exception

# Use the safe_get_option to retrieve the values, defaulting to 'Manual' if not found
# This provides a fallback mechanism for logging and auditing purposes.
job_id = safe_get_option(job_id_obj) or "Manual"    # Used for logging and audit
job_run_id = safe_get_option(job_run_id_obj) or "Manual"

# Output the retrieved IDs for debugging and traceability
# This print statement helps in verifying that the correct IDs are being used in the ETL process.
print(f"Job ID: {job_id}, Job Run ID: {job_run_id}")

# Redefine widgets with resolved values for downstream cells (ensures consistency)
# This step ensures that the widgets reflect the actual job and run IDs for any subsequent operations.
dbutils.widgets.text("job_id", str(job_id)) 
dbutils.widgets.text("job_run_id", str(job_run_id))

# COMMAND ----------

# DBTITLE 1,Run the configuration Notebook
# MAGIC %run ../configuration/configs

# COMMAND ----------

# DBTITLE 1,Run the configuration Notebook
# MAGIC %run ../configuration/postgres

# COMMAND ----------

ca7jurisdiction_view=execute_select_PMTIN("select * from ca7jurisdiction")
ca7jurisdiction_view.createOrReplaceTempView("ca7jurisdiction_view")

# COMMAND ----------

# DBTITLE 1,ETL query for Non Owned Auto Data
log_info_to_file("[START] Extraction for NOA_data...")
logger.info("[START] Extraction for NOA_data...")
try:
    NOA_query = fetch_query_from_table('ca7noa')
    logger.info(f"NOA_query: {NOA_query}")
    log_info_to_file(f"NOA_query: {NOA_query}")
    NOA_data = eval(exec_select_landing)(NOA_query)
    NOA_data.createOrReplaceTempView("NOA_data")
    row_count = NOA_data.count()
    logger.info(f"NOA_data loaded with {row_count} rows.")
    log_info_to_file(f"NOA_data loaded with {row_count} rows.")
    logger.info(f"NOA_data schema: {NOA_data.schema}")
    log_info_to_file(f"NOA_data schema: {NOA_data.schema}")
    display(NOA_data)
    logger.info("[END] Extraction for NOA_data.")
    log_info_to_file("[END] Extraction for NOA_data.")
except Exception as e:
    logger.error(f"Error loading NOA_data: {e}", exc_info=True)
    log_info_to_file(f"Error loading NOA_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------

log_info_to_file("[START] Extraction for account_location...")
logger.info("[START] Extraction for account_location...")
location_query = "select * from account_location"
try:
    account_location = execute_select_Framework(location_query)
    account_location.createOrReplaceTempView("account_location_view")
    row_count = account_location.count()
    logger.info(f"account_location loaded with {row_count} rows.")
    log_info_to_file(f"account_location loaded with {row_count} rows.")
    logger.info(f"account_location schema: {account_location.schema}")
    log_info_to_file(f"account_location schema: {account_location.schema}")
    display(account_location)
    logger.info("[END] Extraction for account_location.")
    log_info_to_file("[END] Extraction for account_location.")
except Exception as e:
    logger.error(f"Error loading account_location: {e}", exc_info=True)
    log_info_to_file(f"Error loading account_location: {str(e)}")
    sys.exit(1)

# COMMAND ----------

log_info_to_file("[START] Join for noa_location_final...")
logger.info("[START] Join for noa_location_final...")
noa_location_query = '''select account_location_view.*,noa_data.* from account_location_view inner join noa_data on trim(noa_data.policynumber) = trim(account_location_view.pmt_payloadid) where vin='00000' and account_location_view.state=noa_data.statecode'''
try:
    logger.info(f"Executing query: {noa_location_query}")
    log_info_to_file(f"Executing query: {noa_location_query}")
    
    CA7NOA_location_final = spark.sql(noa_location_query)
    CA7NOA_location_final.createOrReplaceTempView("noa_location_final")
    
    row_count = CA7NOA_location_final.count()
    logger.info(f"CA7NOA_location_final loaded with {row_count} rows.")
    log_info_to_file(f"CA7NOA_location_final loaded with {row_count} rows.")
    
    logger.info(f"CA7NOA_location_final schema: {CA7NOA_location_final.schema}")
    log_info_to_file(f"CA7NOA_location_final schema: {CA7NOA_location_final.schema}")
    
    display(CA7NOA_location_final)
    logger.info("[END] Join for noa_location_final.")
    log_info_to_file("[END] Join for noa_location_final.")
except Exception as e:
    logger.error(f"Error loading CA7NOA_location_final: {e}", exc_info=True)
    log_info_to_file(f"Error loading CA7NOA_location_final: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,CA7NOA table Transformation
log_info_to_file("[START] Transformation for CA7NOA_final...")
logger.info("[START] Transformation for CA7NOA_final...")
CA7NOA_final_query = """
    SELECT DISTINCT 
           concat('CA7NOA:', trim(PolicyNumber), '-', StateCode) AS pmt_id,
           concat('CA7CAL_', trim(PolicyNumber)) AS pmt_parent,
           trim(CityCtyNmTx) AS garaginglocation,
           CASE WHEN trim(NumberOfEmployees) = 'IF ANY' THEN 0 ELSE CAST(trim(NumberOfEmployees) AS INTEGER) END AS numberofemployees,
           CASE WHEN trim(NumberOfPartners) = 'IF ANY' THEN 0 ELSE CAST(trim(NumberOfPartners) AS INTEGER) END AS numberofpartners,
           CASE WHEN trim(NumberOfVolunteers) = 'IF ANY' THEN 0 ELSE CAST(trim(NumberOfVolunteers) AS INTEGER) END AS numberofvolunteers,
           trim(StateCode) AS state,
           trim(noa_location_final.Territory) AS territory,
           trim(noa_location_final.ZipCode) AS zipcode,
           concat('PL:', trim(PolicyNumber), '-', Locationnum) AS garagelocationinternal,
           trim(PolicyNumber) AS pmt_payloadid,
           'usd' AS preferredcoveragecurrency,
           'usd' AS preferredsettlementcurrency,
           'Auto Services Partnership or LLC' AS nonownershiprisktype
    FROM noa_location_final
   INNER JOIN ca7jurisdiction_view
      ON trim(noa_location_final.PolicyNumber) = trim(ca7jurisdiction_view.pmt_payloadid)
      AND ca7jurisdiction_view.nonownedautowanted = 'Yes'
      AND trim(noa_location_final.StateCode) = trim(ca7jurisdiction_view.state)
"""
try:
    CA7NOA_final = spark.sql(CA7NOA_final_query)
    CA7NOA_final.createOrReplaceTempView("CA7NOA_final")
    row_count = CA7NOA_final.count()
    logger.info(f"CA7NOA_final loaded with {row_count} rows.")
    log_info_to_file(f"CA7NOA_final loaded with {row_count} rows.")
    logger.info(f"CA7NOA_final schema: {CA7NOA_final.schema}")
    log_info_to_file(f"CA7NOA_final schema: {CA7NOA_final.schema}")
    display(CA7NOA_final)
    logger.info("[END] Transformation for CA7NOA_final.")
    log_info_to_file("[END] Transformation for CA7NOA_final.")
except Exception as e:
    logger.error(f"Error loading CA7NOA_final: {e}", exc_info=True)
    log_info_to_file(f"Error loading CA7NOA_final: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Writing CA7NOA Table in PMTIN
try:
    row_count = CA7NOA_final.count()
    logger.info(f"[START] Writing {row_count} rows to table 'ca7noa' in PMTIN.")
    log_info_to_file(f"[START] Writing {row_count} rows to table 'ca7noa' in PMTIN.")
    logger.info(f"CA7NOA_final schema: {CA7NOA_final.schema}")
    log_info_to_file(f"CA7NOA_final schema: {CA7NOA_final.schema}")
    write_and_log_pmtin(
        CA7NOA_final,
        table_name="ca7noa",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
    )
    logger.info("[END] Successfully wrote CA7NOA_final to table 'ca7noa'.")
    log_info_to_file("[END] Successfully wrote CA7NOA_final to table 'ca7noa'.")
except Exception as e:
    logger.error(f"Error writing CA7NOA_final to table 'ca7noa'", exc_info=True)
    log_info_to_file(f"Error writing CA7NOA_final to table 'ca7noa': {str(e)}")
    sys.exit(1)

# COMMAND ----------

