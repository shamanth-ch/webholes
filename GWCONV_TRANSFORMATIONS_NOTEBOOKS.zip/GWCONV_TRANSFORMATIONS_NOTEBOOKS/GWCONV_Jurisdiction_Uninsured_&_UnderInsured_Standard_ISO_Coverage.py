# Databricks notebook source
# DBTITLE 1,Configuration
# MAGIC %run ../configuration/configs

# COMMAND ----------

# DBTITLE 1,Configuration
# MAGIC %run ../configuration/postgres

# COMMAND ----------

# DBTITLE 1,Logger
# Logger setup for tracking errors and process info in this notebook
import logging
import sys

logger = logging.getLogger('ca7jurcov_df')
logger.setLevel(logging.INFO)

# COMMAND ----------

# DBTITLE 1,ETL Query for Jurisdiction Standard ISO
ca7jurcov_query="""
SELECT 
/* ---------------------- */
/* CoPolicyPointer fields */
/* ---------------------- */
P."SystemAssignId",
P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
CAST(RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",
P."PolicyEffDt",

/* -------------------------------- */
/* ViewCurPic_CoPolicyDetail Fields */
/* -------------------------------- */
CoPolicyDetail."PredStateCd" AS "PredominantStateCode",

/* --------------------------- */
/* ViewCurPic_AuStInput fields */
/* --------------------------- */
AuStInput."StateCd",

/* -------------------------------------- */
/* ViewCurPic_AuStUMInput fields          */
/* -------------------------------------- */
/* LimitTypeUMUIM Info:                   */
/* 1 - CSL Incl PD                        */
/* 2 - CSL Excl PD                        */
/* 3 - Split Incl PD                      */
/* 4 - Split Excl PD                      */
/* -------------------------------------- */
AuStUMInput."TypeLimit" AS "LimitTypeUMUIM",
AuStUMInput."CombLimt" AS "UMCSL",
AuStUMInput."BI1Limit" AS "UMBILimit",
----AuStUMInput."BI2Limit" AS "BILimit"  /* This does not appear on the screen print from PwC but is in the xml */
AuStUMInput."PDLimit" AS "UMPDLimit",
AuStUMInput."UIMCombLimit" AS "UIMCSL",
AuStUMInput."UIMBI1Limit" AS "UIMBILimit",
----AuStUMInput."UIMBI2Limit" AS "UIMBI2Limit"  /* This does not appear on the screen print from PwC but is in the xml */
AuStUMInput."UIMPDLimit" AS "UIMPDLimt",
AuStUMInput."IndivCoupleInd" AS "IndividualNamedInsured",
AuStUMInput."MiscInfoInd" AS "UMMisc",
AuStUMInput."MiscInfo2Ind" AS "AddOnCov"

FROM Policy P1
INNER JOIN CoPolicyPointer P
   ON P."SystemAssignId" = P1."SourceSystemId"
INNER JOIN ViewCurPic_CoPolicyDetail CoPolicyDetail
   ON P."SystemAssignId" = CoPolicyDetail."SystemAssignId"
INNER JOIN ViewCurPic_AuStInput AuStInput
   ON P."SystemAssignId" = AuStInput."SystemAssignId"
INNER JOIN ViewCurPic_AuStUMInput AuStUMInput
   ON P."SystemAssignId" = AuStUMInput."SystemAssignId"
   AND AuStInput."StateCd" = AuStUMInput."StateCd"

WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
-- AND P1."LOB" IN ('AU', 'GR', 'TU')

order by "PolicyNumber", "StateCd"
"""
try:
  # Execute the query and create a temp view for downstream use
  ca7jurcov_df = eval(exec_select_landing)(ca7jurcov_query)
  ca7jurcov_df.createOrReplaceTempView("ca7jurcov_df")  # Create a temporary view for further processing
  print(ca7jurcov_df.count())  # Print the count of records retrieved
  display(ca7jurcov_df)  # Display the results
except Exception as e:
  # Log the error and exit if there is an issue loading the data
  logger.info("error ca7jurcov: {}".format(e)) 
  sys.exit(1)

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct concat(trim(UIMBILimit),'/',trim(UIMPDLimt)) AS Splitlimt from ca7jurcov_df 
# MAGIC where concat(trim(UIMBILimit),'/',trim(UIMPDLimt)) IN ('5000/10000','20000/40000','30000/65000','30000/60000','10000/20000','15000/30000','25000/50000','50000/500000','100000/100000','300000/500000','35000/70000','50000/100000','30000/500000','100000/300000','500000/500000','75000/150000','100000/500000','250000/500000','500000/1000000','1000000/1000000','300000/300000','1000000/2000000','200000/200000','100000/200000','2500000/5000000','200000/400000','5000000/10000000','300000/600000','2000000/2000000','2500000/2500000','5000000/5000000','10000000/10000000')
# MAGIC
# MAGIC
# MAGIC
# MAGIC -- select distinct concat(trim(UMPDLimit),'/',trim(UMBILimit)) AS Splitlimt from ca7jurcov_df 
# MAGIC -- where concat(trim(UMPDLimit),'/',trim(UMBILimit)) IN ('5000/10000','20000/40000','30000/65000','30000/60000','10000/20000','15000/30000','25000/50000','50000/500000','100000/100000','300000/500000','35000/70000','50000/100000','30000/500000','100000/300000','500000/500000','75000/150000','100000/500000','250000/500000','500000/1000000','1000000/1000000','300000/300000','1000000/2000000','200000/200000','100000/200000','2500000/5000000','200000/400000','5000000/10000000','300000/600000','2000000/2000000','2500000/2500000','5000000/5000000','10000000/10000000')

# COMMAND ----------

# DBTITLE 1,Jurisdiction Parent
jur_parent = execute_select_PMTIN("select * from ca7jurisdiction")
jur_parent.createOrReplaceTempView("jur_parent")
display(jur_parent)

# COMMAND ----------

# DBTITLE 1,Transformation of CA7StateCov for Jurisd Un-Under-Insured
Jurisd_Un_ca7statecov_query = """
SELECT DISTINCT
    concat('CA7StateCov:', trim(PolicyNumber),'_','CA7UninsuredMotoristPropertyDamage1',trim(StateCd)) AS pmt_id,
    concat('Jur:', trim(PolicyNumber), '-', trim(StateCd)) AS pmt_parent,
    'CA7UninsuredMotoristPropertyDamage1' AS CodeIdentifier,
    'usd' AS currency,
    trim(PolicyNumber) as pmt_payloadid
FROM ca7jurcov_df
WHERE trim(LimitTypeUMUIM) IS NOT NULL

UNION ALL

SELECT DISTINCT
    concat('CA7StateCov:', trim(PolicyNumber),'_','CA7UnderinsuredMotoristPropertyDamage1',trim(StateCd)) AS pmt_id,
    concat('Jur:', trim(PolicyNumber), '-', trim(StateCd)) AS pmt_parent,
    'CA7UnderinsuredMotoristPropertyDamage1' AS CodeIdentifier,
    'usd' AS currency,
    trim(PolicyNumber) as pmt_payloadid
FROM ca7jurcov_df
WHERE trim(LimitTypeUMUIM) IS NOT NULL

UNION ALL

SELECT DISTINCT
    concat('CA7StateCov:', trim(PolicyNumber),'_','CA7VehicleUninsuredMotoristPolicy',trim(StateCd)) AS pmt_id,
    concat('Jur:', trim(PolicyNumber), '-', trim(StateCd)) AS pmt_parent,
    'CA7VehicleUninsuredMotoristPolicy' AS CodeIdentifier,
    'usd' AS currency,
    trim(PolicyNumber) as pmt_payloadid
FROM ca7jurcov_df
WHERE trim(LimitTypeUMUIM) IS NOT NULL
AND (trim(UMCSL) IS NOT NULL OR trim(UMBILimit) IS NOT NULL OR trim(UMPDLimit) IS NOT NULL) 

UNION ALL

SELECT DISTINCT
    concat('CA7StateCov:', trim(PolicyNumber),'_','CA7VehicleUnderinsuredMotoristPolicy',trim(StateCd)) AS pmt_id,
    concat('Jur:', trim(PolicyNumber), '-', trim(StateCd)) AS pmt_parent,
    'CA7VehicleUnderinsuredMotoristPolicy' AS CodeIdentifier,
    'usd' AS currency,
    trim(PolicyNumber) as pmt_payloadid
FROM ca7jurcov_df
WHERE trim(LimitTypeUMUIM) IS NOT NULL
AND (trim(UMCSL) IS NOT NULL OR trim(UMBILimit) IS NOT NULL OR trim(UMPDLimit) IS NOT NULL)

"""

try:
    Jurisd_Un_ca7statecov_data = spark.sql(Jurisd_Un_ca7statecov_query)
    Jurisd_Un_ca7statecov_data.createOrReplaceTempView("Jurisd_Un_ca7statecov_data")
    print(Jurisd_Un_ca7statecov_data.count())
    display(Jurisd_Un_ca7statecov_data)
except Exception as e:
    logger.info("error Jurisd_Un_ca7statecov_data: {}".format(e))
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Writing CA7StateCov to PMTIN

# SQL to find mismatching pmt_parent, count null pmt_id, and check for duplicates for Jurisd_Un_ca7statecov_data
invalid_refs_sql = """
SELECT DISTINCT pmt_parent
FROM Jurisd_Un_ca7statecov_data
WHERE pmt_parent NOT IN (
  SELECT DISTINCT pmt_id FROM jur_parent
)
"""

null_pmt_id_sql = """
SELECT COUNT(*) as null_count
FROM Jurisd_Un_ca7statecov_data
WHERE pmt_id IS NULL
"""

duplicate_pmt_id_sql = """
SELECT pmt_id, COUNT(*) as cnt
FROM Jurisd_Un_ca7statecov_data
GROUP BY pmt_id
HAVING COUNT(*) > 1
"""

invalid_refs = spark.sql(invalid_refs_sql)
null_pmt_id_count = spark.sql(null_pmt_id_sql).collect()[0]['null_count']
duplicate_pmt_ids = spark.sql(duplicate_pmt_id_sql)

if invalid_refs.count() == 0 and null_pmt_id_count == 0 and duplicate_pmt_ids.count() == 0:
    logger.info('referential integrity checks passed')
    logger.info('No Null pmt_id values found')
    logger.info('No duplicate pmt_id values found')

    # Jurisd_Un_ca7statecov_data.write.jdbc(url=jdbc_url_pmtin, table='ca7statecov', mode='append', properties=properties)
else:
    if invalid_refs.count() > 0:
        logger.error("Referential integrity issue: Some pmt_parent values do not exist in jur_parent.")
        for row in invalid_refs.collect():
            logger.error(f"Invalid pmt_parent: {row.pmt_parent}")
    if null_pmt_id_count > 0:   
        logger.error(f"Null pmt_id values found in Jurisd_Un_ca7statecov_data: {null_pmt_id_count}")
    if duplicate_pmt_ids.count() > 0:
        logger.error("Duplicate pmt_id values found in Jurisd_Un_ca7statecov_data.")
        for row in duplicate_pmt_ids.collect():
            logger.error(f"Duplicate pmt_id: {row.pmt_id} with count: {row.cnt}")

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct StateCd from ca7jurcov_df
# MAGIC -- display(ca7jurcov_df.groupBy('UMMisc').count())

# COMMAND ----------

Covterm_Jurisd_Un_query = """
SELECT DISTINCT
    concat('CA7UninsuredMotoristPropertyDamage1:',trim(PolicyNumber),'_','CA7UninsuredMotoristPropertyDamageLimitText2') AS pmt_id,
    concat('CA7StateCov:', trim(PolicyNumber),'_','CA7UninsuredMotoristPropertyDamage1',trim(StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7UninsuredMotoristPropertyDamageLimitText2' AS CodeIdentifier,
    CASE WHEN trim(UMPDLimit) IS NOT NULL THEN trim(UMPDLimit) ELSE 'NoCoverage' END AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM ca7jurcov_df
WHERE trim(UMPDLimit) IS NOT NULL

UNION ALL

SELECT DISTINCT
    concat('CA7UnderinsuredMotoristPropertyDamage1:',trim(PolicyNumber),'_','CA7UnderinsuredMotoristPropertyDamageLimitText2') AS pmt_id,
    concat('CA7StateCov:', trim(PolicyNumber),'_','CA7UnderinsuredMotoristPropertyDamage1',trim(StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7UnderinsuredMotoristPropertyDamageLimitText2' AS CodeIdentifier,
    CASE WHEN trim(UIMPDLimt) IS NOT NULL THEN trim(UIMPDLimt) ELSE 'NoCoverage' END AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM ca7jurcov_df
WHERE trim(UIMPDLimt) IS NOT NULL

UNION ALL

SELECT DISTINCT
    concat('CA7VehicleUninsuredMotoristPolicy:',trim(PolicyNumber),'_','CA7CombinedSingleLimitText1') AS pmt_id,
    concat('CA7StateCov:', trim(PolicyNumber),'_','CA7VehicleUninsuredMotoristPolicy',trim(StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7CombinedSingleLimitText1' AS CodeIdentifier,
    CASE WHEN trim(UMCSL) IS NOT NULL THEN trim(UMCSL) ELSE 'NotApplicable' END AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM ca7jurcov_df
WHERE trim(UMCSL) IS NOT NULL

UNION ALL

SELECT DISTINCT
    concat('CA7VehicleUninsuredMotoristPolicy:',trim(PolicyNumber),'_','CA7SplitLimit1') AS pmt_id,
    concat('CA7StateCov:', trim(PolicyNumber),'_','CA7VehicleUninsuredMotoristPolicy',trim(StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7SplitLimit1' AS CodeIdentifier,
    CASE WHEN trim(UMBILimit) IS NOT NULL AND trim(UMPDLimit) IS NOT NULL THEN concat(trim(UMBILimit),'/',trim(UMPDLimit)) ELSE 'NotApplicable' END AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM ca7jurcov_df
WHERE trim(UMBILimit) IS NOT NULL AND trim(UMPDLimit) IS NOT NULL

UNION ALL

SELECT DISTINCT
    concat('CA7VehicleUninsuredMotoristPolicy:',trim(PolicyNumber),'_','CA7CovType22') AS pmt_id,
    concat('CA7StateCov:', trim(PolicyNumber),'_','CA7VehicleUninsuredMotoristPolicy',trim(StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7CovType22' AS CodeIdentifier,
    CASE 
        WHEN trim(UMCSL) IS NULL AND trim(UMBILimit) IS NULL AND trim(UMPDLimit) IS NULL AND trim(StateCd) IN ('AK','AL','AR','AZ','CA','CO','DE','FL','GA','HI','IA','IL','ID','IN','KS','KY','LA','MD','MO','MS','MT','NC','ND','NE','NJ','NM','NV','OH','OK','PA','PR','SD','TN','TX','UT','VA','WY') THEN 'NoCoverage'
         WHEN trim(UMCSL) IS NOT NULL AND trim(StateCd) IN ('HI','NM') THEN 'CombinedSingleLimitNon_stacked'
         WHEN trim(LimitTypeUMUIM) = '2' AND trim(StateCd) IN ('MS') THEN 'CombinedSingleLimit_BodilyInjuryNon_stacked'
         WHEN trim(LimitTypeUMUIM) = '1' AND trim(StateCd) IN ('MS') AND trim(UMCSL) IS NOT NULL THEN 'CombinedSingleLimit_BodilyInjuryandPropertyDamageNon_stacked'
         WHEN trim(LimitTypeUMUIM) = '1' AND trim(StateCd) IN ('AK','IN','TN','TX') AND trim(UMCSL) IS NOT NULL THEN 'CombinedSingleLimitWithPropertyDamage'
         WHEN trim(LimitTypeUMUIM) = '2' AND trim(StateCd) IN ('AK','IN','TN') AND trim(UMCSL) IS NOT NULL THEN 'CombinedSingleLimitWithoutPropertyDamage'
         WHEN trim(StateCd) IN ('NC') AND trim(UMCSL) IS NOT NULL AND trim(UIMCSL) IS NOT NULL THEN 'CombinedSingleLimitWithUnderinsuredMotoristsCoverage'
         WHEN trim(LimitTypeUMUIM) IN ('1','2') AND trim(StateCd) IN ('AL','AR','AZ','CA','CO','CT','DE','GA','IA','IL','ID','KS','KY','LA','MD','ME','MI','MO','MN','NH','ND','NE','NJ','NV','OH','OR','PR','RI','SD','UT','VT','VA','WY','WI','WV' ) AND trim(UMCSL) IS NOT NULL THEN 'CombinedSingleLimit'
         WHEN trim(UMCSL) IS NOT NULL AND trim(AddOnCov) = 'Y' THEN 'CombinedSingleLimit_AlternativeCoverage'
         WHEN trim(LimitTypeUMUIM) IN ('3','4') AND trim(StateCd) IN ('AK','AL','AR','AZ','CA','CO','CT','DE','GA','IA','IL','ID','IN','KS','KY','LA','MD','MI','ME','MO','MN','ND','NE','NH','NM','NV','OH','OR','PR','RI','SC','SD','TN','TX','UT','VA','VT','WI','WV','WY') AND trim(UMBILimit) IS NOT NULL AND trim(UMPDLimit) IS NOT NULL THEN 'SplitLimit'
         WHEN trim(StateCd) IN ('VA') AND trim(UMBILimit) IS NOT NULL AND trim(UMPDLimit) IS NOT NULL AND trim(AddOnCov) = 'Y' THEN 'SplitLimit_AlternativeCoverage'
         WHEN trim(StateCd) IN ('FL','MT','OK') AND trim(UMCSL) IS NOT NULL THEN 'CombinedSingleLimitNon_Stacked'
         WHEN trim(StateCd) IN ('PA') AND trim(UMCSL) IS NOT NULL THEN 'CombinedSingleLimitNonstacked'
         WHEN trim(LimitTypeUMUIM) = '3' AND trim(StateCd) IN ('FL','MS','OK','MT') AND trim(UMBILimit) IS NOT NULL AND trim(UMPDLimit) IS NOT NULL THEN 'SplitLimitNon_stacked'
         WHEN trim(StateCd) IN ('PA') AND trim(UMBILimit) IS NOT NULL AND trim(UMPDLimit) IS NOT NULL THEN 'SplitLimitNonstacked'
         WHEN trim(StateCd) IN ('DC') AND trim(UMCSL) IS NOT NULL AND trim(UIMCSL) IS NOT NULL THEN 'CombinedSingleLimitIncludesUnderinsuredMotoristsCoverage'
         WHEN trim(StateCd) IN ('DC','NC') AND trim(UMCSL) IS NOT NULL AND trim(UIMCSL) IS NULL THEN 'CombinedSingleLimitWithoutUnderinsuredMotoristsCoverage'
         WHEN trim(StateCd) IN ('NC') AND trim(UMBILimit) IS NOT NULL AND trim(UMPDLimit) IS NOT NULL AND trim(UIMBILimit) IS NOT NULL AND trim(UIMPDLimt) IS NOT NULL THEN 'SplitLimitWithUnderinsuredMotoristsCoverage'
         WHEN trim(StateCd) IN ('DC') AND trim(UMBILimit) IS NOT NULL AND trim(UMPDLimit) IS NOT NULL AND trim(UIMBILimit) IS NOT NULL AND trim(UIMPDLimt) IS NOT NULL THEN 'SplitLimitIncludesUnderinsuredMotoristsCoverage'
         WHEN trim(StateCd) IN ('DC','NC') AND trim(UMBILimit) IS NOT NULL AND trim(UMPDLimit) IS NOT NULL AND trim(UIMBILimit) IS NULL AND trim(UIMPDLimt) IS NULL THEN 'SplitLimitWithoutUnderinsuredMotoristsCoverage'
         WHEN trim(StateCd) IN ('NY') AND trim(UMCSL) IS NOT NULL AND trim(UMMisc) = 'Y' THEN 'CombinedSingleLimitSupplementaryCoverage'
         WHEN trim(StateCd) IN ('NY') AND trim(UMBILimit) IS NOT NULL AND trim(UMPDLimit) IS NOT NULL AND trim(UMMisc) = 'Y' THEN 'SplitLimitSupplementaryCoverage'
         WHEN trim(StateCd) IN ('NY') AND trim(LimitTypeUMUIM) IN ('3','4') AND concat(trim(UMBILimit),'/',trim(UMPDLimit)) = '25000/50000' THEN 'SplitLimitStatutoryCoverage'
     END AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM ca7jurcov_df

UNION ALL

SELECT DISTINCT
    concat('CA7VehicleUninsuredMotoristPolicy:',trim(PolicyNumber),'_','CA7UninsuredMotoristsCovTypeDescription') AS pmt_id,
    concat('CA7StateCov:', trim(PolicyNumber),'_','CA7VehicleUninsuredMotoristPolicy',trim(StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7UninsuredMotoristsCovTypeDescription' AS CodeIdentifier,
    CASE WHEN trim(UMMisc) = 'Y' THEN 'EconomicLossCoverage'
        WHEN trim(UMMisc) = 'N' THEN 'EconomicAndNoneconomicLossCoverage' END AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM ca7jurcov_df
WHERE trim(UMMisc) IN ('Y','N')

UNION ALL

SELECT DISTINCT
    concat('CA7VehicleUnderinsuredMotoristPolicy:',trim(PolicyNumber),'_','CA7CombinedSingleLimitText') AS pmt_id,
    concat('CA7StateCov:', trim(PolicyNumber),'_','CA7VehicleUnderinsuredMotoristPolicy',trim(StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7CombinedSingleLimitText' AS CodeIdentifier,
    trim(UIMCSL) AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM ca7jurcov_df
WHERE trim(UIMCSL) IS NOT NULL

UNION ALL

SELECT DISTINCT
    concat('CA7VehicleUnderinsuredMotoristPolicy:',trim(PolicyNumber),'_','CA7SplitLimit') AS pmt_id,
    concat('CA7StateCov:', trim(PolicyNumber),'_','CA7VehicleUnderinsuredMotoristPolicy',trim(StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7SplitLimit' AS CodeIdentifier,
    concat(trim(UIMBILimit),'/',trim(UIMPDLimt)) AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM ca7jurcov_df
WHERE concat(trim(UIMBILimit),'/',trim(UIMPDLimt)) IS NOT NULL

UNION ALL

SELECT DISTINCT
    concat('CA7VehicleUnderinsuredMotoristPolicy:',trim(PolicyNumber),'_','CA7CovType21') AS pmt_id,
    concat('CA7StateCov:', trim(PolicyNumber),'_','CA7VehicleUnderinsuredMotoristPolicy',trim(StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7CovType21' AS CodeIdentifier,
    CASE
        WHEN trim(StateCd) IN ('AR','AZ','HI','IA','ID','IL','IN','KY','MO','MT','ND','OH','PA','SC','SD','UT','WA','WI','WV') AND trim(UIMCSL) IS NULL AND trim(UIMBILimit) IS NULL AND trim(UIMPDLimt) IS NULL THEN 'NoCoverage'
        WHEN trim(StateCd) IN ('HI') AND trim(UIMCSL) IS NOT NULL THEN 'CombinedSingleLimitNon_Stacked'
        WHEN trim(StateCd) IN ('WA') AND trim(LimitTypeUMUIM) = '1' AND trim(UIMCSL) IS NOT NULL THEN 'CombinedSingleLimitWithPropertyDamage'
        WHEN trim(StateCd) IN ('WA') AND trim(LimitTypeUMUIM) = '2' AND trim(UIMCSL) IS NOT NULL THEN 'CombinedSingleLimitWithoutPropertyDamage'
        WHEN trim(StateCd) IN ('MT') AND trim(UIMCSL) IS NOT NULL THEN 'CombinedSingleLimitNon_Stacked'
        WHEN trim(StateCd) IN ('PA') AND trim(UIMCSL) IS NOT NULL THEN 'CombinedSingleLimitNonstacked'
        WHEN trim(StateCd) IN ('MT') AND trim(LimitTypeUMUIM) = '3' AND trim(UIMBILimit) IS NOT NULL AND trim(UIMPDLimt) IS NOT NULL THEN 'SplitLimitNon_stacked'
        WHEN trim(StateCd) IN ('MT') AND trim(LimitTypeUMUIM) = '4' AND trim(UIMBILimit) IS NOT NULL THEN 'SplitLimitNon_stacked'
        WHEN trim(StateCd) IN ('PA') AND trim(LimitTypeUMUIM) = '3' AND trim(UIMBILimit) IS NOT NULL AND trim(UIMPDLimt) IS NOT NULL THEN 'SplitLimitNonstacked'
        WHEN trim(StateCd) IN ('PA') AND trim(LimitTypeUMUIM) = '4' AND trim(UIMBILimit) IS NOT NULL THEN 'SplitLimitNonstacked'
        WHEN trim(StateCd) IN ('AR','AZ','CT','IA','ID','IL','IN','KY','MN','MO','ND','OH','SC','SD','UT','WI','WV') AND trim(UIMCSL) IS NOT NULL THEN 'CombinedSingleLimit'
        WHEN trim(StateCd) IN ('CT') AND trim(UIMCSL) IS NOT NULL AND trim(UMMisc) = 'Y' THEN 'CombinedSingleLimitConversionCoverage'
        WHEN trim(StateCd) IN ('AR','AZ','CT','IA','ID','IL','IN','KY','MN','MO','ND','OH','SC','SD','UT','WI','WV') AND trim(UIMBILimit) IS NOT NULL AND trim(UIMPDLimt) IS NOT NULL THEN 'SplitLimit'
        WHEN trim(StateCd) IN ('CT') AND trim(UMMisc) = 'Y' THEN 'SplitLimitConversionCoverage'
    END AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM ca7jurcov_df
"""

try:
    Covterm_Jurisd_Un_data = spark.sql(Covterm_Jurisd_Un_query)
    Covterm_Jurisd_Un_data.createOrReplaceTempView("Covterm_Jurisd_Un_data")
    print(Covterm_Jurisd_Un_data.count())
    display(Covterm_Jurisd_Un_data)
except Exception as e:
    logger.info("error Covterm_Jurisd_Un_data: {}".format(e))
    sys.exit(1)

# COMMAND ----------

