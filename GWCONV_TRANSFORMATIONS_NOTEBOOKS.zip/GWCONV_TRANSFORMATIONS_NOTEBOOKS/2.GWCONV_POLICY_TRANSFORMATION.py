# Databricks notebook source
# Cell 1: Initialize Logging
"""
- Introduced more granular log levels (e.g., `logger.error`, `logger.debug`).
- Logs are written to both the notebook console and to 'etl_logfile.log' in append mode.
"""
import logging

import sys




logger = logging.getLogger('Policy Details')
logger.setLevel(logging.INFO)  # Keep as INFO for general logs; use DEBUG for debugging

# Remove all handlers if already set (to avoid duplicate logs in notebook reruns)
if logger.hasHandlers():
    logger.handlers.clear()

# Console handler
handler = logging.StreamHandler()
handler.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s %(levelname)s: %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)

# File handler in append mode
log_file_handler = logging.FileHandler('etl_logfile.log', mode='a')
log_file_handler.setLevel(logging.DEBUG)
log_file_handler.setFormatter(formatter)
logger.addHandler(log_file_handler)

logger.info("Logging initialized in append mode. All log levels will be written to etl_logfile.log.")

# COMMAND ----------

# DBTITLE 1,Setup Job Context and Widgets

# Create widgets for job_id and job_run_id
dbutils.widgets.text("job_id", "")
dbutils.widgets.text("job_run_id", "")


# Get the current notebook context
context = dbutils.notebook.entry_point.getDbutils().notebook().getContext()



# Get the current notebook context
context = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
job_id_obj = context.jobId()          # Fetch jobId
job_run_id_obj = context.jobRunId()   # Fetch jobRunId

notebook_path = context.notebookPath().get() # Fetch the notebook path


notebook_name = notebook_path.split('/')[-1]   # Extract the notebook name from the path

def safe_get_option(option_obj):
    try:
        if option_obj.isDefined():
            return option_obj.get()
        else:
            return None
    except Exception:
        return None

# Use the safe_get_option to retrieve the values
job_id = safe_get_option(job_id_obj) or "Manual"    # Default to "Manual" if not found
job_run_id = safe_get_option(job_run_id_obj) or "Manual"

# Output the retrieved IDs
print(f"Job ID: {job_id}, Job Run ID: {job_run_id}")

# Define widgets for job_id and job_run_id
dbutils.widgets.text("job_id", str(job_id)) 
dbutils.widgets.text("job_run_id", str(job_run_id))

# COMMAND ----------

# DBTITLE 1,Run the configuration Notebook
# MAGIC %run ../configuration/configs

# COMMAND ----------

# DBTITLE 1,Run the configuration Notebook
# MAGIC %run ../configuration/postgres

# COMMAND ----------

# DBTITLE 1,ETL query for Policy Basic
policy_basic_query='''
WITH producing_soc_profitcenter AS (
  SELECT 
  
    g."groupcode",
    g."p",
    g."profitcentercode",
    g."soc",
    p."profitcenterdescription"
  FROM lkpgroupcodesnova g
  LEFT JOIN lkpProfitCenterNova p
    ON p."profitcentercode" = g."profitcentercode"
),
lkp_sid AS (
  SELECT "profitcentercode", "profitcenterdescription"
  FROM lkpProfitCenterNova
  WHERE "profitcentercode" = 'SID'
),
lkp_cid AS (
  SELECT "profitcentercode", "profitcenterdescription"
  FROM lkpProfitCenterNova
  WHERE "profitcentercode" = 'CID'
)
SELECT
 P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS PolicyNumber,
  cast(trim(p."PolicyId") || coalesce(trim(p."PolicySuffixCd"), '') AS varchar(8)) AS "AccountNumber",
  REGEXP_REPLACE(
      CoInsureName."InsuredNm",
      '[\x01-\x1F,\x92\x7C]',
      ' ',
      'g'
    ) AS AccountName,
  trim(p."PolicyId") AS "AccountFirstPart",
  p."PolicyEffDt" AS "PolicyEffectiveDate",
  cts."PolicyExpDt"   AS "PolicyExpirationDate",
  'Days' AS "PolicyTermType",
  cts."PolicyTermDaysCt" AS "TermNumber",
  p."QuoteSubmitDt" AS "WrittenDate",
  cpd."PredStateCd" AS "BaseState",
  cc."InsurerANmTx" AS "UnderwritingCompany",
  CASE 
    WHEN ci."AddrLine2Tx" IS NULL THEN
      ci."AddrLine1Tx" || ', ' || ci."CityNm" || ', ' ||
      ci."StateCd" || ' ' || ci."ZipCd"
    ELSE
      ci."AddrLine1Tx" || ', ' || ci."AddrLine2Tx" || ', ' ||
      ci."CityNm" || ', ' || ci."StateCd" || ' ' || ci."ZipCd"
  END AS "PolicyAddress",
  (cts."PolicyExpDt" + interval '30 days')::date AS "DateQuoteNeeded",
  cts."TermPremAmt" AS "EstimatedPremium",
  cpd."GroupCd" AS "ProgramGroupCode",
  CASE
    WHEN pmi."MarketSegmentCd" = 'OAR'
      THEN 'OAR ORSIU Alternative Risk'
    WHEN cpd."GroupCd" IS NULL AND pmi."MarketSegmentCd" = 'SMU'
      THEN sid."profitcentercode" || ' ' || sid."profitcenterdescription"
    WHEN cpd."GroupCd" IN ('B094', 'C177')
      THEN sid."profitcentercode" || ' ' || sid."profitcenterdescription"
    WHEN cpd."GroupCd" IS NULL AND pmi."MarketSegmentCd" IN ('CMU','RMS')
      THEN cid."profitcentercode" || ' ' || cid."profitcenterdescription"
    WHEN cpd."GroupCd" LIKE 'T%' AND pmi."MarketSegmentCd" IN ('CMU','RMS')
      THEN cid."profitcentercode" || ' ' || cid."profitcenterdescription"
    WHEN soc."groupcode" IS NULL
      THEN 'PMA Companies'
    ELSE soc."profitcentercode" || ' ' || soc."profitcenterdescription"
  END AS "ProfitCenter",
  soc."soc" AS "SOC",
  ci."WorkPhoneNo" AS "WorkPhone",
  NULL::text AS "FaxPhone",
  ci."EmailAddrTx" AS "EmailAddress1",
  NULL::text AS "EmailAddress2",
  bi."BusDescTx"    AS description_of_business,
  ci."CountryCd" AS "Country",
  ci."AddrLine1Tx" AS "Address1",
  ci."AddrLine2Tx" AS "Address2",
  ci."AddrLine3Tx" AS "Address3",
  ci."CityNm" AS "City",
  ci."CountyNm" AS "County",
  ci."StateCd" AS "State",
  ci."ZipCd" AS "ZipCode",
  bi."NAICCd" AS "IndustryCode",
  NULL::text AS "AddressType",
  coalesce(trim(p."PolicySuffixCd"), ' ')  AS subaccountnumber_ext,
  NULL::text AS "Description",
  ci."FEINId" AS "FEIN",
  'PD Conversion' AS "InputSource",
  cpd."GroupCd" AS groupcode,
  bi."NAICCd"        AS industry_code,
  pr."ProducerId" AS producer_code,
cc."AuCommPct" as AppliedCommision_Ext,
  cc."CommAmt" as FlatCommissionAmount_Ext
FROM Policy p1
JOIN CoPolicyPointer p ON p."SystemAssignId" = p1."SourceSystemId"
JOIN viewcurpic_coinsuredname CoInsureName ON p."SystemAssignId" = CoInsureName."SystemAssignId"
JOIN ViewCurPic_CoTransactionSummary cts ON cts."SystemAssignId" = p."SystemAssignId"
JOIN ViewCurPic_CoPolicyDetail cpd ON cpd."SystemAssignId" = p."SystemAssignId"
JOIN ViewCurPic_CoProducer pr ON pr."SystemAssignId" = p."SystemAssignId"
JOIN ViewCurPic_CoInsuredInfo ci ON ci."SystemAssignId" = p."SystemAssignId"
JOIN ViewCurPic_CoPMIndicatorInfo pmi ON pmi."SystemAssignId" = p."SystemAssignId"
JOIN ViewCurPic_CoBusinessInfo bi ON bi."SystemAssignId" = p."SystemAssignId"
LEFT JOIN producing_soc_profitcenter soc
  ON soc."groupcode" = cpd."GroupCd"
LEFT JOIN CoCertCommonInfo cc
  ON cc."SystemAssignId" = p."SystemAssignId"
LEFT JOIN lkp_sid sid
  ON pmi."MarketSegmentCd" = 'SMU'
LEFT JOIN lkp_cid cid
  ON pmi."MarketSegmentCd" IN ('CMU','RMS')
WHERE p1."PolicyStatus" IN ('INFORCE','FUTURE')
  --AND p1."LOB" IN ('AU','GR','TU')
ORDER BY substring(p."PolicyPrefixCd" from 1 for 2),
         p1."PolicyEffDt",
         p1."PolicyNumber"
'''
try:
   # policy_basic_query = fetch_query_from_table('policy_details')
    policy_basic = eval(exec_select_landing)(policy_basic_query)
    policy_basic.createOrReplaceTempView("policy_basic")
    row_count = policy_basic.count()
    display(policy_basic)
    logger.info(f"policy_basic loaded with {row_count} rows")
except Exception as e:
    logger.error("Error executing policy_basic query.", exc_info=True)
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,ETL query forRatemode FormID PCA 03 01
Ratemode_FormID_query = """

-- Sprint5_Line – Standard - Liability and MedPay Coverage Limits Deductible
-- CTE to Check if Form# PCA 0301 Exists
SELECT "PolicyNumber","DoesFormPCA0301Exist" FROM (
WITH FormCheckPCA0301 AS (
    SELECT AUSelectedForm."SystemAssignId", AUSelectedForm."StateCd"
    FROM ViewCurPic_AUSelectedForm AUSelectedForm
    WHERE AUSelectedForm."FormId" IN ('PCA 03 01')
)
 
SELECT 
    -- CoPolicyPointer fields
    P."SystemAssignId",
    P1."LOB",
    P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
    CAST(RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",
 
    -- CoBusinessInfo fields
    CoBusinessInfo."BusTypeTx" AS "BusinessType",
 
    -- AuPolInput fields
    AuPolInput."LiabSymbolLst" AS "LiabilitySymbol",
    AuPolInput."LiabLimitTypeCd" AS "LiabilityLimitTypeCode",
    AuPolInput."CSLLiabLimit" AS "LiabilityLimit",
    AuPolInput."BI1Limit" AS "BI1Limit",
    AuPolInput."BI2Limit" AS "BI2Limit",
    AuPolInput."PDLimit" AS "PDLimit",
    AuPolInput."LiabDedTypeCd" AS "LiabilityDeductionTypeCode",
    AuPolInput."LiabDedAmt" AS "LiabilityDeductible",
    AuPolInput."MedPaySymbolLst" AS "MedPaySymbol",
    AuPolInput."PredMedPayLimit" AS "MedPayLimit",
 
    -- DoesFormPCA0301Exist
    CASE WHEN FormCheckPCA0301."SystemAssignId" IS NOT NULL THEN 'Y' ELSE 'N' END AS "DoesFormPCA0301Exist"
--    FormCheckPCA0301."SystemAssignId"
 
FROM Policy P1
INNER JOIN CoPolicyPointer P
    ON P."SystemAssignId" = P1."SourceSystemId"
INNER JOIN ViewCurPic_CoBusinessInfo CoBusinessInfo
    ON P."SystemAssignId" = CoBusinessInfo."SystemAssignId"
INNER JOIN ViewCurPic_AuPolInput AuPolInput
    ON P."SystemAssignId" = AuPolInput."SystemAssignId"
LEFT JOIN FormCheckPCA0301
    ON P."SystemAssignId" = FormCheckPCA0301."SystemAssignId"
 
WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
-- AND P1."LOB" IN ('AU', 'GR', 'TU')
 
ORDER BY AuPolInput."BI1Limit" DESC
)
"""

try:
    Ratemode_FormID_data = eval(exec_select_landing)(Ratemode_FormID_query)
    Ratemode_FormID_data.createOrReplaceTempView("Ratemode_FormID_data")
    print(Ratemode_FormID_data.count())
    display(Ratemode_FormID_data)
    logger.info(f"Ratemode_FormID_data loaded with {row_count} rows")
except Exception as e:
    logger.error("Error executing Ratemode_FormID_data query.", exc_info=True)
    sys.exit(1)


# COMMAND ----------

# DBTITLE 1,ETL query for Account Basic
account_basic_query = '''
-- CTE: producing_soc_profitcenter
--   Joins group codes with profit center descriptions for later enrichment
WITH producing_soc_profitcenter AS (
  SELECT 
    g."groupcode",  -- Group code from the group codes table
    g."p",          -- Additional field from the group codes table
    g."profitcentercode",  -- Profit center code from the group codes table
    g."soc",        -- SOC code from the group codes table
    p."profitcenterdescription"  -- Description of the profit center from the lookup table
  FROM lkpgroupcodesnova g
  LEFT JOIN lkpProfitCenterNova p
    ON p."profitcentercode" = g."profitcentercode"  -- Join to get descriptions for profit centers
),
-- CTE: lkp_sid and lkp_cid
--   Lookup tables for special profit center codes (SID, CID) used in business rules
lkp_sid AS (
  SELECT "profitcentercode", "profitcenterdescription"
  FROM lkpProfitCenterNova
  WHERE "profitcentercode" = 'SID'  -- Filter for SID profit center code
),
lkp_cid AS (
  SELECT "profitcentercode", "profitcenterdescription"
  FROM lkpProfitCenterNova
  WHERE "profitcentercode" = 'CID'  -- Filter for CID profit center code
)
SELECT DISTINCT
    RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS account_number,
    REGEXP_REPLACE(
      CoInsureName."InsuredNm",
      '[\x01-\x1F,\x92|]',
      ' '
    ) AS account_name,
    CoInsuredInfo."WorkPhoneNo"    AS work_phone,
    NULL                           AS fax_phone,
    CoInsuredInfo."EmailAddrTx"    AS email_address1,
    NULL                           AS email_address2,
    CoInsuredInfo."CountryCd"      AS country,
    CoInsuredInfo."AddrLine1Tx"    AS address1,
    CoInsuredInfo."AddrLine2Tx"    AS address2,
    CoInsuredInfo."AddrLine3Tx"    AS address3,
    CoInsuredInfo."CityNm"         AS city,
    CoInsuredInfo."CountyNm"       AS county,
    CoInsuredInfo."StateCd"        AS state,
    CoInsuredInfo."ZipCd"          AS zip_code,
    NULL                           AS address_type,
    NULL                           AS description,
    CoInsuredInfo."FEINId"         AS fein,
    NULL                           AS first_name,
    NULL                           AS last_name,
    CoBusinessInfo."BusDescTx"     AS business_operation_description,
    CoBusinessInfo."BusTypeCd"     AS account_organization_type,
    CoBusinessInfo."NAICCd"        AS industry_code,
    'Active'                       AS account_status,
    CoBusinessInfo."BusDescTx"     AS description_of_business,
    NULL                           AS organization,
    CoProducer."ProducerId"         AS producer_code,
    'en_US'                        AS primary_language,
    NULL                           AS year_business_started,
    'Company'                      AS account_holder_contact_type,
    cpd."GroupCd" AS groupcode,
  

    CASE
      WHEN pmi."MarketSegmentCd" = 'OAR'
        THEN 'OAR ORSIU Alternative Risk'
      WHEN cpd."GroupCd" IS NULL AND pmi."MarketSegmentCd" = 'SMU'
        THEN sid."profitcentercode" || ' ' || sid."profitcenterdescription"
      WHEN cpd."GroupCd" IN ('B094', 'C177')
        THEN sid."profitcentercode" || ' ' || sid."profitcenterdescription"
      WHEN cpd."GroupCd" IS NULL AND pmi."MarketSegmentCd" IN ('CMU','RMS')
        THEN cid."profitcentercode" || ' ' || cid."profitcenterdescription"
      WHEN cpd."GroupCd" LIKE 'T%' AND pmi."MarketSegmentCd" IN ('CMU','RMS')
        THEN cid."profitcentercode" || ' ' || cid."profitcenterdescription"
      WHEN soc."groupcode" IS NULL
        THEN 'PMA Companies'
      ELSE soc."profitcentercode" || ' ' || soc."profitcenterdescription"
    END AS "ProfitCenter",
    soc."soc" AS "SOC"
FROM policy P1
JOIN copolicypointer P
  ON P."SystemAssignId" = P1."SourceSystemId"
JOIN viewcurpic_coinsuredname CoInsureName
  ON P."SystemAssignId" = CoInsureName."SystemAssignId"
JOIN viewcurpic_coinsuredinfo CoInsuredInfo
  ON P."SystemAssignId" = CoInsuredInfo."SystemAssignId"
LEFT JOIN viewcurpic_coproducer CoProducer
  ON P."SystemAssignId" = CoProducer."SystemAssignId"
LEFT JOIN viewcurpic_cobusinessinfo CoBusinessInfo
  ON P."SystemAssignId" = CoBusinessInfo."SystemAssignId"
JOIN ViewCurPic_CoPMIndicatorInfo pmi ON pmi."SystemAssignId" = p."SystemAssignId"
JOIN ViewCurPic_CoPolicyDetail cpd ON cpd."SystemAssignId" = p."SystemAssignId"
LEFT JOIN lkp_sid sid
  ON pmi."MarketSegmentCd" = 'SMU'
LEFT JOIN lkp_cid cid
  ON pmi."MarketSegmentCd" IN ('CMU','RMS')
LEFT JOIN producing_soc_profitcenter soc
  ON soc."groupcode" = cpd."GroupCd"
WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
  AND P1."LOB" IN ('AU','GR','TU')'''
try:
    #account_basic_query = fetch_query_from_table('account_details')
    account_basic = eval(exec_select_landing)(account_basic_query)
    account_basic.createOrReplaceTempView("account_basic")
    row_count = account_basic.count()
    logger.info(f"account_basic loaded with {row_count} rows")
except Exception as e:
    logger.error("Error executing account_basic query.", exc_info=True)
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,ETL query for Additional_Name_Insured
try:
    ANI_query = fetch_query_from_table("ani_details")
    ANI_DF = eval(exec_select_landing)(ANI_query)
    ANI_DF.createOrReplaceTempView("ani_basic")
    row_count = ANI_DF.count()
    logger.info(f"ANI_DF loaded with {row_count} rows")
except Exception as e:
    logger.error(f"Error executing ANI query.", exc_info=True)
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Deduplicate Account Basic with custom ranking
# Deduplicate Account_Holder_Location with custom ranking
z = spark.sql("""
    SELECT *
    FROM (
        SELECT *,
               ROW_NUMBER() OVER (PARTITION BY REGEXP_REPLACE(account_number, '[^0-9]', '') ORDER BY account_number) AS row_num
        FROM account_basic
    ) AS subquery
    WHERE row_num = 1
    """)
z.cache()
z.createOrReplaceTempView("account_basic_1")
display(z)

# COMMAND ----------

# DBTITLE 1,Joining Policy_Basic & Account_Basic to extract all the Schemas
query="""select a.account_number,a.zip_code,p.accountname,a.work_phone,a.account_organization_type, p.*,r.DoesFormPCA0301Exist from policy_basic p  inner join account_basic_1 a on REGEXP_REPLACE(p.accountnumber, '[^0-9]', '') = REGEXP_REPLACE(a.account_number, '[^0-9]', '')
inner join Ratemode_FormID_data r on p.policynumber = r.PolicyNumber
"""
account_policy_basic=spark.sql(query)
account_policy_basic.createOrReplaceTempView("account_policy_basic")
account_policy_basic.cache()
display(account_policy_basic)
logger.info(f"account_policy_basic loaded with {account_policy_basic.count()} rows")

# COMMAND ----------

# DBTITLE 1,Reading the TYPELIST table
typelist_query = """
SELECT *
FROM typelist"""
try:
    typelist = eval(exec_select_framework)(typelist_query)
    typelist.createOrReplaceTempView("typelist")
    row_count = typelist.count()
    logger.info(f"typelist loaded with {row_count} rows")
except Exception as e:
    logger.info(f"error loading typelist: {e}")
    sys.exit(1)

# COMMAND ----------

organization_typelist=execute_select_Framework("select * from organization_typelist")
organization_typelist.createOrReplaceTempView("organization_typelist")
display( organization_typelist)

# COMMAND ----------

organization_query='''
select DISTINCT 
CONCAT('Acct:', TRIM(ahl.policynumber)) AS PMT_ID,  -- Unique account identifier for PMTIN
trim(ot.Name) as name,
trim(ahl.policynumber) as pmt_payloadid

from account_policy_basic ahl
LEFT JOIN organization_typelist ot
ON trim(ahl.producer_code)= trim(ot.BrokerNumber_Ext)
'''
try:
    organization_df = spark.sql(organization_query)  # Execute the SQL query to transform organization data
    organization_df.createOrReplaceTempView("organization_final")  # Create a temporary view for further processing
    display(organization_df)  # Display the transformed organization data for validation
except Exception as e:
    # Error handling: log and halt if organization transformation fails
    logger.info(f"Error loading organization_final: {e}")  # Log the error message for debugging
    sys.exit(1)  # Exit the program with an error status to indicate failure


# COMMAND ----------


logger = get_etl_logger('Account_Holders_Locations')
# Cell Purpose: Write the transformed Account table to the PMTIN database.
# Business Context: This step persists the cleaned and enriched Account data for downstream insurance processing and reporting.

try:
    # Attempt to write the DataFrame to the specified table
    write_and_log_pmtin(
      organization_df,
        table_name="organization",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
    )
    # Log success message if the write operation is successful
    logger.info("Successfully wrote Account_Holder_Locations to table 'account'.")
except Exception as e:
    # Log and halt if the write operation fails, as this is a critical ETL output
    logger.error(f"Error writing Account_Holder_Locations to table 'account'", exc_info=True)
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,PNI Account table Transformation
# Create a new DataFrame for PNI Account
Account_query = """
    SELECT DISTINCT
        concat("Acct:" , trim(policynumber)) AS pmt_id,
        trim(account_number) as accountnumber,
        substr(MAX(CASE WHEN typelist.typelist = 'AccountOrgType' AND typelist.description = account_policy_basic.account_organization_type THEN typelist.code END),1,22) as accountorgtype,
        'Active' as accountstatus,
        description_of_business as busopsdesc,
        'usd' as preferredcoveragecurrency,
        'usd' as preferredsettlementcurrency,
        'en_US' as primarylanguage,
        'en_US' as primarylocale,
        substr(MAX(CASE WHEN typelist.typelist = 'SOCType_Ext' AND typelist.codevalue = account_policy_basic.SOC THEN typelist.code END),1,12)  as producingsoctype_ext,
        trim(concat("IC:" , policynumber)) as industrycode,
        concat("Acctloc:" , trim(policynumber)) AS primarylocation,
        trim(policynumber) AS pmt_payloadid
    FROM account_policy_basic
    LEFT JOIN typelist
        ON  (typelist.codevalue = account_policy_basic.SOC AND typelist.typelist = 'SOCType_Ext') OR
    (typelist.description = account_policy_basic.account_organization_type AND typelist.typelist = 'AccountOrgType')
    GROUP BY 
        account_number,
        description_of_business,
        policynumber
    ORDER BY accountnumber
"""

#  Execute the query
try:
    account_df = spark.sql(Account_query)
    account_df.createOrReplaceTempView("account_final")
    # display(account_df)
    logger.info(f"account_df loaded with {account_df.count()} rows")
except Exception as e:
    logger.info(f"Error loading account_final: {e}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,PNI Address table Transformation
# Create a new DataFrame for Address table
Address_query = """
    SELECT DISTINCT trim(concat("Addr:" , policynumber)) AS pmt_id,
           address1 AS addressline1,
           address2 AS addressline2,
           'business' AS addresstype,
           FALSE AS batchgeocode,
           trim(city) AS city,
           'US' AS country,
           trim(county) AS county,
           FALSE AS manualaddressind_ext,
           trim(zip_code) AS postalcode,
           'none' AS geocodestatus,
           trim(state) AS state,
           'unverified' AS verificationstatus_gc,
           trim(policynumber) AS pmt_payloadid
    FROM account_policy_basic
"""

# Execute the query
try:
    address_df = spark.sql(Address_query)
    address_df.createOrReplaceTempView("address_final")
    # display(address_df)
    logger.info(f"address_df loaded with {address_df.count()} rows")
except Exception as e:
    logger.info(f"Error loading address_final: {e}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Writing PNI Address Table in PMTIN
# Cell 4: Write to PMT_IN Table
"""
Issue:
- The write function does not handle cases when the DataFrame is empty.
- Success or failure of the write operation isn't logged.

Change:
- Add guards for empty datasets and log the write operation.
"""
try:
        write_and_log_pmtin(
            address_df,
            table_name="address",
            job_id=job_id,
            job_run_id=job_run_id,
            notebook_name=notebook_name,
            truncate=False
        )
        logger.info("Successfully wrote Account_Holder_Locations to table 'address'.")
except Exception as e:
        logger.error(f"Error writing Account_Holder_Locations to table 'address'", exc_info=True)
        sys.exit(1)

# COMMAND ----------

# DBTITLE 1,PNI Company table Transformation
#  Create a new DataFrame for Company_main table
Company_main_query = """
    SELECT DISTINCT
        trim(concat("Com:" , trim(policynumber), " : ", monotonically_increasing_id())) AS pmt_id,
        1 AS accountholdercount,
        substr(trim(EmailAddress1),1,60) AS emailaddress1,
 CASE 
            WHEN instr(accountname, 'DBA') > 0 THEN 
trim(substr(regexp_replace(regexp_replace(substr(accountname, 1, instr(accountname, 'DBA') - 2), '^[ :]+', ''), '[\r\\n]', ''), 1, 60))
            ELSE trim(substr(regexp_replace(regexp_replace(accountname, '[\r\\n]', ''), '^[ :]+', ''), 1, 60))
        END AS name,
        'usd' AS preferredcurrency,
        'usd' AS preferredsettlementcurrency,
        substr(concat(trim(Account_number), name,':Com'), 1,64) AS publicid,
        trim(concat(substr(fein, 1, 2), '-', substr(fein, 3)))  AS taxid,
        'unconfirmed' AS taxstatus,
        trim(work_phone) AS workphone,
        'work' as primaryphone,
        'US' as workphonecountry,
        null as dbaaka_ext,
      
        CAST(NULL AS DECIMAL(4,1)) AS withholdingrate,
        trim(concat("Addr:" , trim(policynumber))) AS primaryaddress,
        trim(policynumber) AS pmt_payloadid
    FROM account_policy_basic
    ORDER BY pmt_payloadid
"""

# Company table DBA insertion
Company_dba_Query = """
    SELECT DISTINCT
        trim(concat("Com_DBA:" , trim(policynumber), " : ", monotonically_increasing_id())) AS pmt_id,
        1 AS accountholdercount,
        substr(trim(EmailAddress1),1,60) AS emailaddress1,
        CASE 
            WHEN instr(accountname, 'DBA') > 0 THEN 
                trim(substr(regexp_replace(regexp_replace(substr(accountname, instr(accountname, 'DBA') + 3), '^[ :]+', ''), '[\r\\n]', ''), 1, 60))
              ELSE trim(substr(regexp_replace(regexp_replace(accountname, '[\r\\n]', ''), '^[ :]+', ''), 1, 60))
        END AS name,
        'usd' AS preferredcurrency,
        'usd' AS preferredsettlementcurrency,
        substr(concat(trim(Account_number), name,':Com'), 1,64) AS publicid,
        trim(concat(substr(fein, 1, 2), '-', substr(fein, 3)))  AS taxid,
        'unconfirmed' AS taxstatus,
        trim(work_phone) AS workphone,
        CAST(NULL AS DECIMAL(4,1)) AS withholdingrate,
        'work' as primaryphone,
        'dba' as dbaaka_ext,
        'US' as workphonecountry,
        trim(concat("Addr:" , trim(policynumber))) AS primaryaddress,
        trim(policynumber) AS pmt_payloadid
    FROM account_policy_basic
    WHERE instr(accountname, 'DBA') > 0
    ORDER BY pmt_payloadid
"""

try:
    Company_main_df = spark.sql(Company_main_query)
    Company_dba_df = spark.sql(Company_dba_Query)
    Company_df = Company_main_df.unionByName(Company_dba_df)
    Company_df.createOrReplaceTempView("company_df_final")
    main_count = Company_main_df.count()
    dba_count = Company_dba_df.count()
    total_count = Company_df.count()
    logger.info(f"Company_main_df loaded with {main_count} rows")
    logger.info(f"Company_dba_df loaded with {dba_count} rows")
    logger.info(f"Company_df loaded with {total_count} rows")
except Exception as e:
    logger.info(f"Error loading company_df_final: {e}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Writing PNI Company Table in PMTIN
# Cell 4: Write to PMT_IN Table
"""
Issue:
- The write function does not handle cases when the DataFrame is empty.
- Success or failure of the write operation isn't logged.

Change:
- Add guards for empty datasets and log the write operation.
"""
Company_df.cache()
try:
        write_and_log_pmtin(
            Company_df,
            table_name="company",
            job_id=job_id,
            job_run_id=job_run_id,
            notebook_name=notebook_name,
            truncate=False
        )
        logger.info("Successfully wrote Account_Holder_Locations to table 'account'.")
except Exception as e:
        logger.error(f"Error writing Account_Holder_Locations to table 'account'", exc_info=True)
        sys.exit(1)

# COMMAND ----------

# DBTITLE 1,PNI Officialid table Transformation
#reading company table from postgre sql
company_query="""
SELECT *
FROM company"""
try:
  company_table=eval(exec_select_pmtin)(company_query)
  company_table.createOrReplaceTempView("company_table")
#   display(company_table)
except Exception as e:
  logger.info("error loading company_table: {}".format(e)) 
  sys.exit(1) 

# Create a new DataFrame for OfficialID table
officialid_query = """
    SELECT DISTINCT trim(concat("OI:" , policynumber)) AS pmt_id,
           c.pmt_id AS pmt_parent,
           'Company' AS pmt_parent_type,
           'FEIN' AS officialidtype,
           trim(concat(substr(fein, 1, 2), '-', substr(fein, 3))) AS officialidvalue,
           trim(policynumber) AS pmt_payloadid
    FROM account_policy_basic
    LEFT JOIN (SELECT * FROM company_table where pmt_id not like '%DBA%') c
    ON trim(account_policy_basic.policynumber) = c.pmt_payloadid
"""

#  Execute the query
try:
    officialid_df = spark.sql(officialid_query)
    officialid_df.createOrReplaceTempView("officialid_final")
    # display(officialid_df)
    logger.info(f"officialid_df loaded with {officialid_df.count()} rows")
except Exception as e:
    logger.info(f"Error loading officialid_final: {e}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Writing PNI Officalid Table in PMTIN
# Cell 4: Write to PMT_IN Table
"""
Issue:
- The write function does not handle cases when the DataFrame is empty.
- Success or failure of the write operation isn't logged.

Change:
- Add guards for empty datasets and log the write operation.
"""
try:
        write_and_log_pmtin(
            officialid_df,
            table_name="officialid",
            job_id=job_id,
            job_run_id=job_run_id,
            notebook_name=notebook_name,
            truncate=False
        )
        logger.info("Successfully wrote Account_Holder_Locations to table 'officialid'.")
except Exception as e:
        logger.error(f"Error writing Account_Holder_Locations to table 'officialid'", exc_info=True)
        sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Gathering All the location data
try:
  location_query=fetch_query_from_table('location_details')
  location_basic=eval(exec_select_landing)(location_query)
  location_basic.createOrReplaceTempView("location_basic")
  # display(location_basic)
  logger.info(f"location_basic loaded with {location_basic.count()} rows")
except Exception as e:
  logger.error(f"Error writing Account_Holder_Locations to table 'officialid'", exc_info=True)
  sys.exit(1) 

# COMMAND ----------

# DBTITLE 1,Developing table for location
# Execute the query
try:
    AccountLocation_query=fetch_query_from_table('accountlocation_details')
    AccountLocations_df = spark.sql(AccountLocation_query)
    AccountLocations_df.createOrReplaceTempView("AccountLocation_final")
    # display(AccountLocations_df)
    logger.info(f"AccountLocations_df loaded with {AccountLocations_df.count()} rows")
except Exception as e:
    logger.info(f"Error loading AccontLocation_final: {e}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Writing a location table in PMTIN
eval(exec_cmd_framework)('truncate table public.account_location')
AccountLocations_df.write.jdbc(url=jdbc_url_framework, table='account_location', mode='append', properties=properties)

# COMMAND ----------

# DBTITLE 1,Selecting the required column for PNI Accountlocation
AccountLocations_final_query="""
select distinct 
    pmt_id,
    pmt_parent,
    cast(nonspecific as boolean) as nonspecific,
    addressline1,
    addressline2,
    addresstype,
    batchgeocode,
    city,
    country,
    county,
    cast(locationnum as integer) as locationnum,
    'none' as geocodestatus,
    postalcode,
    state,
    pmt_payloadid 
from AccountLocation_final
"""
try:
    AccountLocations_final_df = spark.sql(AccountLocations_final_query)
    AccountLocations_final_df.createOrReplaceTempView("AccountLocation_final_without_vin")
    # display(AccountLocations_final_df)
    logger.info(f"AccountLocations_final_df loaded with {AccountLocations_final_df.count()} rows")
except Exception as e:
    logger.info(f"Error loading AccountLocation_final_without_vin: {e}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Writing PNI Accountlocation Table in PMTIN

"""
Issue:
- The write function does not handle cases when the DataFrame is empty.
- Success or failure of the write operation isn't logged.

Change:
- Add guards for empty datasets and log the write operation.
"""
try:
        write_and_log_pmtin(
            AccountLocations_final_df,
            table_name="accountlocation",
            job_id=job_id,
            job_run_id=job_run_id,
            notebook_name=notebook_name,
            truncate=False
        )
        logger.info("Successfully wrote Account_Holder_Locations to table 'accountlocation'.")
except Exception as e:
        logger.error(f"Error writing Account_Holder_Locations to table 'accountlocation'", exc_info=True)
        sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Adding location to Account table
query="""SELECT DISTINCT
         a.pmt_id,
        accountnumber,
        accountorgtype,
        accountstatus,
        busopsdesc,
        preferredcoveragecurrency,
        preferredsettlementcurrency,
        primarylanguage,
        primarylocale,
        producingsoctype_ext,
        industrycode,
        b.pmt_id AS primarylocation,
        a.pmt_payloadid
from account_final a
inner join (select * from AccountLocation_final where vin = '') b on trim(a.pmt_payloadid)=trim(b.pmt_payloadid)"""

try:
    query_account_final = spark.sql(query)
    query_account_final.createOrReplaceTempView("query_account_final")
    # display(query_account_final)
    logger.info(f"query_account_final loaded with {query_account_final.count()} rows")
except Exception as e:
    logger.info(f"Error loading query_account_final: {e}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Writing PNI Account Table in PMTIN
# Cell 4: Write to PMT_IN Table
"""
Issue:
- The write function does not handle cases when the DataFrame is empty.
- Success or failure of the write operation isn't logged.

Change:
- Add guards for empty datasets and log the write operation.
"""
try:
        write_and_log_pmtin(
            account_df,
            table_name="account",
            job_id=job_id,
            job_run_id=job_run_id,
            notebook_name=notebook_name,
            truncate=False
        )
        logger.info("Successfully wrote account_df to table 'account'.")
except Exception as e:
        logger.error(f"Error writing Account_Holder_Locations to table 'account'", exc_info=True)
        sys.exit(1)

# COMMAND ----------

# DBTITLE 1,PNI Accountcontact table Transformation
#reading company table from postgre sql
company_query="""
SELECT *
FROM company"""
try:
  company_table=eval(exec_select_pmtin)(company_query)
  company_table.createOrReplaceTempView("company_table")
#   display(company_table)
except Exception as e:
  logger.info("error loading company_table: {}".format(e)) 
  sys.exit(1) 

# Create a new DataFrame with the same schema
AccountContact_query = """
    SELECT DISTINCT CASE 
                        WHEN c.pmt_id like '%DBA%' THEN trim(concat("Acctcon_DBA:", trim(policynumber)))
                        ELSE trim(concat("Acctcon:", trim(policynumber)))
                    END AS pmt_id,
           trim(concat("Acct:", policynumber)) AS pmt_parent,
           c.pmt_id AS contact,
           'Company' AS contact_type,
           trim(policynumber) AS pmt_payloadid
    FROM account_policy_basic
    LEFT JOIN company_table c
    ON trim(account_policy_basic.policynumber) = c.pmt_payloadid
"""

#  Execute the query
try:
    AccountContact_df = spark.sql(AccountContact_query)
    AccountContact_df.createOrReplaceTempView("AccountContact_final")
    # display(AccountContact_df)
    logger.info(f"AccountContact_df loaded with {AccountContact_df.count()} rows")
except Exception as e:
    logger.info(f"Error loading AccontContact_final: {e}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Writing PNI Accountcontact Table in PMTIN

"""
Issue:
- The write function does not handle cases when the DataFrame is empty.
- Success or failure of the write operation isn't logged.

Change:
- Add guards for empty datasets and log the write operation.
"""
try:
        write_and_log_pmtin(
            AccountContact_df,
            table_name="accountcontact",
            job_id=job_id,
            job_run_id=job_run_id,
            notebook_name=notebook_name,
            truncate=False
        )
        logger.info("Successfully wrote account_df to table 'accountcontact'.")
except Exception as e:
        logger.error(f"Error writing Account_Holder_Locations to table 'accountcontact'", exc_info=True)
        sys.exit(1)

# COMMAND ----------

# DBTITLE 1,PNI pmt_payloadstatus table Transformation
#  Create a new DataFrame for PMT_PayloadStatus table
PMT_PayloadStatus = """
    SELECT DISTINCT trim(policynumber) AS pmt_payloadid,
            trim(account_number) AS pmt_groupid,
           'NEW' AS pmt_status
    FROM account_policy_basic
"""

try:
    PMT_PayloadStatus_df = spark.sql(PMT_PayloadStatus)
    PMT_PayloadStatus_df.createOrReplaceTempView("PMT_PayloadStatus_final")
    # display(PMT_PayloadStatus_df)
    logger.info(f"PMT_PayloadStatus_df loaded with {PMT_PayloadStatus_df.count()} rows")
except Exception as e:
    logger.info(f"Error loading PMT_PayloadStatus_final: {e}")

# COMMAND ----------

# DBTITLE 1,Writing PNI PMT_PayloadStatus Table in PMTIN
"""
Issue:
- The write function does not handle cases when the DataFrame is empty.
- Success or failure of the write operation isn't logged.

Change:
- Add guards for empty datasets and log the write operation.
"""
try:
    write_and_log_pmtin(
        PMT_PayloadStatus_df,
        table_name="pmt_payloadstatus",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name,
        truncate=False
    )
    logger.info("Successfully wrote PMT_PayloadStatus_df to table 'pmt_payloadstatus'.")
except Exception as e:
    logger.error(f"Error writing PMT_PayloadStatus_df to table 'pmt_payloadstatus'", exc_info=True)
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,PNI ProducerCode table Transformation
# Create a new DataFrame for Producercode table
ProducerCode = """
    SELECT DISTINCT trim(concat("PC:", trim(policynumber))) AS pmt_id,
           CASE WHEN groupcode is null then '100-002541' ELSE groupcode END AS code,
           trim(policynumber) AS pmt_payloadid
    FROM account_policy_basic
"""

try:
    ProducerCode_df = spark.sql(ProducerCode)
    ProducerCode_df.createOrReplaceTempView("ProducerCode_final")
    # display(ProducerCode_df)
    logger.info(f"ProducerCode_df loaded with {ProducerCode_df.count()} rows")
except Exception as e:
    logger.info(f"Error loading ProducerCode_final: {e}")

# COMMAND ----------

# DBTITLE 1,Writing PNI ProducerCode Table in PMTIN
try:
    write_and_log_pmtin(
        ProducerCode_df,
        table_name="producercode",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name,
        truncate=False
    )
    logger.info("Successfully wrote ProducerCode_df to table 'producercode'.")
except Exception as e:
    logger.error(f"Error writing ProducerCode_df to table 'producercode'", exc_info=True)
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,PNI Accountproducercode table Transformation
# Create a new DataFrame AccountProducerCode table
AccountProducerCode = """
    SELECT DISTINCT concat("APC:", trim(policynumber)) AS pmt_id,
           concat("Acct:", trim(policynumber)) AS pmt_parent,
           concat("PC:", trim(policynumber)) AS producercode,
           trim(policynumber) AS pmt_payloadid
    FROM account_policy_basic
"""

try:
    AccountProducerCode_df = spark.sql(AccountProducerCode)
    AccountProducerCode_df.createOrReplaceTempView("AccountProducerCode_final")
    # display(AccountProducerCode_df)
    logger.info(f"AccountProducerCode_df loaded with {AccountProducerCode_df.count()} rows")
except Exception as e:
    logger.info(f"Error loading AccountProducerCode_final: {e}")

# COMMAND ----------

# DBTITLE 1,Writing PNI Accountproducercode Table in PMTIN
try:
    write_and_log_pmtin(
        AccountProducerCode_df,
        table_name="accountproducercode",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name,
        truncate=False
    )
    logger.info("Successfully wrote AccountProducerCode_df to table 'accountproducercode'.")
except Exception as e:
    logger.error(f"Error writing AccountProducerCode_df to table 'accountproducercode'", exc_info=True)
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,PNI IndustryCode table Transformation
# Create a new DataFrame for IndustryCode table
IndustryCode = """
    SELECT DISTINCT concat("IC:", trim(policynumber)) AS pmt_id,
           case when industry_code is null then '0782' else industry_code end AS code,
           trim(policynumber) AS pmt_payloadid
    FROM account_policy_basic
"""

try:
    IndustryCode_df = spark.sql(IndustryCode)
    IndustryCode_df.createOrReplaceTempView("IndustryCode_final")
    display(IndustryCode_df)
    logger.info(f"IndustryCode_df loaded with {IndustryCode_df.count()} rows")
except Exception as e:
    logger.info(f"Error loading IndustryCode_final: {e}")

# COMMAND ----------

# DBTITLE 1,Writing PNI Industrycode Table in PMTIN
try:
    write_and_log_pmtin(
        IndustryCode_df,
        table_name="industrycode",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name,
        truncate=False
    )
    logger.info("Successfully wrote IndustryCode_df to table 'industrycode'.")
except Exception as e:
    logger.error(f"Error writing IndustryCode_df to table 'industrycode'", exc_info=True)
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Nameinsured table Transformation
# Create a new DataFrame for NamedInsured table
NamedInsured = """
    SELECT DISTINCT
        concat("NI:" , trim(policynumber)) AS pmt_id,
        trim(concat('Acctcon:', trim(policynumber))) AS pmt_parent,
        concat('IC:', trim(policynumber)) AS industrycode,
        trim(PolicyNumber) AS pmt_payloadid
        FROM account_policy_basic
    """

try:
    NamedInsured_df = spark.sql(NamedInsured)
    NamedInsured_df.createOrReplaceTempView("NamedInsured_final")
    # display(NamedInsured_df)
    logger.info(f"NamedInsured_df loaded with {NamedInsured_df.count()} rows")
except Exception as e:
    logger.info(f"Error loading NamedInsured_final: {e}")

# COMMAND ----------

# DBTITLE 1,Writing NamedInsured Table in PMTIN
try:
    write_and_log_pmtin(
        NamedInsured_df,
        table_name="namedinsured",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
       
    )
    logger.info("Successfully wrote NamedInsured_df to table 'namedinsured'.")
except Exception as e:
    logger.error(f"Error writing NamedInsured_df to table 'namedinsured'", exc_info=True)
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Effectivedatedfields table Transformation
# Create a new DataFrame for effectivedatedfields Table
effectivedatedfields = """
    SELECT DISTINCT
        concat("EDF:" , trim(PolicyNumber)) AS pmt_id,
        concat("PP:" , trim(PolicyNumber)) AS PMT_Parent,
        --concat("PL:" , trim(PolicyNumber)) AS PrimaryLocation,
        --b.pmt_id as PrimaryLocation,
        concat("PL:" , trim(b.pmt_payloadid),'-',b.locationnum) AS PrimaryLocation,
        concat("PPNI:" , trim(PolicyNumber)) AS PrimaryNamedInsured,
        concat("PC:" , trim(PolicyNumber)) AS ProducerCode,
        trim(PolicyNumber) AS PMT_PayloadId

        FROM account_policy_basic a 
        inner join (select * from AccountLocation_final where vin='') b on trim(a.PolicyNumber)=trim(b.pmt_payloadid)

    """

try:
    effectivedatedfields_df = spark.sql(effectivedatedfields)
    effectivedatedfields_df.createOrReplaceTempView("effectivedatedfields_final")
    # display(effectivedatedfields_df)
    logger.info(f"effectivedatedfields_df loaded with {effectivedatedfields_df.count()} rows")
except Exception as e:
    logger.info(f"Error loading effectivedatedfields_final: {e}")

# COMMAND ----------

# DBTITLE 1,Writing Effectivedatedfields Table in PMTIN
try:
    write_and_log_pmtin(
        effectivedatedfields_df,
        table_name="effectivedatedfields",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
        
    )
    logger.info("Successfully wrote effectivedatedfields_df to table 'effectivedatedfields'.")
except Exception as e:
    logger.error(f"Error writing effectivedatedfields_df to table 'effectivedatedfields'", exc_info=True)
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Policy table Transformation
# Create a new DataFrame for policy Table
policy = """
    SELECT DISTINCT
        concat("Policy:" , trim(PolicyNumber)) AS pmt_id,
        'Synced' AS appeventsyncstatus,
        'en_US' AS primarylanguage,
        'en_US' AS primarylocale,
        'CA7CommAuto' AS productcode,
        concat("Acct:" , trim(policynumber)) AS account,
        concat("PC:" , trim(policynumber)) AS producercodeofservice,
        trim(PolicyNumber) AS pmt_payloadid
        FROM account_policy_basic
    """

try:
    policy_df = spark.sql(policy)
    policy_df.createOrReplaceTempView("policy_final")
    # display(policy_df)
    logger.info(f"policy_df loaded with {policy_df.count()} rows")
except Exception as e:
    logger.info(f"Error loading policy_final: {e}")

# COMMAND ----------

# DBTITLE 1,Writing Policy Table in PMTIN
try:
    write_and_log_pmtin(
        policy_df,
        table_name="policy",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name)
    
    logger.info("Successfully wrote policy_df to table 'policy'.")
except Exception as e:
    logger.error(f"Error writing policy_df to table 'policy'", exc_info=True)
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Policyaddress table Transformation
# Create a new DataFrame for policyaddress Table
policyaddress = """
    SELECT DISTINCT
        concat("Policy Addr:" , trim(PolicyNumber)) AS pmt_id,
        concat("EDF:" , trim(PolicyNumber)) AS pmt_parent,
        trim(concat("Addr:" , policynumber)) AS Address,
        trim(PolicyNumber) AS pmt_payloadid
        FROM account_policy_basic
    """
try:
    policyaddress_df = spark.sql(policyaddress)
    policyaddress_df.createOrReplaceTempView("policyaddress_final")
    # display(policyaddress_df)
    logger.info(f"policyaddress_df loaded with {policyaddress_df.count()} rows")
except Exception as e:
    logger.info(f"Error loading policyaddress_final: {e}")

# COMMAND ----------

# DBTITLE 1,Writing Policyaddress Table in PMTIN
try:
    write_and_log_pmtin(
        policyaddress_df,
        table_name="policyaddress",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
        
    )
    logger.info("Successfully wrote policyaddress_df to table 'policyaddress'.")
except Exception as e:
    logger.error(f"Error writing policyaddress_df to table 'policyaddress'", exc_info=True)
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Policylocation table Transformation
# Create a new DataFrame for policylocation Table
policylocation = """
    SELECT DISTINCT
        concat("PL:", trim(pmt_payloadid),'-',locationnum) AS pmt_id,
        concat("PP:", trim(pmt_payloadid)) AS pmt_parent,
        'none' AS geocodestatus,
        locationnum,
        'unverified' AS verificationstatus_gc,
        pmt_id AS accountlocation,
        concat('IC:', trim(pmt_payloadid)) AS industrycode,
        pmt_payloadid
    FROM AccountLocation_final
"""
try:
    policylocation_df = spark.sql(policylocation)
    policylocation_df.createOrReplaceTempView("policylocation_final")
    # display(policylocation_df)
    logger.info(f"policylocation_df loaded with {policylocation_df.count()} rows")
except Exception as e:
    logger.info(f"Error loading policylocation_final: {e}")

# COMMAND ----------

# DBTITLE 1,Writing Policylocation Table in PMTIN
try:
    write_and_log_pmtin(
        policylocation_df,
        table_name="policylocation",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
        
    )
    logger.info("Successfully wrote policylocation_df to table 'policylocation'.")
except Exception as e:
    logger.error(f"Error writing policylocation_df to table 'policylocation'", exc_info=True)
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,UWCompany table Transformation
#  Create a new DataFrame for UWCompany Table
UWCompany = """
    SELECT DISTINCT
        concat("UW:" , trim(PolicyNumber)) AS pmt_id,
        'PMAIC' as code,
        trim(PolicyNumber) AS pmt_payloadid
    FROM account_policy_basic 
    """
try:
    UWCompany = spark.sql(UWCompany)
    UWCompany.createOrReplaceTempView("UWCompany_final")
    # display(UWCompany)
    logger.info(f"UWCompany loaded with {UWCompany.count()} rows")
except Exception as e:
    logger.info(f"Error loading UWCompany_final: {e}")

# COMMAND ----------

# DBTITLE 1,Writing UWCompany Table in PMTIN
try:
    write_and_log_pmtin(
        UWCompany,
        table_name="UWCompany",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
     
    )
    logger.info("Successfully wrote UWCompany to table 'UWCompany'.")
except Exception as e:
    logger.error(f"Error writing UWCompany to table 'UWCompany'", exc_info=True)
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Policyperiod table Transformation
# Load ANI_df
ANI_DF.createOrReplaceTempView("ANI_DF")

#  Create a new DataFrame for policyperiod Table
policyperiod = """
      SELECT 
        concat('PP:', trim(apb.PolicyNumber)) AS pmt_id,
        concat('Policy:', trim(apb.PolicyNumber)) AS pmt_parent,

        CASE
            WHEN ani.PolicyNumber IS NOT NULL AND apb.accountname LIKE '%DBA%' THEN 
                'Policy included DBA name - Review and Confirm Names converted correctly\\nPolicy included P0913 Review and Update Additional Named Insureds'
            WHEN ani.PolicyNumber IS NOT NULL AND apb.accountname NOT LIKE '%DBA%' THEN 
                'Policy included P0913 Review and Update Additional Named Insureds'
            WHEN ani.PolicyNumber IS NULL AND apb.accountname LIKE '%DBA%' THEN 
                'Policy included DBA name - Review and Confirm Names converted correctly'
            ELSE NULL
        END AS activitynotification_ext,

        'Synced' AS appeventsyncstatus,
        apb.BaseState AS basestate,
        'PMAIC' AS claimhandlingentity_ext,
        'usd' AS depositamount_cur,

        -- Normalize PolicyExpirationDate and calculate editeffectivedate
        CAST(date_sub(CAST(apb.PolicyExpirationDate AS DATE), 365) AS TIMESTAMP) AS editeffectivedate,

        -- Remove commas from EstimatedPremium and safely cast to decimal
        CAST(regexp_replace(trim(coalesce(apb.EstimatedPremium, '0')), ',', '') AS DECIMAL(18,2)) AS estimatedpremium_amt,
        'usd' AS estimatedpremium_cur,

        'PDConversion' AS inputsource_ext,
        'DefaultBilling' AS invoicingmethod,

        -- Normalize PolicyExpirationDate and calculate periodend/periodstart
        CAST(apb.PolicyExpirationDate AS TIMESTAMP) AS periodend,
        CAST(date_sub(CAST(apb.PolicyExpirationDate AS DATE), 365) AS TIMESTAMP) AS periodstart,

        -- Join with typelist for profitcenter and soc
        profitcenter.code AS profitcenter_ext,
        soc.code AS producingsoc_ext,

        TRUE AS renewalconversionflag_ext,

        'usd' AS totpremiumincovcurrencyrpt_cur,
        'usd' AS totalcostincovcurrencyrpt_cur,
        'usd' AS trancostincovcurrencyrpt_cur,

        concat('PC:' , trim(apb.policynumber)) AS producercodeofrecord,
        concat('UW:' , trim(apb.PolicyNumber)) AS uwcompany,
        trim(apb.PolicyNumber) AS pmt_payloadid,
        trim(apb.PolicyNumber) AS policynumber,

  CAST(SUBSTRING(apb.PolicyNumber,5,2) AS STRING)  AS specialdigits_ext,

        CAST(apb.subaccountnumber_ext AS STRING) AS subaccountnumber_ext,
    CASE WHEN trim(DoesFormPCA0301Exist) = 'Y' THEN 'AACRetro_Ext'
         ELSE 'AAFRetro_Ext'
    END AS ca7ratemode_ext

    FROM account_policy_basic apb
    LEFT JOIN ANI_DF ani
      ON trim(upper(apb.PolicyNumber)) = trim(upper(ani.PolicyNumber))

    -- Join with typelist for profitcenter
    LEFT JOIN (
      SELECT DISTINCT codevalue, code
      FROM typelist
      WHERE typelist = 'ProfitCenter_Ext'
    ) AS profitcenter
      ON profitcenter.codevalue = apb.ProfitCenter

    -- Join with typelist for soc
    LEFT JOIN (
      SELECT DISTINCT codevalue, code
      FROM typelist
      WHERE typelist = 'SOCType_Ext'
    ) AS soc
      ON soc.codevalue = apb.SOC
"""

try:
    policyperiod_df = spark.sql(policyperiod)
    policyperiod_df.createOrReplaceTempView("policyperiod_final")
    display(policyperiod_df)
    logger.info(f"policyperiod_df loaded with {policyperiod_df.count()} rows")
except Exception as e:
  
    logger.info(f"Error loading policyperiod_final: {e}")

# COMMAND ----------

# DBTITLE 1,Writing Policyperiod Table in PMTIN
try:
    write_and_log_pmtin(
        policyperiod_df,
        table_name="policyperiod",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
       
    )
    logger.info("Successfully wrote policyperiod_df to table 'policyperiod'.")
except Exception as e:
    logger.error(f"Error writing policyperiod_df to table 'policyperiod'", exc_info=True)
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Policyprinamedinsured table Transformation
#reading company table from postgre sql
company_query="""
SELECT *
FROM company"""
try:
  company_table=eval(exec_select_pmtin)(company_query)
  company_table.createOrReplaceTempView("company_table")
#   display(company_table)
except Exception as e:
  logger.info("error loading company_table: {}".format(e)) 
  sys.exit(1) 

#  Create a new DataFrame for policyprinamedinsured Table
policyprinamedinsured = """
    SELECT DISTINCT
        concat("PPNI:" , trim(PolicyNumber)) AS pmt_id,
        concat("PP:" , trim(PolicyNumber)) AS pmt_parent,
        cast(NULL as integer) AS seqnumber,
        concat("NI:" , trim(policynumber)) AS accountcontactrole,
        c.pmt_id AS contactdenorm,
        'NamedInsured' AS accountcontactRole_type,
        'Company' AS contactdenorm_type,
        trim(PolicyNumber) AS pmt_payloadid
    FROM account_policy_basic
    JOIN (select * from company_table where pmt_id not like '%DBA%') c ON trim(account_policy_basic.policynumber) = c.pmt_payloadid
    """

try:
    policyprinamedinsured_df = spark.sql(policyprinamedinsured)
    policyprinamedinsured_df.createOrReplaceTempView("policyprinamedinsured_final")
    # display(policyprinamedinsured_df)
    logger.info(f"policyprinamedinsured_df loaded with {policyprinamedinsured_df.count()} rows")
except Exception as e:
    logger.info(f"Error loading policyprinamedinsured_final: {e}")

# COMMAND ----------

# DBTITLE 1,Writing Policyprinamedinsured Table in PMTIN
try:
    write_and_log_pmtin(
        policyprinamedinsured_df,
        table_name="policyprinamedinsured",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
      
    )
    logger.info("Successfully wrote policyprinamedinsured_df to table 'policyprinamedinsured'.")
except Exception as e:
    logger.error(f"Error writing policyprinamedinsured_df to table 'policyprinamedinsured'", exc_info=True)
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Territorycode table Transformation
#  Create a new DataFrame for Territorycode Table
territorycode = """
    SELECT DISTINCT
        concat("TC:" , trim(PolicyNumber)) AS pmt_id,
        --concat("PL:" , trim(PolicyNumber)) AS pmt_parent,
        concat("PL:" , trim(b.pmt_payloadid),'-',b.locationnum) AS pmt_parent,
        'CA7Line' AS policylinepatterncode,
        trim(PolicyNumber) AS pmt_payloadid
    FROM account_policy_basic a
    inner join (select * from AccountLocation_final where vin='') b on trim(a.PolicyNumber)=trim(b.pmt_payloadid)
    """
try:
    territorycode_df = spark.sql(territorycode)
    territorycode_df.createOrReplaceTempView("territorycode_final")
    # display(territorycode_df)
    logger.info(f"territorycode_df loaded with {territorycode_df.count()} rows")
except Exception as e:
    logger.info(f"Error loading territorycode_final: {e}")

# COMMAND ----------

# DBTITLE 1,Writing Territorycode Table in PMTIN
try:
    write_and_log_pmtin(
        territorycode_df,
        table_name="territorycode",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
      
    )
    logger.info("Successfully wrote territorycode_df to table 'territorycode'.")
except Exception as e:
    logger.error(f"Error writing territorycode_df to table 'territorycode'", exc_info=True)
    sys.exit(1)

# COMMAND ----------

# MAGIC %md
# MAGIC ##                                    Policy DBA Tables

# COMMAND ----------

# DBTITLE 1,dbarole_sp table Transformation
#reading company table from postgre sql
accountcontact_query="""
SELECT *
FROM accountcontact"""
try:
  accountcontact_table=eval(exec_select_pmtin)(accountcontact_query)
  accountcontact_table.createOrReplaceTempView("accountcontact_table")
#   display(accountcontact_table)
except Exception as e:
  logger.info("error loading accountcontact_table: {}".format(e)) 
  sys.exit(1) 

#  Create a new DataFrame for dbarole_sp Table
dbarole_sp = """
    SELECT DISTINCT
        CASE WHEN z.pmt_id LIKE '%DBA%' THEN concat("DRSP_DBA:" , trim(policynumber))
            ELSE concat("DRSP:" , trim(policynumber))
        END AS pmt_id,
        z.pmt_id AS pmt_parent,
        FALSE AS primarydba,
        trim(PolicyNumber) AS pmt_payloadid 
    FROM account_policy_basic
    INNER JOIN (select * from accountcontact_table where pmt_id like '%DBA%') z ON trim(account_policy_basic.PolicyNumber) = z.pmt_payloadid
"""

try:
    dbarole_sp_df = spark.sql(dbarole_sp)
    dbarole_sp_df.createOrReplaceTempView("dbarole_sp_final")
    # display(dbarole_sp_df)
    logger.info(f"dbarole_sp_df loaded with {dbarole_sp_df.count()} rows")
except Exception as e:
    logger.info(f"Error loading dbarole_sp_final: {e}")

# COMMAND ----------

# DBTITLE 1,Writing dbarole_sp Table in PMTIN
try:
    write_and_log_pmtin(
        dbarole_sp_df,
        table_name="dbarole_sp",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
      
    )
    logger.info("Successfully wrote dbarole_sp_df to table 'dbarole_sp'.")
except Exception as e:
    logger.error(f"Error writing dbarole_sp_df to table 'dbarole_sp'", exc_info=True)
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Policydbarole_sp table Transformation
#reading company table from postgre sql
company_query="""
SELECT *
FROM company"""
try:
  company_table=eval(exec_select_pmtin)(company_query)
  company_table.createOrReplaceTempView("company_table")
#   display(company_table)
except Exception as e:
  logger.info("error loading company_table: {}".format(e)) 
  sys.exit(1) 

#  Create a new DataFrame for policydbarole_sp Table
policydbarole_sp = """
    SELECT DISTINCT
        CASE WHEN dbarole_sp_final.pmt_id LIKE '%DBA%' THEN concat("PDBSP_DBA:" , trim(policynumber))
            ELSE concat("PDBSP:" , trim(policynumber))
        END AS pmt_id,
        concat("PP:" , trim(PolicyNumber)) AS pmt_parent,
        FALSE AS primarydbainternal,
        dbarole_sp_final.pmt_id AS accountcontactrole,
        c.pmt_id AS contactdenorm,
        'DBARole_SP' AS accountcontactrole_type,
        'Company' AS contactdenorm_type,
        trim(PolicyNumber) AS pmt_payloadid         
    FROM account_policy_basic
    JOIN dbarole_sp_final ON trim(account_policy_basic.policynumber) = dbarole_sp_final.pmt_payloadid
    JOIN (select * from company_table where pmt_id like '%DBA%') c ON trim(account_policy_basic.policynumber) = c.pmt_payloadid
    """
try:
    policydbarole_sp_df = spark.sql(policydbarole_sp)
    policydbarole_sp_df.createOrReplaceTempView("policydbarole_sp_final")
    # display(policydbarole_sp_df)
    logger.info(f"policydbarole_sp_df loaded with {policydbarole_sp_df.count()} rows")
except Exception as e:
    logger.info(f"Error loading policydbarole_sp_final: {e}")

# COMMAND ----------

# DBTITLE 1,Writing Policydbarole_sp Table in PMTIN
try:
    write_and_log_pmtin(
        policydbarole_sp_df,
        table_name="policydbarole_sp",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
    
    )
    logger.info("Successfully wrote policydbarole_sp_df to table 'policydbarole_sp'.")
except Exception as e:
    logger.error(f"Error writing policydbarole_sp_df to table 'policydbarole_sp'", exc_info=True)
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Policycontactroledbarole_sp table Transformation
#  Create a new DataFrame for policycontactroledbarole_sp Table
policycontactroledbarole_sp = """
    SELECT DISTINCT
        concat("PCRDSP:" , trim(PolicyNumber)) AS pmt_id,
        concat("PPNI:" , trim(PolicyNumber)) AS pmt_parent,
        'PolicyPriNamedInsured' AS pmt_parent_type,
        policydbarole_sp_final.pmt_id AS policydbarole,
        trim(PolicyNumber) AS pmt_payloadid                 
    FROM account_policy_basic
    JOIN policydbarole_sp_final ON trim(account_policy_basic.policynumber) = policydbarole_sp_final.pmt_payloadid
"""
try:
    policycontactroledbarole_sp_df = spark.sql(policycontactroledbarole_sp)
    policycontactroledbarole_sp_df.createOrReplaceTempView("policycontactroledbarole_sp_final")
    # display(policycontactroledbarole_sp_df)
    logger.info(f"policycontactroledbarole_sp_df loaded with {policycontactroledbarole_sp_df.count()} rows")
except Exception as e:
    logger.info(f"Error loading policycontactroledbarole_sp_final: {e}")

# COMMAND ----------

# DBTITLE 1,Writing Policycontactroledbarole_sp Table in PMTIN
try:
    write_and_log_pmtin(
        policycontactroledbarole_sp_df,
        table_name="policycontactroledbarole_sp",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
      
    )
    logger.info("Successfully wrote policycontactroledbarole_sp_df to table 'policycontactroledbarole_sp'.")
except Exception as e:
    logger.error(f"Error writing policycontactroledbarole_sp_df to table 'policycontactroledbarole_sp'", exc_info=True)
    sys.exit(1)

# COMMAND ----------

