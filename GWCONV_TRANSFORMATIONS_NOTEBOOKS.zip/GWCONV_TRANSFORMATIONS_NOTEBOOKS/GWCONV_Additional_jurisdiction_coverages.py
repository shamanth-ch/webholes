# Databricks notebook source
# MAGIC %run ../configuration/configs

# COMMAND ----------

# MAGIC %run ../configuration/postgres

# COMMAND ----------

/* -------------------------------------------------------------------------------------------------------------- */
/* Sprint 7 - On-Hook Coverage                                                                                    */
/* --------                                                                                                       */
/* Views used:                                                                                                    */
/* ViewCurPic_AuStInput, ViewCurPic_AuStGKLInput                                                                  */
/* -------------------------------------------------------------------------------------------------------------- */

select 
/* ---------------------- */
/* CoPolicyPointer fields */
/* ---------------------- */
P.SystemAssignId
,P1.LOB
,P.PolicyPrefixCd + ' ' + RTRIM(P.PolicyId) + ISNULL(RTRIM(P.PolicySuffixCd),' ') as PolicyNumber 
,CAST (RTRIM(P.PolicyID) + ISNULL(RTRIM(P.PolicySuffixCd),' ') AS VARCHAR(8)) AS AccountNumber

/* ----------------- */
/* AuPolInput fields */
/* ----------------- */
,AuPolInput.NAICCd AS NAICCode

/* ------------------------------------ */
/* ViewCurPic_AuStInput fields          */
/* ------------------------------------ */
,AuStInput.StateCd AS StateCode
,AuStInput.GKLAllPerDedInd AS AllPerilsDeductible

/* ------------------------------------ */
/* ViewCurPic_AuStGKLInput fields       */
/* ------------------------------------ */
,AuStGKLInput.CompLimit AS CompLimit
,AuStGKLInput.CompDed1Amt AS CompDeductible
,AuStGKLInput.SpecPerilsLimit AS SCLLimit
,AuStGKLInput.SpecPerilsDed1Amt AS SCLDeductible
,AuStGKLInput.CollLimit AS CollsionLimit
,AuStGKLInput.CollDedAmt AS CollsionDeductible
/* ------------------------------------ */
/* RatingBase info:                     */
/* Legal Liability = 1                  */
/* Direct Primary = 2                   */
/* Direct Excess = 3                    */
/* ------------------------------------ */
,AuStGKLInput.RatingBasisInd AS RatingBase


FROM [Garcdb_old_version].[RDODS].[Policy] P1 
INNER JOIN [GARCDB].[dbo].[CoPolicyPointer] P
   ON P.SystemAssignId = P1.SourceSystemId
INNER JOIN [GARCDB].[dbo].[ViewCurPic_AuPolInput] AuPolInput
   ON P.SystemAssignId = AUPolInput.SystemAssignId

/* -------------- */
/* Sprint 4 joins */
/* -------------- */
INNER JOIN [GARCDB].[dbo].[ViewCurPic_AuStInput] AuStInput
   ON P.SystemAssignId = AuStInput.SystemAssignId
INNER JOIN [GARCDB].[dbo].[ViewCurPic_AuStGKLInput] AuStGKLInput
   ON P.SystemAssignId = AuStGKLInput.SystemAssignId
   AND AuStInput.StateCd = AuStGKLInput.StateCd

WHERE P1.PolicyStatus IN ('INFORCE', 'FUTURE')
AND P1.LOB IN ('AU', 'GR', 'TU')

order by PolicyNumber, StateCode
