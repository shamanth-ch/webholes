# Databricks notebook source
# Cell 1: Initialize Logging
"""
- Introduced more granular log levels (e.g., `logger.error`, `logger.debug`).
- Logs are written to both the notebook console and to 'etl_logfile.log' in append mode.
"""
import logging
import sys

logger = logging.getLogger('CA7Jurisdiction')
logger.setLevel(logging.INFO)  # Keep as INFO for general logs; use DEBUG for debugging

# Remove all handlers if already set (to avoid duplicate logs in notebook reruns)
if logger.hasHandlers():
    logger.handlers.clear()

# Console handler
handler = logging.StreamHandler()
handler.setLevel(logging.DEBUG)  # Allow for detailed debugging at runtime
formatter = logging.Formatter('%(asctime)s %(levelname)s: %(message)s')  # Add consistent logging format
handler.setFormatter(formatter)
logger.addHandler(handler)

# File handler in append mode
log_file_handler = logging.FileHandler('etl_logfile.log', mode='a')
log_file_handler.setLevel(logging.INFO)
log_file_handler.setFormatter(formatter)
logger.addHandler(log_file_handler)

logger.info("Logging initialized in append mode. All log levels will be written to etl_logfile.log.")

# Function to log info messages to file
def log_info_to_file(message):
    logger.info(message)

# COMMAND ----------

# DBTITLE 1,Setup Job Context and Widgets

# Create widgets for job_id and job_run_id
dbutils.widgets.text("job_id", "")
dbutils.widgets.text("job_run_id", "")

# Get the current notebook context
context = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
job_id_obj = context.jobId()          # Fetch jobId
job_run_id_obj = context.jobRunId()   # Fetch jobRunId
notebook_path = context.notebookPath().get() # Fetch the notebook path
notebook_name = notebook_path.split('/')[-1]   # Extract the notebook name from the path

def safe_get_option(option_obj):
    try:
        if option_obj.isDefined():
            return option_obj.get()
        else:
            return None
    except Exception:
        return None

# Use the safe_get_option to retrieve the values
job_id = safe_get_option(job_id_obj) or "Manual"    # Default to "Manual" if not found
job_run_id = safe_get_option(job_run_id_obj) or "Manual"

# Output the retrieved IDs
print(f"Job ID: {job_id}, Job Run ID: {job_run_id}")
logger.info(f"Job context: job_id={job_id}, job_run_id={job_run_id}, notebook={notebook_name}")
log_info_to_file(f"Job context: job_id={job_id}, job_run_id={job_run_id}, notebook={notebook_name}")

# Define widgets for job_id and job_run_id
dbutils.widgets.text("job_id", str(job_id)) 
dbutils.widgets.text("job_run_id", str(job_run_id))

# COMMAND ----------

# DBTITLE 1,Run the configuration Notebook
# MAGIC %run ../configuration/configs

# COMMAND ----------

# DBTITLE 1,Run the configuration Notebook
# MAGIC %run ../configuration/postgres

# COMMAND ----------

# DBTITLE 1,ETL query for Jurisdition Data
log_info_to_file("[START] Extraction for ca7jurisdiction...")
logger.info("[START] Extraction for ca7jurisdiction...")
try:
    jurisdiction_query = fetch_query_from_table("ca7jurisdiction")
    logger.info(f"Fetched query for ca7jurisdiction: {jurisdiction_query}")
    log_info_to_file(f"Fetched query for ca7jurisdiction: {jurisdiction_query}")
    Jurisdiction_data = eval(exec_select_landing)(jurisdiction_query)
    Jurisdiction_data.createOrReplaceTempView("Jurisdiction_data")
    row_count = Jurisdiction_data.count()
    logger.info(f"Jurisdiction_data loaded with {row_count} rows.")
    log_info_to_file(f"Jurisdiction_data loaded with {row_count} rows.")
    logger.info(f"Jurisdiction_data schema: {Jurisdiction_data.schema}")
    log_info_to_file(f"Jurisdiction_data schema: {Jurisdiction_data.schema}")
    display(Jurisdiction_data)
    logger.info("[END] Extraction for ca7jurisdiction.")
    log_info_to_file("[END] Extraction for ca7jurisdiction.")
except Exception as e:
    logger.error("Error loading Jurisdiction_data:", exc_info=True)
    log_info_to_file(f"Error loading Jurisdiction_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Transformation of CA7Jurisdiction table
# Create a new DataFrame for the CA7Jurisdiction schema

logger.info("[START] Transformation for CA7Jurisdiction_final...")
log_info_to_file("[START] Transformation for CA7Jurisdiction_final...")
CA7Jurisdiction_final_query = """
        SELECT  DISTINCT
        concat('Jur:',trim(PolicyNumber),'-',trim(StateCode)) AS pmt_id,
        concat('CA7CAL_',trim(PolicyNumber)) AS pmt_parent,
        trim(ChiropracticInd) AS AdditionalChiropracticTreatments,
        CASE WHEN trim(BrdAddlPIPInd) = 'Y' THEN 'Yes' ELSE 'No' END AS BroadenedPIPCoverage,
        CASE WHEN trim(CollCostHireAmt) IS NOT NULL OR trim(OTCCostHireAmt) IS NOT NULL THEN 'Yes' ELSE 'No' END AS HiredAuto,
        CASE WHEN trim(NOwnEmplCnt) IS NOT NULL THEN 'Yes' ELSE 'No' END AS NonOwnedAutoWanted,
        CASE WHEN trim(PIPMisc2) IS NOT NULL THEN 'Yes' ELSE 'No' END AS DeathBenefits,
        trim(ExcessAttCareInd) AS ExcessAttendantCareCoverageLimits,
        trim(FuneralExpenseInd) AS FuneralExpenseBenefitsLimit,
        CASE WHEN trim(PIPMisc4) IS NOT NULL THEN 'Yes' ELSE 'No' END AS IncreasedLimitsOfMedicalExpenseBenefits,
        --trim() AS MedicalExpenseBenefitsLimit,
        trim(MedExpenseLimit) AS PIPMedicalExpensesLimits,
        --PersonalInjuryProtectionCoverageType,
        'Less than 300' AS Population,
        trim(StateCode) AS State,
        trim(Territory) AS Territory,
        CASE WHEN trim(PIPMisc3) = 'N' THEN 'Yes' ELSE 'No' END AS WageLossBenefits,
        CASE WHEN trim(PIPMisc1) IS NOT NULL THEN 'Yes' ELSE 'No' END AS WaiverOfPersonalInjuryProtectionBenefits,
        trim(ZipCode) AS ZipCode,
        trim(PolicyNumber) AS PMT_PayloadId,

        'No' AS AlternativeExpensesBenefits,
        'No' AS RiskAnalyzerWanted,
        'No' AS SymbolRating,
        'No' AS CoordinationOfBenefitsExcessPIP,
        'No' AS EngageInTruckingOperations,
        'No' AS ExclusionOfPIPMedicalExpenses,
        'No' AS ExperienceRatingModificationPhysicalDamageApplies,
        'No' AS FleetAutoPolicy,
        'No' AS GovernmentalSubdivisions,
        'No' AS MedicalExpenseAndOrIncomeLossBenefits,
        'No' AS PowerUnitsDesigToTowSuchTrailAreInsurForThesCoveUndeTheSamePoli,
        'usd' AS PreferredCoverageCurrency,
        'usd' AS PreferredSettlementCurrency,
        'No' AS PropertyDamageLiabilityCoverageBuyback,
        'No' AS RejectionOfPIPMedicalExpensesCoverage,
        'No' AS ScheduleRatingModificationApplies,
        'No' AS MedicalExpenseElimination,
        'No' AS OnlyCoversLessThan5EligiblePPTVehicles,
        'No Coverage' AS OptionalBasicEconomicLossCoverage,
        'No' AS VehicleMovedUnderWritOfAttachment          
    FROM Jurisdiction_data
"""
try:
    CA7Jurisdiction_final = spark.sql(CA7Jurisdiction_final_query)
    CA7Jurisdiction_final.createOrReplaceTempView("CA7Jurisdiction_final")
    row_count = CA7Jurisdiction_final.count()
    logger.info(f"CA7Jurisdiction_final loaded with {row_count} rows.")
    log_info_to_file(f"CA7Jurisdiction_final loaded with {row_count} rows.")
    logger.info(f"CA7Jurisdiction_final schema: {CA7Jurisdiction_final.schema}")
    log_info_to_file(f"CA7Jurisdiction_final schema: {CA7Jurisdiction_final.schema}")
    display(CA7Jurisdiction_final)
    logger.info("[END] Transformation for CA7Jurisdiction_final.")
    log_info_to_file("[END] Transformation for CA7Jurisdiction_final.")
except Exception as e:
    logger.error("Error loading CA7Jurisdiction_final:", exc_info=True)
    log_info_to_file(f"Error loading CA7Jurisdiction_final: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Writing table to PMTIN
try:
    row_count = CA7Jurisdiction_final.count()
    logger.info(f"[START] Writing {row_count} rows to table 'ca7jurisdiction' in PMTIN.")
    log_info_to_file(f"[START] Writing {row_count} rows to table 'ca7jurisdiction' in PMTIN.")
    logger.info(f"CA7Jurisdiction_final schema: {CA7Jurisdiction_final.schema}")
    log_info_to_file(f"CA7Jurisdiction_final schema: {CA7Jurisdiction_final.schema}")
    write_and_log_pmtin(
        CA7Jurisdiction_final,
        table_name="ca7jurisdiction",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
    )
    logger.info("[END] Successfully wrote CA7Jurisdiction_final to table 'ca7jurisdiction'.")
    log_info_to_file("[END] Successfully wrote CA7Jurisdiction_final to table 'ca7jurisdiction'.")
except Exception as e:
    logger.error(f"Error writing CA7Jurisdiction_final to table 'ca7jurisdiction'", exc_info=True)
    log_info_to_file(f"Error writing CA7Jurisdiction_final to table 'ca7jurisdiction': {str(e)}")
    sys.exit(1)

# COMMAND ----------

