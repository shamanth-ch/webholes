# Databricks notebook source
# MAGIC %run ../configuration/configs

# COMMAND ----------

# MAGIC %run ../configuration/postgres

# COMMAND ----------


# Logger setup for tracking errors and process info in this notebook
import logging
import sys

logger = logging.getLogger('covterm')
logger.setLevel(logging.INFO)

# COMMAND ----------

# Read the data from CSV instead of Excel, since Excel is not supported in Unity Catalog
# Update the path below if you upload the CSV to a different location
csv_path1 = "file:/Workspace/Shared/GW_Mgrtn_Nprod_Databricks/GWCONV_TRANSFORMATIONS_NOTEBOOKS/etlclausepattern.csv"
csv_path2 = "file:/Workspace/Shared/GW_Mgrtn_Nprod_Databricks/GWCONV_TRANSFORMATIONS_NOTEBOOKS/etlcovtermoption.csv"
csv_path3 = "file:/Workspace/Shared/GW_Mgrtn_Nprod_Databricks/GWCONV_TRANSFORMATIONS_NOTEBOOKS/etlcovtermpattern.csv"

df_etlclausepattern = (
    spark.read.format("csv")
    .option("header", "true")
    .option("inferSchema", "true")
    .load(csv_path1)
)
df_etlcovtermoption = (
    spark.read.format("csv")
    .option("header", "true")
    .option("inferSchema", "true")
    .load(csv_path2)
)
df_etlcovtermpattern = (
    spark.read.format("csv")
    .option("header", "true")
    .option("inferSchema", "true")
    .load(csv_path3)
)

display(df_etlclausepattern)
display(df_etlcovtermoption)
display(df_etlcovtermpattern)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Exclusions Covterm

# COMMAND ----------

codeidentifiers = [
    'CA7CommAutomblDedEnd_Ext',
    'CA7WestVAChangesCovExtensionForTemporarySubstitute',
    'CA7NamedIndivsBroadenedPersonalInjuryProtection',
    'CA7PANamedIndivsBroadenedFirstPartyBenefits',
    'CA7ImpoundedAutoEndorsmnt_Ext',
    'CA7AlskaNtcOfCancel_Ext',
    'CA7DsgntdEntyAlskaCov_Ext', 
    "CA7DesignatedLocationsGeneralLiabAggLimitForCerta2",
    "CA7FellowEmplCov",
    "CA7FellowEmplCovForDesignatedEmplsPoss",
    "CA7OptionalLmtsLossOfUseExpenses",
    "CA7LeasingOrRentalConcernsContingent1",
    "CA7CovForCertainOpsInConnectionWithRailroads",
    "CA7TruckersExcessCovForNamedInsuredAndNamedLessors",
    "CA7NonOwnedAutoLiabExtendedVolunteersNOA",
    'CA7ExclDesignatedProds1',
    'CA7ChangesToTheBankruptcyOrInsolvencyExclForActsE3',
    'CA7IAUninsuredAndUnderinsuredMotoristsCov',
    'CA7CustomerComplaintLegalDefenseCovWithNoCovForNew',
    'CA7NYTowTrucks',
    'CA7AddedAndCombinationFirstPartyBenefitsEndorsemen',
    'CA7LAChangesCovExtensionForRentalVehicles',
    'CA7LossPayableFormReg335',
    'CA7LmtdGeneralLiabCovForDesignatedUnmannedAircraf2',
    'CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA',
    'CA7LmtdGeneralLiabCovForDesignatedUnmannedAircraft',
    'CA7LmtdGeneralLiabCovForDesignatedUnmannedAircraf2',
    'CA7LmtdGeneralLiabCovForDesignatedUnmannedAircraf2',
    'CA7LmtdGeneralLiabCovForDesignatedUnmannedAircraft',
    'CA7HiredAutoLiabHAU'
]

from pyspark.sql.functions import col, lit

matched = df.filter(col("CodeIdentifier").isin(codeidentifiers))
display(matched)

matched_codes = [row['CodeIdentifier'] for row in matched.select("CodeIdentifier").distinct().collect()]
missing_codes = [c for c in codeidentifiers if c not in matched_codes]

if missing_codes:
    from pyspark.sql import Row
    missing_df = spark.createDataFrame([Row(CodeIdentifier=c) for c in missing_codes])
    display(missing_df)

# COMMAND ----------

import pandas as pd

# Create dictionary with the coverage data
coverage_data = {
    'COVERAGESUBTYPE': [
        'CA7StateSchedCov',
        'CA7CommAutoLineSchedExcl',
        'CA7CommAutoLineSchedCov',
        'CA7StateSchedCov',
        'CA7StateSchedCov',
        'CA7StateCov',
        'CA7StateSchedCov',
        'CA7CommAutoLineSchedExcl',
        'CA7StateCov',
        'CA7StateSchedCov',
        'CA7CommAutoLineSchedCov',
        'CA7StateCov',
        'CA7CommAutoLineSchedCov',
        
        'CA7StateCov',
        'CA7CommAutoLineCov',
        'CA7StateCov',
        'CA7StateCov',
        'CA7StateCov',
        'CA7StateCov',
        'CA7CommAutoLineSchedCov',
        'CA7NOACov',
        'CA7CommAutoLineExcl',
        'CA7CommAutoLineExcl',
        'CA7HAUCov',
        'CA7NOACov',
        'CA7CommAutoLineCov',
        'CA7CommAutoLineSchedCov'
    ],
    'CODEIDENTIFIER': [
        'CA7PANamedIndivsBroadenedFirstPartyBenefits',
        'CA7ChangesToTheBankruptcyOrInsolvencyExclForActsE3',
        'CA7DesignatedLocationsGeneralLiabAggLimitForCerta2',
        'CA7ImpoundedAutoEndorsmnt_Ext',
        'CA7AlskaNtcOfCancel_Ext',
        'CA7WestVAChangesCovExtensionForTemporarySubstitute',
        'CA7DsgntdEntyAlskaCov_Ext',
        'CA7ExclDesignatedProds1',
        'CA7CommAutomblDedEnd_Ext',
        'CA7NamedIndivsBroadenedPersonalInjuryProtection',
        'CA7FellowEmplCovForDesignatedEmplsPoss',
        'CA7IAUninsuredAndUnderinsuredMotoristsCov',
        'CA7LeasingOrRentalConcernsContingent1',
        'CA7AddedAndCombinationFirstPartyBenefitsEndorsemen',
        'CA7FellowEmplCov',
        'CA7CustomerComplaintLegalDefenseCovWithNoCovForNew',
        'CA7NYTowTrucks',
        'CA7LAChangesCovExtensionForRentalVehicles',
        'CA7LossPayableFormReg335',
        'CA7CovForCertainOpsInConnectionWithRailroads',
        'CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA',
        'CA7LmtdGeneralLiabCovForDesignatedUnmannedAircraf2',
        'CA7LmtdGeneralLiabCovForDesignatedUnmannedAircraft',
        'CA7HiredAutoLiabHAU',
        'CA7NonOwnedAutoLiabExtendedVolunteersNOA',
        'CA7OptionalLmtsLossOfUseExpenses',
        'CA7TruckersExcessCovForNamedInsuredAndNamedLessors'
    ]
}

# Create DataFrame from the dictionary
df = pd.DataFrame(coverage_data)

# Display the dictionary structure
print("Dictionary structure:")
print(f"Keys: {list(coverage_data.keys())}")
print(f"Number of records: {len(coverage_data['COVERAGESUBTYPE'])}")

# Display the DataFrame
print("\nDataFrame:")
print(df)

# Show some basic info about the DataFrame
print(f"\nDataFrame shape: {df.shape}")
print(f"\nUnique COVERAGESUBTYPE values: {df['COVERAGESUBTYPE'].nunique()}")
print(f"Unique CODEIDENTIFIER values: {df['CODEIDENTIFIER'].nunique()}")

# Display unique coverage subtypes
print(f"\nUnique COVERAGESUBTYPE values:")
print(df['COVERAGESUBTYPE'].unique())


# COMMAND ----------

from pyspark.sql.functions import upper, trim

# Create DataFrame from coverage_data dictionary
coverage_df = spark.createDataFrame(
    [(row['COVERAGESUBTYPE'], row['CODEIDENTIFIER']) for row in df.to_dict('records')],
    ["entityname", "codeidentifier"]
)

for row in coverage_df.collect():
    entityname = row['entityname']
    codeidentifier = row['codeidentifier']
    entity_view = f"{entityname.lower()}_view"
    entity_table = entityname

    try:
        entity_df = eval(exec_select_pmtin)(f"select * from {entity_table}")
        entity_df.createOrReplaceTempView(entity_view)
    except Exception as e:
        logger.error(f"Error loading table {entity_table}: {e}")
        continue

    if "sched" in entityname.lower():  
        filter_col = "patterncode"
    else:
        filter_col = "codeidentifier"

    try:
        filtered_policies = spark.sql(
            f"select * from {entity_view} where {filter_col} = '{codeidentifier}'"
        )
        filtered_policies.createOrReplaceTempView("filtered_policies")
        display(filtered_policies)
    except Exception as e:
        logger.error(f"Error filtering policies for {entity_table}: {e}")
        continue

    try:
        pp_activity = eval(exec_select_pmtin)("select * from policyperiod")
        pp_activity.createOrReplaceTempView("pp_activity")
    except Exception as e:
        logger.error(f"Error loading table policyperiod: {e}")
        continue

    activity_message = f"Please Update the coverage terms related to {codeidentifier}. for {entityname}"
    sql_query = f"""
    SELECT DISTINCT
        pp.pmt_id,
        pp.pmt_parent,
        CASE
            WHEN ma.pmt_payloadid IS NOT NULL THEN
                CASE
                    WHEN pp.activitynotification_ext IS NULL OR trim(pp.activitynotification_ext) = ''
                    THEN '{activity_message}'
                    ELSE concat_ws('\\n', pp.activitynotification_ext, '{activity_message}')
                END
            ELSE pp.activitynotification_ext
        END AS activitynotification_ext,
        pp.appeventsyncstatus,
        pp.basestate,
        pp.claimhandlingentity_ext,
        pp.depositamount_cur,
        pp.editeffectivedate,
        pp.estimatedpremium_amt,
        pp.estimatedpremium_cur,
        pp.inputsource_ext,
        pp.invoicingmethod,
        pp.periodend,
        pp.periodstart,
        pp.producingsoc_ext,
        pp.renewalconversionflag_ext,
        pp.totpremiumincovcurrencyrpt_cur,
        pp.totalcostincovcurrencyrpt_cur,
        pp.trancostincovcurrencyrpt_cur,
        pp.profitcenter_ext,
        pp.producercodeofrecord,
        pp.uwcompany,
        pp.pmt_payloadid,
        pp.specialdigits_ext,
        pp.subaccountnumber_ext
    FROM pp_activity pp
    LEFT JOIN filtered_policies_{entityname}_{codeidentifier} ma
        ON upper(trim(pp.pmt_payloadid)) = upper(trim(ma.pmt_payloadid))
    """

    try:
        pp_activity_updated = spark.sql(sql_query)
        display(pp_activity_updated)
    except Exception as e:
        logger.error(f"Error running final SQL for {entity_table}: {e}")
        continue
    eval(exec_cmd_framework)('truncate table public.policyperiod')
    pp_activity_updated.write.jdbc(url=jdbc_url_framework, table='policyperiod', mode='append', properties=properties)
    eval(exec_cmd_pmtin)('truncate table public.policyperiod')
    pp_manual_excl = execute_select_Framework('select * from policyperiod')
    pp_manual_excl.write.jdbc(url=jdbc_url_pmtin, table='policyperiod', mode='append', properties=properties)

# COMMAND ----------

from pyspark.sql.functions import upper, trim

# Create DataFrame from coverage_data dictionary
coverage_df = spark.createDataFrame(
    [(row['COVERAGESUBTYPE'], row['CODEIDENTIFIER']) for row in df.to_dict('records')],
    ["entityname", "codeidentifier"]
)

for row in coverage_df.collect():
    entityname = row['entityname']
    codeidentifier = row['codeidentifier']
    entity_view = f"{entityname.lower()}_view"
    entity_table = entityname

    try:
        entity_df = eval(exec_select_pmtin)(f"select * from {entity_table}")
        entity_df.createOrReplaceTempView(entity_view)
    except Exception as e:
        logger.error(f"Error loading table {entity_table}: {e}")
        continue

    if "sched" in entityname.lower():  
        filter_col = "patterncode"
    else:
        filter_col = "codeidentifier"

    try:
        filtered_policies = spark.sql(
            f"select * from {entity_view} where {filter_col} = '{codeidentifier}'"
        )
        filtered_policies.createOrReplaceTempView(f"filtered_policies_{entityname}_{codeidentifier}")
    except Exception as e:
        logger.error(f"Error filtering policies for {entity_table}: {e}")
        continue

    try:
        pp_activity = eval(exec_select_pmtin)("select * from policyperiod")
        pp_activity.createOrReplaceTempView("pp_activity")
    except Exception as e:
        logger.error(f"Error loading table policyperiod: {e}")
        continue

    activity_message = f"Please Update the coverage terms related to {codeidentifier}. for {entityname}"
    sql_query = f"""
    SELECT DISTINCT
        pp.pmt_id,
        pp.pmt_parent,
        CASE
            WHEN ma.pmt_payloadid IS NOT NULL THEN
                CASE
                    WHEN pp.activitynotification_ext IS NULL OR trim(pp.activitynotification_ext) = ''
                    THEN '{activity_message}'
                    ELSE concat_ws('\\n', pp.activitynotification_ext, '{activity_message}')
                END
            ELSE pp.activitynotification_ext
        END AS activitynotification_ext,
        pp.appeventsyncstatus,
        pp.basestate,
        pp.claimhandlingentity_ext,
        pp.depositamount_cur,
        pp.editeffectivedate,
        pp.estimatedpremium_amt,
        pp.estimatedpremium_cur,
        pp.inputsource_ext,
        pp.invoicingmethod,
        pp.periodend,
        pp.periodstart,
        pp.producingsoc_ext,
        pp.renewalconversionflag_ext,
        pp.totpremiumincovcurrencyrpt_cur,
        pp.totalcostincovcurrencyrpt_cur,
        pp.trancostincovcurrencyrpt_cur,
        pp.profitcenter_ext,
        pp.producercodeofrecord,
        pp.uwcompany,
        pp.pmt_payloadid,
        pp.specialdigits_ext,
        pp.subaccountnumber_ext
    FROM pp_activity pp
    LEFT JOIN filtered_policies_{entityname}_{codeidentifier} ma
        ON upper(trim(pp.pmt_payloadid)) = upper(trim(ma.pmt_payloadid))
    """

    try:
        pp_activity_updated = spark.sql(sql_query)
        display(pp_activity_updated)
    except Exception as e:
        logger.error(f"Error running final SQL for {entity_table}: {e}")
        continue

    eval(exec_cmd_framework)('truncate table public.policyperiod')
    pp_activity_updated.write.jdbc(url=jdbc_url_framework, table='policyperiod', mode='append', properties=properties)
    eval(exec_cmd_pmtin)('truncate table public.policyperiod')
    pp_manual_excl = execute_select_Framework('select * from policyperiod')
    pp_manual_excl.write.jdbc(url=jdbc_url_pmtin, table='policyperiod', mode='append', properties=properties)

# COMMAND ----------


from pyspark.sql.functions import trim, when, col

# Mapping FormId to CodeIdentifier as per the provided CASE WHEN logic
formid_to_codeidentifier = {
    'CA 25 55': 'CA7ExclProdsAndWorkYouPerformed',
    'CA 25 50': 'CA7ExclDamageToRentedPremises',
    'CA 25 62': 'CA7ChangesToTheBankruptcyOrInsolvencyExclForActsE3',
    'CA 04 55': 'CA7CommunicableDiseaseExclForCovrdAutosLiabExposur',
    'CA 27 05': 'CA7UnmannedAircraftExclForGeneralLiabCovs',
    'CA 27 16': 'CA7ExclCrossSuitsLiabForGeneralLiabCovs',
    'CA 27 14': 'CA7CannabisExclWithHempAndLessorRiskExceptionForGe',
    'CA 25 51': 'CA7ExclDesignatedProds1',
    'CA 23 85': 'CA7ExclOfTerrNuclearBiologicalChemicalTerr',
    'CA 25 54': 'CA7ExclPersonalAndAdvertisingInjuryLiab',
    'CA 27 13': 'CA7CannabisExclWithHempExceptionForGeneralLiabCovs',
    'CA 23 94': 'CA7SilicaOrSilicaReltdDustExclForCovrdAutosExposur',
    'CA 25 37': 'CA7FungiOrBacteriaExclGarageOpsOthThanCovrdAutos',
    'CA 25 24': 'CA7ExclY2KCompReltdElectrProbExceptionBIPremises',
    'CA 25 56': 'CA7ExclDesignatedWorkYouPerformed1',
    'CA 27 07': 'CA7UnmannedAircraftExclForGeneralLiabCovsPersonalA',
    'CA 04 42': 'CA7ExclOfFedEmplsUsingAutosInGovBusiness',
    'CA 25 19': 'CA7ExclY2KCompReltdElectrProbProdsWork',
    'CA 25 53': 'CA7ExclNewlyAcquiredOrFormedAutoDealership',
    'CA 25 39': 'CA7SilicaOrSilicaReltdDustExclForOthThanCovrdAutos',
    'CA 26 04': 'CA7AmendmentOfSingleInterestPolicyProvisionsPublic',
    'CA 25 65': 'CA7TotalBankruptcyOrInsolvencyExclForActsErrorsOrO',
    'CA 25 64': 'CA7ExclOfSpecifiedActsErrorsOrOmissionsLiabCovs',
    'CA 25 57': 'CA7CommunicableDiseaseExclForGeneralLiabCovs',
    'CA 23 84': 'CA7ExclOfTerr',
    'CA 27 12': 'CA7CannabisExclForGeneralLiabCovs',
    'CA 28 03': 'CA7AbuseOrMolestationExclForCovrdAutosLiabExposure',
    'PCA 20 27': 'CA7TotPollExcl_Ext',
    'PCA 20 21': 'CA7AssltBttryExcl_Ext',
    'PCA 06 02': 'CA7LmtdExclOfNmdDrvr_Ext',
    'PCA 06 13': 'CA7EmployersLiabExclTemporaryWorker_Ext',
    'PCA 05 12': 'CA7HrdNOwndRtlFdDlvry_Ext',
    'PCA 20 07': 'CA7AbsMolestnSxlMscndtExcl_Ext',
    'CA 25 16': 'CA7GarageCovFormOthThanCovrdAutosExposureTotalPoll',
    'CA 23 86': 'CA7ExclOfTerrAboveMinStatutoryLmts',
    'CA 25 36': 'CA7GarageCovOthThanCovrdAutosExposureTotPolltnExcl',
    'CA 23 87': 'CA7ExclOfTerrNuclearBiologicalChemicalTerrAboveMin',
    'CA 27 19': 'CA7PFASExclForGeneralLiabCovs',
    'CA 20 11': 'CA7LeasingOrRentalConcernsExclOfCertainLeasedAuto1',
    'CA 25 25': 'CA7Y2KCompReltdElectrncPrblsExclOfSpecnCovForDesin',
    'CA 27 21': 'CA7AbuseOrMolestationExclForGeneralLiabAndActsErro',
    'CA 27 22': 'CA7SexualAbuseOrSexualMolestationExclForGeneralLia',
    'CA 27 06': 'CA7UnmannedAircraftExclForGeneralLiabCovsBIAndProp',
    'CA 20 30': 'CA7EmergencyVehiclesVolunteerFirefightersAndWorker',
    'CA 25 18': 'CA7ExclY2KCompReltdElectrProb',
    'CA 23 01': 'CA7Explosives',
    'CA 27 10': 'CA7LmtdGeneralLiabCovForDesignatedUnmannedAircraf1',
    'CA 27 08': 'CA7LmtdGeneralLiabCovForDesignatedUnmannedAircraf2',
    'CA 27 09': 'CA7LmtdGeneralLiabCovForDesignatedUnmannedAircraft',
    'CA 99 13': 'CA7FiduciaryLiabOfBanks',
    'CA 23 05': 'CA7WrongDeliveryOfLiquidProds'
    
}

# Create a DataFrame with FormId and corresponding CodeIdentifier
from pyspark.sql.functions import lit

formid_codeidentifier_df = spark.createDataFrame(
    [(k, v) for k, v in formid_to_codeidentifier.items()],
    ["FormId", "CodeIdentifier"]
)

# Join with etlclausepattern to get ClausePatternID for each CodeIdentifier
clausepattern_with_code = df_etlclausepattern.join(
    formid_codeidentifier_df,
    df_etlclausepattern["CodeIdentifier"] == formid_codeidentifier_df["CodeIdentifier"],
    how="right"
).select(
    formid_codeidentifier_df["FormId"],
    formid_codeidentifier_df["CodeIdentifier"],
    df_etlclausepattern["ID"].alias("ClausePatternID")
)

# Join with etlcovtermpattern to get PatternID, mark as null if not found
result_df = clausepattern_with_code.join(
    df_etlcovtermpattern,
    clausepattern_with_code["ClausePatternID"] == df_etlcovtermpattern["ClausePatternID"],
    how="left"
).select(
    clausepattern_with_code["FormId"],
    clausepattern_with_code["CodeIdentifier"],
    clausepattern_with_code["ClausePatternID"],
    df_etlcovtermpattern["PatternID"]
)

display(result_df)
result_df.createOrReplaceTempView('result_df')

# COMMAND ----------

df_ca7commautolineexcl = execute_select_PMTIN("select * from ca7commautolineexcl")
df_ca7commautolineexcl.createOrReplaceTempView("ca7commautolineexcl_view")

joined_df = spark.sql("""
    SELECT a.*, b.PatternID
    FROM ca7commautolineexcl_view a
    INNER JOIN result_df b
    ON a.CodeIdentifier = b.CodeIdentifier
""")

joined_df.createOrReplaceTempView("ca7commautolineexcl_with_patternid")
display(joined_df)

# COMMAND ----------

from pyspark.sql import Row

data = [
    ("CA7ManualPremium126", "0"),
    ("CA7ManualPremium107", "0"),
    ("CA7ManualPremium23", "0"),
    ("CA7ManualPremium167", "0"),
    ("CA7ManualPremium35", "0"),
    ("CA7ManualPremium34", "0"),
    ("CA7ManualPremium31", "0"),
    ("CA7ManualPremium113", "0"),
    ("CA7ManualPremium32", "0"),
    ("CA7ManualPremium30", "0"),
    ("CA7ManualPremium110", "0"),
    ("CA7ManualPremium36", "0"),
    ("CA7ManualPremium108", "0"),
    ("CA7ManualPremium121", "0"),
    ("CA7ManualPremium112", "0"),
    ("Manual Premium", "0"),
    ("CA7ManualPremium37", "0"),
    ("CA7InsuranceAgentOrBroker", "Yes"),
    ("CA7OdometerMileage", "Yes"),
    ("CA7Title", "Yes"),
    ("CA7TruthInLendingConsumerLeasingActs", "Yes"),
    ("CA7ManualPremium27", "0"),
    ("CA7ManualPremium164", "0")
]

df_codeidentifier_value = spark.createDataFrame(data, ["covterm", "value"])
display(df_codeidentifier_value)
df_codeidentifier_value.createOrReplaceTempView("df_codeidentifier_value")

# COMMAND ----------



result_df = (
  spark.sql("""
    select 
      cpd.pmt_id,
      cpd.pmt_parent,
      cpd.pmt_payloadid,
      cpd.patternID,
      cpd.codeidentifier,
      cdv.covterm,        
      cdv.value
    from ca7commautolineexcl_with_patternid cpd
    left join df_codeidentifier_value cdv 
      on cpd.patternID = cdv.covterm
  """)
  .filter("patternID is not null and covterm is not null")
)

result_df.createOrReplaceTempView("tempview_no_null_patternid_covterm")
display(result_df)

# COMMAND ----------

covterm_excl = spark.sql("""
select 
  concat(covterm,'-',pmt_payloadid, '-',patternID) as pmt_id,
  pmt_id as pmt_parent,
  'CA7CommAutoLineExcl' as pmt_parent_type,
  covterm as codeidentifier,
  value as value,
  pmt_payloadid as pmt_payloadid 
from tempview_no_null_patternid_covterm
""")
covterm_excl.createOrReplaceTempView("tempview_pmt")

# COMMAND ----------


#eval(exec_cmd_pmtin)('truncate table public.covterm')
covterm_excl.write.jdbc(url=jdbc_url_pmtin, table='covterm', mode='append', properties=properties)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Covterm of Standard ISO Coverage - Liability and MedPay Coverage Limits Deductible

# COMMAND ----------

# DBTITLE 1,ETL query of Standard ISO Coverages
# LiabilitySymbol Notes                                                               
#  1-Any Auto                                                                          
#  2-Owned Autos                                                                       
#  3-Owned Private Passenger Autos                                                     
#  4-Owned Autos Other Than Private Passenger                                          
#  5-Owned Autos Subject to PIP (never used)                                           
#  6-Owned Autos Subject to Compulsory UM Law (never used)                             
#  7-Specifically Described Autos                                                      
#  8-Hired Autos                                                                       
#  9-Non-Owned Autos                                                                   
#  19-Mobile Equip Subject to Compulsory, F.R. or Other Motor Vehicle Law (never used) 

# LiabilityLimitTypeCode Notes                                                        
#  1-Combined Single Limit                                                             
#  2-Split Limits     

#  LiabilityLimit Notes                                                                
#  Null when the AuPolInput.LiabLimitTypeCd = 2                                                                 

# BI1Limit Notes                                                                      
#  This is valued when the LiabilityLimitTypeCode = 2

# BI2Limit Notes                                                                      
#  This is valued when the LiabilityLimitTypeCode = 2                                   

# LiabilityDeductionTypeCode Notes                                                    
#  1-BI and PD                                                                        
#  2-BI Only                                                                          
#  3-PD Only 

# MedPaySymbol Notes                                                               
#  1-Any Auto                                                                          
#  2-Owned Autos                                                                       
#  3-Owned Private Passenger Autos                                                     
#  4-Owned Autos Other Than Private Passenger                                          
#  5-Owned Autos Subject to PIP (never used)                                           
#  6-Owned Autos Subject to Compulsory UM Law (never used)                             
#  7-Specifically Described Autos                                                      
#  8-Hired Autos                                                                       
#  9-Non-Owned Autos                                                                   
#  19-Mobile Equip Subject to Compulsory, F.R. or Other Motor Vehicle Law (never used)

Standard_ISO_Coverage_query = '''
-- Sprint5_Line – Standard - Liability and MedPay Coverage Limits Deductible
-- CTE to Check if Form# PCA 0301 Exists

WITH FormCheckPCA0301 AS (
    SELECT AUSelectedForm."SystemAssignId", AUSelectedForm."StateCd"
    FROM ViewCurPic_AUSelectedForm AUSelectedForm
    WHERE AUSelectedForm."FormId" IN ('PCA 03 01')
)

SELECT 
    -- CoPolicyPointer fields
    P."SystemAssignId",
    P1."LOB",
    P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
    CAST(RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",

    -- CoBusinessInfo fields
    CoBusinessInfo."BusTypeTx" AS "BusinessType",

    -- AuPolInput fields
    AuPolInput."LiabSymbolLst" AS "LiabilitySymbol",
    AuPolInput."LiabLimitTypeCd" AS "LiabilityLimitTypeCode",
    AuPolInput."CSLLiabLimit" AS "LiabilityLimit",
    AuPolInput."BI1Limit" AS "BI1Limit",
    AuPolInput."BI2Limit" AS "BI2Limit",
    AuPolInput."PDLimit" AS "PDLimit",
    AuPolInput."LiabDedTypeCd" AS "LiabilityDeductionTypeCode",
    AuPolInput."LiabDedAmt" AS "LiabilityDeductible",
    AuPolInput."MedPaySymbolLst" AS "MedPaySymbol",
    AuPolInput."PredMedPayLimit" AS "MedPayLimit",

    -- DoesFormPCA0301Exist
    CASE WHEN FormCheckPCA0301."SystemAssignId" IS NOT NULL THEN 'Y' ELSE 'N' END AS "DoesFormPCA0301Exist"
--    FormCheckPCA0301."SystemAssignId"

FROM Policy P1
INNER JOIN CoPolicyPointer P
    ON P."SystemAssignId" = P1."SourceSystemId"
INNER JOIN ViewCurPic_CoBusinessInfo CoBusinessInfo
    ON P."SystemAssignId" = CoBusinessInfo."SystemAssignId"
INNER JOIN ViewCurPic_AuPolInput AuPolInput
    ON P."SystemAssignId" = AuPolInput."SystemAssignId"
LEFT JOIN FormCheckPCA0301
    ON P."SystemAssignId" = FormCheckPCA0301."SystemAssignId"

WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
 -- AND P1."LOB" IN ('AU', 'GR', 'TU')

ORDER BY AuPolInput."BI1Limit" DESC

'''

try:
  Standard_ISO_Coverage_data = eval(exec_select_landing)(Standard_ISO_Coverage_query)
  Standard_ISO_Coverage_data.createOrReplaceTempView("Standard_ISO_Coverage_data")
  print(Standard_ISO_Coverage_data.count())
  display(Standard_ISO_Coverage_data)
except Exception as e:
  logger.info("error loading Standard_ISO_Coverage_data: {}".format(e)) 
  sys.exit(1) 

# COMMAND ----------

Covterm_Standard_ISO_Cov_query = '''
    SELECT DISTINCT
    concat('CA7VehicleMedPay:',trim(PolicyNumber),'_CA7LimitText1') AS pmt_id,
    concat('CA7CommAutoLineCov:',trim(PolicyNumber),'_CA7VehicleMedPay') AS pmt_parent,
    'CA7CommAutoLineCov' AS pmt_parent_type,
    'CA7LimitText1' AS codeidentifier,
    CASE WHEN trim(MedPaySymbol) IS NOT NULL THEN trim(MedPayLimit) ELSE 'NoCoverage' END AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Standard_ISO_Coverage_data

UNION ALL

SELECT DISTINCT
    concat('CA7VehicleLiab:',trim(PolicyNumber),'_','CA7CovType13') AS pmt_id,
    concat('CA7CommAutoLineCov:',trim(PolicyNumber),'_',"CA7VehicleLiab") AS pmt_parent,
    'CA7CommAutoLineCov' AS pmt_parent_type,
    'CA7CovType13' AS codeidentifier,
    CASE 
        -- 1 maps to CombinedSingleLimit,2 maps to SplitLimit
        WHEN LiabilityLimitTypeCode = '1' THEN 'CombinedSingleLimit'
        WHEN LiabilityLimitTypeCode = '2' THEN 'SplitLimit'
        ELSE 'No Coverage'
    END  AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Standard_ISO_Coverage_data

UNION ALL

SELECT DISTINCT
    concat('CA7VehicleLiab:',trim(PolicyNumber),'_','CA7LimitText') AS pmt_id,
    concat('CA7CommAutoLineCov:',trim(PolicyNumber),'_',"CA7VehicleLiab") AS pmt_parent,
    'CA7CommAutoLineCov' AS pmt_parent_type,
    'CA7LimitText' AS codeidentifier,
    CASE WHEN LiabilitySymbol IS NULL THEN "NotApplicable"
        WHEN LiabilityLimitTypeCode = '1' THEN 
            CASE 
                WHEN trim(LiabilityLimit) IN (
                    '15000','110000','25000','50000','55000','30000','90000','85000','70000','60000','75000','65000','35000',
                    '100000','125000','150000','200000','250000','300000','350000','400000','500000','510000','600000','750000',
                    '1000000','1500000','2000000','2500000','3000000','5000000','7500000','10000000',
                    '20000/40000','25000/50000','35000/70000','50000/100000','75000/150000','100000/200000','100000/300000',
                    '200000/200000','200000/400000','250000/500000','300000/300000','300000/600000','500000/1000000',
                    '1000000/1000000','2000000/2000000','2500000/2500000','5000000/5000000','10000000/10000000'
                ) THEN trim(LiabilityLimit)
                ELSE 'NotApplicable'
            END
        WHEN LiabilityLimitTypeCode = '2' THEN 
            CASE 
                WHEN trim(PDLimit) IN (
                    '15000','110000','25000','50000','55000','30000','90000','85000','70000','60000','75000','65000','35000',
                    '100000','125000','150000','200000','250000','300000','350000','400000','500000','510000','600000','750000',
                    '1000000','1500000','2000000','2500000','3000000','5000000','7500000','10000000',
                    '20000/40000','25000/50000','35000/70000','50000/100000','75000/150000','100000/200000','100000/300000',
                    '200000/200000','200000/400000','250000/500000','300000/300000','300000/600000','500000/1000000',
                    '1000000/1000000','2000000/2000000','2500000/2500000','5000000/5000000','10000000/10000000'
                ) THEN trim(PDLimit)
                ELSE 'NotApplicable'
            END
    END  AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Standard_ISO_Coverage_data

UNION ALL

SELECT DISTINCT
   concat('CA7VehicleLiab:',trim(PolicyNumber),'_','CA7PropertyDamageLimit16') AS pmt_id,
   concat('CA7CommAutoLineCov:',trim(PolicyNumber),'_',"CA7VehicleLiab") AS pmt_parent,
   'CA7CommAutoLineCov' AS pmt_parent_type,
   'CA7PropertyDamageLimit16' AS codeidentifier,
   CASE 
        WHEN LiabilitySymbol IS NULL THEN 'NoCoverage'
        WHEN LiabilityLimitTypeCode = '1' THEN 'NotApplicable'
        WHEN LiabilityLimitTypeCode = '2' THEN  trim(BI1Limit)
   END AS value,
   trim(PolicyNumber) AS pmt_payloadid
FROM Standard_ISO_Coverage_data

UNION ALL

SELECT DISTINCT
    concat('CA7VehicleLiab:', trim(PolicyNumber), '_', 'CA7Ded124') AS pmt_id,
    concat('CA7CommAutoLineCov:', trim(PolicyNumber), '_', 'CA7VehicleLiab') AS pmt_parent,
    'CA7CommAutoLineCov' AS pmt_parent_type,
    'CA7Ded124' AS codeidentifier,
    CASE 
     WHEN DoesFormPCA0301Exist = 'Y' THEN 'NotApplicable_Ext'
        WHEN LiabilityDeductionTypeCode = '1' THEN
            CASE 
                WHEN CONCAT(TRIM(LiabilityDeductible), 'CombinedSingleLimit') IN (
                    '250CombinedSingleLimit',
                    '500CombinedSingleLimit',
                    '1000CombinedSingleLimit',
                    '2500CombinedSingleLimit',
                    '5000CombinedSingleLimit',
                    '10000CombinedSingleLimit',
                    '20000CombinedSingleLimit',
                    '25000CombinedSingleLimit',
                    '50000CombinedSingleLimit',
                    '75000CombinedSingleLimit',
                    '100000CombinedSingleLimit'
                ) THEN CONCAT(TRIM(LiabilityDeductible), 'CombinedSingleLimit')
                ELSE 'NoDeductible'
            END
        WHEN LiabilityDeductionTypeCode = '3' THEN
            CASE 
                WHEN CONCAT(TRIM(LiabilityDeductible), 'PropertyDamagePerAccident') IN (
                    '250PropertyDamagePerAccident',
                    '500PropertyDamagePerAccident',
                    '1000PropertyDamagePerAccident',
                    '2500PropertyDamagePerAccident',
                    '5000PropertyDamagePerAccident',
                    '10000PropertyDamagePerAccident',
                    '20000PropertyDamagePerAccident',
                    '25000PropertyDamagePerAccident',
                    '50000PropertyDamagePerAccident',
                    '75000PropertyDamagePerAccident',
                    '100000PropertyDamagePerAccident'
                ) THEN CONCAT(TRIM(LiabilityDeductible), 'PropertyDamagePerAccident')
                ELSE 'NoDeductible'
            END
        ELSE 'NoDeductible'
    END AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Standard_ISO_Coverage_data

UNION ALL

SELECT DISTINCT
    concat('CA7LargeDeductibleCov_Ext:',trim(PolicyNumber),'_','Deductible') AS pmt_id,
    concat('CA7CommAutoLineCov:',trim(PolicyNumber),'_','CA7LargeDeductibleCov_Ext') AS pmt_parent,
    'CA7CommAutoLineCov' AS pmt_parent_type,
    'Deductible' AS codeidentifier,
    CASE WHEN trim(DoesFormPCA0301Exist) = 'Y' THEN NULL ELSE 'NoDeductible' END AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Standard_ISO_Coverage_data

UNION ALL

SELECT DISTINCT
    concat('CA7LargeDeductibleCov_Ext:',trim(PolicyNumber),'_','AggregateDeductibleValue') AS pmt_id,
    concat('CA7CommAutoLineCov:',trim(PolicyNumber),'_','CA7LargeDeductibleCov_Ext') AS pmt_parent,
    'CA7CommAutoLineCov' AS pmt_parent_type,
    'AggregateDeductibleValue' AS codeidentifier,
    CASE WHEN trim(DoesFormPCA0301Exist) = 'Y' THEN NULL ELSE 'NoDeductible' END AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Standard_ISO_Coverage_data

UNION ALL

SELECT DISTINCT
    concat('CA7LargeDeductibleCov_Ext:',trim(PolicyNumber),'_','AggregateDeductible') AS pmt_id,
    concat('CA7CommAutoLineCov:',trim(PolicyNumber),'_','CA7LargeDeductibleCov_Ext') AS pmt_parent,
    'CA7CommAutoLineCov' AS pmt_parent_type,
    'AggregateDeductible' AS codeidentifier,
    'NoCoverage' AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Standard_ISO_Coverage_data

UNION ALL

SELECT DISTINCT
    concat('CA7LargeDeductibleCov_Ext:',trim(PolicyNumber),'_','DeductibleType') AS pmt_id,
    concat('CA7CommAutoLineCov:',trim(PolicyNumber),'_','CA7LargeDeductibleCov_Ext') AS pmt_parent,
    'CA7CommAutoLineCov' AS pmt_parent_type,
    'DeductibleType' AS codeidentifier,
    'CombinedSingleLimit' AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Standard_ISO_Coverage_data

'''
try:
  Covterm_Standard_ISO_Cov_data = spark.sql(Covterm_Standard_ISO_Cov_query)
  Covterm_Standard_ISO_Cov_data.createOrReplaceTempView("Covterm_Standard_ISO_Cov_data")
  print(Covterm_Standard_ISO_Cov_data.count())
  display(Covterm_Standard_ISO_Cov_data)
except Exception as e:
  logger.info("error loading Covterm_Standard_ISO_Cov_data: {}".format(e)) 
  sys.exit(1) 

# COMMAND ----------

# DBTITLE 1,Writing Covterm in PMTIN

CA7CommAutoLineCov =execute_select_PMTIN("select * from CA7CommAutoLineCov")
CA7CommAutoLineCov.createOrReplaceTempView("CA7CommAutoLineCov")
# SQL to find mismatching pmt_parent, count null pmt_id, and check for duplicates for ca7haucov data
invalid_refs_sql = """
SELECT DISTINCT pmt_parent
FROM Covterm_Standard_ISO_Cov_data
WHERE pmt_parent NOT IN (
  SELECT DISTINCT pmt_id FROM CA7CommAutoLineCov
)
"""

null_pmt_id_sql = """
SELECT COUNT(*) as null_count
FROM Covterm_Standard_ISO_Cov_data
WHERE pmt_id IS NULL
"""

duplicate_pmt_id_sql = """
SELECT pmt_id, COUNT(*) as cnt
FROM Covterm_Standard_ISO_Cov_data
GROUP BY pmt_id
HAVING COUNT(*) > 1
"""

invalid_refs = spark.sql(invalid_refs_sql)
null_pmt_id_count = spark.sql(null_pmt_id_sql).collect()[0]['null_count']
duplicate_pmt_ids = spark.sql(duplicate_pmt_id_sql)

if invalid_refs.count() == 0 and null_pmt_id_count == 0 and duplicate_pmt_ids.count() == 0:
    logger.info('referential integrity checks passed')
    logger.info('No Null pmt_id values found')
    logger.info('No duplicate pmt_id values found')

    Covterm_Standard_ISO_Cov_data.write.jdbc(url=jdbc_url_pmtin, table='covterm', mode='append', properties=properties)
else:
    if invalid_refs.count() > 0:
        logger.error("Referential integrity issue: Some pmt_parent values do not exist in CA7CommAutoLineCov.")
        for row in invalid_refs.collect():
            logger.error(f"Invalid pmt_parent: {row.pmt_parent}")
    if null_pmt_id_count > 0:
        logger.error(f"Null pmt_id values found in Covterm_Standard_ISO_Cov_data: {null_pmt_id_count}")
    if duplicate_pmt_ids.count() > 0:
        logger.error("Duplicate pmt_id values found in Covterm_Standard_ISO_Cov_data.")
        for row in duplicate_pmt_ids.collect():
            logger.error(f"Duplicate pmt_id: {row.pmt_id} with count: {row.cnt}")
            

# COMMAND ----------

# MAGIC %md
# MAGIC ##Line Level Additional - ISO Coverages (Drive Other Car Coverage, Trailer Interchange Coverage)

# COMMAND ----------

# DBTITLE 1,ETL query for Line Additional ISO Coverage
Additional_ISO_Coverage_query = '''
/* -------------------------------------------------------------------------------------------------------------- */
/* Spint5_Line - Commercial Auto Line Additional ISO Coverages                                                    */
/* 09/08/25 changes (pstemp):                                                                                     */
/* Use ViewCurPic_CoPolicyDetail to Get Predominant State                                                         */
/* Added fields from ViewCurPic_AuPolInput                                                                        */
/* Added Additional Coverage fields from ViewCurPic_AuStDOCInput and ViewCurPic_AuStUMInput                       */
/* 09/22/25 changes (pstemp):                                                                                     */
/* Added view ViewCurPic_AuStTIInput for Trailer Interchange Agreement fields                                     */
/* -------------------------------------------------------------------------------------------------------------- */


/* ------------------------------------------------------------------------ */
/* Symbol List Info                                                         */
/* 1-Any Auto                                                               */
/* 2-Owned Autos                                                            */
/* 3-Owned Private Passenger Autos                                          */
/* 4-Owned Autos Other Than Private Passenger                               */
/* 5-Owned Autos Subject to PIP                                             */
/* 6-Owned Autos Subject to Compulsory UM Law                               */
/* 7-Specifically Described Autos                                           */
/* 8-Hired Autos                                                            */
/* 9-Non-Owned Autos                                                        */
/* 19-Mobile Equip Subject to Compulsory, F.R. or Other Motor Vehicle Law&lt;  */
/* ------------------------------------------------------------------------ */

SELECT 
/* ---------------------- */
/* CoPolicyPointer fields */
/* ---------------------- */
P."SystemAssignId",
P1."LOB",
P."PolicyPrefixCd" || ' ' || TRIM(P."PolicyId") || COALESCE(TRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
(TRIM(P."PolicyId") || COALESCE(TRIM(P."PolicySuffixCd"), ' '))::VARCHAR(8) AS "AccountNumber",

/* ---------------------- */
/* CoPolicyDetail fields  */
/* ---------------------- */
CoPolicyDetail."PredStateCd" AS "PredominantStateCode",

/* ----------------- */
/* AuPolInput fields */
/* ----------------- */
AuPolInput."LiabSymbolLst" AS "LiabilitySymbol",
AuPolInput."LiabLimitTypeCd" AS "LiabilityType",
AuPolInput."CSLLiabLimit" AS "LiabilityLimit",
AuPolInput."BI1Limit" AS "BodilyInjuryLimit1",
AuPolInput."BI2Limit" AS "BodilyInjuryLimit2",
AuPolInput."PDLimit" AS "PropertyDamageLiabilityLimit",
AuPolInput."PredMedPayLimit",
AuPolInput."LiabLimitTypeCd",

/* ---------------------- */
/* AuStDOCInput fields    */
/* ---------------------- */
AuStDOCInput."IndivCovCnt" AS "NumberOfIndividualsCovered",
coverage."CoveragesApplicable",
AuStDOCInput."LiabCSLOvrdAmt" AS "LiabilityCSLOverrideAmount",
AuStDOCInput."MedPayLimit" AS "MedPayLimit",
AuStDOCInput."CompDedAmt" AS "CompDed",
AuStDOCInput."CompDedCauseOfLossCd" AS "CompDedCauseOfLossCode",
AuStDOCInput."CompDedGlassCd" AS "CompDedFullGlass",
AuStDOCInput."CollDedAmt" AS "CollDed",
AuStDOCInput."DocUmOvrd" AS "UMUIMOverrideIndicator",
AuStDOCInput."UIMBIOvrd1Limit" AS "UMBILimit1",
AuStDOCInput."UIMBIOvrd2Limit" AS "UMBILimit2",
AuStDOCInput."UMPDOvrdLimit" AS "UMPDLimit",
AuStDOCInput."MiscInfo",
AuStDOCInput."MiscOvrdInfoInd",
AuStDOCInput."UMCSLOvrdAmt" AS "UMCSL",
AuStDOCInput."UIMBIOvrd1Limit" AS "UMBIMLimit1",
AuStDOCInput."UIMBIOvrd2Limit" AS "UMBIMLimit2",

/* ---------------------- */
/* AuStUMInput fields     */
/* ---------------------- */
--LimitTypeUMUIM
-- 1 = 'CSL Incl PD'
-- 2 = 'CSL Excl PD'
-- 3 = 'Split Incl PD'
-- 4 = 'Split Excl PD' 
AuStUMInput."TypeLimit" AS "LimitTypeUMUIM",
AuStUMInput."CombLimt" AS "St_UMCLSLimit",
AuStUMInput."BI1Limit" AS "St_UMBILimit1",
AuStUMInput."BI2Limit" AS "St_UMBILimit2",
AuStUMInput."PDLimit" AS "St_UMPDLimt",
AuStUMInput."UIMCombLimit" AS "St_UIMCLSLimit",
AuStUMInput."UIMBI1Limit" AS "St_UIMBILimit1",
AuStUMInput."UIMBI2Limit" AS "St_UIMBILimit2",
AuStUMInput."UIMPDLimit" AS "St_UIMPDLimt",
AuStUMInput."IndivCoupleInd" AS "IndividualNamedInsured",
AuStUMInput."MiscInfoInd" AS "UMMisc",

/* ----------------------------- */
/* ViewCurPic_AuStTIInput Fields */
/* ----------------------------- */
AuStTIInput."CompValAmt" AS "TrailerInterchangeCompValue",
AuStTIInput."CompDedAmt" AS "TrailerInterchangeDeductible",
AuStTIInput."CollValAmt" AS "TrailerInterchangeCollisionValue",
AuStTIInput."CollDedAmt" AS "TrailerInterchangeCollisionDeductible",
/* --------------------------------- */
/* TrailerInterchangeRadius Info:    */
/* 1 - Local/0-50 miles,             */
/* 2 - Intermediate/ 51-200 miles,   */
/* 3 - Long Distance/Over 200 miles  */
/* --------------------------------- */
AuStTIInput."RadiusofUseCd" AS "TrailerInterchangeRadius",
AuStTIInput."ZoneTerritoryCd" AS "TrailerInterchangeZone1",
AuStTIInput."FarthestZoneCd" AS "TrailerInterchangeFarthestZone",
AuStTIInput."CoverTrlrsCnt" AS "TrailerInterchangeNumberOfTrailers",
AuStTIInput."CoverDaysCnt" AS "TrailerInterchangeNumberOfDays",
/* ------------------------------------------- */
/* TrailerInterchangeCoverageSCLValue Info:    */
/* 1 - Fire                                    */
/* 2 - Fire & Theft                            */
/* 3 - Specified Perils                        */
/* 4 - Limited Specified Perils                */
/* ------------------------------------------- */
AuStTIInput."SpecPerilValAmt" AS "TrailerInterchangeCoverageSCLValue",
AuStTIInput."SpecPerilDedAmt" AS "TrailerInterchangeCoverageSCLDeductible",
AuStTIInput."SpecPerilTypeCd" AS "TrailerInterchangeCoverageSCLType",
AuStTIInput."SpecPerilPremAmt" AS "TrailerInterchangeCoverageSCLPremium"

FROM Policy AS P1
INNER JOIN CoPolicyPointer AS P
   ON P."SystemAssignId" = P1."SourceSystemId"
INNER JOIN ViewCurPic_CoPolicyDetail AS CoPolicyDetail
   ON P."SystemAssignId" = CoPolicyDetail."SystemAssignId"
INNER JOIN ViewCurPic_AuPolInput AS AuPolInput
   ON P."SystemAssignId" = AuPolInput."SystemAssignId"
INNER JOIN ViewCurPic_AuStInput AS AuStInput
   ON P."SystemAssignId" = AuStInput."SystemAssignId"
   AND CoPolicyDetail."PredStateCd" = AuStInput."StateCd"
LEFT JOIN ViewCurPic_AuStTIInput AS AuStTIInput
   ON P."SystemAssignId" = AuStTIInput."SystemAssignId"
   AND CoPolicyDetail."PredStateCd" = AuStTIInput."StateCd"
LEFT JOIN ViewCurPic_AuStDOCInput AS AuStDOCInput
   ON P."SystemAssignId" = AuStDOCInput."SystemAssignId"
   AND CoPolicyDetail."PredStateCd" = AuStDOCInput."StateCd"
LEFT JOIN ViewCurPic_AuStUMInput AS AuStUMInput
   ON P."SystemAssignId" = AuStUMInput."SystemAssignId"
   AND CoPolicyDetail."PredStateCd" = AuStUMInput."StateCd"
LEFT JOIN LATERAL (
    SELECT unnest(string_to_array(AuStDOCInput."SelCovgsLst", ',')) AS "CoveragesApplicable"
) AS coverage ON true
WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
AND P1."LOB" IN ('AU', 'GR', 'TU')

--Order by AuStTIInput.SpecPerilValAmt desc
ORDER BY "TrailerInterchangeRadius" DESC

'''

try:
  Additional_ISO_Coverage_data = eval(exec_select_landing)(Additional_ISO_Coverage_query)
  Additional_ISO_Coverage_data.createOrReplaceTempView("Additional_ISO_Coverage_data")
  print(Additional_ISO_Coverage_data.count())
  display(Additional_ISO_Coverage_data)
except Exception as e:
  logger.info("error loading Additional_ISO_Coverage_data: {}".format(e)) 
  sys.exit(1) 

# COMMAND ----------

CovTerm_Additional_ISO_Coverage_query = '''
SELECT DISTINCT
    concat('CA7DOCCovBroadCovForNamedIndivsLiab:',trim(PolicyNumber),'_','CA7CovType51') AS pmt_id,
    concat('CA7LineSchedCovItemCov:',trim(PolicyNumber),'_','CA7DOCCovBroadCovForNamedIndivsLiab') AS pmt_parent,
    'CA7LineSchedCovItemCov' AS pmt_parent_type,
    'CA7CovType51' AS CodeIdentifier,
    CASE WHEN trim(LiabilityType) = '1' THEN 'CombinedSingleLimit'
         WHEN trim(LiabilityType) = '2' THEN 'SplitLimit'
         ELSE 'NoCoverage' 
    END AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Additional_ISO_Coverage_data
WHERE trim(PredominantStateCode) IS NOT NULL AND trim(CoveragesApplicable) = '1'

UNION ALL

SELECT DISTINCT
    concat('CA7DOCCovBroadCovForNamedIndivsLiab:',trim(PolicyNumber),'_','CA7LimitText28') AS pmt_id,
    concat('CA7LineSchedCovItemCov:',trim(PolicyNumber),'_','CA7DOCCovBroadCovForNamedIndivsLiab') AS pmt_parent,
    'CA7LineSchedCovItemCov' AS pmt_parent_type,
    'CA7LimitText28' AS CodeIdentifier,
    CASE WHEN trim(LiabilityCSLOverrideAmount) IS NULL THEN trim(LiabilityLimit)
         WHEN trim(LiabilityCSLOverrideAmount) IS NOT NULL THEN trim(LiabilityCSLOverrideAmount)
         ELSE 'NotApplicable' 
    END AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Additional_ISO_Coverage_data
WHERE trim(PredominantStateCode) IS NOT NULL AND trim(CoveragesApplicable) = '1'

UNION ALL

SELECT DISTINCT
    concat('CA7DOCCovBroadCovForNamedIndivsLiab:',trim(PolicyNumber),'_','CA7PropertyDamageLimit14') AS pmt_id,
    concat('CA7LineSchedCovItemCov:',trim(PolicyNumber),'_','CA7DOCCovBroadCovForNamedIndivsLiab') AS pmt_parent,
    'CA7LineSchedCovItemCov' AS pmt_parent_type,
    'CA7PropertyDamageLimit14' AS CodeIdentifier,
    CASE WHEN trim(PropertyDamageLiabilityLimit) IS NULL THEN trim(LiabilityLimit)
         WHEN trim(PropertyDamageLiabilityLimit) IS NOT NULL THEN trim(PropertyDamageLiabilityLimit)
         ELSE 'NotApplicable' 
    END AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Additional_ISO_Coverage_data
WHERE trim(PredominantStateCode) IS NOT NULL AND trim(CoveragesApplicable) = '1'

UNION ALL

SELECT DISTINCT
    concat('CA7DOCCovBroadCovForNamedIndivsMedPay:',trim(PolicyNumber),'_','CA7LimitText37') AS pmt_id,
    concat('CA7LineSchedCovItemCov:',trim(PolicyNumber),'_','CA7DOCCovBroadCovForNamedIndivsMedPay') AS pmt_parent,
    'CA7LineSchedCovItemCov' AS pmt_parent_type,
    'CA7LimitText37' AS CodeIdentifier,
    CASE WHEN trim(MedPayLimit) IS NOT NULL THEN trim(MedPayLimit)
         WHEN trim(MedPayLimit) IS NULL THEN 'NoCoverage'
    END AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Additional_ISO_Coverage_data
WHERE trim(PredominantStateCode) IS NOT NULL AND trim(CoveragesApplicable) = '2'

UNION ALL

SELECT DISTINCT
    concat('CA7DOCCovBroadCovForNamedIndivsMedPay:',trim(PolicyNumber),'_','CA7SubjectToNoFault') AS pmt_id,
    concat('CA7LineSchedCovItemCov:',trim(PolicyNumber),'_','CA7DOCCovBroadCovForNamedIndivsMedPay') AS pmt_parent,
    'CA7LineSchedCovItemCov' AS pmt_parent_type,
    'CA7SubjectToNoFault' AS CodeIdentifier,
    'No' AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Additional_ISO_Coverage_data
WHERE trim(PredominantStateCode) IS NOT NULL AND trim(CoveragesApplicable) = '2'

UNION ALL

SELECT DISTINCT
    concat('CA7DOCCovBroadCovForNamedIndivsOthThanCollision:',trim(PolicyNumber),'_','CA7Wanted42') AS pmt_id,
    concat('CA7LineSchedCovItemCov:',trim(PolicyNumber),'_','CA7DOCCovBroadCovForNamedIndivsOthThanCollision') AS pmt_parent,
    'CA7LineSchedCovItemCov' AS pmt_parent_type,
    'CA7Wanted42' AS CodeIdentifier,
    CASE WHEN trim(CoveragesApplicable) = '4' THEN 'Yes' ELSE 'No' END AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Additional_ISO_Coverage_data
WHERE trim(PredominantStateCode) IS NOT NULL AND trim(CoveragesApplicable) = '4'

UNION ALL

SELECT DISTINCT
    concat('CA7DOCCovBroadCovForNamedIndivsOthThanCollision:',trim(PolicyNumber),'_','CA7OthThanCollision') AS pmt_id,
    concat('CA7LineSchedCovItemCov:',trim(PolicyNumber),'_','CA7DOCCovBroadCovForNamedIndivsOthThanCollision') AS pmt_parent,
    'CA7LineSchedCovItemCov' AS pmt_parent_type,
    'CA7OthThanCollision' AS CodeIdentifier,
    CASE WHEN trim(CoveragesApplicable) = '4' THEN 'Yes' ELSE 'No' END AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Additional_ISO_Coverage_data
WHERE trim(PredominantStateCode) IS NOT NULL AND trim(CoveragesApplicable) = '4'

UNION ALL

--SELECT DISTINCT
--    concat('CA7DOCCovBroadCovForNamedIndivsOthThanCollision:',trim(PolicyNumber),'_','CA7DedType5') AS pmt_id,
--    concat('CA7LineSchedCovItemCov:',trim(PolicyNumber),'_','CA7DOCCovBroadCovForNamedIndivsOthThanCollision') AS pmt_parent,
--    'CA7LineSchedCovItemCov' AS pmt_parent_type,
--    'CA7DedType5' AS CodeIdentifier,
--     AS value,
--    trim(PolicyNumber) AS pmt_payloadid
-- FROM Additional_ISO_Coverage_data
-- WHERE trim(PredominantStateCode) IS NOT NULL AND trim(CoveragesApplicable) = '4'

--UNION ALL

SELECT DISTINCT
    concat('CA7DOCCovBroadCovForNamedIndivsOthThanCollision:',trim(PolicyNumber),'_','CA7Ded39') AS pmt_id,
    concat('CA7LineSchedCovItemCov:',trim(PolicyNumber),'_','CA7DOCCovBroadCovForNamedIndivsOthThanCollision') AS pmt_parent,
    'CA7LineSchedCovItemCov' AS pmt_parent_type,
    'CA7Ded39' AS CodeIdentifier,
    CASE WHEN trim(CompDed) IS NOT NULL THEN trim(CompDed)
         ELSE 'NotApplicable' 
    END AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Additional_ISO_Coverage_data
WHERE trim(PredominantStateCode) IS NOT NULL AND trim(CoveragesApplicable) = '4'

UNION ALL

SELECT DISTINCT
    concat('CA7DOCCovBroadCovForNamedIndivsCollision:',trim(PolicyNumber),'_','CA7Ded37') AS pmt_id,
    concat('CA7LineSchedCovItemCov:',trim(PolicyNumber),'_','CA7DOCCovBroadCovForNamedIndivsCollision') AS pmt_parent,
    'CA7LineSchedCovItemCov' AS pmt_parent_type,
    'CA7Ded37' AS CodeIdentifier,
    CASE WHEN trim(CollDed) IS NOT NULL THEN trim(CollDed)
         ELSE 'NotApplicable' 
    END AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Additional_ISO_Coverage_data
WHERE trim(PredominantStateCode) IS NOT NULL AND trim(CoveragesApplicable) = '5'

UNION ALL

--SELECT DISTINCT
--    concat('CA7DOCCovBroadCovForNamedIndivsUninsuredMotorists:',trim(PolicyNumber),'_','CA7CovType53') AS pmt_id,
--    concat('CA7LineSchedCovItemCov:',trim(PolicyNumber),'_','CA7DOCCovBroadCovForNamedIndivsUninsuredMotorists') AS pmt_parent,
--    'CA7LineSchedCovItemCov' AS pmt_parent_type,
--    'CA7CovType53' AS CodeIdentifier,
-- --LimitTypeUMUIM
-- -- 1 = 'CSL Incl PD'
-- -- 2 = 'CSL Excl PD'
-- -- 3 = 'Split Incl PD'
-- -- 4 = 'Split Excl PD'
--    CASE WHEN trim(LimitTypeUMUIM) = '1' THEN 'CSL Incl PD'
--         WHEN trim(LimitTypeUMUIM) = '2' THEN 'CSL Excl PD'
--         WHEN trim(LimitTypeUMUIM) = '3' THEN 'Split Incl PD'
--         WHEN trim(LimitTypeUMUIM) = '4' THEN 'Split Excl PD'
--         ELSE 'NotApplicable'
--    END AS value,
--    trim(PolicyNumber) AS pmt_payloadid
-- FROM Additional_ISO_Coverage_data
-- WHERE trim(PredominantStateCode) IS NOT NULL AND trim(CoveragesApplicable) = '3'

--UNION ALL

--SELECT DISTINCT
--    concat('CA7DOCCovBroadCovForNamedIndivsUninsuredMotorists:',trim(PolicyNumber),'_','CA7CombinedSingleLimitText5') AS pmt_id,
--    concat('CA7LineSchedCovItemCov:',trim(PolicyNumber),'_','CA7DOCCovBroadCovForNamedIndivsUninsuredMotorists') AS pmt_parent,
--    'CA7LineSchedCovItemCov' AS pmt_parent_type,
--    'CA7CombinedSingleLimitText5' AS CodeIdentifier,
--    CASE WHEN trim(UMUIMOverrideIndicator) = 'Y' THEN trim(UMCSL)
--         WHEN trim(UMUIMOverrideIndicator) = 'N' THEN trim(St_UMCLSLimit)
--         ELSE 'NotApplicable' END AS value,
--    trim(PolicyNumber) AS pmt_payloadid
--FROM Additional_ISO_Coverage_data
--WHERE trim(PredominantStateCode) IS NOT NULL AND trim(CoveragesApplicable) = '3'

--UNION ALL

--SELECT DISTINCT
--    concat('CA7DOCCovBroadCovForNamedIndivsUninsuredMotorists:',trim(PolicyNumber),'_','CA7SplitLimit5') AS pmt_id,
--    concat('CA7LineSchedCovItemCov:',trim(PolicyNumber),'_','CA7DOCCovBroadCovForNamedIndivsUninsuredMotorists') AS pmt_parent,
--    'CA7LineSchedCovItemCov' AS pmt_parent_type,
--    'CA7SplitLimit5' AS CodeIdentifier,
--    'NotApplicable' AS value,
--    trim(PolicyNumber) AS pmt_payloadid
--FROM Additional_ISO_Coverage_data
--WHERE trim(PredominantStateCode) IS NOT NULL AND trim(CoveragesApplicable) = '3'

--UNION ALL

--SELECT DISTINCT
--    concat('CA7DOCCovBroadCovForNamedIndivsUnderinsuredMotoris:',trim(PolicyNumber),'_','CA7CovType52') AS pmt_id,
--    concat('CA7LineSchedCovItemCov:',trim(PolicyNumber),'_','CA7DOCCovBroadCovForNamedIndivsUnderinsuredMotoris') AS pmt_parent,
--    'CA7LineSchedCovItemCov' AS pmt_parent_type,
--    'CA7CovType52' AS CodeIdentifier,
-- --LimitTypeUMUIM
-- -- 1 = 'CSL Incl PD'
-- -- 2 = 'CSL Excl PD'
-- -- 3 = 'Split Incl PD'
-- -- 4 = 'Split Excl PD'
--     CASE WHEN trim(LimitTypeUMUIM) = '1' THEN 'CSL Incl PD'
--          WHEN trim(LimitTypeUMUIM) = '2' THEN 'CSL Excl PD'
--          WHEN trim(LimitTypeUMUIM) = '3' THEN 'Split Incl PD'
--          WHEN trim(LimitTypeUMUIM) = '4' THEN 'Split Excl PD'
--          ELSE 'NotApplicable'
--     END AS value,
--     trim(PolicyNumber) AS pmt_payloadid
-- FROM Additional_ISO_Coverage_data
-- WHERE trim(PredominantStateCode) IS NOT NULL AND trim(CoveragesApplicable) = '3'

--UNION ALL

--SELECT DISTINCT
--    concat('CA7DOCCovBroadCovForNamedIndivsUnderinsuredMotoris:',trim(PolicyNumber),'_','CA7SplitLimit4') AS pmt_id,
--    concat('CA7LineSchedCovItemCov:',trim(PolicyNumber),'_','CA7DOCCovBroadCovForNamedIndivsUnderinsuredMotoris') AS pmt_parent,
--    'CA7LineSchedCovItemCov' AS pmt_parent_type,
--    'CA7SplitLimit4' AS CodeIdentifier,
--    'NotApplicable' AS value,
--    trim(PolicyNumber) AS pmt_payloadid
-- FROM Additional_ISO_Coverage_data
-- WHERE trim(PredominantStateCode) IS NOT NULL AND trim(CoveragesApplicable) = '3'

--UNION ALL

SELECT DISTINCT
    concat('CA7TrailerInterchangeAgreementComprehensive:',trim(PolicyNumber),'_','CA7LimitOfLiab1') AS pmt_id,
    concat('CA7LineSchedCovItemCov:',trim(PolicyNumber),'_','CA7TrailerInterchangeAgreementComprehensive') AS pmt_parent,
    'CA7LineSchedCovItemCov' AS pmt_parent_type,
    'CA7LimitOfLiab1' AS CodeIdentifier,
    CASE
        WHEN CAST(trim(TrailerInterchangeCompValue) AS DECIMAL) > 20000 THEN 'Over20000' ELSE trim(TrailerInterchangeCompValue) END AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Additional_ISO_Coverage_data
WHERE trim(TrailerInterchangeCompValue) IS NOT NULL
'''

try:
  CovTerm_Additional_ISO_Coverage_data = spark.sql(CovTerm_Additional_ISO_Coverage_query)
  CovTerm_Additional_ISO_Coverage_data.createOrReplaceTempView("CovTerm_Additional_ISO_Coverage_data")
  print(CovTerm_Additional_ISO_Coverage_data.count())
  display(CovTerm_Additional_ISO_Coverage_data)
except Exception as e:
  logger.info("error loading CovTerm_Additional_ISO_Coverage_data: {}".format(e)) 
  sys.exit(1) 

# COMMAND ----------

# DBTITLE 1,Writing Covterm in PMTIN
CA7LineSchedCovItemCov =execute_select_PMTIN("select * from CA7LineSchedCovItemCov")
CA7LineSchedCovItemCov.createOrReplaceTempView("CA7LineSchedCovItemCov")
# SQL to find mismatching pmt_parent, count null pmt_id, and check for duplicates for ca7haucov data
invalid_refs_sql = """
SELECT DISTINCT pmt_parent
FROM CovTerm_Additional_ISO_Coverage_data
WHERE pmt_parent NOT IN (
  SELECT DISTINCT pmt_id FROM CA7LineSchedCovItemCov
)
"""

null_pmt_id_sql = """
SELECT COUNT(*) as null_count
FROM CovTerm_Additional_ISO_Coverage_data
WHERE pmt_id IS NULL
"""

duplicate_pmt_id_sql = """
SELECT pmt_id, COUNT(*) as cnt
FROM CovTerm_Additional_ISO_Coverage_data
GROUP BY pmt_id

HAVING COUNT(*) > 1
"""


invalid_refs = spark.sql(invalid_refs_sql)
null_pmt_id_count = spark.sql(null_pmt_id_sql).collect()[0]['null_count']
duplicate_pmt_ids = spark.sql(duplicate_pmt_id_sql)

if invalid_refs.count() == 0 and null_pmt_id_count == 0 and duplicate_pmt_ids.count() == 0:
    logger.info('referential integrity checks passed')
    logger.info('No Null pmt_id values found')
    logger.info('No duplicate pmt_id values found')

    CovTerm_Additional_ISO_Coverage_data.write.jdbc(url=jdbc_url_pmtin, table='covterm', mode='append', properties=properties)
else:
    if invalid_refs.count() > 0:
        logger.error("Referential integrity issue: Some pmt_parent values do not exist in CA7LineSchedCovItemCov.")
        for row in invalid_refs.collect():
            logger.error(f"Invalid pmt_parent: {row.pmt_parent}")
    if null_pmt_id_count > 0:
        logger.error(f"Null pmt_id values found in CovTerm_Additional_ISO_Coverage_data: {null_pmt_id_count}")
    if duplicate_pmt_ids.count() > 0:
        logger.error("Duplicate pmt_id values found in CovTerm_Additional_ISO_Coverage_data.")
        for row in duplicate_pmt_ids.collect():
            logger.error(f"Duplicate pmt_id: {row.pmt_id} with count: {row.cnt}")
            

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Line Additional ISO by Anurag

# COMMAND ----------

additional_ISO_Coverages_query = '''
 /* -------------------------------------------------------------------------------------------------------------- */
/* Sprint_6_NOVA_218__29_45_54                                                                                    */
/* 09/26/2025 (pstemp)                                                                                            */
/* Views used:                                                                                                    */
/* ViewCurPic_AuPolPollutionInput - 29 (Pollution Liability)                                                      */
/* ViewCurPic_GrLocDrvAwyCollInput - 45 (Dealers Driveaway Collision)                                             */
/* ViewCurPic_AuPolFreeformInput - 54 (Employee Benefits Liability)                                               */
/* -------------------------------------------------------------------------------------------------------------- */

/* -------------------------------------------------------------------------------------------------------------- */
/* First SQL returns all states for the forms needed                                                              */
/* -------------------------------------------------------------------------------------------------------------- */
select 
/* ---------------------- */
/* CoPolicyPointer fields */
/* ---------------------- */
P."SystemAssignId"
, P."PolicyPrefixCd" || ' ' || TRIM(P."PolicyId") || COALESCE(TRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber"
 ,   CAST(TRIM(P."PolicyId") || COALESCE(TRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber"
,P."PolicyEffDt"

/* -------------------------------- */
/* ViewCurPic_CoPolicyDetail Fields */
/* -------------------------------- */
,CoPolicyDetail."PredStateCd" AS PredominantStateCode


/* --------------------------- */
/* ViewCurPic_AuStInput fields */
/* --------------------------- */
,AuStInput."StateCd"

/* ------------------------------------- */
/* ViewCurPic_AUSelectedForm fields      */
/* ------------------------------------- */
,AUSelectedForm."FormId"
,AUSelectedForm."FormEdCd" AS FormEditionCode
,AUSelectedForm."FormDescTx" AS FormDescription

/* ------------------------------------- */
/* ViewCurPic_AUFormFillin fields        */
/* ------------------------------------- */
----,AUFormFillin.FillinTx AS PersonOrOrganization
----,AUFormFillin.PageNo AS PageNumber
----,AuFormFillin.OccurrenceNo AS OccurenceNumber

/* --------------------------------------- */
/* AuPolPollutionInput Fields NOVA-218, 29 */
/* --------------------------------------- */
/* --------------------------------------- */
/* PollutionChangeTypeCode Info:           */
/* 1 - Percent                             */
/* 2 - Flat charge                         */
/* --------------------------------------- */
,AuPolPollutionInput."ChrgTypeCd" AS PollutionChangeTypeCode
,AuPolPollutionInput."SurchFct" AS PollutionPercentage
,AuPolPollutionInput."FlatChrgAmt" AS PollutionFlatChargeAmount
,AuPolPollutionInput."MinPremAmt" AS PollutionMinimumPremiumAmount

/* --------------------------------------------------- */
/* ViewCurPic_GrLocDrvAwyCollInput fields NOVA-218, 45 */
/* --------------------------------------------------- */
/* --------------------------------------------------- */
/* DealerDrivewayIndBlanket info                       */
/* 1 - Individual                                      */          
/* 2   Blanket                                         */
/* --------------------------------------------------- */
,GrLocDrvAwyCollInput."CoverageTypeNCd" AS DealerDrivewayIndBlanket
,GrLocDrvAwyCollInput."FactoryPriceNewAmt" AS DealerDrivewayPriceNew
,GrLocDrvAwyCollInput."MileageAmt" AS DealerDrivewayMilage
,GrLocDrvAwyCollInput."DedAmt" AS DealerDrivewayDeductible
,GrLocDrvAwyCollInput."CoveredAutoCnt" AS DealerDrivewayNumberOfAutos
,GrLocDrvAwyCollInput."TripsCnt" AS DealerDrivewayNumberOfTrips

/* ------------------------------------------------ */
/* ViewCurPic_AuPolFreeformInput field NOVA-218, 54 */
/* ------------------------------------------------ */
,AuPolFreeformInput."Limit1" AS EmployeeBenefitsLiabilityAggregateLimit
,AuPolFreeformInput."RiskTypeCd" AS EmployeeBenefitsLiabilityTypeOfCharge
,AuPolFreeformInput."Prem1Amt" AS EmployeeBenefitsLiabilityPremiumCharge
,AuPolFreeformInput."FlatChargeInd" AS EmployeeBenefitsLiabilityFlatCharge
,AuPolFreeformInput."FullyEarnedInd" AS EmployeeBenefitsLiabilityFullyEarned

FROM Policy P1 
INNER JOIN CoPolicyPointer P
   ON P."SystemAssignId" = P1."SourceSystemId"
INNER JOIN ViewCurPic_CoPolicyDetail CoPolicyDetail
ON P."SystemAssignId" = CoPolicyDetail."SystemAssignId"
LEFT JOIN ViewCurPic_AuPolFreeformInput AuPolFreeformInput
ON P."SystemAssignId" = AuPolFreeformInput."SystemAssignId"
INNER JOIN ViewCurPic_AuStInput AuStInput
   ON P."SystemAssignId" = AuStInput."SystemAssignId"
LEFT JOIN ViewCurPic_AUSelectedForm AUSelectedForm
   ON P."SystemAssignId" = AUSelectedForm."SystemAssignId"
   AND AuStInput."StateCd" = AUSelectedForm."StateCd"
LEFT JOIN ViewCurPic_AuPolPollutionInput AuPolPollutionInput
   ON P."SystemAssignId" = AuPolPollutionInput."SystemAssignId"
LEFT JOIN ViewCurPic_GrLocDrvAwyCollInput GrLocDrvAwyCollInput
   ON P."SystemAssignId" = GrLocDrvAwyCollInput."SystemAssignId"
   AND CoPolicyDetail."PredStateCd" = GrLocDrvAwyCollInput."StateCd" 
   AND GrLocDrvAwyCollInput."LocNo" = '1'
   AND GrLocDrvAwyCollInput."BldgNo" = '1'
----LEFT JOIN [GARCDB_ORSIU].[dbo].[ViewCurPic_AUFormFillin] AUFormFillin
----   ON P.SystemAssignId = AUFormFillin.SystemAssignId
----   AND AuSelectedForm.FormId = AUFormFillin.FormId


WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
AND P1."LOB" IN ('AU', 'GR', 'TU')
-----AND AuSelectedForm."FormId" IN ('CA 25 02','CA 99 55','CA 25 48','CA 26 32' ,'CA 27 01','CA 25 48.' ,'CA 25 68','CA 25 70' ,---'CA 25 71','CA 25 72' 
                             ----,'CA 25 78','CA 25 82','CA 25 86')


UNION ALL

/* -------------------------------------------------------------------------------------------------------------- */
/* Second SQL returns 'CW' County Wide state for the forms needed                                                 */
/* -------------------------------------------------------------------------------------------------------------- */

select 
/* ---------------------- */
/* CoPolicyPointer fields */
/* ---------------------- */
P."SystemAssignId"
, P."PolicyPrefixCd" || ' ' || TRIM(P."PolicyId") || COALESCE(TRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber"
 ,   CAST(TRIM(P."PolicyId") || COALESCE(TRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber"
,P."PolicyEffDt"

/* -------------------------------- */
/* ViewCurPic_CoPolicyDetail Fields */
/* -------------------------------- */
,CoPolicyDetail."PredStateCd" AS PredominantStateCode

/* ------------------------------------- */
/* ViewCurPic_AUSelectedForm fields      */
/* Added StateCd for 'CW'                */
/* ------------------------------------- */
,AUSelectedForm."StateCd" AS StateCd
,AUSelectedForm."FormId"
,AUSelectedForm."FormEdCd" AS FormEditionCode
,AUSelectedForm."FormDescTx" AS FormDescription

/* ------------------------------------- */
/* ViewCurPic_AUFormFillin fields        */
/* ------------------------------------- */
----,AUFormFillin.FillinTx AS PersonOrOrganization
----,AUFormFillin.PageNo AS PageNumber
----,AuFormFillin.OccurrenceNo AS OccurenceNumber

/* --------------------------------------- */
/* AuPolPollutionInput Fields NOVA-218, 29 */
/* --------------------------------------- */
/* --------------------------------------- */
/* PollutionChangeTypeCode Info:           */
/* 1 - Percent                             */
/* 2 - Flat charge                         */
/* --------------------------------------- */
,AuPolPollutionInput."ChrgTypeCd" AS PollutionChangeTypeCode
,AuPolPollutionInput."SurchFct" AS PollutionPercentage
,AuPolPollutionInput."FlatChrgAmt" AS PollutionFlatChargeAmount
,AuPolPollutionInput."MinPremAmt" AS PollutionMinimumPremiumAmount

/* --------------------------------------------------- */
/* ViewCurPic_GrLocDrvAwyCollInput fields NOVA-218, 45 */
/* --------------------------------------------------- */
/* --------------------------------------------------- */
/* DealerDrivewayIndBlanket info                       */
/* 1 - Individual                                      */          
/* 2   Blanket                                         */
/* --------------------------------------------------- */
,GrLocDrvAwyCollInput."CoverageTypeNCd" AS DealerDrivewayIndBlanket
,GrLocDrvAwyCollInput."FactoryPriceNewAmt" AS DealerDrivewayPriceNew
,GrLocDrvAwyCollInput."MileageAmt" AS DealerDrivewayMilage
,GrLocDrvAwyCollInput."DedAmt" AS DealerDrivewayDeductible
,GrLocDrvAwyCollInput."CoveredAutoCnt" AS DealerDrivewayNumberOfAutos
,GrLocDrvAwyCollInput."TripsCnt" AS DealerDrivewayNumberOfTrips

/* ------------------------------------------------ */
/* ViewCurPic_AuPolFreeformInput field NOVA-218, 54 */
/* ------------------------------------------------ */
,AuPolFreeformInput."Limit1" AS EmployeeBenefitsLiabilityAggregateLimit
,AuPolFreeformInput."RiskTypeCd" AS EmployeeBenefitsLiabilityTypeOfCharge
,AuPolFreeformInput."Prem1Amt" AS EmployeeBenefitsLiabilityPremiumCharge
,AuPolFreeformInput."FlatChargeInd" AS EmployeeBenefitsLiabilityFlatCharge
,AuPolFreeformInput."FullyEarnedInd" AS EmployeeBenefitsLiabilityFullyEarned


FROM Policy P1 
INNER JOIN CoPolicyPointer P
   ON P."SystemAssignId" = P1."SourceSystemId"
INNER JOIN ViewCurPic_CoPolicyDetail CoPolicyDetail
   ON P."SystemAssignId" = CoPolicyDetail."SystemAssignId"
INNER JOIN ViewCurPic_AuPolInput AuPolInput
   ON P."SystemAssignId" = AUPolInput."SystemAssignId"
LEFT JOIN ViewCurPic_AuPolFreeformInput AuPolFreeformInput
ON P."SystemAssignId" = AuPolFreeformInput."SystemAssignId"
--INNER JOIN [GARCDB_ORSIU].[dbo].[ViewCurPic_AuStInput] AuStInput
--   ON P.SystemAssignId = AuStInput.SystemAssignId
LEFT JOIN ViewCurPic_AUSelectedForm AUSelectedForm
   ON P."SystemAssignId" = AUSelectedForm."SystemAssignId"
   AND AUSelectedForm."StateCd" = 'CW'
LEFT JOIN ViewCurPic_AuPolPollutionInput AuPolPollutionInput
   ON P."SystemAssignId" = AuPolPollutionInput."SystemAssignId"
LEFT JOIN ViewCurPic_GrLocDrvAwyCollInput GrLocDrvAwyCollInput
   ON P."SystemAssignId" = GrLocDrvAwyCollInput."SystemAssignId"
   AND CoPolicyDetail."PredStateCd" = GrLocDrvAwyCollInput."StateCd" 
   AND GrLocDrvAwyCollInput."LocNo" = '1'
   AND GrLocDrvAwyCollInput."BldgNo" = '1'
----LEFT JOIN [GARCDB_ORSIU].[dbo].[ViewCurPic_AUFormFillin] AUFormFillin
----   ON P.SystemAssignId = AUFormFillin.SystemAssignId
----   AND AuSelectedForm.FormId = AUFormFillin.FormId

WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
AND P1."LOB" IN ('AU', 'GR', 'TU')
-------AND AuSelectedForm."FormId" IN ('CA 25 02','CA 99 55','CA 25 48','CA 26 32' ,'CA 27 01','CA 25 48.' ,'CA 25 68','CA 25 70' ,---'CA 25 71','CA 25 72' 
                             ------,'CA 25 78','CA 25 82','CA 25 86')




Order by "PolicyNumber", "StateCd", "FormId"

'''

try:
  # Execute the query and create a temp view for downstream use
  additional_ISO_Coverages_data = eval(exec_select_landing)(additional_ISO_Coverages_query)
  additional_ISO_Coverages_data.createOrReplaceTempView("additional_ISO_Coverages_data")  # Create a temporary view for further processing
  print(additional_ISO_Coverages_data.count())  # Print the count of records retrieved
  display(additional_ISO_Coverages_data)  # Display the results
except Exception as e:
  # Log the error and exit if there is an issue loading the data
  logger.info("error loading additional_ISO_Coverages_data: {}".format(e)) 
  sys.exit(1)


# COMMAND ----------

# DBTITLE 1,Query to get PMT_ID and PMT_Parent
additional_iso_cov_trans_query = '''
    SELECT DISTINCT
        concat('CA7CommAutoLineCov:', trim(PolicyNumber), '_', codeidentifier) AS pmt_id,
        concat('CA7CAL_', PolicyNumber) AS pmt_parent,
        codeidentifier,
        Currency,
        dealerdrivewayindblanket,
        dealerdrivewaypricenew,
        dealerdrivewaymilage,
        dealerdrivewaydeductible,
        dealerdrivewaynumberofautos,
        dealerdrivewaynumberoftrips,
        max(employeebenefitsliabilityaggregatelimit) over (partition by pmt_payloadid) as employeebenefitsliabilityaggregatelimit,
        max(pollutionminimumpremiumamount) over (partition by pmt_payloadid) as pollutionminimumpremiumamount,
        pmt_payloadid
    FROM (
        
        SELECT 
            PolicyNumber,
            CASE 
                WHEN trim(FormId) = 'PCA 99 55' THEN 'CA7PollutionLiabBroadCovForCovrdAutosGarageCovForm' 
                WHEN trim(FormId) = 'PCA 25 59' THEN 'CA7DesignatedLocationsGeneralLiabAggLimitForCerta2' 
                WHEN trim(FormId) IN ('CA 23 30','CA 23 07 VA','CA 23 29 HI','CA 23 31 AK','CA 23 40 MN','CA 05 29 WA','CA 23 3') THEN 'CA7MotorCarrierEndorsement1' 
                WHEN trim(FormId) = 'CA 20 56' THEN 'CA7FellowEmplCovForDesignatedEmplsPoss'
                WHEN trim(FormId) = 'CA 20 09' THEN 'CA7LeasingOrRentalConcernsContingent1'
                WHEN trim(FormId) = 'CA 20 55' THEN 'CA7FellowEmplCov'
                WHEN trim(FormId) IN ('CA 20 70','CA 20 75 NY') THEN 'CA7CovForCertainOpsInConnectionWithRailroads'
                WHEN trim(FormId) = 'CA 25 02' THEN 'CA7DealersDriveAwayCollision'
                WHEN trim(FormId) IN ('CA 99 17','CA 04 25 CA') THEN 'CA7IndividualNamedInsured'
                WHEN trim(FormId) = 'CA 23 04' THEN 'CA7RollingStores'
                WHEN trim(FormId) IN ('CA 99 90','CA 04 28 VA') THEN 'CA7OptionalLmtsLossOfUseExpenses'
                WHEN trim(FormId) IN ('CA 25 48 VA','CA 26 32 NC','CA 27 01 MI','CA 25 48. (IL)','CA 25 68 MT','CA 25 70 CO','CA 25 71 WY','CA 25 72 NH','CA 25 78 CT','CA 25 82 NM','CA 25 86 IL') THEN 'CA7EmplBenefitsLiab'
                WHEN trim(FormId) = 'CA 23 08' THEN 'CA7TruckersExcessCovForNamedInsuredAndNamedLessors'
            END AS codeidentifier,
            'usd' AS Currency,
            dealerdrivewayindblanket,
            dealerdrivewaypricenew,
            dealerdrivewaymilage,
            dealerdrivewaydeductible,
            dealerdrivewaynumberofautos,
            dealerdrivewaynumberoftrips,
            employeebenefitsliabilityaggregatelimit,
            pollutionminimumpremiumamount,
            trim(PolicyNumber) AS pmt_payloadid
        FROM additional_ISO_Coverages_data
        WHERE trim(FormId) IN (
            'PCA 99 55','PCA 25 59','CA 23 30','CA 23 07 VA','CA 23 29 HI','CA 23 31 AK','CA 23 40 MN','CA 05 29 WA','CA 23 3',
            'CA 20 56','CA 20 09','CA 20 55','CA 20 70','CA 20 75 NY','CA 25 02','CA 99 17','CA 04 25 CA','CA 23 04',
            'CA 99 90','CA 04 28 VA','CA 25 48 VA','CA 26 32 NC','CA 27 01 MI','CA 25 48. (IL)','CA 25 68 MT','CA 25 70 CO',
            'CA 25 71 WY','CA 25 72 NH','CA 25 78 CT','CA 25 82 NM','CA 25 86 IL','CA 23 08'
        )
    ) 
    WHERE codeidentifier IS NOT NULL
'''

try:
    additional_iso_cov_trans_data = spark.sql(additional_iso_cov_trans_query)
    additional_iso_cov_trans_data.createOrReplaceTempView("additional_iso_cov_trans_data")
    print(additional_iso_cov_trans_data.count())
    display(additional_iso_cov_trans_data)
except Exception as e:
    logger.info("error loading additional_iso_cov_trans_data: {}".format(e)) 
    sys.exit(1)

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##Hired Auto Standard And Additional Coverage Covetrms

# COMMAND ----------

# DBTITLE 1,ETL query for Hired Auto
Hired_Auto_ISO_Coverages_query = '''
    /* -------------------------------------------------------------------------------------------------------------- */
/* NOTE: */
/* **** This SQL runs for 20 - 30 minutes, probably due to out of sequence transactions in Policy Decisions */
/* **** So it does full table scans to get the results */
/* Sprint_6_CA Hired Auto Coverages */
/* 09/26/2025 (pstemp) */
/* Forms to research: */
/* CA 20 33 - Autos Leased, Hired, Rented Or Borrowed With Drivers - Physical Damage */
/* CA 99 23 - Rental Reimbursement */
/* CA 04 39 - Volunteer Hired Autos */
/* CA 20 54 - Employee Hired Autos */
/* Added view ViewCurPic_AuStHiredPDInput */
/* 09/30/2025 (pstemp) */
/* Added fields: */
/* HiredAutoLiabilityExcessHiredAmount */
/* HiredAutoLiabilityPrimaryHiredAmount */
/* 10/01/2025 (pstemp) */
/* Added CTE ReimbursementRentalCoverage_Dedup to get Rental Reimbursement Info at the Vehicle Level */
/* -------------------------------------------------------------------------------------------------------------- */

/* -------------------------------------------------------------------------------------------------------------- */
/* CTE to pull Reimbursement Rental Coverage at the Vehicle Level */
/* -------------------------------------------------------------------------------------------------------------- */
WITH ReimbursementRentalCoverage_Dedup AS (
    SELECT DISTINCT 
        "SystemAssignId",
        "StateCd",
        "RentalCovgCd",
        "RentalReimbMaxAmt",
        "MaxDaysNo",
        ROW_NUMBER() OVER (PARTITION BY "SystemAssignId", "StateCd" ORDER BY "VehicleNo" ASC) AS "DupNum"
    FROM ViewCurPic_AuVehRentReimInput
)

-- First SQL returns all states for the forms needed
SELECT 
/* ---------------------- */
/* CoPolicyPointer fields */
/* ---------------------- */
    P."SystemAssignId",
    P."PolicyPrefixCd" || ' ' || TRIM(P."PolicyId") || COALESCE(TRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
    CAST(TRIM(P."PolicyId") || COALESCE(TRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",
    P."PolicyEffDt",

/* ------------------------------ */
/* ViewCurPic_CoPolicyDetail Fields */
/* ------------------------------ */
    CoPolicyDetail."PredStateCd" AS "PredominantStateCode",

/* ------------------------------ */
/* ViewCurPic_AuStInput fields */
/* ------------------------------ */
    AuStInput."StateCd",
    AuStInput."ExcessHiredAmt" AS "HiredAutoLiabilityExcessHiredAmount",
    AuStInput."PrimaryHiredAmt" AS "HiredAutoLiabilityPrimaryHiredAmount",

/* ------------------------------ */
/* ViewCurPic_AUSelectedForm fields */
/* ------------------------------ */
    AUSelectedForm."FormId",
    AUSelectedForm."FormEdCd" AS "FormEditionCode",
    AUSelectedForm."FormDescTx" AS "FormDescription",

/* ------------------------------ */
/* ViewCurPic_AuStHiredPDInput Fields */
/* FormID CA 20 33 (Null because its CW) */
/* ------------------------------ */
    NULL AS "HiredAutoPDPremiumTypeCode",
    NULL AS "HiredAutoPDOTCCostOfHireAmount",
    NULL AS "HiredAutoPDOTCDeductibleAmt",
    NULL AS "HiredAutoPDCollCostOfHireAmount",
    NULL AS "HiredAutoPDCollDeductibleAmount",

/* ------------------------------ */
/* ViewCurPic_AuVehRentReimInput Fields */
/* Via CTE ReimbursementRentalCoverage_Dedup */
/* ------------------------------ */
    ReimbursementRentalCoverage."RentalCovgCd" AS "RentalCoverage",
    ReimbursementRentalCoverage."RentalReimbMaxAmt" AS "RentalMaximumAmountPerDay",
    ReimbursementRentalCoverage."MaxDaysNo" AS "RentalMaximumNumberOfDays",
/* ------------------------------------*/
/* ViewCurPic_AuPolInput Fields */
/* ------------------------------------*/
AuPolInput."LiabSymbolLst" AS "LiabSymbolLst",
AuPolInput."LiabLimitTypeCd" AS "LiabLimitTypeCd"

FROM Policy AS P1
INNER JOIN CoPolicyPointer AS P
    ON P."SystemAssignId" = P1."SourceSystemId"
INNER JOIN ViewCurPic_CoPolicyDetail AS CoPolicyDetail
    ON P."SystemAssignId" = CoPolicyDetail."SystemAssignId"
INNER JOIN ViewCurPic_AuPolInput AuPolInput
   ON P."SystemAssignId" = AUPolInput."SystemAssignId"
INNER JOIN ViewCurPic_AuStInput AS AuStInput
    ON P."SystemAssignId" = AuStInput."SystemAssignId"
LEFT JOIN ViewCurPic_AUSelectedForm AS AUSelectedForm
    ON P."SystemAssignId" = AUSelectedForm."SystemAssignId"
    AND AuStInput."StateCd" = AUSelectedForm."StateCd"
LEFT JOIN ReimbursementRentalCoverage_Dedup AS ReimbursementRentalCoverage
    ON P."SystemAssignId" = ReimbursementRentalCoverage."SystemAssignId"
    AND AuStInput."StateCd" = ReimbursementRentalCoverage."StateCd"
    AND ReimbursementRentalCoverage."DupNum" = 1
----LEFT JOIN [Garcdb].[dbo].[ViewCurPic_AUFormFillin] AUFormFillin
----   ON P.SystemAssignId = AUFormFillin.SystemAssignId
----   AND AuSelectedForm.FormId = AUFormFillin.FormId

WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
  AND P1."LOB" IN ('AU', 'TU')
  AND TRIM(AUSelectedForm."FormId") IN ('CA 20 33','CA 99 23','CA 04 39','CA 20 54')

UNION ALL

-- Second SQL returns 'CW' County Wide state for the forms needed
SELECT 
/* ---------------------- */
/* CoPolicyPointer fields */
/* ---------------------- */
    P."SystemAssignId",
    P."PolicyPrefixCd" || ' ' || TRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
    CAST(TRIM(P."PolicyId") || COALESCE(TRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",
    P."PolicyEffDt",

/* ------------------------------ */
/* ViewCurPic_CoPolicyDetail Fields */
/* ------------------------------ */
    CoPolicyDetail."PredStateCd" AS "PredominantStateCode",

/* ------------------------------ */
/* ViewCurPic_AUSelectedForm fields */
/* Added StateCd for 'CW' */
/* ------------------------------ */
    AUSelectedForm."StateCd" AS "StateCd",
    NULL AS "HiredAutoLiabilityExcessHiredAmount",
    NULL AS "HiredAutoLiabilityPrimaryHiredAmount",
    AUSelectedForm."FormId",
    AUSelectedForm."FormEdCd" AS "FormEditionCode",
    AUSelectedForm."FormDescTx" AS "FormDescription",

/* ------------------------------ */
/* ViewCurPic_AuStHiredPDInput Fields */
/* FormID CA 20 33 for PredominantStateCode */
/* ------------------------------ */
/* HiredAutoPDPremiumTypeCode info: */
/* Flat Charge = 1 */
/* Cost of Hire = 2 */
/* System Rated = 3 */
    AuStHiredPDInput."PremTypeCd" AS "HiredAutoPDPremiumTypeCode",
    AuStHiredPDInput."OTCCostHireAmt" AS "HiredAutoPDOTCCostOfHireAmount",
    AuStHiredPDInput."OTCDedAmt" AS "HiredAutoPDOTCDeductibleAmt",
    AuStHiredPDInput."CollCostHireAmt" AS "HiredAutoPDCollCostOfHireAmount",
    AuStHiredPDInput."CollHireDedAmt" AS "HiredAutoPDCollDeductibleAmount",

/* ------------------------------ */
/* ViewCurPic_AuVehRentReimInput Fields */
/* Via CTE ReimbursementRentalCoverage_Dedup */
/* ------------------------------ */
/* RentalCoverage Info */
/* 1 - Comprehensive */
/* 2 - Specified Perils */
/* 3 - Collision */
/* 1,3 - Comprehensive and Collision */
/* 2,3 - Specified Perils and Collision */
    ReimbursementRentalCoverage."RentalCovgCd" AS "RentalCoverage",
    ReimbursementRentalCoverage."RentalReimbMaxAmt" AS "RentalMaximumAmountPerDay",
    ReimbursementRentalCoverage."MaxDaysNo" AS "RentalMaximumNumberOfDays",

/* ------------------------------------- */
/* ViewCurPic_AUFormFillin fields        */
/* ------------------------------------- */
----,AUFormFillin.FillinTx AS PersonOrOrganization,
----,AUFormFillin.PageNo AS PageNumber,
----,AuFormFillin.OccurrenceNo AS OccurenceNumber,
/* ------------------------------------*/
/* ViewCurPic_AuPolInput Fields */
/* ------------------------------------------------------------------------ */
/* Symbol List Info                                                         */
/* 1-Any Auto                                                               */
/* 2-Owned Autos                                                            */
/* 3-Owned Private Passenger Autos                                          */
/* 4-Owned Autos Other Than Private Passenger                               */
/* 5-Owned Autos Subject to PIP                                             */
/* 6-Owned Autos Subject to Compulsory UM Law                               */
/* 7-Specifically Described Autos                                           */
/* 8-Hired Autos                                                            */
/* 9-Non-Owned Autos                                                        */
/* 19-Mobile Equip Subject to Compulsory, F.R. or Other Motor Vehicle Law<  */
/* ------------------------------------------------------------------------ */
/* ------------------------------------*/
SymbolLst."LiabSymbolLst" AS "LiabSymbolLst",
AuPolInput."LiabLimitTypeCd" AS "LiabLimitTypeCd"

FROM Policy AS P1
INNER JOIN CoPolicyPointer AS P
    ON P."SystemAssignId" = P1."SourceSystemId"
INNER JOIN ViewCurPic_CoPolicyDetail AS CoPolicyDetail
    ON P."SystemAssignId" = CoPolicyDetail."SystemAssignId"
INNER JOIN ViewCurPic_AuPolInput AuPolInput
   ON P."SystemAssignId" = AUPolInput."SystemAssignId"
----LEFT JOIN [Garcdb].[dbo].[AuPolOthCovgInput] AuPolOthCovgInput
----ON P.SystemAssignId = AuPolOthCovgInput.SystemAssignId
--INNER JOIN [Garcdb].[dbo].[ViewCurPic_AuStInput] AuStInput
--   ON P.SystemAssignId = AuStInput.SystemAssignId
LEFT JOIN ViewCurPic_AuStHiredPDInput AS AuStHiredPDInput
    ON P."SystemAssignId" = AuStHiredPDInput."SystemAssignId"
    AND CoPolicyDetail."PredStateCd" = AuStHiredPDInput."StateCd"
LEFT JOIN ViewCurPic_AUSelectedForm AS AUSelectedForm
    ON P."SystemAssignId" = AUSelectedForm."SystemAssignId"
    AND AUSelectedForm."StateCd" = 'CW'
LEFT JOIN ReimbursementRentalCoverage_Dedup AS ReimbursementRentalCoverage
    ON P."SystemAssignId" = ReimbursementRentalCoverage."SystemAssignId"
    AND CoPolicyDetail."PredStateCd" = ReimbursementRentalCoverage."StateCd"
    AND ReimbursementRentalCoverage."DupNum" = 1
LEFT JOIN LATERAL (
    SELECT unnest(string_to_array(AuPolInput."LiabSymbolLst", ',')) AS "LiabSymbolLst"
) AS SymbolLst ON true
----LEFT JOIN [Garcdb].[dbo].[ViewCurPic_AUFormFillin] AUFormFillin
----   ON P.SystemAssignId = AUFormFillin.SystemAssignId
----   AND AuSelectedForm.FormId = AUFormFillin.FormId

WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
  AND P1."LOB" IN ('AU','TU')
  AND TRIM(AUSelectedForm."FormId") IN ('CA 20 33','CA 99 23','CA 04 39','CA 20 54')

ORDER BY "PolicyNumber", "StateCd", "FormId"
'''

try:
  # Execute the query and create a temp view for downstream use
  Hired_Auto_ISO_Coverages_data = eval(exec_select_landing)(Hired_Auto_ISO_Coverages_query)
  Hired_Auto_ISO_Coverages_data.createOrReplaceTempView("Hired_Auto_ISO_Coverages_data")  # Create a temporary view for further processing
  print(Hired_Auto_ISO_Coverages_data.count())  # Print the count of records retrieved
  display(Hired_Auto_ISO_Coverages_data)  # Display the results
except Exception as e:
  # Log the error and exit if there is an issue loading the data
  logger.info("error loading Hired_Auto_ISO_Coverages_data: {}".format(e)) 
  sys.exit(1)


# COMMAND ----------

# DBTITLE 1,Covterm of Hired Auto Coverages
CovTerm_Hired_Auto_Coverage_query = '''
SELECT DISTINCT
    concat('CA7HiredAutoOthThanCollisionHAU:',trim(PolicyNumber),'_','CA7CovType90') AS pmt_id,
    concat('CA7HAUCov:',trim(PolicyNumber),'_', 'CA7HiredAutoOthThanCollisionHAU') AS pmt_parent,
    'CA7HAUCov' AS pmt_parent_type,
    'CA7CovType90' AS CodeIdentifier,
    CASE WHEN trim(HiredAutoPDOTCDeductibleAmt) IS NULL THEN 'NoCoverage' ELSE 'Comprehensive' END AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Hired_Auto_ISO_Coverages_data
WHERE trim(FormId) = 'CA 20 33' AND trim(HiredAutoPDOTCCostOfHireAmount) IS NOT NULL

UNION ALL

SELECT DISTINCT
    concat('CA7HiredAutoOthThanCollisionHAU:',trim(PolicyNumber),'_','CA7Ded95') AS pmt_id,
    concat('CA7HAUCov:',trim(PolicyNumber),'_', 'CA7HiredAutoOthThanCollisionHAU') AS pmt_parent,
    'CA7HAUCov' AS pmt_parent_type,
    'CA7Ded95' AS CodeIdentifier,
    CASE WHEN lower(trim(HiredAutoPDOTCDeductibleAmt)) = 'full' THEN 'FullCoverage'
         WHEN trim(HiredAutoPDOTCDeductibleAmt) IS NULL THEN 'NoDeductible'
         ELSE trim(HiredAutoPDOTCDeductibleAmt) END AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Hired_Auto_ISO_Coverages_data
WHERE trim(FormId) = 'CA 20 33' AND trim(HiredAutoPDOTCCostOfHireAmount) IS NOT NULL

UNION ALL

SELECT DISTINCT
    concat('CA7HiredAutoCollisionHAU:',trim(PolicyNumber),'_','CA7CovType2') AS pmt_id,
    concat('CA7HAUCov:',trim(PolicyNumber),'_','CA7HiredAutoCollisionHAU') AS pmt_parent,
    'CA7HAUCov' AS pmt_parent_type,
    'CA7CovType2' AS CodeIdentifier,
     CASE 
        WHEN trim(HiredAutoPDCollDeductibleAmount) IS NULL OR trim(HiredAutoPDCollDeductibleAmount) = '' THEN 'NoCoverage'
        ELSE 'Collision'
    END AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Hired_Auto_ISO_Coverages_data
WHERE trim(FormId) = 'CA 20 33' AND trim(HiredAutoPDCollCostOfHireAmount) IS NOT NULL

UNION ALL

SELECT DISTINCT
    concat('CA7HiredAutoCollisionHAU:',trim(PolicyNumber),'_','CA7Ded93') AS pmt_id,
    concat('CA7HAUCov:',trim(PolicyNumber),'_','CA7HiredAutoCollisionHAU') AS pmt_parent,
    'CA7HAUCov' AS pmt_parent_type,
    'CA7Ded93' AS CodeIdentifier,
    CASE WHEN trim(HiredAutoPDCollDeductibleAmount) IS NULL OR trim(HiredAutoPDCollDeductibleAmount) = '' THEN 'NotApplicable'
         ELSE trim(HiredAutoPDCollDeductibleAmount) END AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Hired_Auto_ISO_Coverages_data
WHERE trim(FormId) = 'CA 20 33' AND trim(HiredAutoPDCollCostOfHireAmount) IS NOT NULL

UNION ALL

SELECT DISTINCT
    concat('CA7HiredAutoRentalVehicleHAU:',trim(PolicyNumber),'_','CA7CovStatus37') AS pmt_id,
    concat('CA7HAUCov:',trim(PolicyNumber),'_','CA7HiredAutoRentalVehicleHAU') AS pmt_parent,
    'CA7HAUCov' AS pmt_parent_type,
    'CA7CovStatus37' AS CodeIdentifier,
    CASE WHEN trim(HiredAutoPDOTCCostOfHireAmount) IS NULL THEN 'NotProvided'
         ELSE 'Provided' END AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Hired_Auto_ISO_Coverages_data
WHERE trim(PredominantStateCode) = 'NY' AND trim(HiredAutoPDOTCDeductibleAmt) IS NOT NULL AND trim(HiredAutoPDOTCCostOfHireAmount) IS NOT NULL

UNION ALL

SELECT DISTINCT
    concat('CA7HiredAutoRentalVehicleHAU:',trim(PolicyNumber),'_','CA7EstimatedAnnualCostOfHire') AS pmt_id,
    concat('CA7HAUCov:',trim(PolicyNumber),'_','CA7HiredAutoRentalVehicleHAU') AS pmt_parent,
    'CA7HAUCov' AS pmt_parent_type,
    'CA7EstimatedAnnualCostOfHire' AS CodeIdentifier,
    trim(HiredAutoPDOTCCostOfHireAmount) AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Hired_Auto_ISO_Coverages_data
WHERE trim(PredominantStateCode) = 'NY' AND trim(HiredAutoPDOTCDeductibleAmt) IS NOT NULL AND trim(HiredAutoPDOTCCostOfHireAmount) IS NOT NULL

UNION ALL

SELECT DISTINCT
    concat('CA7HiredAutoLiabHAU:',trim(PolicyNumber),'_','CA7CostOfHireInsuredProvidingExcess') AS pmt_id,
    concat('CA7HAUCov:',trim(PolicyNumber),'_', 'CA7HiredAutoLiabHAU') AS pmt_parent,
    'CA7HAUCov' AS pmt_parent_type,
    'CA7CostOfHireInsuredProvidingExcess' AS CodeIdentifier,
    trim(HiredAutoLiabilityExcessHiredAmount) AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Hired_Auto_ISO_Coverages_data
WHERE trim(HiredAutoLiabilityExcessHiredAmount) IS NOT NULL AND trim(HiredAutoLiabilityPrimaryHiredAmount) IS NOT NULL

UNION ALL

SELECT DISTINCT
    concat('CA7HiredAutoLiabHAU:',trim(PolicyNumber),'_','CA7CostOfHireInsuredProvidingPrimary') AS pmt_id,
    concat('CA7HAUCov:',trim(PolicyNumber),'_', 'CA7HiredAutoLiabHAU') AS pmt_parent,
    'CA7HAUCov' AS pmt_parent_type,
    'CA7CostOfHireInsuredProvidingPrimary' AS CodeIdentifier,
    trim(HiredAutoLiabilityPrimaryHiredAmount) AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Hired_Auto_ISO_Coverages_data
WHERE trim(HiredAutoLiabilityPrimaryHiredAmount) IS NOT NULL AND trim(HiredAutoLiabilityExcessHiredAmount) IS NOT NULL

UNION ALL

SELECT DISTINCT
    concat('CA7HiredAutoLiabHAU:',trim(PolicyNumber),'_','CA7CovType89') AS pmt_id,
    concat('CA7HAUCov:',trim(PolicyNumber),'_', 'CA7HiredAutoLiabHAU') AS pmt_parent,
    'CA7HAUCov' AS pmt_parent_type,
    'CA7CovType89' AS CodeIdentifier,
    CASE WHEN trim(LiabSymbolLst) = '8' AND trim(LiabLimitTypeCd) IS NULL THEN 'NoCoverage'
         WHEN trim(LiabSymbolLst) = '8' AND trim(LiabLimitTypeCd) = '1' THEN 'CombinedSingleLimit'
         WHEN trim(LiabSymbolLst) = '8' AND trim(LiabLimitTypeCd) = '2' THEN 'SplitLimit' END AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Hired_Auto_ISO_Coverages_data
WHERE trim(LiabSymbolLst) = '8' AND trim(HiredAutoLiabilityExcessHiredAmount) IS NOT NULL AND trim(HiredAutoLiabilityPrimaryHiredAmount) IS NOT NULL

UNION ALL 
SELECT DISTINCT
    concat('CA7CovType88:',trim(PolicyNumber),'_','CA7HiredAutoTruckersLiabHAU') AS pmt_id,
   concat('CA7HAUCov:',trim(PolicyNumber),'_', 'CA7HiredAutoTruckersLiabHAU')  AS pmt_parent,
    'CA7HAUCov' AS pmt_parent_type,
    'CA7CovType88' AS CodeIdentifier,
    'NoCoverage' AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Hired_Auto_ISO_Coverages_data

UNION ALL 
SELECT DISTINCT
    concat('CA7Limit5:',trim(PolicyNumber),'_','CA7HiredAutoTruckersLiabHAU') AS pmt_id,
   concat('CA7HAUCov:',trim(PolicyNumber),'_', 'CA7HiredAutoTruckersLiabHAU')  AS pmt_parent,
    'CA7HAUCov' AS pmt_parent_type,
    'CA7Limit5' AS CodeIdentifier,
     'NotApplicable'AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Hired_Auto_ISO_Coverages_data

UNION ALL 
SELECT DISTINCT
    concat('CA7Ded86:',trim(PolicyNumber),'_','CA7HiredAutoTruckersLiabHAU') AS pmt_id,
   concat('CA7HAUCov:',trim(PolicyNumber),'_', 'CA7HiredAutoTruckersLiabHAU')  AS pmt_parent,
    'CA7HAUCov' AS pmt_parent_type,
    'CA7Ded86' AS CodeIdentifier,
     '0' AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Hired_Auto_ISO_Coverages_data

UNION ALL 

SELECT DISTINCT
    concat('CA7CostOfHireTruckersInsuredProvidingPrimary:',trim(PolicyNumber),'_','CA7HiredAutoTruckersLiabHAU') AS pmt_id,
   concat('CA7HAUCov:',trim(PolicyNumber),'_', 'CA7HiredAutoTruckersLiabHAU')  AS pmt_parent,
    'CA7HAUCov' AS pmt_parent_type,
    'CA7CostOfHireTruckersInsuredProvidingPrimary' AS CodeIdentifier,
     '0' AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Hired_Auto_ISO_Coverages_data

UNION ALL 

SELECT DISTINCT
    concat('CA7CostOfHireTruckersInsuredProvidingExcess:',trim(PolicyNumber),'_','CA7HiredAutoTruckersLiabHAU') AS pmt_id,
   concat('CA7HAUCov:',trim(PolicyNumber),'_', 'CA7HiredAutoTruckersLiabHAU')  AS pmt_parent,
    'CA7HAUCov' AS pmt_parent_type,
    'CA7CostOfHireTruckersInsuredProvidingExcess' AS CodeIdentifier,
     '0' AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM Hired_Auto_ISO_Coverages_data
'''
try:
  CovTerm_Hired_Auto_Coverage_data = spark.sql(CovTerm_Hired_Auto_Coverage_query)
  CovTerm_Hired_Auto_Coverage_data = CovTerm_Hired_Auto_Coverage_data.dropDuplicates(["pmt_id"])
  CovTerm_Hired_Auto_Coverage_data.createOrReplaceTempView("CovTerm_Hired_Auto_Coverage_data")
  print(CovTerm_Hired_Auto_Coverage_data.count())
  display(CovTerm_Hired_Auto_Coverage_data)
except Exception as e:
  logger.info("error loading CovTerm_Hired_Auto_Coverage_data: {}".format(e)) 
  sys.exit(1)

# COMMAND ----------

CA7HAUCOV = execute_select_PMTIN("select * from ca7haucov")
CA7HAUCOV.createOrReplaceTempView("CA7HAUCOV")
# SQL to find mismatching pmt_parent, count null pmt_id, and check for duplicates for ca7haucov data
invalid_refs_sql = """
SELECT DISTINCT pmt_parent
FROM CovTerm_Hired_Auto_Coverage_data
WHERE pmt_parent NOT IN (
  SELECT DISTINCT pmt_id FROM CA7HAUCOV
)
"""

null_pmt_id_sql = """
SELECT COUNT(*) as null_count
FROM CovTerm_Hired_Auto_Coverage_data
WHERE pmt_id IS NULL
"""

duplicate_pmt_id_sql = """
SELECT pmt_id, COUNT(*) as cnt
FROM CovTerm_Hired_Auto_Coverage_data
GROUP BY pmt_id
HAVING COUNT(*) > 1
"""

invalid_refs = spark.sql(invalid_refs_sql)
null_pmt_id_count = spark.sql(null_pmt_id_sql).collect()[0]['null_count']
duplicate_pmt_ids = spark.sql(duplicate_pmt_id_sql)

# Always insert valid records, regardless of referential integrity check results
valid_records = spark.sql("""
    SELECT *
    FROM CovTerm_Hired_Auto_Coverage_data
    WHERE pmt_parent IN (
        SELECT DISTINCT pmt_id FROM CA7HAUCOV
    )
""")
valid_records.write.jdbc(url=jdbc_url_pmtin, table='covterm', mode='append', properties=properties)

if invalid_refs.count() == 0 and null_pmt_id_count == 0 and duplicate_pmt_ids.count() == 0:
    logger.info('referential integrity checks passed')
    logger.info('No Null pmt_id values found')
    logger.info('No duplicate pmt_id values found')
else:
    if invalid_refs.count() > 0:
        logger.error("Referential integrity issue: Some pmt_parent values do not exist in CA7HAUCOV.")
        for row in invalid_refs.collect():
            logger.error(f"Invalid pmt_parent: {row.pmt_parent}")
    if null_pmt_id_count > 0:
        logger.error(f"Null pmt_id values found in CovTerm_Hired_Auto_Coverage_data: {null_pmt_id_count}")
    if duplicate_pmt_ids.count() > 0:
        logger.error("Duplicate pmt_id values found in CovTerm_Hired_Auto_Coverage_data.")
        for row in duplicate_pmt_ids.collect():
            logger.error(f"Duplicate pmt_id: {row.pmt_id} with count: {row.cnt}")

# COMMAND ----------

# DBTITLE 1,Writing Covterm in PMTIN
CA7HAUCOV =execute_select_PMTIN("select * from ca7haucov")
CA7HAUCOV.createOrReplaceTempView("CA7HAUCOV")
# SQL to find mismatching pmt_parent, count null pmt_id, and check for duplicates for ca7haucov data
invalid_refs_sql = """
SELECT DISTINCT pmt_parent
FROM CovTerm_Hired_Auto_Coverage_data
WHERE pmt_parent NOT IN (
  SELECT DISTINCT pmt_id FROM CA7HAUCOV
)
"""

null_pmt_id_sql = """
SELECT COUNT(*) as null_count
FROM CovTerm_Hired_Auto_Coverage_data
WHERE pmt_id IS NULL
"""

duplicate_pmt_id_sql = """
SELECT pmt_id, COUNT(*) as cnt
FROM CovTerm_Hired_Auto_Coverage_data
GROUP BY pmt_id
HAVING COUNT(*) > 1
"""

invalid_refs = spark.sql(invalid_refs_sql)
null_pmt_id_count = spark.sql(null_pmt_id_sql).collect()[0]['null_count']
duplicate_pmt_ids = spark.sql(duplicate_pmt_id_sql)

if invalid_refs.count() == 0 and null_pmt_id_count == 0 and duplicate_pmt_ids.count() == 0:
    logger.info('referential integrity checks passed')
    logger.info('No Null pmt_id values found')
    logger.info('No duplicate pmt_id values found')

   # CovTerm_Hired_Auto_Coverage_data.write.jdbc(url=jdbc_url_pmtin, table='covterm', mode='append', properties=properties)
else:
    if invalid_refs.count() > 0:
        logger.error("Referential integrity issue: Some pmt_parent values do not exist in CA7HAUCOV.")
        for row in invalid_refs.collect():
            logger.error(f"Invalid pmt_parent: {row.pmt_parent}")
    if null_pmt_id_count > 0:
        logger.error(f"Null pmt_id values found in CovTerm_Hired_Auto_Coverage_data: {null_pmt_id_count}")
    if duplicate_pmt_ids.count() > 0:
        logger.error("Duplicate pmt_id values found in CovTerm_Hired_Auto_Coverage_data.")
        for row in duplicate_pmt_ids.collect():
            logger.error(f"Duplicate pmt_id: {row.pmt_id} with count: {row.cnt}")
            

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #Jurisdiction covterm

# COMMAND ----------

statecovterms = eval(exec_select_pmtin)("select * from ca7statecov")
statecovterms.createOrReplaceTempView("statecovterms_view")

# COMMAND ----------

statecovterms = eval(exec_select_pmtin)("select * from ca7statecov")
statecovterms.createOrReplaceTempView("statecovterms_view")
display(statecovterms)
distinct_codeidentifiers = spark.sql("select distinct codeidentifier from statecovterms_view")
display(distinct_codeidentifiers)

# Join with etlclausepattern to get ClausePatternID for each CodeIdentifier
clausepattern_with_code = df_etlclausepattern.join(
    distinct_codeidentifiers,
    df_etlclausepattern["CodeIdentifier"] == distinct_codeidentifiers["codeidentifier"],
    how="right"
).select(
    distinct_codeidentifiers["codeidentifier"].alias("CodeIdentifier"),
    df_etlclausepattern["ID"].alias("ClausePatternID")
)

# Join with etlcovtermpattern to get PatternID, mark as null if not found
result_df = clausepattern_with_code.join(
    df_etlcovtermpattern,
    clausepattern_with_code["ClausePatternID"] == df_etlcovtermpattern["ClausePatternID"],
    how="left"
).select(
    clausepattern_with_code["CodeIdentifier"],
    clausepattern_with_code["ClausePatternID"],
    df_etlcovtermpattern["PatternID"]
)

display(result_df)
result_df.createOrReplaceTempView('result_df')

# COMMAND ----------

ca7jurcov_query="""
/* -------------------------------------------------------------------------------------------------------------- */
/* Sprint_6_CA Jurisdiction ISO and Proprietary Coverage                                                          */
/* 09/19/2025 (pstemp)                                                                                            */
/* Main Source ViewCurPic_AuStUMInput                                                                             */
/* Added Predomiant State                                                                                         */
/* -------------------------------------------------------------------------------------------------------------- */
WITH FormCheckPCA0301 AS (
    SELECT AUSelectedForm."SystemAssignId", AUSelectedForm."StateCd"
    FROM ViewCurPic_AUSelectedForm AUSelectedForm
    WHERE AUSelectedForm."FormId" IN ('PCA 03 01')
)
select 
/* ---------------------- */
/* CoPolicyPointer fields */
/* ---------------------- */
P."SystemAssignId"
,P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"),' ') as "PolicyNumber"
,CAST (RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"),' ') AS VARCHAR(8)) AS "AccountNumber"
,P."PolicyEffDt"

/* -------------------------------- */
/* ViewCurPic_CoPolicyDetail Fields */
/* -------------------------------- */
,CoPolicyDetail."PredStateCd" AS "PredominantStateCode"

/* --------------------------- */
/* ViewCurPic_AuStInput fields */
/* --------------------------- */
,AuStInput."StateCd",

/* -------------------------------------- */
/* ViewCurPic_AuStUMInput fields          */
/* -------------------------------------- */
 AuPolInput."LiabSymbolLst" AS "LiabilitySymbol",
     AuPolInput."LiabLimitTypeCd" AS "LiabilityLimitTypeCode",
    AuPolInput."CSLLiabLimit" AS "LiabilityLimit",
    AuPolInput."BI1Limit" AS "BI1Limit",
    AuPolInput."BI2Limit" AS "BI2Limit",
    AuPolInput."PDLimit" AS "PDLimit",
    AuPolInput."LiabDedTypeCd" AS "LiabilityDeductionTypeCode",
    AuPolInput."LiabDedAmt" AS "LiabilityDeductible"

,AuStUMInput."TypeLimit" AS "LimitTypeUMUIM"
,AuStUMInput."CombLimt" AS "UMCLSLimit"
,AuStUMInput."BI1Limit" AS "UMBILimit1"
,AuStUMInput."BI2Limit" AS "UMBILimit2"
,AuStUMInput."PDLimit" AS "UMPDLimt"
,AuStUMInput."UIMCombLimit" AS "UIMCLSLimit"
,AuStUMInput."UIMBI1Limit" AS "UIMBILimit1"
,AuStUMInput."UIMBI2Limit" AS "UIMBILimit2"
,AuStUMInput."UIMPDLimit" AS "UIMPDLimt"
,AuStUMInput."IndivCoupleInd" AS "IndividualNamedInsured"
,AuStUMInput."MiscInfoInd" AS "UMMisc",
CASE WHEN FormCheckPCA0301."SystemAssignId" IS NOT NULL THEN 'Y' ELSE 'N' END AS "DoesFormPCA0301Exist"



FROM policy P1
INNER JOIN copolicypointer P
   ON P."SystemAssignId" = P1."SourceSystemId"
   
   
INNER JOIN viewcurpic_copolicydetail CoPolicyDetail
   ON P."SystemAssignId" = CoPolicyDetail."SystemAssignId"
INNER JOIN viewcurpic_austinput AuStInput
   ON P."SystemAssignId" = AuStInput."SystemAssignId"
INNER JOIN viewcurpic_austuminput AuStUMInput
   ON P."SystemAssignId" = AuStUMInput."SystemAssignId"
   AND AuStInput."StateCd" = AuStUMInput."StateCd"
INNER JOIN ViewCurPic_AuPolInput AuPolInput
    ON P."SystemAssignId" = AuPolInput."SystemAssignId"

LEFT JOIN FormCheckPCA0301
    ON P."SystemAssignId" = FormCheckPCA0301."SystemAssignId"


WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
AND P1."LOB" IN ('AU', 'GR', 'TU')

order by "PolicyNumber", "StateCd"
--Order by LimitTypeUMUIM desc


"""
try:
  # Execute the query and create a temp view for downstream use
  ca7jurcov_df = eval(exec_select_landing)(ca7jurcov_query)
  ca7jurcov_df.createOrReplaceTempView("ca7jurcov_df")  # Create a temporary view for further processing
  print(ca7jurcov_df.count())  # Print the count of records retrieved
  display(ca7jurcov_df)  # Display the results
except Exception as e:
  # Log the error and exit if there is an issue loading the data
  logger.info("error ca7jurcov: {}".format(e)) 
  sys.exit(1)

# COMMAND ----------

jur_formcode_VAAKND_query = '''
-- Query to extract Commercial Auto Line Proprietary Coverage Forms with mapping

SELECT 
    -- CoPolicyPointer fields
    P."SystemAssignId",
    P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
    CAST(RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",
    P."PolicyEffDt",
    -- ViewCurPic_AuStInput fields
    AuStInput."StateCd",
    -- ViewCurPic_AUSelectedForm fields
    AUSelectedForm."FormId",
    AUSelectedForm."FormDescTx" AS "FormDescription",
    CASE 
        WHEN trim(AuStInput."StateCd") = 'VA' AND AuStMPDeathBInput."WorkLossTypeCd" IS NOT NULL THEN 'CA7MedicalExpenseAndIncomeLossBenefitsEndorsement'
        WHEN trim(AuStInput."StateCd") = 'AK' 
             AND AuStAttyFeeInput."AttyFeeLimit" IS NOT NULL 
             THEN 'CA7AKChangesAttorneysFees'
        WHEN (austhiredpdinput."CollCostHireAmt" IS NOT NULL  
              OR austhiredpdinput."OTCCostHireAmt" IS NOT NULL  
              OR NonOwnedInput."NOwnEmplCnt" IS NOT NULL) 
             AND trim(AuStInput."StateCd") = 'ND' 
             THEN 'CA7NDChangesRentalVehicleCovPrivatePassengerAutos'
    END AS "FormId_Mapped",

    AuStAttyFeeInput."AttyFeeLimit" AS JudgementAmount,
    AuStMPDeathBInput."WorkLossTypeCd" AS MedPayDeathWorkLossTypeCode,
    austhiredpdinput."CollCostHireAmt" as collcosthireamt,
    austhiredpdinput."OTCCostHireAmt" as otcchireamt,
    NonOwnedInput."NOwnEmplCnt" as NonOwnedEmplCnt

FROM policy P1
INNER JOIN copolicypointer P
   ON P."SystemAssignId" = P1."SourceSystemId"
INNER JOIN viewcurpic_austinput AuStInput
   ON P."SystemAssignId" = AuStInput."SystemAssignId"

LEFT JOIN viewcurpic_austhiredpdinput austhiredpdinput
  ON P."SystemAssignId" = austhiredpdinput."SystemAssignId"
  AND AuStInput."StateCd" = austhiredpdinput."StateCd"
LEFT JOIN ViewCurPic_AuStNonOwnedInput NonOwnedInput
  ON P."SystemAssignId" = NonOwnedInput."SystemAssignId"
  AND AuStInput."StateCd"= NonOwnedInput."StateCd"
LEFT JOIN viewcurpic_auselectedform AUSelectedForm
   ON P."SystemAssignId" = AUSelectedForm."SystemAssignId"
   AND trim(AuStInput."StateCd") = trim(AUSelectedForm."StateCd")
LEFT JOIN "ViewCurPic_AuStAttyFeeInput" AuStAttyFeeInput
   ON P."SystemAssignId" = AuStAttyFeeInput."SystemAssignId"
   AND AuStInput."StateCd" = AuStAttyFeeInput."StateCd"
LEFT JOIN "ViewCurPic_AuStMPDeathBInput" AuStMPDeathBInput
   ON P."SystemAssignId" = AuStMPDeathBInput."SystemAssignId"
   AND AuStInput."StateCd" = AuStMPDeathBInput."StateCd"

WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
  AND P1."LOB" IN ('AU', 'GR', 'TU')
  AND (
    trim(AuStInput."StateCd") = 'VA'
    OR trim(AuStInput."StateCd") = 'AK'
    OR trim(AuStInput."StateCd") = 'ND'
  )
ORDER BY "PolicyNumber", "StateCd", "FormId"
'''

try:
  jur_formcode_VAAKND_df = eval(exec_select_landing)(jur_formcode_VAAKND_query)
  jur_formcode_VAAKND_df.createOrReplaceTempView("jur_formcode_VAKAND_df")
  print(jur_formcode_VAAKND_df.count())
  display(jur_formcode_VAAKND_df)
except Exception as e:
  logger.info("error loading covterm: {}".format(e))
  sys.exit(1)

# COMMAND ----------


jur_onhookcollision_query = '''
/* -------------------------------------------------------------------------------------------------------------- */
/* Sprint 7 - On-Hook Coverage                                                                                    */
/* --------                                                                                                       */
/* Views used:                                                                                                    */
/* ViewCurPic_AuStInput, ViewCurPic_AuStGKLInput                                                                  */
/* -------------------------------------------------------------------------------------------------------------- */

SELECT 
    /* ---------------------- */
    /* CoPolicyPointer fields */
    /* ---------------------- */
    P."SystemAssignId",
    P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
    CAST(RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",
    /* ----------------- */
    /* AuPolInput fields */
    /* ----------------- */
    AuPolInput."NAICCd" AS "NAICCode",

    /* ------------------------------------ */
    /* ViewCurPic_AuStInput fields          */
    /* ------------------------------------ */
    AuStInput."StateCd" AS "StateCd",
    AuStInput."GKLAllPerDedInd" AS "AllPerilsDeductible",

    /* ------------------------------------ */
    /* ViewCurPic_AuStGKLInput fields       */
    /* ------------------------------------ */
    AuStGKLInput."CompLimit" AS "CompLimit",
    AuStGKLInput."CompDed1Amt" AS "CompDeductible",
    AuStGKLInput."SpecPerilsLimit" AS "SCLLimit",
    AuStGKLInput."SpecPerilsDed1Amt" AS "SCLDeductible",
    AuStGKLInput."CollLimit" AS "CollisionLimit",
    AuStGKLInput."CollDedAmt" AS "CollisionDeductible",
    
    /* ------------------------------------ */
    /* RatingBase info:                     */
    /* Legal Liability = 1                  */
    /* Direct Primary = 2                   */
    /* Direct Excess = 3                    */
    /* ------------------------------------ */
    AuStGKLInput."RatingBasisInd" AS "RatingBase"

FROM policy P1 
INNER JOIN copolicypointer P
    ON P."SystemAssignId" = P1."SourceSystemId"
INNER JOIN viewcurpic_aupolinput AuPolInput
    ON P."SystemAssignId" = AuPolInput."SystemAssignId"
INNER JOIN viewcurpic_austinput AuStInput
    ON P."SystemAssignId" = AuStInput."SystemAssignId"
INNER JOIN "ViewCurPic_AuStGKLInput"  AuStGKLInput
    ON P."SystemAssignId" = AuStGKLInput."SystemAssignId"
    AND AuStInput."StateCd" = AuStGKLInput."StateCd"

WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
AND P1."LOB" IN ('AU', 'GR', 'TU')

ORDER BY "PolicyNumber", "StateCd"
'''

try:
    jur_onhookcollision_df = eval(exec_select_landing)(jur_onhookcollision_query)
    jur_onhookcollision_df.createOrReplaceTempView("jur_onhookcollision_df")
    display(jur_onhookcollision_df)
except Exception as e:
    logger.info("error ca7statecov_df: {}".format(e))
    sys.exit(1)

# COMMAND ----------


jur_employeebenefits_query = '''
/* -------------------------------------------------------------------------------------------------------------- */
/* Sprint 7 - Employee Benefits Liability                                                                         */
/* --------                                                                                                       */
/* Views used:                                                                                                    */
/* ViewCurPic_AuPolInput, ViewCurPic_AuPolOthCovgInput                                                            */
/* -------------------------------------------------------------------------------------------------------------- */

SELECT 
    -- CoPolicyPointer fields
    P."SystemAssignId",
    P1."LOB",
    P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
    CAST(RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",

    -- AuPolInput fields
    AuPolInput."NAICCd" AS "NAICCode",

    AuPolOthCovgInput."CovgCd",
    AuPolOthCovgInput."Limit1" AS "AggregateLimit",
    AuPolOthCovgInput."ChargeTypeInd" AS "TypeOfCharge",
    AuPolOthCovgInput."Prem1Amt" AS "PremiumCharge",
    AuPolOthCovgInput."FlatChargeInd" AS "FlatCharge",
    AuPolOthCovgInput."FullyEarnedInd" AS "FullyEarned",
    AuPolOthCovgInput."Limit2" AS "EachEmployeeLimit",
    AuPolOthCovgInput."DedAmt" AS "Deductible",
    AuPolOthCovgInput."Prem2Amt" AS "ExtReptPremCharge",
    AuPolOthCovgInput."RetroDt" AS "RetroDate",

--AustInput fields
 AuStInput."StateCd" AS "StateCd",

 --CoPolicyDetail fields

CoPolicyDetail."PredStateCd" AS "PredominantStateCode"




    


FROM policy P1
INNER JOIN copolicypointer P
    ON P."SystemAssignId" = P1."SourceSystemId"

INNER JOIN ViewCurPic_CoPolicyDetail AS CoPolicyDetail
    ON P."SystemAssignId" = CoPolicyDetail."SystemAssignId"

INNER JOIN viewcurpic_austinput AuStInput
    ON P."SystemAssignId" = AuStInput."SystemAssignId"
     AND CoPolicyDetail."PredStateCd" = AuStInput."StateCd"

INNER JOIN viewcurpic_aupolinput AuPolInput
    ON P."SystemAssignId" = AuPolInput."SystemAssignId"
INNER JOIN viewcurpic_aupolothcovginput AuPolOthCovgInput
    ON P."SystemAssignId" = AuPolOthCovgInput."SystemAssignId"
    AND AuPolOthCovgInput."CovgCd" = 'EMBE'

WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
AND P1."LOB" IN ('AU', 'GR', 'TU')

ORDER BY "PolicyNumber", "SystemAssignId"
'''

try:
    jur_employeebenefits_df = eval(exec_select_landing)(jur_employeebenefits_query)
    jur_employeebenefits_df.createOrReplaceTempView("jur_employeebenefits_df")
    print(jur_employeebenefits_df.count())
    display(jur_employeebenefits_df)
except Exception as e:
    logger.info("error loading jur_employeebenefits_df: {}".format(e))
    sys.exit(1)

# COMMAND ----------

NoFaultPip_query = '''
/* -------------------------------------------------------------------------------------------------------------- */
/* Sprint 7 - No Fault PIP                                                                                        */
/* --------                                                                                                       */
/* Views used:                                                                                                    */
/* ViewCurPic_AuStInput, ViewCurPic_AuStNoFltPIPInput                                                             */
/* -------------------------------------------------------------------------------------------------------------- */

SELECT 
    /* ---------------------- */
    /* CoPolicyPointer fields */
    /* ---------------------- */
    P."SystemAssignId",
    P1."LOB",
    (P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ')) AS "PolicyNumber",
    CAST(RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",

    /* ----------------- */
    /* AuPolInput fields */
    /* ----------------- */
    AuPolInput."NAICCd" AS "NAICCode",
    AuPolInput."PIPSymbolLst" AS "PIPSymbollist",
    AuPolInput."AddPIPSymbolLst" AS "AddPIPSymbollist",
    
  
    /* ------------------------------------ */
    /* ViewCurPic_AuStInput fields          */
    /* ------------------------------------ */
    AuStInput."StateCd" AS "StateCd",

    /* ------------------------------------ */
    /* ViewCurPic_AuStNoFltPIPInput fields  */
    /* ------------------------------------ */
    AuStNoFltPIPInput."NoFltPIPThrshAmt" AS "PIPLimit",
    AuStNoFltPIPInput."AddlNoFltPIPInd" AS "AdditionPIP",
    AuStNoFltPIPInput."WorkLossLimit" AS "WorkLoss",
    AuStNoFltPIPInput."PIPDedLimit" AS "PIPDeductible",
    AuStNoFltPIPInput."PIPMisc1Ind" AS "PIPMisc1",
    AuStNoFltPIPInput."PIPMisc2Ind" AS "PIPMisc2",
    AuStNoFltPIPInput."AddlPIPLimit" AS "AddlPIPLimit",
 
    /* ------------------------------------- */
    /* PIPMisc4 Info:                        */
    /* Y                                     */
    /* N                                     */
    /* 1 - 100,000                           */
    /* 2 - 300,000                           */
    /* 3 - 500,000                           */
    /* 4 - 1,000,000                         */
    /* ------------------------------------- */
    AuStNoFltPIPInput."PIPMisc4Ind" AS "PIPMisc4",
    AuStNoFltPIPInput."MedExpenseLimit" AS "MedExpenseLimit"

FROM policy P1 
INNER JOIN copolicypointer P
    ON P."SystemAssignId" = P1."SourceSystemId"
INNER JOIN viewcurpic_aupolinput AuPolInput
    ON P."SystemAssignId" = AuPolInput."SystemAssignId"
INNER JOIN viewcurpic_austinput AuStInput
    ON P."SystemAssignId" = AuStInput."SystemAssignId"
INNER JOIN viewcurpic_austnofltpipinput AuStNoFltPIPInput
    ON P."SystemAssignId" = AuStNoFltPIPInput."SystemAssignId"
    AND AuStInput."StateCd" = AuStNoFltPIPInput."StateCd"

WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
AND P1."LOB" IN ('AU', 'GR', 'TU')

ORDER BY "PIPMisc1" DESC
'''

try:
    NoFaultPip_df = eval(exec_select_landing)(NoFaultPip_query)
    NoFaultPip_df.createOrReplaceTempView("NoFaultPip_df")
    print(NoFaultPip_df.count())
    display(NoFaultPip_df)
except Exception as e:
    logger.info("error loading NoFaultPip_df: {}".format(e))
    sys.exit(1)

# COMMAND ----------

jur_formcode_VAAKND_query = '''
-- Query to extract Commercial Auto Line Proprietary Coverage Forms with mapping

SELECT 
    -- CoPolicyPointer fields
    P."SystemAssignId",
    P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
    CAST(RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",
    P."PolicyEffDt",
    -- ViewCurPic_AuStInput fields
    AuStInput."StateCd",
    -- ViewCurPic_AUSelectedForm fields
    AUSelectedForm."FormId",
    AUSelectedForm."FormDescTx" AS "FormDescription",
    CASE 
        WHEN trim(AuStInput."StateCd") = 'VA' AND AuStMPDeathBInput."WorkLossTypeCd" IS NOT NULL THEN 'CA7MedicalExpenseAndIncomeLossBenefitsEndorsement'
        WHEN trim(AuStInput."StateCd") = 'AK' AND AuStAttyFeeInput."AttyFeeLimit" IS NOT NULL THEN 'CA7AKChangesAttorneysFees'
        WHEN (austhiredpdinput."CollCostHireAmt" IS NOT NULL  
              OR austhiredpdinput."OTCCostHireAmt" IS NOT NULL  
              OR NonOwnedInput."NOwnEmplCnt" IS NOT NULL) 
             AND trim(AuStInput."StateCd") = 'ND' 
             THEN 'CA7NDChangesRentalVehicleCovPrivatePassengerAutos'
    END AS "FormId_Mapped",

    AuStAttyFeeInput."AttyFeeLimit" AS JudgementAmount,
    AuStMPDeathBInput."WorkLossTypeCd" AS MedPayDeathWorkLossTypeCode,
    austhiredpdinput."CollCostHireAmt" as collcosthireamt,
    austhiredpdinput."OTCCostHireAmt" as otcchireamt,
    NonOwnedInput."NOwnEmplCnt" as NonOwnedEmplCnt

FROM policy P1
INNER JOIN copolicypointer P
   ON P."SystemAssignId" = P1."SourceSystemId"
INNER JOIN viewcurpic_austinput AuStInput
   ON P."SystemAssignId" = AuStInput."SystemAssignId"

LEFT JOIN viewcurpic_austhiredpdinput austhiredpdinput
  ON P."SystemAssignId" = austhiredpdinput."SystemAssignId"
  AND AuStInput."StateCd" = austhiredpdinput."StateCd"
LEFT JOIN ViewCurPic_AuStNonOwnedInput NonOwnedInput
  ON P."SystemAssignId" = NonOwnedInput."SystemAssignId"
  AND AuStInput."StateCd"= NonOwnedInput."StateCd"
LEFT JOIN viewcurpic_auselectedform AUSelectedForm
   ON P."SystemAssignId" = AUSelectedForm."SystemAssignId"
   AND trim(AuStInput."StateCd") = trim(AUSelectedForm."StateCd")
LEFT JOIN "ViewCurPic_AuStAttyFeeInput" AuStAttyFeeInput
   ON P."SystemAssignId" = AuStAttyFeeInput."SystemAssignId"
   AND AuStInput."StateCd" = AuStAttyFeeInput."StateCd"
LEFT JOIN "ViewCurPic_AuStMPDeathBInput" AuStMPDeathBInput
   ON P."SystemAssignId" = AuStMPDeathBInput."SystemAssignId"
   AND AuStInput."StateCd" = AuStMPDeathBInput."StateCd"

WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
  AND P1."LOB" IN ('AU', 'GR', 'TU')
  AND (
    trim(AuStInput."StateCd") = 'VA'
    OR trim(AuStInput."StateCd") = 'AK'
    OR trim(AuStInput."StateCd") = 'ND'
  )
ORDER BY "PolicyNumber", "StateCd", "FormId"
'''

try:
  jur_formcode_VAAKND_df = eval(exec_select_landing)(jur_formcode_VAAKND_query)
  jur_formcode_VAAKND_df.createOrReplaceTempView("jur_formcode_VAKAND_df")
  print(jur_formcode_VAAKND_df.count())
  display(jur_formcode_VAAKND_df)
except Exception as e:
  logger.info("error loading jur_formcode_VAAKND_df: {}".format(e))
  sys.exit(1)

# COMMAND ----------


jur_formcode_query = '''
-- Query to extract Commercial Auto Line Proprietary Coverage Forms with mapping

SELECT 
    -- CoPolicyPointer fields
    P."SystemAssignId",
    P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
    CAST(RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",
    P."PolicyEffDt",
    -- ViewCurPic_AuStInput fields
    AuStInput."StateCd",
    -- ViewCurPic_AUSelectedForm fields
    AUSelectedForm."FormId",
    AUSelectedForm."FormDescTx" AS "FormDescription",
    CASE 
        WHEN trim(AUSelectedForm."FormId") = 'PCA 05 50' THEN 'CA7MobileEquipmentAmendatoryEndorsementVA_Ext'
        WHEN trim(AUSelectedForm."FormId") = 'CA 01 90' THEN 'CA7CTChangesLiabOfMunicipalities'
        WHEN trim(AUSelectedForm."FormId") = 'P02104' THEN 'CA7SchOfUnUndrInsrdMtrCov_Ext'
        WHEN trim(AUSelectedForm."FormId") = 'PCA 0557 NY' THEN 'CA7WaiverOfDeprecationNewPrivatePassVehicleNY_Ext'
        WHEN trim(AUSelectedForm."FormId") = 'PCA 20 36' THEN 'CA7WhoIsAnInsdAmenCA_Ext'
        WHEN trim(AUSelectedForm."FormId") IN ('PCA 03 01','PCA 03 02','PCA 03 06','PCA 03 08','PCA 03 10') THEN 'CA7CommAutomblDedEnd_Ext'
        WHEN trim(AUSelectedForm."FormId") = 'CA 02 04' THEN 'CA7ChangesCancellationForOversizedVehicles'
        WHEN trim(AUSelectedForm."FormId") = 'CA 22 68' THEN 'CA7PIPOptionalWaiverOfScheduledMedicalExpenseBenef'
        WHEN trim(AUSelectedForm."FormId") = 'CA 04 05' THEN 'CA7TXRuralElectrificationCooperativeEndorsement'
        WHEN trim(AUSelectedForm."FormId") = 'CA 01 89' THEN 'CA7WestVAChangesCovExtensionForTemporarySubstitute'
        WHEN trim(AUSelectedForm."FormId") = 'CA 04 15' THEN 'CA7GaragekeepersCovForAutosAndWatercrafts'
        WHEN trim(AUSelectedForm."FormId") = 'PCA 05 25' THEN 'CA7BodilyInjuryRedefined_Ext'
        WHEN trim(AUSelectedForm."FormId") = 'PCA 20 41' THEN 'CA7ClmExpIncldCov_Ext'
        WHEN trim(AUSelectedForm."FormId") = 'PCA 20 40' THEN 'CA7DedLiabRmbrstCovFL_Ext'
        WHEN trim(AUSelectedForm."FormId") = 'PCA 20 08' THEN 'CA7DedLiabRmbrstCov_Ext'
        WHEN trim(AUSelectedForm."FormId") = 'PCA 20 37' THEN 'CA7DedLiabRmbrstKY_Ext'
        WHEN trim(AUSelectedForm."FormId") = 'PCA 05 09' THEN 'CA7ExtendedCancellationCondIL_Ext'
        WHEN trim(AUSelectedForm."FormId") = 'PCA 05 34' THEN 'CA7FLGlassRepairWaiverOfDedForOtherThanWinshield_Ext'
        WHEN trim(AUSelectedForm."FormId") = 'PCA 05 22' AND trim(AuStInput."StateCd") = 'FL' THEN 'CA7PhyDamageAddTranFL_Ext'
        WHEN trim(AUSelectedForm."FormId") = 'PCA 05 22' AND trim(AuStInput."StateCd") = 'VA' THEN 'CA7PhyDamageAddTranVA_Ext'
        WHEN trim(AUSelectedForm."FormId")= 'CA 22 01' THEN 'CA7NamedIndivsBroadenedPersonalInjuryProtection' 
        -- sprint 8 
        WHEN trim(AUSelectedForm."FormId")='CA 21 12' THEN 'CA7IAUninsuredAndUnderinsuredMotoristsCov'
         WHEN trim(AUSelectedForm."FormId")='CA 25 85' THEN 'CA7CustomerComplaintLegalDefenseCovWithNoCovForNew'
        WHEN trim(AUSelectedForm."FormId")='CA 25 87' THEN 'CA7ExtendedReportingPeriodForEmpBensLiabCovWithNoC'
        WHEN trim(AUSelectedForm."FormId")='CA 04 20' THEN 'CA7NYSupplementalSpousalBILiabCov'
        WHEN trim(AUSelectedForm."FormId")='CA 99 09' THEN 'CA7DistrictOfColumbiaEmplsUsingAutosInGovBusinessM'
        WHEN trim(AUSelectedForm."FormId")='CA 20 45' THEN 'CA7NYTowTrucks'
        WHEN trim(AUSelectedForm."FormId")='CA 01 78' THEN 'CA7LAChangesCovExtensionForRentalVehicles'
        WHEN trim(AUSelectedForm."FormId")='CA 99 89' THEN 'CA7LossPayableFormReg335'
        WHEN trim(AUSelectedForm."FormId")='CA 01 06' THEN 'CA7COAndMDChangesInPolicyCollisionCovInMexico'
        WHEN trim(AUSelectedForm."FormId")='CA 22 31' THEN 'CA7AddedDeathBenefit'
    END AS "FormId_Mapped",

    NonOwnedInput."NOwnEmplCnt" AS "Nonownedemployeecount",
    austhiredpdinput."CollCostHireAmt" AS "CostOfHireInsuredProvidingPrimary",
    austhiredpdinput."OTCCostHireAmt" AS "CostOfHireInsuredProvidingExcess",
    AuStAttyFeeInput."AttyFeeLimit" AS JudgementAmount,
    AuStMPDeathBInput."WorkLossTypeCd" AS MedPayDeathWorkLossTypeCode

FROM policy P1
INNER JOIN copolicypointer P
   ON P."SystemAssignId" = P1."SourceSystemId"
INNER JOIN viewcurpic_austinput AuStInput
   ON P."SystemAssignId" = AuStInput."SystemAssignId"

LEFT JOIN viewcurpic_austhiredpdinput austhiredpdinput
  ON P."SystemAssignId" = austhiredpdinput."SystemAssignId"
  AND AuStInput."StateCd" = austhiredpdinput."StateCd"
LEFT JOIN ViewCurPic_AuStNonOwnedInput NonOwnedInput
  ON P."SystemAssignId" = NonOwnedInput."SystemAssignId"
  AND AuStInput."StateCd"= NonOwnedInput."StateCd"
LEFT JOIN viewcurpic_auselectedform AUSelectedForm
   ON P."SystemAssignId" = AUSelectedForm."SystemAssignId"
   AND trim(AuStInput."StateCd") = trim(AUSelectedForm."StateCd")
LEFT JOIN "ViewCurPic_AuStAttyFeeInput" AuStAttyFeeInput
   ON P."SystemAssignId" = AuStAttyFeeInput."SystemAssignId"
   AND AuStInput."StateCd" = AuStAttyFeeInput."StateCd"
LEFT JOIN "ViewCurPic_AuStMPDeathBInput" AuStMPDeathBInput
   ON P."SystemAssignId" = AuStMPDeathBInput."SystemAssignId"
   AND AuStInput."StateCd" = AuStMPDeathBInput."StateCd"

WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
  AND P1."LOB" IN ('AU', 'GR', 'TU')
  AND (
    trim(AUSelectedForm."FormId") IN (
      'PCA 05 50',
      'PCA 05 50',
      'CA 01 90',
      'P02104',
      'PCA 0557 NY',
      'PCA 20 36',
      'PCA 03 01','PCA 03 02','PCA 03 06','PCA 03 08','PCA 03 10',
      'CA 02 04',
      'CA 22 68',
      'CA 04 05',
      'CA 01 89',
      'CA 04 15',
      'PCA 05 25',
      'PCA 20 41',
      'PCA 20 40',
      'PCA 20 08',
      'PCA 20 37',
      'PCA 05 09',
      'PCA 05 34',
      'PCA 05 22',
      'CA 22 01',
      'CA 21 12',
      'CA 25 85',
     'CA 25 87',
     'CA 04 20',
     'CA 99 09',
     'CA 20 45',
     'CA 01 78',
     'CA 99 89',
     'CA 01 06',
     'CA 22 31'

    )
  )
ORDER BY "PolicyNumber", "StateCd", "FormId"
'''

try:
  jur_formcode_df = eval(exec_select_landing)(jur_formcode_query)
  jur_formcode_df.createOrReplaceTempView("jur_formcode_df")
  print(jur_formcode_df.count())
  display(jur_formcode_df)
except Exception as e:
  logger.info("error loading jur_formcode_df: {}".format(e))
  sys.exit(1)

# COMMAND ----------

covterm_CA7UninsuredMotoristPropertyDamagetext2_FIXED_query = """


-- Fix 3: Cost of Hire (This one was already correct - no IN subquery)
SELECT DISTINCT
    concat('CA7Jur:',trim(v.PolicyNumber),'-','CA7CostOfHire','-',trim(v.StateCd)) AS pmt_id,
    concat('Jur:',trim(v.PolicyNumber),'-','CA7NDChangesRentalVehicleCovPrivatePassengerAutos','-',trim(v.StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7CostOfHire' AS codeidentifier,
    CAST(
        CASE 
            WHEN (v.collcosthireamt = 'IF ANY' OR v.otcchireamt = 'IF ANY') AND v.NonOwnedEmplCnt IS NULL THEN '0'
            WHEN v.collcosthireamt IS NOT NULL THEN v.collcosthireamt
            WHEN v.otcchireamt IS NOT NULL THEN v.otcchireamt
            WHEN v.collcosthireamt IS NULL AND v.otcchireamt IS NULL AND v.NonOwnedEmplCnt IS NOT NULL THEN v.NonOwnedEmplCnt
            ELSE NULL
        END AS STRING
    ) AS value,
    trim(v.PolicyNumber) AS pmt_payloadid
FROM jur_formcode_VAKAND_df v
WHERE v.FormId_Mapped = 'CA7NDChangesRentalVehicleCovPrivatePassengerAutos' 
  AND (v.collcosthireamt IS NOT NULL OR v.otcchireamt IS NOT NULL OR v.NonOwnedEmplCnt IS NOT NULL)
  AND EXISTS (
      SELECT 1 FROM statecovterms_view p 
      WHERE p.CodeIdentifier = 'CA7NDChangesRentalVehicleCovPrivatePassengerAutos'
      AND p.pmt_payloadid = trim(v.PolicyNumber)
      AND p.pmt_id = concat('Jur:',trim(v.PolicyNumber),'-','CA7NDChangesRentalVehicleCovPrivatePassengerAutos','-',trim(v.StateCd))
  )

UNION ALL

-- Fix 4: Employee Benefits Coverage Type
SELECT DISTINCT
    concat('CA7Jur:',trim(e.PolicyNumber),'-','CA7CovType84','-',trim(e.StateCd)) AS pmt_id,
    concat('Jur:', trim(e.PolicyNumber), '-CA7EmplBenefitsLiabCovWithNoCovForNewlyAcquiredOrF-', trim(e.StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7CovType84' AS codeidentifier,
    CAST(CASE WHEN trim(e.CovgCd) = 'EMBE' THEN 'EmployeeBenefitsPrograms' END AS STRING) AS value,
    trim(e.PolicyNumber) AS pmt_payloadid
FROM jur_employeebenefits_df e
WHERE (e.AggregateLimit IS NOT NULL OR e.EachEmployeeLimit IS NOT NULL)
  AND EXISTS (
      SELECT 1 FROM statecovterms_view p 
      WHERE p.CodeIdentifier = 'CA7EmplBenefitsLiabCovWithNoCovForNewlyAcquiredOrF'
      AND p.pmt_payloadid = trim(e.PolicyNumber)
      AND p.pmt_id = concat('Jur:', trim(e.PolicyNumber), '-CA7EmplBenefitsLiabCovWithNoCovForNewlyAcquiredOrF-', trim(e.StateCd))
  )

UNION ALL

-- Fix 5: Employee Benefits Deductible
SELECT DISTINCT
    concat('CA7Jur:',trim(e.PolicyNumber),'-','CA7Ded63','-',trim(e.StateCd)) AS pmt_id,
    concat('Jur:', trim(e.PolicyNumber), '-CA7EmplBenefitsLiabCovWithNoCovForNewlyAcquiredOrF-', trim(e.StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7Ded63' AS codeidentifier,
    CAST(trim(e.Deductible) AS STRING) AS value,
    trim(e.PolicyNumber) AS pmt_payloadid
FROM jur_employeebenefits_df e
WHERE (e.AggregateLimit IS NOT NULL OR e.EachEmployeeLimit IS NOT NULL)
  AND EXISTS (
      SELECT 1 FROM statecovterms_view p 
      WHERE p.CodeIdentifier = 'CA7EmplBenefitsLiabCovWithNoCovForNewlyAcquiredOrF'
      AND p.pmt_payloadid = trim(e.PolicyNumber)
      AND p.pmt_id = concat('Jur:', trim(e.PolicyNumber), '-CA7EmplBenefitsLiabCovWithNoCovForNewlyAcquiredOrF-', trim(e.StateCd))
  )

UNION ALL

-- Fix 6: Employee Benefits Each Employee Limit (This one didn't have IN subquery - keep as is)
SELECT DISTINCT
    concat('CA7Jur:',trim(e.PolicyNumber),'-','CA7LimitText46','-',trim(e.StateCd)) AS pmt_id,
    concat('Jur:', trim(e.PolicyNumber), '-CA7EmplBenefitsLiabCovWithNoCovForNewlyAcquiredOrF-', trim(e.StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7LimitText46' AS codeidentifier,
    CAST(e.EachEmployeeLimit AS STRING) AS value,
    trim(e.PolicyNumber) AS pmt_payloadid
FROM jur_employeebenefits_df e
WHERE (e.AggregateLimit IS NOT NULL OR e.EachEmployeeLimit IS NOT NULL)
  AND EXISTS (
      SELECT 1 FROM statecovterms_view p 
      WHERE p.CodeIdentifier = 'CA7EmplBenefitsLiabCovWithNoCovForNewlyAcquiredOrF'
      AND p.pmt_payloadid = trim(e.PolicyNumber)
      AND p.pmt_id = concat('Jur:', trim(e.PolicyNumber), '-CA7EmplBenefitsLiabCovWithNoCovForNewlyAcquiredOrF-', trim(e.StateCd))
  )

UNION ALL

-- Fix 7: Employee Benefits Aggregate Limit
SELECT DISTINCT
    concat('CA7Jur:',trim(e.PolicyNumber),'-','CA7AggLimit4','-',trim(e.StateCd)) AS pmt_id,
    concat('Jur:', trim(e.PolicyNumber), '-CA7EmplBenefitsLiabCovWithNoCovForNewlyAcquiredOrF-', trim(e.StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7AggLimit4' AS codeidentifier,
    CAST(e.AggregateLimit AS STRING) AS value,
    trim(e.PolicyNumber) AS pmt_payloadid
FROM jur_employeebenefits_df e
WHERE (e.AggregateLimit IS NOT NULL OR e.EachEmployeeLimit IS NOT NULL)
  AND EXISTS (
      SELECT 1 FROM statecovterms_view p 
      WHERE p.CodeIdentifier = 'CA7EmplBenefitsLiabCovWithNoCovForNewlyAcquiredOrF'
      AND p.pmt_payloadid = trim(e.PolicyNumber)
      AND p.pmt_id = concat('Jur:', trim(e.PolicyNumber), '-CA7EmplBenefitsLiabCovWithNoCovForNewlyAcquiredOrF-', trim(e.StateCd))
  )

UNION ALL

-- Fix 8: Employee Benefits Manual Premium
SELECT DISTINCT
    concat('CA7Jur:',trim(e.PolicyNumber),'-','CA7ManualPremium51','-',trim(e.StateCd)) AS pmt_id,
    concat('Jur:', trim(e.PolicyNumber), '-CA7EmplBenefitsLiabCovWithNoCovForNewlyAcquiredOrF-', trim(e.StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7ManualPremium51' AS codeidentifier,
    CAST(e.PremiumCharge AS STRING) AS value,
    trim(e.PolicyNumber) AS pmt_payloadid
FROM jur_employeebenefits_df e
WHERE (e.AggregateLimit IS NOT NULL OR e.EachEmployeeLimit IS NOT NULL)
  AND EXISTS (
      SELECT 1 FROM statecovterms_view p 
      WHERE p.CodeIdentifier = 'CA7EmplBenefitsLiabCovWithNoCovForNewlyAcquiredOrF'
      AND p.pmt_payloadid = trim(e.PolicyNumber)
      AND p.pmt_id = concat('Jur:', trim(e.PolicyNumber), '-CA7EmplBenefitsLiabCovWithNoCovForNewlyAcquiredOrF-', trim(e.StateCd))
  )

UNION ALL

-- Fix 9: Employee Benefits Retroactive Date (This one didn't have IN subquery - add EXISTS for consistency)
SELECT DISTINCT
    concat('CA7Jur:',trim(e.PolicyNumber),'-','CA7RetroactiveDate3','-',trim(e.StateCd)) AS pmt_id,
    concat('Jur:', trim(e.PolicyNumber), '-CA7EmplBenefitsLiabCovWithNoCovForNewlyAcquiredOrF-', trim(e.StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7RetroactiveDate3' AS codeidentifier,
    CAST(e.RetroDate AS STRING) AS value,
    trim(e.PolicyNumber) AS pmt_payloadid
FROM jur_employeebenefits_df e
WHERE (e.AggregateLimit IS NOT NULL OR e.EachEmployeeLimit IS NOT NULL)
  AND EXISTS (
      SELECT 1 FROM statecovterms_view p 
      WHERE p.CodeIdentifier = 'CA7EmplBenefitsLiabCovWithNoCovForNewlyAcquiredOrF'
      AND p.pmt_payloadid = trim(e.PolicyNumber)
      AND p.pmt_id = concat('Jur:', trim(e.PolicyNumber), '-CA7EmplBenefitsLiabCovWithNoCovForNewlyAcquiredOrF-', trim(e.StateCd))
  )

UNION ALL

-- Fix 10: Customer Complaint Manual Premium (THE BIG PROBLEM - was using wrong source table)
SELECT DISTINCT
    concat('CA7Jur:',trim(f.PolicyNumber),'-','CA7ManualPremium52','-',trim(f.StateCd)) AS pmt_id,
    concat('Jur:', trim(f.PolicyNumber), '-CA7CustomerComplaintLegalDefenseCovWithNoCovForNew-', trim(f.StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7ManualPremium52' AS codeidentifier,
    CAST('0' AS STRING) AS value,
    trim(f.PolicyNumber) AS pmt_payloadid
FROM jur_formcode_df f  -- Changed from jur_employeebenefits_df to jur_formcode_df
WHERE f.FormId_Mapped = 'CA7CustomerComplaintLegalDefenseCovWithNoCovForNew'  -- Added proper filter
  AND EXISTS (
      SELECT 1 FROM statecovterms_view p 
      WHERE p.CodeIdentifier = 'CA7CustomerComplaintLegalDefenseCovWithNoCovForNew'
      AND p.pmt_payloadid = trim(f.PolicyNumber)
      AND p.pmt_id = concat('Jur:', trim(f.PolicyNumber), '-CA7CustomerComplaintLegalDefenseCovWithNoCovForNew-', trim(f.StateCd))
  )

UNION ALL

-- Fix 11: Accidental Death Benefits Limit
SELECT DISTINCT
    concat('CA7Jur:',trim(n.PolicyNumber),'-','CA7AccidentalDeathBenefitsLimit','-',trim(n.StateCd)) AS pmt_id,
    concat('Jur:', trim(n.PolicyNumber), '-CA7AddedAndCombinationFirstPartyBenefitsEndorsemen-', trim(n.StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7AccidentalDeathBenefitsLimit' AS codeidentifier,
    CAST(trim(n.PIPMisc2) AS STRING) AS value,
    trim(n.PolicyNumber) AS pmt_payloadid
FROM NoFaultPip_df n
WHERE trim(n.StateCd)='PA' 
  AND trim(n.PIPSymbollist)='5' 
  AND trim(n.AddPIPSymbollist)='5' 
  AND trim(n.PIPLimit)='1ST PARTY'
  AND EXISTS (
      SELECT 1 FROM statecovterms_view p 
      WHERE p.CodeIdentifier = 'CA7AddedAndCombinationFirstPartyBenefitsEndorsemen'
      AND p.pmt_payloadid = trim(n.PolicyNumber)
      AND p.pmt_id = concat('Jur:', trim(n.PolicyNumber), '-CA7AddedAndCombinationFirstPartyBenefitsEndorsemen-', trim(n.StateCd))
  )

UNION ALL

-- Fix 12: Benefits
SELECT DISTINCT
    concat('CA7Jur:',trim(n.PolicyNumber),'-','CA7Benefits','-',trim(n.StateCd)) AS pmt_id,
    concat('Jur:', trim(n.PolicyNumber), '-CA7AddedAndCombinationFirstPartyBenefitsEndorsemen-', trim(n.StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7Benefits' AS codeidentifier,
    CAST(
        CASE WHEN trim(n.AddlPIPLimit) IS NULL OR trim(n.AddlPIPLimit) = '' THEN 'AddedFirst_partyBenefits'
             ELSE 'CombinationFirst_partyBenefits' END AS STRING
    ) AS value,
    trim(n.PolicyNumber) AS pmt_payloadid
FROM NoFaultPip_df n
WHERE trim(n.StateCd)='PA' 
  AND trim(n.PIPSymbollist)='5' 
  AND trim(n.AddPIPSymbollist)='5' 
  AND trim(n.PIPLimit)='1ST PARTY'
  AND EXISTS (
      SELECT 1 FROM statecovterms_view p 
      WHERE p.CodeIdentifier = 'CA7AddedAndCombinationFirstPartyBenefitsEndorsemen'
      AND p.pmt_payloadid = trim(n.PolicyNumber)
      AND p.pmt_id = concat('Jur:', trim(n.PolicyNumber), '-CA7AddedAndCombinationFirstPartyBenefitsEndorsemen-', trim(n.StateCd))
  )

UNION ALL

-- Fix 13: Funeral Expense Benefits Limit
SELECT DISTINCT
    concat('CA7Jur:',trim(n.PolicyNumber),'-','CA7FuneralExpenseBenefitsLimit','-',trim(n.StateCd)) AS pmt_id,
    concat('Jur:', trim(n.PolicyNumber), '-CA7AddedAndCombinationFirstPartyBenefitsEndorsemen-', trim(n.StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7FuneralExpenseBenefitsLimit' AS codeidentifier,
    CAST(trim(n.PIPMisc1) AS STRING) AS value,
    trim(n.PolicyNumber) AS pmt_payloadid
FROM NoFaultPip_df n
WHERE trim(n.StateCd)='PA' 
  AND trim(n.PIPSymbollist)='5' 
  AND trim(n.AddPIPSymbollist)='5' 
  AND trim(n.PIPLimit)='1ST PARTY'
  AND EXISTS (
      SELECT 1 FROM statecovterms_view p 
      WHERE p.CodeIdentifier = 'CA7AddedAndCombinationFirstPartyBenefitsEndorsemen'
      AND p.pmt_payloadid = trim(n.PolicyNumber)
      AND p.pmt_id = concat('Jur:', trim(n.PolicyNumber), '-CA7AddedAndCombinationFirstPartyBenefitsEndorsemen-', trim(n.StateCd))
  )

UNION ALL

-- Fix 14: Medical Expense Benefits Limit
SELECT DISTINCT
    concat('CA7Jur:',trim(n.PolicyNumber),'-','CA7MedicalExpenseBenefitsLimit','-',trim(n.StateCd)) AS pmt_id,
    concat('Jur:', trim(n.PolicyNumber), '-CA7AddedAndCombinationFirstPartyBenefitsEndorsemen-', trim(n.StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7MedicalExpenseBenefitsLimit' AS codeidentifier,
    CAST(trim(n.MedExpenseLimit) AS STRING) AS value,
    trim(n.PolicyNumber) AS pmt_payloadid
FROM NoFaultPip_df n
WHERE trim(n.StateCd)='PA' 
  AND trim(n.PIPSymbollist)='5' 
  AND trim(n.AddPIPSymbollist)='5' 
  AND trim(n.PIPLimit)='1ST PARTY'
  AND EXISTS (
      SELECT 1 FROM statecovterms_view p 
      WHERE p.CodeIdentifier = 'CA7AddedAndCombinationFirstPartyBenefitsEndorsemen'
      AND p.pmt_payloadid = trim(n.PolicyNumber)
      AND p.pmt_id = concat('Jur:', trim(n.PolicyNumber), '-CA7AddedAndCombinationFirstPartyBenefitsEndorsemen-', trim(n.StateCd))
  )

UNION ALL

-- Fix 15: Work Loss Benefits Limit
SELECT DISTINCT
    concat('CA7Jur:',trim(n.PolicyNumber),'-','CA7WorkLossBenefitsLimit','-',trim(n.StateCd)) AS pmt_id,
    concat('Jur:', trim(n.PolicyNumber), '-CA7AddedAndCombinationFirstPartyBenefitsEndorsemen-', trim(n.StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7WorkLossBenefitsLimit' AS codeidentifier,
    CAST(trim(n.WorkLoss) AS STRING) AS value,
    trim(n.PolicyNumber) AS pmt_payloadid
FROM NoFaultPip_df n
WHERE trim(n.StateCd)='PA' 
  AND trim(n.PIPSymbollist)='5' 
  AND trim(n.AddPIPSymbollist)='5' 
  AND trim(n.PIPLimit)='1ST PARTY'
  AND EXISTS (
      SELECT 1 FROM statecovterms_view p 
      WHERE p.CodeIdentifier = 'CA7AddedAndCombinationFirstPartyBenefitsEndorsemen'
      AND p.pmt_payloadid = trim(n.PolicyNumber)
      AND p.pmt_id = concat('Jur:', trim(n.PolicyNumber), '-CA7AddedAndCombinationFirstPartyBenefitsEndorsemen-', trim(n.StateCd))
  )

UNION ALL

SELECT DISTINCT
    concat('CA7Jur:',trim(n.PolicyNumber),'-','CA7AddedPersonalInjuryProtectionOption','-',trim(n.StateCd)) AS pmt_id,
    concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7AddedPersonalInjuryProtectionOption' AS codeidentifier,
    CAST(trim(n.AdditionPIP) AS STRING) AS value,
    trim(n.PolicyNumber) AS pmt_payloadid
FROM NoFaultPip_df n
WHERE trim(n.StateCd)='MN' 
  AND EXISTS (
      SELECT 1 FROM statecovterms_view p 
      WHERE p.CodeIdentifier = 'CA7AddedPersonalInjuryProtection1'
      AND p.pmt_payloadid = trim(n.PolicyNumber)
      AND p.pmt_id = concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd))
  )

UNION ALL

SELECT DISTINCT
    concat('CA7Jur:',trim(n.PolicyNumber),'-','CA7OptionNumber','-',trim(n.StateCd)) AS pmt_id,
    concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7OptionNumber' AS codeidentifier,
    CAST(CASE WHEN trim(n.AdditionPIP) IS NULL THEN 'NoCoverage' ELSE trim(n.AdditionPIP) END AS STRING) AS value,
    trim(n.PolicyNumber) AS pmt_payloadid
FROM NoFaultPip_df n
WHERE trim(n.StateCd) IN ('NJ','KS','KY') 
  AND EXISTS (
      SELECT 1 FROM statecovterms_view p 
      WHERE p.CodeIdentifier = 'CA7AddedPersonalInjuryProtection1'
      AND p.pmt_payloadid = trim(n.PolicyNumber)
      AND p.pmt_id = concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd))
  )

UNION ALL

SELECT DISTINCT
    concat('CA7Jur:',trim(n.PolicyNumber),'-','CA7AddedDeathBenefit','-',trim(n.StateCd)) AS pmt_id,
    concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7AddedDeathBenefit' AS codeidentifier,
    CAST('10000' AS STRING) AS value,
    trim(n.PolicyNumber) AS pmt_payloadid
FROM jur_formcode_df n
WHERE  n.FormId_Mapped='CA7AddedDeathBenefit'
  AND EXISTS (
      SELECT 1 FROM statecovterms_view p 
      WHERE p.CodeIdentifier = 'CA7AddedPersonalInjuryProtection1'
      AND p.pmt_payloadid = trim(n.PolicyNumber)
      AND p.pmt_id = concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd))
  )

UNION ALL
--CA7FuneralExpenseBenefits12

SELECT DISTINCT
    concat('CA7Jur:',trim(n.PolicyNumber),'-','CA7FuneralExpenseBenefits12','-',trim(n.StateCd)) AS pmt_id,
    concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7FuneralExpenseBenefits12' AS codeidentifier,
    CAST('2000' AS STRING) AS value,
    trim(n.PolicyNumber) AS pmt_payloadid
FROM jur_formcode_df n
WHERE  n.FormId_Mapped='CA7AddedDeathBenefit'
  AND EXISTS (
      SELECT 1 FROM statecovterms_view p 
      WHERE p.CodeIdentifier = 'CA7AddedPersonalInjuryProtection1'
      AND p.pmt_payloadid = trim(n.PolicyNumber)
      AND p.pmt_id = concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd))
  )

UNION ALL

SELECT DISTINCT
    concat('CA7Jur:',trim(n.PolicyNumber),'-','CA7IncomeContinuationBenefitsMaxWeeklyLimit','-',trim(n.StateCd)) AS pmt_id,
    concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7IncomeContinuationBenefitsMaxWeeklyLimit' AS codeidentifier,
    CAST(
        CASE 
            WHEN trim(n.AdditionPIP) = '1' THEN '100'
            WHEN trim(n.AdditionPIP) = '2' THEN '125'
            WHEN trim(n.AdditionPIP) = '3' THEN '175'
            WHEN trim(n.AdditionPIP) = '4' THEN '250'
            WHEN trim(n.AdditionPIP) = '5' THEN '400'
            WHEN trim(n.AdditionPIP) = '6' THEN '500'
            WHEN trim(n.AdditionPIP) = '7' THEN '600'
            WHEN trim(n.AdditionPIP) = '8' THEN '700'
            WHEN trim(n.AdditionPIP) = '9' THEN '100'
            WHEN trim(n.AdditionPIP) = '10' THEN '125'
            WHEN trim(n.AdditionPIP) = '11' THEN '175'
            WHEN trim(n.AdditionPIP) = '12' THEN '250'
            WHEN trim(n.AdditionPIP) = '13' THEN '400'
            WHEN trim(n.AdditionPIP) = '14' THEN '500'
            WHEN trim(n.AdditionPIP) = '15' THEN '600'
            WHEN trim(n.AdditionPIP) = '16' THEN '700'
        END AS STRING
    ) AS value,
    trim(n.PolicyNumber) AS pmt_payloadid
FROM NoFaultPip_df n
WHERE trim(n.StateCd) IN ('NJ') 
  AND EXISTS (
      SELECT 1 FROM statecovterms_view p 
      WHERE p.CodeIdentifier = 'CA7AddedPersonalInjuryProtection1'
      AND p.pmt_payloadid = trim(n.PolicyNumber)
      AND p.pmt_id = concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd))
  )

UNION ALL

SELECT DISTINCT
    concat('CA7Jur:',trim(n.PolicyNumber),'-','CA7IncomeContinuationBenefitsMaxTotalLimit','-',trim(n.StateCd)) AS pmt_id,
    concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7IncomeContinuationBenefitsMaxTotalLimit' AS codeidentifier,
    CAST(
        CASE 
            WHEN trim(n.AdditionPIP) = '1' THEN '10400'
            WHEN trim(n.AdditionPIP) = '2' THEN '13000'
            WHEN trim(n.AdditionPIP) = '3' THEN '18200'
            WHEN trim(n.AdditionPIP) = '4' THEN '26000'
            WHEN trim(n.AdditionPIP) = '5' THEN '41600'
            WHEN trim(n.AdditionPIP) = '6' THEN '52000'
            WHEN trim(n.AdditionPIP) = '7' THEN '62400'
            WHEN trim(n.AdditionPIP) = '8' THEN '72800'
            WHEN trim(n.AdditionPIP) IN ('9','10','11','12','13','14','15','16') THEN 'Unlimited'
        END AS STRING
    ) AS value,
    trim(n.PolicyNumber) AS pmt_payloadid
FROM NoFaultPip_df n
WHERE trim(n.StateCd) IN ('NJ') 
  AND EXISTS (
      SELECT 1 FROM statecovterms_view p 
      WHERE p.CodeIdentifier = 'CA7AddedPersonalInjuryProtection1'
      AND p.pmt_payloadid = trim(n.PolicyNumber)
      AND p.pmt_id = concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd))
  )

UNION ALL

SELECT DISTINCT
    concat('CA7Jur:',trim(n.PolicyNumber),'-','CA7EssentialServicesBenefitsMaxDailyLimit','-',trim(n.StateCd)) AS pmt_id,
    concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7EssentialServicesBenefitsMaxDailyLimit' AS codeidentifier,
    CAST(
        CASE 
            WHEN trim(n.AdditionPIP) = '1' THEN '12'
            WHEN trim(n.AdditionPIP) IN ('2','3','4','5','6','7','8','10','11','12','13','14','15','16') THEN '20'
            WHEN trim(n.AdditionPIP) = '9' THEN '12'
        END AS STRING
    ) AS value,
    trim(n.PolicyNumber) AS pmt_payloadid
FROM NoFaultPip_df n
WHERE trim(n.StateCd) IN ('NJ') 
  AND EXISTS (
      SELECT 1 FROM statecovterms_view p 
      WHERE p.CodeIdentifier = 'CA7AddedPersonalInjuryProtection1'
      AND p.pmt_payloadid = trim(n.PolicyNumber)
      AND p.pmt_id = concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd))
  )

UNION ALL

SELECT DISTINCT
    concat('CA7Jur:',trim(n.PolicyNumber),'-','CA7NamedInsuredType','-',trim(n.StateCd)) AS pmt_id,
    concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7NamedInsuredType' AS codeidentifier,
    CAST(
        CASE 
            WHEN trim(n.AdditionPIP) IN ('1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16') THEN 'NamedInsuredandOneorMoreResidentRelatives'
        END AS STRING
    ) AS value,
    trim(n.PolicyNumber) AS pmt_payloadid
FROM NoFaultPip_df n
WHERE trim(n.StateCd) IN ('NJ') 
  AND EXISTS (
      SELECT 1 FROM statecovterms_view p 
      WHERE p.CodeIdentifier = 'CA7AddedPersonalInjuryProtection1'
      AND p.pmt_payloadid = trim(n.PolicyNumber)
      AND p.pmt_id = concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd))
  )

  UNION ALL

  SELECT DISTINCT
    concat('CA7Jur:',trim(n.PolicyNumber),'-','CA7MedicalExpensesBenefitLimit1','-',trim(n.StateCd)) AS pmt_id,
    concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7MedicalExpensesBenefitLimit1' AS codeidentifier,
    CAST(
        CASE 
            WHEN trim(n.AdditionPIP) = '1' THEN '12500'
            when trim(n.AdditionPIP) = '2' THEN '27500'
        END AS STRING
    ) AS value,
    trim(n.PolicyNumber) AS pmt_payloadid
FROM NoFaultPip_df n
WHERE trim(n.StateCd) IN ('KS') 
  AND EXISTS (
      SELECT 1 FROM statecovterms_view p 
      WHERE p.CodeIdentifier = 'CA7AddedPersonalInjuryProtection1'
      AND p.pmt_payloadid = trim(n.PolicyNumber)
      AND p.pmt_id = concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd))
  )

UNION ALL
 SELECT DISTINCT
    concat('CA7Jur:',trim(n.PolicyNumber),'-','CA7RehabilitationExpenses','-',trim(n.StateCd)) AS pmt_id,
    concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7RehabilitationExpenses' AS codeidentifier,
    CAST(
        CASE 
            WHEN trim(n.AdditionPIP) = '1' THEN '12500'
            when trim(n.AdditionPIP) = '2' THEN '27500'
        END AS STRING
    ) AS value,
    trim(n.PolicyNumber) AS pmt_payloadid
FROM NoFaultPip_df n
WHERE trim(n.StateCd) IN ('KS') 
  AND EXISTS (
      SELECT 1 FROM statecovterms_view p 
      WHERE p.CodeIdentifier = 'CA7AddedPersonalInjuryProtection1'
      AND p.pmt_payloadid = trim(n.PolicyNumber)
      AND p.pmt_id = concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd))
  )

  UNION ALL

   SELECT DISTINCT
    concat('CA7Jur:',trim(n.PolicyNumber),'-','CA7WorkLossBenefitsLimit3','-',trim(n.StateCd)) AS pmt_id,
    concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7WorkLossBenefitsLimit3' AS codeidentifier,
    CAST(
        CASE 
            WHEN trim(n.AdditionPIP) = '1' THEN '1050'
            when trim(n.AdditionPIP) = '2' THEN '1250'
        END AS STRING
    ) AS value,
    trim(n.PolicyNumber) AS pmt_payloadid
FROM NoFaultPip_df n
WHERE trim(n.StateCd) IN ('KS') 
  AND EXISTS (
      SELECT 1 FROM statecovterms_view p 
      WHERE p.CodeIdentifier = 'CA7AddedPersonalInjuryProtection1'
      AND p.pmt_payloadid = trim(n.PolicyNumber)
      AND p.pmt_id = concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd))
  )

   UNION ALL
-- CA7FuneralExpensesBenefitLimit
SELECT DISTINCT
    concat('CA7Jur:',trim(n.PolicyNumber),'-','CA7FuneralExpensesBenefitLimit','-',trim(n.StateCd)) AS pmt_id,
    concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7FuneralExpensesBenefitLimit' AS codeidentifier,
    CAST(
        CASE 
            WHEN trim(n.AdditionPIP) = '1' THEN '2000'
            when trim(n.AdditionPIP) = '2' THEN '2500'
        END AS STRING
    ) AS value,
    trim(n.PolicyNumber) AS pmt_payloadid
FROM NoFaultPip_df n
WHERE trim(n.StateCd) IN ('KS')
  AND EXISTS (
      SELECT 1 FROM statecovterms_view p 
      WHERE p.CodeIdentifier = 'CA7AddedPersonalInjuryProtection1'
      AND p.pmt_payloadid = trim(n.PolicyNumber)
      AND p.pmt_id = concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd))
  )

UNION ALL

-- CA7SurvivorLoss1
SELECT DISTINCT
    concat('CA7Jur:',trim(n.PolicyNumber),'-','CA7SurvivorLoss1','-',trim(n.StateCd)) AS pmt_id,
    concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7SurvivorLoss1' AS codeidentifier,
    CAST(
        CASE 
            WHEN trim(n.AdditionPIP) = '1' THEN '1050'
            when trim(n.AdditionPIP) = '2' THEN '1250'
        END AS STRING
    ) AS value,
    trim(n.PolicyNumber) AS pmt_payloadid
FROM NoFaultPip_df n
WHERE trim(n.StateCd) IN ('KS')
  AND EXISTS (
      SELECT 1 FROM statecovterms_view p 
      WHERE p.CodeIdentifier = 'CA7AddedPersonalInjuryProtection1'
      AND p.pmt_payloadid = trim(n.PolicyNumber)
      AND p.pmt_id = concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd))
  )

UNION ALL

-- CA7EssentialServices
SELECT DISTINCT
    concat('CA7Jur:',trim(n.PolicyNumber),'-','CA7EssentialServices','-',trim(n.StateCd)) AS pmt_id,
    concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7EssentialServices' AS codeidentifier,
    CAST(
        CASE 
            WHEN trim(n.AdditionPIP) = '1' THEN '25'
            when trim(n.AdditionPIP) = '2' THEN '25'
        END AS STRING
    ) AS value,
    trim(n.PolicyNumber) AS pmt_payloadid
FROM NoFaultPip_df n
WHERE trim(n.StateCd) IN ('KS')
  AND EXISTS (
      SELECT 1 FROM statecovterms_view p 
      WHERE p.CodeIdentifier = 'CA7AddedPersonalInjuryProtection1'
      AND p.pmt_payloadid = trim(n.PolicyNumber)
      AND p.pmt_id = concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd))
  )

UNION ALL

-- CA7BenefitPeriod
SELECT DISTINCT
    concat('CA7Jur:',trim(n.PolicyNumber),'-','CA7BenefitPeriod','-',trim(n.StateCd)) AS pmt_id,
    concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7BenefitPeriod' AS codeidentifier,
    CAST(
        CASE 
            WHEN trim(n.AdditionPIP) = '1' THEN '1year'
            when trim(n.AdditionPIP) = '2' THEN '2years'
        END AS STRING
    ) AS value,
    trim(n.PolicyNumber) AS pmt_payloadid
FROM NoFaultPip_df n
WHERE trim(n.StateCd) IN ('KS')
  AND EXISTS (
      SELECT 1 FROM statecovterms_view p 
      WHERE p.CodeIdentifier = 'CA7AddedPersonalInjuryProtection1'
      AND p.pmt_payloadid = trim(n.PolicyNumber)
      AND p.pmt_id = concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd))
  )

UNION ALL

-- CA7BenefitPeriod
SELECT DISTINCT
    concat('CA7Jur:',trim(n.PolicyNumber),'-','CA7Limit91','-',trim(n.StateCd)) AS pmt_id,
    concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd)) AS pmt_parent,
    'CA7StateCov' AS pmt_parent_type,
    'CA7Limit91' AS codeidentifier,
    CAST(
        CASE 
            WHEN trim(PIPLimit) = '10,000' THEN '10000'
            WHEN trim(PIPLimit) = '25,000' THEN '25000'
            WHEN trim(PIPLimit) = '40,000' THEN '40000'
            WHEN trim(PIPLimit) = '90,000' THEN '90000'
        END AS STRING
    ) AS value,
    trim(n.PolicyNumber) AS pmt_payloadid
FROM NoFaultPip_df n
WHERE trim(n.StateCd) IN ('FL')
  AND EXISTS (
      SELECT 1 FROM statecovterms_view p 
      WHERE p.CodeIdentifier = 'CA7AddedPersonalInjuryProtection1'
      AND p.pmt_payloadid = trim(n.PolicyNumber)
      AND p.pmt_id = concat('Jur:', trim(n.PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(n.StateCd))
  )
"""

try:
    logger.info("Ensuring parent table is cached...")
    spark.sql("CACHE TABLE statecovterms_view")
    logger.info("Loading child data with fixed query...")
    covterm_CA7UninsuredMotoristPropertyDamagetext2_data = spark.sql(covterm_CA7UninsuredMotoristPropertyDamagetext2_FIXED_query)
    covterm_CA7UninsuredMotoristPropertyDamagetext2_data.createOrReplaceTempView("covterm_CA7UninsuredMotoristPropertyDamagetext2_data")
    child_count = covterm_CA7UninsuredMotoristPropertyDamagetext2_data.count()
    logger.info(f"Child records loaded: {child_count}")
    print(f"Total child records: {child_count}")
    display(covterm_CA7UninsuredMotoristPropertyDamagetext2_data)
except Exception as e:
    logger.error(f"Error loading covterm_CA7UninsuredMotoristPropertyDamagetext2_data: {e}")
    sys.exit(1)


# COMMAND ----------


# SQL to find mismatching pmt_parent, count null pmt_id, and check for duplicates for covterm_CA7UninsuredMotoristPropertyDamagetext2_data
invalid_refs_sql = """
SELECT DISTINCT pmt_parent
FROM covterm_CA7UninsuredMotoristPropertyDamagetext2_data
WHERE pmt_parent NOT IN (
  SELECT DISTINCT pmt_id FROM statecovterms_view
)
"""

null_pmt_id_sql = """
SELECT COUNT(*) as null_count
FROM covterm_CA7UninsuredMotoristPropertyDamagetext2_data
WHERE pmt_id IS NULL
"""

duplicate_pmt_id_sql = """
SELECT pmt_id, COUNT(*) as cnt
FROM covterm_CA7UninsuredMotoristPropertyDamagetext2_data
GROUP BY pmt_id
HAVING COUNT(*) > 1
"""

invalid_refs = spark.sql(invalid_refs_sql)
null_pmt_id_count = spark.sql(null_pmt_id_sql).collect()[0]['null_count']
duplicate_pmt_ids = spark.sql(duplicate_pmt_id_sql)

if invalid_refs.count() == 0 and null_pmt_id_count == 0 and duplicate_pmt_ids.count() == 0:
    logger.info('refrential integrity checks passed')
    logger.info('No Null pmt_id values found')
    logger.info('No duplicate pmt_id values found')

    covterm_CA7UninsuredMotoristPropertyDamagetext2_data.write.jdbc(url=jdbc_url_pmtin, table='covterm', mode='append', properties=properties)
else:
    if invalid_refs.count() > 0:
        logger.error("Referential integrity issue: Some pmt_parent values do not exist in statecovterms_view.")
        for row in invalid_refs.collect():
            logger.error(f"Invalid pmt_parent: {row.pmt_parent}")
    if null_pmt_id_count > 0:
        logger.error(f"Null pmt_id values found in covterm_CA7UninsuredMotoristPropertyDamagetext2_data: {null_pmt_id_count}")
    if duplicate_pmt_ids.count() > 0:
        logger.error("Duplicate pmt_id values found in covterm_CA7UninsuredMotoristPropertyDamagetext2_data.")
        for row in duplicate_pmt_ids.collect():
            logger.error(f"Duplicate pmt_id: {row.pmt_id} with count: {row.cnt}")

# COMMAND ----------


garagekeepers_coverage_query = '''
/* -------------------------------------------------------------------------------------------------------------- */
/* Sprint 7 - Garagekeepers Coverage                                                                              */
/* --------                                                                                                       */
/* Views used:                                                                                                    */
/* ViewCurPic_AuStInput, ViewCurPic_GrStGKLInput, ViewCurPic_GrLocInput, ViewCurPic_GrLocGKLInput                 */
/* NOTE: These values are contained in Gr tables at the state and location level.                                 */ 
/* -------------------------------------------------------------------------------------------------------------- */

SELECT 
    -- CoPolicyPointer fields
    P."SystemAssignId",
    P1."LOB",
    P."PolicyPrefixCd" || ' ' || TRIM(P."PolicyId") || COALESCE(TRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
    (TRIM(P."PolicyId") || COALESCE(TRIM(P."PolicySuffixCd"), ' '))::VARCHAR(8) AS "AccountNumber",

    -- AuPolInput fields
    AuPolInput."NAICCd" AS "NAICCode",

    -- ViewCurPic_AuStInput fields
    AuStInput."StateCd" AS "StateCode",

    -- ViewCurPic_GrStGKLInput fields
    GrStGKLInput."LegalLiabDirTypeCd" AS "LegalDirect",
    GrStGKLInput."PrimOrExcessTypeCd" AS "PrimaryExcess",

    GrLocInput."LocNo" AS "LocationNumber",
    GrLocInput."BldgNo" AS "BuildingNumber",

    -- ViewCurPic_GrLocGKLInput fields
    GrLocGKLInput."BlktRatedNCd" AS "Blanket",
    GrLocGKLInput."ValetParkingInd" AS "ValetParking",
    GrLocGKLInput."CompMaxLmt" AS "CompLimit",
    GrLocGKLInput."CompPerCarDedAmt" AS "CompDeductible",
    GrLocGKLInput."SpecPerilsMaxLmt" AS "SCLLimit",
    GrLocGKLInput."SpPPerCarDedAmt" AS "SCLDeductible",
    GrLocGKLInput."CollMaxLmt" AS "CollisionLimit",
    GrLocGKLInput."CollDedAmt" AS "CollisionDeductible",
    GrLocGKLInput."GKLCompRtOvrdLmt" AS "CompRate",
    GrLocGKLInput."GKLSPRtOvrdLmt" AS "SCOLRate",
    GrLocGKLInput."GKLCollRtOvrdLmt" AS "CollRate"

FROM Policy AS P1
INNER JOIN CoPolicyPointer AS P
    ON P."SystemAssignId" = P1."SourceSystemId"
INNER JOIN ViewCurPic_AuPolInput AS AuPolInput
    ON P."SystemAssignId" = AuPolInput."SystemAssignId"
INNER JOIN ViewCurPic_AuStInput AS AuStInput
    ON P."SystemAssignId" = AuStInput."SystemAssignId"
INNER JOIN ViewCurPic_GrStGKLInput AS GrStGKLInput
    ON P."SystemAssignId" = GrStGKLInput."SystemAssignId"
    AND AuStInput."StateCd" = GrStGKLInput."StateCd"
INNER JOIN ViewCurPic_GrLocInput AS GrLocInput
    ON P."SystemAssignId" = GrLocInput."SystemAssignId"
    AND AuStInput."StateCd" = GrLocInput."StateCd"
INNER JOIN ViewCurPic_GrLocGKLInput AS GrLocGKLInput
    ON P."SystemAssignId" = GrLocGKLInput."SystemAssignId"
    AND AuStInput."StateCd" = GrLocGKLInput."StateCd"
    AND GrLocInput."LocNo" = GrLocGKLInput."LocNo"
    AND GrLocInput."BldgNo" = GrLocGKLInput."BldgNo"
WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
  AND P1."LOB" IN ('AU', 'GR', 'TU')
ORDER BY "PolicyNumber", "StateCode", "LocationNumber", "BuildingNumber"
'''

try:
    garagekeepers_coverage_df = eval(exec_select_landing)(garagekeepers_coverage_query)
    garagekeepers_coverage_df.createOrReplaceTempView("garagekeepers_coverage_df")
    print(garagekeepers_coverage_df.count())
    display(garagekeepers_coverage_df)
except Exception as e:
    logger.info("error loading garagekeepers_coverage_df: {}".format(e))
    sys.exit(1)

# COMMAND ----------

garagekeepers_coverage_query = '''
/* -------------------------------------------------------------------------------------------------------------- */
/* Sprint 7 - Garagekeepers Coverage                                                                              */
/* --------                                                                                                       */
/* Views used:                                                                                                    */
/* ViewCurPic_AuStInput, ViewCurPic_GrStGKLInput, ViewCurPic_GrLocInput, ViewCurPic_GrLocGKLInput                 */
/* NOTE: These values are contained in Gr tables at the state and location level.                                 */ 
/* -------------------------------------------------------------------------------------------------------------- */


SELECT 
    -- CoPolicyPointer fields
    P."SystemAssignId",
    P1."LOB",
    P."PolicyPrefixCd" || ' ' || TRIM(P."PolicyId") || COALESCE(TRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
    (TRIM(P."PolicyId") || COALESCE(TRIM(P."PolicySuffixCd"), ' '))::VARCHAR(8) AS "AccountNumber",

    -- AuPolInput fields
    AuPolInput."NAICCd" AS "NAICCode",

    -- ViewCurPic_AuStInput fields
    AuStInput."StateCd" AS "StateCode",

    -- ViewCurPic_GrStGKLInput fields
    GrStGKLInput."LegalLiabDirTypeCd" AS "LegalDirect",
    GrStGKLInput."PrimOrExcessTypeCd" AS "PrimaryExcess",

    GrLocInput."LocNo" AS "LocationNumber",
    GrLocInput."BldgNo" AS "BuildingNumber",

    -- ViewCurPic_GrLocGKLInput fields
    GrLocGKLInput."BlktRatedNCd" AS "Blanket",
    GrLocGKLInput."ValetParkingInd" AS "ValetParking",
    GrLocGKLInput."CompMaxLmt" AS "CompLimit",
    GrLocGKLInput."CompPerCarDedAmt" AS "CompDeductible",
    GrLocGKLInput."SpecPerilsMaxLmt" AS "SCLLimit",
    GrLocGKLInput."SpPPerCarDedAmt" AS "SCLDeductible",
    GrLocGKLInput."CollMaxLmt" AS "CollisionLimit",
    GrLocGKLInput."CollDedAmt" AS "CollisionDeductible",
    GrLocGKLInput."GKLCompRtOvrdLmt" AS "CompRate",
    GrLocGKLInput."GKLSPRtOvrdLmt" AS "SCOLRate",
    GrLocGKLInput."GKLCollRtOvrdLmt" AS "CollRate",

    -- CoLocInfo fields
    CoLocInfo."AddressLine1Tx" as "addressline1"

FROM Policy AS P1
INNER JOIN CoPolicyPointer AS P
    ON P."SystemAssignId" = P1."SourceSystemId"
INNER JOIN ViewCurPic_AuPolInput AS AuPolInput
    ON P."SystemAssignId" = AuPolInput."SystemAssignId"
INNER JOIN ViewCurPic_AuStInput AS AuStInput
    ON P."SystemAssignId" = AuStInput."SystemAssignId"
INNER JOIN ViewCurPic_GrStGKLInput AS GrStGKLInput
    ON P."SystemAssignId" = GrStGKLInput."SystemAssignId"
    AND AuStInput."StateCd" = GrStGKLInput."StateCd"
INNER JOIN ViewCurPic_GrLocInput AS GrLocInput
    ON P."SystemAssignId" = GrLocInput."SystemAssignId"
    AND AuStInput."StateCd" = GrLocInput."StateCd"
INNER JOIN ViewCurPic_GrLocGKLInput AS GrLocGKLInput
    ON P."SystemAssignId" = GrLocGKLInput."SystemAssignId"
    AND AuStInput."StateCd" = GrLocGKLInput."StateCd"
    AND GrLocInput."LocNo" = GrLocGKLInput."LocNo"
    AND GrLocInput."BldgNo" = GrLocGKLInput."BldgNo"
INNER JOIN "ViewCurPic_CoLocInfo" AS  CoLocInfo
    ON P."SystemAssignId" = CoLocInfo."SystemAssignId"
    AND AuStInput."StateCd" = CoLocInfo."StateCd"
	AND GrLocInput."LocNo" = CoLocInfo."LocNo"
    AND GrLocInput."BldgNo" = CoLocInfo."BldgNo"

WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
  AND P1."LOB" IN ('AU', 'GR', 'TU')
ORDER BY "PolicyNumber", "StateCode", "LocationNumber", "BuildingNumber"
'''

try:
    garagekeepers_coverage_df = eval(exec_select_landing)(garagekeepers_coverage_query)
    garagekeepers_coverage_df.createOrReplaceTempView("garagekeepers_coverage_df")
    print(garagekeepers_coverage_df.count())
    display(garagekeepers_coverage_df)
except Exception as e:
    logger.info("error loading garagekeepers_coverage_df: {}".format(e))
    sys.exit(1)

# COMMAND ----------

stateschecovterm_Garagekeeper_query = '''
SELECT DISTINCT
    concat('Stateschedcov-', trim(PolicyNumber), '-CA7Garagekeepers-', trim(StateCode),'-',trim(addressline1)) AS pmt_id,
    concat('Jursched:', trim(PolicyNumber), '-','CA7Garagekeepers' , '-', trim(StateCode)) AS pmt_parent,
    addressline1 as stringcol1,
    CASE WHEN trim(LegalDirect) ='L' AND trim(PrimaryExcess) = 'E' then 'Direct Excess'
    WHEN trim(LegalDirect)='D' AND trim(PrimaryExcess)='P' then 'Direct Primary'
    WHEN trim(LegalDirect)='L' then 'Legal Liability'

    
    
    
    END AS optioncol1,
    'usd' as preferredcoveragecurrency,
    'usd' AS preferredsettlementcurrency,
    trim(PolicyNumber) AS pmt_payloadid
FROM  garagekeepers_coverage_df
'''

try:
    stateschecovterm_Garagekeeper_data = spark.sql(stateschecovterm_Garagekeeper_query)
    stateschecovterm_Garagekeeper_data.createOrReplaceTempView("stateschecovterm_Garagekeeper_data")
    print(stateschecovterm_Garagekeeper_data.count())
    display(stateschecovterm_Garagekeeper_data)
except Exception as e:
    logger.info("error loading stateschecovterm_Garagekeeper_data: {}".format(e))
    sys.exit(1)

# COMMAND ----------

statesched = eval(exec_select_pmtin)('select * from ca7stateschedcov')
statesched.createOrReplaceTempView("statesched")
display(statesched)

# COMMAND ----------

# SQL to find mismatching pmt_parent, count null pmt_id, and check for duplicates for stateschecovterm_data
invalid_refs_sql = """
SELECT DISTINCT pmt_parent
FROM stateschecovterm_Garagekeeper_data
WHERE pmt_parent NOT IN (
  SELECT DISTINCT pmt_id FROM statesched
)
"""

null_pmt_id_sql = """
SELECT COUNT(*) as null_count
FROM stateschecovterm_Garagekeeper_data
WHERE pmt_id IS NULL
"""

duplicate_pmt_id_sql = """
SELECT pmt_id, COUNT(*) as cnt
FROM stateschecovterm_Garagekeeper_data
GROUP BY pmt_id
HAVING COUNT(*) > 1
"""

invalid_refs = spark.sql(invalid_refs_sql)
null_pmt_id_count = spark.sql(null_pmt_id_sql).collect()[0]['null_count']
duplicate_pmt_ids = spark.sql(duplicate_pmt_id_sql)

if invalid_refs.count() == 0 and null_pmt_id_count == 0 and duplicate_pmt_ids.count() == 0:
    logger.info('referential integrity checks passed')
    logger.info('No Null pmt_id values found')
    logger.info('No duplicate pmt_id values found')

    stateschecovterm_Garagekeeper_data.write.jdbc(url=jdbc_url_pmtin, table='ca7stateschedcovitem', mode='append', properties=properties)
else:
    if invalid_refs.count() > 0:
        logger.error("Referential integrity issue: Some pmt_parent values do not exist in statesched.")
        for row in invalid_refs.collect():
            logger.error(f"Invalid pmt_parent: {row.pmt_parent}")
    if null_pmt_id_count > 0:
        logger.error(f"Null pmt_id values found in stateschecovterm_data: {null_pmt_id_count}")
    if duplicate_pmt_ids.count() > 0:
        logger.error("Duplicate pmt_id values found in stateschecovterm_data.")
        for row in duplicate_pmt_ids.collect():
            logger.error(f"Duplicate pmt_id: {row.pmt_id} with count: {row.cnt}")

# COMMAND ----------

jur_CA7PANamedIndivsBroadenedFirstPartyBenefits_query = '''
select 
      P."SystemAssignId",
    P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
    CAST(RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",
  austnofltpipinput."StateCd",
  austnofltpipinput."MedExpenseLimit",
  austnofltpipinput."WorkLossLimit",
  austnofltpipinput."FuneralExpenseInd"
from policy P1
inner join copolicypointer P
  on P."SystemAssignId" = P1."SourceSystemId"
inner join viewcurpic_austnofltpipinput austnofltpipinput
  on P."SystemAssignId" = austnofltpipinput."SystemAssignId"
where austnofltpipinput."StateCd" = 'PA'
  and austnofltpipinput."NoFltPIPThrshAmt" = '1ST PARTY'
  and austnofltpipinput."BrdAddlPIPInd" is not null
  
'''

try:
  jur_CA7PANamedIndivsBroadenedFirstPartyBenefits_df = eval(exec_select_landing)(jur_CA7PANamedIndivsBroadenedFirstPartyBenefits_query)
  jur_CA7PANamedIndivsBroadenedFirstPartyBenefits_df.createOrReplaceTempView("jur_CA7PANamedIndivsBroadenedFirstPartyBenefits_df")
  print(jur_CA7PANamedIndivsBroadenedFirstPartyBenefits_df.count())
  display(jur_CA7PANamedIndivsBroadenedFirstPartyBenefits_df)
except Exception as e:
  logger.info("error loading jur_formcode_df: {}".format(e))
  sys.exit(1)

# COMMAND ----------


statesched = eval(exec_select_pmtin)("select * from ca7stateschedcov")
statesched.createOrReplaceTempView("statesched")
display(statesched)

# COMMAND ----------

stateschecovterm_query = '''
SELECT DISTINCT
    concat('Stateschedcov-', trim(PolicyNumber), '-CA7PANamedIndivsBroadenedFirstPartyBenefits-', trim(StateCd)) AS pmt_id,
    concat('Jursched:', trim(PolicyNumber), '-','CA7PANamedIndivsBroadenedFirstPartyBenefits' , '-', trim(StateCd)) AS pmt_parent,
   
    CASE WHEN trim(MedExpenseLimit) = '100000' THEN '100000' END AS optioncol5,
    CASE WHEN trim(WorkLossLimit) = 'Y' THEN 'Included' END AS optioncol6,
    trim(FuneralExpenseInd) AS optioncol4,
    'usd' as preferredcoveragecurrency,
    'usd' AS preferredsettlementcurrency,
    trim(PolicyNumber) AS pmt_payloadid
FROM jur_CA7PANamedIndivsBroadenedFirstPartyBenefits_df
'''

try:
    stateschecovterm_data = spark.sql(stateschecovterm_query)
    stateschecovterm_data.createOrReplaceTempView("stateschecovterm_data")
    print(stateschecovterm_data.count())
    display(stateschecovterm_data)
except Exception as e:
    logger.info("error loading stateschecovterm_data: {}".format(e))
    sys.exit(1)

# COMMAND ----------

# SQL to find mismatching pmt_parent, count null pmt_id, and check for duplicates for stateschecovterm_data
invalid_refs_sql = """
SELECT DISTINCT pmt_parent
FROM stateschecovterm_data
WHERE pmt_parent NOT IN (
  SELECT DISTINCT pmt_id FROM statesched
)
"""

null_pmt_id_sql = """
SELECT COUNT(*) as null_count
FROM stateschecovterm_data
WHERE pmt_id IS NULL
"""

duplicate_pmt_id_sql = """
SELECT pmt_id, COUNT(*) as cnt
FROM stateschecovterm_data
GROUP BY pmt_id
HAVING COUNT(*) > 1
"""

invalid_refs = spark.sql(invalid_refs_sql)
null_pmt_id_count = spark.sql(null_pmt_id_sql).collect()[0]['null_count']
duplicate_pmt_ids = spark.sql(duplicate_pmt_id_sql)

if invalid_refs.count() == 0 and null_pmt_id_count == 0 and duplicate_pmt_ids.count() == 0:
    logger.info('referential integrity checks passed')
    logger.info('No Null pmt_id values found')
    logger.info('No duplicate pmt_id values found')

    stateschecovterm_data.write.jdbc(url=jdbc_url_pmtin, table='ca7stateschedcovitem', mode='append', properties=properties)
else:
    if invalid_refs.count() > 0:
        logger.error("Referential integrity issue: Some pmt_parent values do not exist in statesched.")
        for row in invalid_refs.collect():
            logger.error(f"Invalid pmt_parent: {row.pmt_parent}")
    if null_pmt_id_count > 0:
        logger.error(f"Null pmt_id values found in stateschecovterm_data: {null_pmt_id_count}")
    if duplicate_pmt_ids.count() > 0:
        logger.error("Duplicate pmt_id values found in stateschecovterm_data.")
        for row in duplicate_pmt_ids.collect():
            logger.error(f"Duplicate pmt_id: {row.pmt_id} with count: {row.cnt}")

# COMMAND ----------

# MAGIC %md
# MAGIC # NoaCoverages covterm

# COMMAND ----------

ca7noacov_query="""
SELECT 
  -- "CoPolicyPointer" fields
  "p"."SystemAssignId",
  "p1"."LOB",
  "p"."PolicyPrefixCd" || ' ' || RTRIM("p"."PolicyId") || COALESCE(RTRIM("p"."PolicySuffixCd"), ' ') AS "PolicyNumber",
  CAST(RTRIM("p"."PolicyId") || COALESCE(RTRIM("p"."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",

  -- "CoBusinessInfo" fields
  "cobusinessinfo"."BusTypeTx" AS "BusinessType",

  -- "AuPolInput" fields
  "aupolinput"."LiabSymbolLst" AS "LiabilitySymbol",
  "aupolinput"."PIPSymbolLst" AS "PIPSymbol",
   "aupolinput"."LiabLimitTypeCd" AS "LiabilityLimitTypeCode",
    "aupolinput"."CSLLiabLimit" AS "LiabilityLimit",
     "aupolinput"."BI1Limit" AS "BI1Limit",
    "aupolinput"."BI2Limit" AS "BI2Limit",
    "aupolinput"."PDLimit" AS "PDLimit",

  -- "ViewCurPic_AuStInput" fields
  "austinput"."StateCd" AS "StateCode",
  "austinput"."AddrLine1Desc" AS "AddressLine",
  "austinput"."TownCd" AS "TownCode",
  "austinput"."TerritoryCd" AS "TerritoryCode",
  "austinput"."CityCtyNmTx" AS "City",
  "austinput"."CityCntyCd" AS "CityCountyCode",
  "austinput"."CityCtyNmTx" || ' ' || "austinput"."ZipCd" AS "AddressLine1",
  "austinput"."ZipCd" AS "ZipCode",
  "austinput"."RiskId",
  "austinput"."MedPayLimit" AS "MedPayLimit",


  -- "ViewCurPic_AuStHiredPDInput" fields
  "austhiredpdinput"."HoldHarmlessAgrmtInd" AS "WithholdHarmlessAgreement",
  "austhiredpdinput"."CollCostHireAmt" AS "CostOfHireInsuredProvidingPrimary",
  "austhiredpdinput"."OTCCostHireAmt" AS "CostOfHireInsuredProvidingExcess",

  -- "ViewCurPic_AuStNonOwnedInput" fields
  "austnonownedinput"."NOwnEmplCnt" AS "NumberOfEmployees",
  "austnonownedinput"."PartnersCnt" AS "NumberOfPartners",
  "austnonownedinput"."VolCt" AS "NumberOfVolunteers",
  "austnonownedinput"."EmplAddInsdInd" AS "EmpAddinsd",


  "austnonownedinput"."ExtVolInd" AS "ExtendedCoverageForVolunteers",
  "austnonownedinput"."ExtPartnerLLCInd" AS "ExtendedCoverageForPartners",

  -- "ViewCurPic_AuStNoFltPIPInput" fields
  "austnofltpipinput"."PIPMisc1Ind" AS "PIPMisc1",
  "austnofltpipinput"."PIPMisc2Ind" AS "PIPMisc2",
  "austnofltpipinput"."PIPMisc3Ind" AS "PIPMisc3",
  "austnofltpipinput"."PIPMisc4Ind" AS "PIPMisc4",
  "austnofltpipinput"."PIPMisc5Ind" AS "PIPMisc5",

  -- "ViewCurPic_AuLocInput" fields
  "aulocinput"."LocNo" AS "LocationNumber",
  "aulocinput"."BldgNo" AS "BuildingNumber"

FROM "policy" "p1"
INNER JOIN "public"."copolicypointer" "p"
  ON "p"."SystemAssignId" = "p1"."SourceSystemId"
INNER JOIN "public"."viewcurpic_cobusinessinfo" "cobusinessinfo"
  ON "p"."SystemAssignId" = "cobusinessinfo"."SystemAssignId"
INNER JOIN "public"."viewcurpic_aupolinput" "aupolinput"
  ON "p"."SystemAssignId" = "aupolinput"."SystemAssignId"

-- Sprint 4 joins
INNER JOIN "public"."viewcurpic_austinput" "austinput"
  ON "p"."SystemAssignId" = "austinput"."SystemAssignId"
LEFT JOIN "public"."viewcurpic_austhiredpdinput" "austhiredpdinput"
  ON "p"."SystemAssignId" = "austhiredpdinput"."SystemAssignId"
  AND "austinput"."StateCd" = "austhiredpdinput"."StateCd"
LEFT JOIN "public"."viewcurpic_austnonownedinput" "austnonownedinput"
  ON "p"."SystemAssignId" = "austnonownedinput"."SystemAssignId"
  AND "austinput"."StateCd" = "austnonownedinput"."StateCd"
LEFT JOIN "public"."viewcurpic_austnofltpipinput" "austnofltpipinput"
  ON "p"."SystemAssignId" = "austnofltpipinput"."SystemAssignId"
  AND "austinput"."StateCd" = "austnofltpipinput"."StateCd"
LEFT JOIN "public"."viewcurpic_aulocinput" "aulocinput"
  ON "p"."SystemAssignId" = "aulocinput"."SystemAssignId"
  AND "austinput"."StateCd" = "aulocinput"."StateCd"

WHERE "p1"."PolicyStatus" IN ('INFORCE', 'FUTURE')
AND P1."LOB" IN ('TU','AU','GR')
AND AuStNonOwnedInput."NOwnEmplCnt" is NOT NULL



ORDER BY "NumberOfEmployees"
"""
try:
  # Execute the query and create a temp view for downstream use
  ca7noacov_df = eval(exec_select_landing)(ca7noacov_query)
  ca7noacov_df.createOrReplaceTempView("ca7noacov_df")  # Create a temporary view for further processing
  print(ca7noacov_df.count())  # Print the count of records retrieved
  display(ca7noacov_df)  # Display the results
except Exception as e:
  # Log the error and exit if there is an issue loading the data
  logger.info("error ca7noacov: {}".format(e)) 
  sys.exit(1) 


# COMMAND ----------

noa_union_query = '''
SELECT DISTINCT
    concat('CA7NonOwnedAutoLiabNOA:',trim(PolicyNumber),'-','CA7LiabCovType2','-',trim(StateCode)) AS pmt_id,
     concat('CA7noaCov:',trim(PolicyNumber),'-',"CA7NonOwnedAutoLiabNOA",'-',trim(StateCode)) AS pmt_parent,
    
    'CA7NOACov' AS pmt_parent_type,
    'CA7LiabCovType2' AS codeidentifier,
    CASE 
        -- 1 maps to CombinedSingleLimit,2 maps to SplitLimit
        WHEN LiabilityLimitTypeCode = '1' THEN 'CombinedSingleLimit'
        WHEN LiabilityLimitTypeCode = '2' THEN 'SplitLimit'
    END  AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM ca7noacov_df WHERE liabilitysymbol is not null

UNION ALL

SELECT DISTINCT
    concat('CA7NonOwnedAutoLiabNOA:',trim(PolicyNumber),'-','CA7LiabLimit','-',trim(StateCode)) AS pmt_id,
    concat('CA7noaCov:',trim(PolicyNumber),'-','CA7NonOwnedAutoLiabNOA','-',trim(StateCode)) AS pmt_parent,
    'CA7NOACov' AS pmt_parent_type,
    'CA7LiabLimit' AS codeidentifier,
    CASE 
        WHEN LiabilitySymbol IS NULL THEN 'NotApplicable'
        WHEN LiabilityLimitTypeCode = '1' AND trim(LiabilityLimit) in (
            '15000','110000','25000','50000','55000','30000','90000','85000','70000','60000','75000','65000','35000',
            '100000','125000','150000','200000','250000','300000','350000','400000','500000','510000','600000','750000',
            '1000000','1500000','2000000','2500000','3000000','5000000','7500000','10000000',
            '20000/40000','25000/50000','35000/70000','50000/100000','75000/150000','100000/200000','100000/300000',
            '200000/200000','200000/400000','250000/500000','300000/300000','300000/600000','500000/1000000',
            '1000000/1000000','2000000/2000000','2500000/2500000','5000000/5000000','10000000/10000000'
        ) THEN trim(LiabilityLimit)
        WHEN LiabilityLimitTypeCode = '2' AND trim(PDLimit) in (
            '15000','110000','25000','50000','55000','30000','90000','85000','70000','60000','75000','65000','35000',
            '100000','125000','150000','200000','250000','300000','350000','400000','500000','510000','600000','750000',
            '1000000','1500000','2000000','2500000','3000000','5000000','7500000','10000000',
            '20000/40000','25000/50000','35000/70000','50000/100000','75000/150000','100000/200000','100000/300000',
            '200000/200000','200000/400000','250000/500000','300000/300000','300000/600000','500000/1000000',
            '1000000/1000000','2000000/2000000','2500000/2500000','5000000/5000000','10000000/10000000'
        ) THEN trim(PDLimit)
    END AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM ca7noacov_df WHERE liabilitysymbol is not null

UNION ALL

SELECT DISTINCT
    concat('CA7NonOwnedAutoLiabNOA:',trim(PolicyNumber),'-','CA7ExtendedCovForEmpls','-',trim(StateCode)) AS pmt_id,
    concat('CA7noaCov:',trim(PolicyNumber),'-',"CA7NonOwnedAutoLiabExtendedEmplsNOA",'-',trim(StateCode)) AS pmt_parent,
    'CA7NOACov' AS pmt_parent_type,
    'CA7ExtendedCovForEmpls' AS codeidentifier,
    CASE 
        WHEN EmpAddinsd= 'Y' THEN 'Yes'
        ELSE 'No'
    END  AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM ca7noacov_df

UNION ALL

SELECT DISTINCT
    concat('CA7NonOwnedAutoLiabNOA:',trim(PolicyNumber),'-','CA7ExtendedCovForPartners','-',trim(StateCode)) AS pmt_id,
    concat('CA7noaCov:',trim(PolicyNumber),'-',"CA7NonOwnedAutoLiabExtendedEmplsNOA",'-',trim(StateCode)) AS pmt_parent,
    'CA7NOACov' AS pmt_parent_type,
    'CA7ExtendedCovForPartners' AS codeidentifier,
    CASE 
        WHEN ExtendedCoverageForPartners= 'Y' THEN 'Yes'
        ELSE 'No'
    END  AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM ca7noacov_df

UNION ALL

SELECT DISTINCT
    concat('CA7NonOwnedAutoLiabNOA:',trim(PolicyNumber),'-','CA7ExtendedCovForVolunteers','-',trim(StateCode)) AS pmt_id,
    concat('CA7noaCov:',trim(PolicyNumber),'-',"CA7NonOwnedAutoLiabExtendedVolunteersNOA",'-',trim(StateCode)) AS pmt_parent,
    'CA7NOACov' AS pmt_parent_type,
    'CA7ExtendedCovForVolunteers' AS codeidentifier,
    CASE 
        WHEN ExtendedCoverageForVolunteers = 'Y' THEN 'Yes'
       ELSE 'No'
    END AS value,
    trim(PolicyNumber) AS pmt_payloadid
FROM ca7noacov_df

UNION ALL

SELECT DISTINCT
    concat('CA7NonOwnedAutoLiabNOA:',trim(PolicyNumber),'-','CA7Limit32','-',trim(StateCode)) AS pmt_id,
   concat('CA7noaCov:',trim(PolicyNumber),'-',"CA7NonOwnedAutoMedPayNOA",'-',trim(StateCode)) AS pmt_parent,
    'CA7NOACov' AS pmt_parent_type,
    'CA7Limit32' AS codeidentifier,
    case 
        when trim(MedPayLimit) is null then 'NoCoverage'
        when cast(trim(MedPayLimit) as decimal(18,0)) in (500, 1000, 2000, 5000, 10000) 
            then cast(cast(trim(MedPayLimit) as decimal(18,0)) as string)
        else 'NoCoverage'
    end as value,
   
    trim(PolicyNumber) AS pmt_payloadid
FROM ca7noacov_df


'''

noa_union_data = spark.sql(noa_union_query)
noa_union_data.createOrReplaceTempView("noa_union_data")
display(noa_union_data)

# COMMAND ----------

noa_union_data.write.jdbc(url=jdbc_url_pmtin, table='covterm', mode='append', properties=properties)

# COMMAND ----------

# MAGIC %md
# MAGIC # Conditions Covterm

# COMMAND ----------

ca7commautolinecond_query = '''
/* ------------------------------------------------------------------------------------------------------------------------ */
/* Sprint5_Line – Standard - Other and Exclusion Coverages (PostgreSQL Version)                                             */
/* ------------------------------------------------------------------------------------------------------------------------ */

SELECT DISTINCT
    -- CoPolicyPointer fields
    P."SystemAssignId",
    P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
    CAST(RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",
    P."PolicyEffDt",

    -- ViewCurPic_AuStInput fields
    AuStInput."StateCd",

    -- ViewCurPic_AUSelectedForm fields
    AUSelectedForm."FormId",
    AUSelectedForm."FormDescTx" AS "FormDescription"

    -- ViewCurPic_AUFormFillin fields (commented out: not used in this query)
    -- AUFormFillin."FillinTx" AS "PersonOrOrganization"
    -- AUFormFillin."PageNo" AS "PageNumber",
    -- AUFormFillin."OccurrenceNo" AS "OccurenceNumber"

FROM policy P1
INNER JOIN copolicypointer P
   ON P."SystemAssignId" = P1."SourceSystemId"
INNER JOIN viewcurpic_austinput AuStInput
   ON P."SystemAssignId" = AuStInput."SystemAssignId"
LEFT JOIN viewcurpic_auselectedform AUSelectedForm
   ON P."SystemAssignId" = AUSelectedForm."SystemAssignId"
   AND AuStInput."StateCd" = AUSelectedForm."StateCd"
-- LEFT JOIN viewcurpic_auformfillin AUFormFillin
   -- ON P."SystemAssignId" = AUFormFillin."SystemAssignId"
   -- AND AUSelectedForm."FormId" = AUFormFillin."FormId"
   -- AUFormFillin join commented out: not used in this query

WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
  AND P1."LOB" IN ('AU', 'GR', 'TU')
  AND AUSelectedForm."FormId" IN (
     'CA 27 18', 'CA 23 97', 'CA 25 58', 'CA 04 43', 'CA 99 15', 'CA 23 25', 'CA 01 21', 'CA 25 61', 'PCA0518', 'PCA0527', 'CA 04 22', 'CA 04 49', 'IL 09 17', 'CA 25 67', 'CA 27 15','CA 04 44', 'PCA 05 04'
  )

UNION ALL

SELECT DISTINCT
    -- CoPolicyPointer fields
    P."SystemAssignId",
    P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
    CAST(RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",
    P."PolicyEffDt",

    -- ViewCurPic_AUSelectedForm fields for 'CW'
    AUSelectedForm."StateCd" AS "StateCd",
    AUSelectedForm."FormId",
    AUSelectedForm."FormDescTx" AS "FormDescription"

    -- ViewCurPic_AUFormFillin fields (commented out: not used in this query)
    -- AUFormFillin."FillinTx" AS "PersonOrOrganization"
    -- AUFormFillin."PageNo" AS "PageNumber",
    -- AUFormFillin."OccurrenceNo" AS "OccurenceNumber"

FROM policy P1
INNER JOIN copolicypointer P
   ON P."SystemAssignId" = P1."SourceSystemId"
INNER JOIN viewcurpic_aupolinput AuPolInput
   ON P."SystemAssignId" = AuPolInput."SystemAssignId"
LEFT JOIN viewcurpic_auselectedform AUSelectedForm
   ON P."SystemAssignId" = AUSelectedForm."SystemAssignId"
   AND trim(AUSelectedForm."StateCd") = 'CW'
-- LEFT JOIN viewcurpic_auformfillin AUFormFillin
   -- ON P."SystemAssignId" = AUFormFillin."SystemAssignId"
   -- AND AUSelectedForm."FormId" = AUFormFillin."FormId"
   -- AUFormFillin join commented out: not used in this query

WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
  AND P1."LOB" IN ('AU', 'GR', 'TU')
  AND trim(AUSelectedForm."FormId") IN (
      'CA 27 18', 'CA 23 97', 'CA 25 58', 'CA 04 43', 'CA 99 15', 'CA 23 25', 'CA 01 21', 'CA 25 61', 'PCA0518', 'PCA0527', 'CA 04 22', 'CA 04 49', 'IL 09 17', 'CA 25 67', 'CA 27 15','CA 04 44', 'PCA 05 04'
  )

ORDER BY "PolicyNumber", "StateCd", "FormId"
-- "PageNumber", "OccurenceNumber"
'''
try:
  Line_level_cond_CA = eval(exec_select_landing)(ca7commautolinecond_query)
  Line_level_cond_CA.createOrReplaceTempView("Line_level_cond_CA")
  print(Line_level_cond_CA.count())
  display(Line_level_cond_CA)
except Exception as e:
 # logger.info("error loading Line_level_exclusions: {}".format(e)) 
  sys.exit(1)
 # logger.info("error loading Line_level_exclusions: {}".format(e)) 
  sys.exit(1)

# COMMAND ----------


manual_premium_queries = [
    ("CA7ManualPremium105", "CA7AutomaticInsuredStatusForNewlyAcquiredOrFormedL_CA7ManualPremium105_query", "CA 27 18"),
    ("CA7ManualPremium3", "CA7CovForInjuryToLeasedWorkers_CA7ManualPremium3_query", "CA 23 25"),
    ("CA7ManualPremium5", "CA7LmtdMexico_CA7ManualPremium5_query", "CA 01 21"),
    ("CA7ManualPremium180", "CA7ExpandedCovTerritoryForGeneralLiabCovsAddition2_CA7ManualPremium180_query", "CA 25 61"),
    ("CA7ManualPremium18", "CA7ExtendedReportingPeriodEndorsementForEmplBenefi_CA7ManualPremium18_query", "IL 09 17"),
]

for view_name, _, form_id in manual_premium_queries:
    query = f'''
    WITH parent_ids AS (
        SELECT 
            left(concat('CA7CommAutoLinecond:', trim(PolicyNumber), '_', 
                CASE
                    WHEN trim(FormId) = 'CA 27 18' THEN 'CA7AutomaticInsuredStatusForNewlyAcquiredOrFormedLl'
                    WHEN trim(FormId) = 'CA 23 97' THEN 'CA7AmphibiousVehicles'
                    WHEN trim(FormId) = 'CA 25 58' THEN 'CA7AmendmentOfLmtsOfInsGeneralLiabCovs'
                    WHEN trim(FormId) = 'CA 04 43' THEN 'CA7WaiverOfTransferOfRightsOfRecoveryAgainstOther1'
                    WHEN trim(FormId) = 'CA 99 15' THEN 'CA7GovBodiesAmendatoryEndorsement'
                    WHEN trim(FormId) = 'CA 23 25' THEN 'CA7CovForInjuryToLeasedWorkers'
                    WHEN trim(FormId) = 'CA 01 21' THEN 'CA7LmtdMexico'
                    WHEN trim(FormId) = 'CA 25 61' THEN 'CA7ExpandedCovTerritoryForGeneralLiabCovsAddition2'
                    WHEN trim(FormId) IN ('PCA0518', 'PCA0527', 'CA 04 22') THEN 'CA7EarlierNoticeOfCancellationProvidedByUs'
                    WHEN trim(FormId) = 'CA 04 49' THEN 'CA7PrimaryAndNoncontributoryOtherInsuranceConditio'
                    WHEN trim(FormId) = 'IL 09 17' THEN 'CA7ResidentAgentCountersignature'
                    WHEN trim(FormId) = 'CA 25 67' THEN 'CA7AmendmentOfPersonalAndAdvertisingInjuryDefiniti'
                    WHEN trim(FormId) = 'CA 27 15' THEN 'CA7AmendmentOfPersonalAndAdvertisingInjuryDefiniti'
                    ELSE 'UnKnownCodeIdentifier'
                END
            ), 99) AS parent_pmt_id,
            PolicyNumber
        FROM Line_level_cond_CA
        WHERE trim(FormId) = '{form_id}'
    )
    SELECT 
        concat('{view_name}', trim(PolicyNumber), '_', ROW_NUMBER() OVER (PARTITION BY trim(PolicyNumber) ORDER BY trim(PolicyNumber))) AS pmt_id,
        parent_pmt_id AS pmt_parent,
        'CA7CommAutoLineCond' AS pmt_parent_type,
        '{view_name}' AS codeidentifier,
        '0' AS value,
        trim(PolicyNumber) AS pmt_payloadid
    FROM parent_ids
    '''
    try:
        cond_df = spark.sql(query)
        cond_df.createOrReplaceTempView(view_name)
        print(cond_df.count())
        display(cond_df)
    except Exception as e:
        print("error")
        #sys.exit(1)

# COMMAND ----------

cond_df.write.jdbc(url=jdbc_url_pmtin, table='covterm', mode='append', properties=properties)

# COMMAND ----------




# COMMAND ----------

