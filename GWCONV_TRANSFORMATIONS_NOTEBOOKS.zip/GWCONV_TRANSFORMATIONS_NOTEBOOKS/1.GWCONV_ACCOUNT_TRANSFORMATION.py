# Databricks notebook source
# Cell Purpose: Initialize logging for the ETL pipeline.
# Business Context: Ensures consistent, formatted logs for debugging, auditing, and monitoring the Guidewire insurance migration ETL process.
"""
This cell sets up a logger for the ETL process, configuring log levels and formatting for consistent output.
- Uses INFO for general logs and DEBUG for detailed debugging.
- StreamHandler outputs logs to the notebook console.
- FileHandler outputs logs to etl_logfile.log for persistent tracking.
- Any logger (by name) can be configured to write to this file by using the same FileHandler setup.
"""
import logging
import sys
import os


LOG_FILE = 'etl_logfile.log'
LOG_FORMAT = '%(asctime)s %(levelname)s: %(message)s'

# Function to get a logger and ensure it logs to both console and the shared file
def get_etl_logger(name):
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    
    # Remove all handlers if already set (to avoid duplicate logs in notebook reruns)
    if logger.hasHandlers():
        logger.handlers.clear()
    
    # StreamHandler for console output
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.INFO)
    formatter = logging.Formatter(LOG_FORMAT)
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)
    
    
    # FileHandler for log file
    file_handler = logging.FileHandler(LOG_FILE)
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(formatter)
    
    # Ensure the FileHandler is not duplicated
    if not any(isinstance(h, logging.FileHandler) for h in logger.handlers):
        logger.addHandler(file_handler)
    
    return logger

# Example: get the logger for this notebook
logger = get_etl_logger('Account_Holders_Locations')
logger.info(f"Logging initialized. Log file location: {os.path.abspath(LOG_FILE)}")

# COMMAND ----------

# Cell Purpose: Set up Databricks widgets and retrieve job context for tracking ETL runs.
# Business Context: Enables parameterization and job tracking for the ETL pipeline, supporting both interactive and scheduled job runs in Databricks.
"""
This cell creates widgets for job_id and job_run_id, retrieves the current notebook context, and extracts job and run IDs for logging and audit purposes.
"""
# Create widgets for job_id and job_run_id for parameterization and job tracking
# These widgets allow passing parameters when running as a Databricks job
# The job_id is used to identify the specific job, while job_run_id is used to track the execution of that job.

dbutils.widgets.text("job_id", "")
dbutils.widgets.text("job_run_id", "")

# Get the current notebook context for extracting job and run metadata
# This context provides information about the job execution environment, including job IDs and notebook path.
context = dbutils.notebook.entry_point.getDbutils().notebook().getContext()

# Extract jobId and jobRunId objects from context (may be Option types)
# These IDs are crucial for tracking the execution of the ETL process.
job_id_obj = context.jobId()          # Option type: may or may not be defined
job_run_id_obj = context.jobRunId()   # Option type: may or may not be defined

# Retrieve the full path to the current notebook for logging purposes
notebook_path = context.notebookPath().get() # Full path to the current notebook
# Extract the notebook name from the path for easier identification in logs
notebook_name = notebook_path.split('/')[-1]   # Extract the notebook name from the path

def safe_get_option(option_obj):
    """
    Safely extract a value from a Databricks Option object.
    Parameters:
        option_obj: Option (Databricks Java/Scala Option type)
            The object to extract the value from.
    Returns:
        value or None: The value if defined, else None.
    Exceptions:
        Catches all exceptions to avoid breaking job context extraction.
        This ensures that even if an error occurs, the job can continue running without interruption.
    """
    try:
        if option_obj.isDefined():
            return option_obj.get()  # Return the value if defined
        else:
            return None  # Return None if not defined
    except Exception:
        return None  # Return None in case of any exception

# Use the safe_get_option to retrieve the values, defaulting to 'Manual' if not found
# This provides a fallback mechanism for logging and auditing purposes.
job_id = safe_get_option(job_id_obj) or "Manual"    # Used for logging and audit
job_run_id = safe_get_option(job_run_id_obj) or "Manual"

# Output the retrieved IDs for debugging and traceability
# This print statement helps in verifying that the correct IDs are being used in the ETL process.
print(f"Job ID: {job_id}, Job Run ID: {job_run_id}")

# Redefine widgets with resolved values for downstream cells (ensures consistency)
# This step ensures that the widgets reflect the actual job and run IDs for any subsequent operations.
dbutils.widgets.text("job_id", str(job_id)) 
dbutils.widgets.text("job_run_id", str(job_run_id))

# COMMAND ----------

# DBTITLE 1,Run the configuration Notebook
# MAGIC %run ../configuration/configs
# MAGIC

# COMMAND ----------

# DBTITLE 1,Run the configuration Notebook
# MAGIC
# MAGIC %run ../configuration/postgres

# COMMAND ----------

# DBTITLE 1,ETL query for Account basic
logger = get_etl_logger('Account_Holders_Locations')
# Cell Purpose: Extract Account Basic data from the source system and create a temp view for downstream ETL steps.
# Business Context: This step loads the raw account holder data, which is the foundation for all subsequent transformations in the Guidewire insurance migration ETL pipeline.
account_basic_query = '''
-- CTE: producing_soc_profitcenter
--   Joins group codes with profit center descriptions for later enrichment
WITH producing_soc_profitcenter AS (
  SELECT 
    g."groupcode",  -- Group code from the group codes table
    g."p",          -- Additional field from the group codes table
    g."profitcentercode",  -- Profit center code from the group codes table
    g."soc",        -- SOC code from the group codes table
    p."profitcenterdescription"  -- Description of the profit center from the lookup table
  FROM lkpgroupcodesnova g
  LEFT JOIN lkpProfitCenterNova p
    ON p."profitcentercode" = g."profitcentercode"  -- Join to get descriptions for profit centers
),
-- CTE: lkp_sid and lkp_cid
--   Lookup tables for special profit center codes (SID, CID) used in business rules
lkp_sid AS (
  SELECT "profitcentercode", "profitcenterdescription"
  FROM lkpProfitCenterNova
  WHERE "profitcentercode" = 'SID'  -- Filter for SID profit center code
),
lkp_cid AS (
  SELECT "profitcentercode", "profitcenterdescription"
  FROM lkpProfitCenterNova
  WHERE "profitcentercode" = 'CID'  -- Filter for CID profit center code
)
SELECT DISTINCT
    RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS account_number,
    REGEXP_REPLACE(
      CoInsureName."InsuredNm",
      '[\x01-\x1F,\x92|]',
      ' '
    ) AS account_name,
    CoInsuredInfo."WorkPhoneNo"    AS work_phone,
    NULL                           AS fax_phone,
    CoInsuredInfo."EmailAddrTx"    AS email_address1,
    NULL                           AS email_address2,
    CoInsuredInfo."CountryCd"      AS country,
    CoInsuredInfo."AddrLine1Tx"    AS address1,
    CoInsuredInfo."AddrLine2Tx"    AS address2,
    CoInsuredInfo."AddrLine3Tx"    AS address3,
    CoInsuredInfo."CityNm"         AS city,
    CoInsuredInfo."CountyNm"       AS county,
    CoInsuredInfo."StateCd"        AS state,
    CoInsuredInfo."ZipCd"          AS zip_code,
    NULL                           AS address_type,
    NULL                           AS description,
    CoInsuredInfo."FEINId"         AS fein,
    NULL                           AS first_name,
    NULL                           AS last_name,
    CoBusinessInfo."BusDescTx"     AS business_operation_description,
    CoBusinessInfo."BusTypeCd"     AS account_organization_type,
    CoBusinessInfo."NAICCd"        AS industry_code,
    'Active'                       AS account_status,
    CoBusinessInfo."BusDescTx"     AS description_of_business,
    NULL                           AS organization,
    
    'en_US'                        AS primary_language,
    NULL                           AS year_business_started,
    'Company'                      AS account_holder_contact_type,
    cpd."GroupCd" AS groupcode,
     CoBusinessInfo."NAICCd" AS IndustryCode,
     CoProducer."ProducerId" AS producer_code,
    
    CASE
      WHEN pmi."MarketSegmentCd" = 'OAR'
        THEN 'OAR ORSIU Alternative Risk'
      WHEN cpd."GroupCd" IS NULL AND pmi."MarketSegmentCd" = 'SMU'
        THEN sid."profitcentercode" || ' ' || sid."profitcenterdescription"
      WHEN cpd."GroupCd" IN ('B094', 'C177')
        THEN sid."profitcentercode" || ' ' || sid."profitcenterdescription"
      WHEN cpd."GroupCd" IS NULL AND pmi."MarketSegmentCd" IN ('CMU','RMS')
        THEN cid."profitcentercode" || ' ' || cid."profitcenterdescription"
      WHEN cpd."GroupCd" LIKE 'T%' AND pmi."MarketSegmentCd" IN ('CMU','RMS')
        THEN cid."profitcentercode" || ' ' || cid."profitcenterdescription"
      WHEN soc."groupcode" IS NULL
        THEN 'PMA Companies'
      ELSE soc."profitcentercode" || ' ' || soc."profitcenterdescription"
    END AS "ProfitCenter",
    soc."soc" AS "SOC"
FROM   copolicypointer P
  
INNER JOIN viewcurpic_coinsuredname CoInsureName
  ON P."SystemAssignId" = CoInsureName."SystemAssignId"
INNER JOIN viewcurpic_coinsuredinfo CoInsuredInfo
  ON P."SystemAssignId" = CoInsuredInfo."SystemAssignId"
 
INNER JOIN viewcurpic_coproducer CoProducer
  ON P."SystemAssignId" = CoProducer."SystemAssignId"
INNER  JOIN viewcurpic_cobusinessinfo CoBusinessInfo
  ON P."SystemAssignId" = CoBusinessInfo."SystemAssignId"
INNER JOIN ViewCurPic_CoPMIndicatorInfo pmi ON pmi."SystemAssignId" = p."SystemAssignId"
INNER JOIN ViewCurPic_CoPolicyDetail cpd ON cpd."SystemAssignId" = p."SystemAssignId"
LEFT JOIN lkp_sid sid
  ON pmi."MarketSegmentCd" = 'SMU'
LEFT JOIN lkp_cid cid
  ON pmi."MarketSegmentCd" IN ('CMU','RMS')
LEFT JOIN producing_soc_profitcenter soc
  ON soc."groupcode" = cpd."GroupCd"


'''
try:
    logger.info(f"Fetched account_basic_query: {account_basic_query}")

    Account_Holder_Locations = eval(exec_select_landing)(account_basic_query)
    logger.info(f"Type of Account_Holder_Locations: {type(Account_Holder_Locations)}")

    if Account_Holder_Locations is None:
        logger.error("Account_Holder_Locations DataFrame is None. Check source query and connection.")
        raise RuntimeError("Account_Holder_Locations DataFrame is None. Query: {}".format(account_basic_query))

    Account_Holder_Locations.createOrReplaceTempView("Account_Holder_Locations")
    display(Account_Holder_Locations)

    logger.info("Successfully loaded Account_Holder_Locations")
except Exception as e:
    logger.error("Error executing Account_Holder_Locations query.", exc_info=True)
    raise RuntimeError(f"Failed to load Account_Holder_Locations: {e}")

# COMMAND ----------

# DBTITLE 1,Creating a temporary view for Account Basic
# Cell Purpose: Create a raw temporary view for Account Holder Locations and optionally display it for validation.
# Business Context: This view preserves the original extracted data for auditing and debugging before any transformation or deduplication.

# Create a temporary view for raw account holder locations (for traceability and debugging)
# This allows us to maintain the original data structure and content for future reference.
Account_Holder_Locations.createOrReplaceTempView("Account_Holder_Locations_Raw")  # Create a temp view for raw data
display(Account_Holder_Locations)
# Display the raw data to verify extraction and transformation logic (uncomment for interactive debugging)
# This step is crucial for ensuring that the data has been extracted correctly and is ready for further processing.
# display(spark.sql("SELECT * FROM Account_Holder_Locations_Raw"))  # Execute SQL to display the data

# COMMAND ----------

# DBTITLE 1,Deduplicate Account Basic with custom ranking
logger = get_etl_logger('Account_Holders_Locations')
# Cell Purpose: Deduplicate Account Holder records using custom ranking logic to ensure data integrity.
# Business Context: This process ensures that only one record per account_number is retained, as required by Guidewire's data model. 
# Deduplication is based on normalized account_number to eliminate formatting differences.

try:
    # Count rows before deduplication for data quality tracking
    pre_dedup_row_count = spark.sql("SELECT COUNT(*) FROM Account_Holder_Locations_Raw").collect()[0][0]
    logger.info(f"Raw Account_Holder_Locations row count before deduplication: {pre_dedup_row_count}")

    # Deduplicate using ROW_NUMBER() over normalized account_number
    # This SQL query creates a temporary view that retains only the first occurrence of each normalized account_number.
    spark.sql("""
        CREATE OR REPLACE TEMP VIEW Account_Holder_Locations AS
        SELECT *
        FROM (
            SELECT *,
                   ROW_NUMBER() OVER (
                       PARTITION BY REGEXP_REPLACE(account_number, '[^0-9]', '')  -- Normalize account_number by removing non-numeric characters
                       ORDER BY account_number  -- Order by account_number to retain the first occurrence
                   ) AS row_num
            FROM Account_Holder_Locations_Raw  -- Source table containing raw account holder data
        ) AS subquery
        WHERE row_num = 1  -- Filter to keep only the first row per normalized account_number
    """)

    # Count rows after deduplication for data quality tracking
    post_dedup_row_count = spark.sql("SELECT COUNT(*) FROM Account_Holder_Locations").collect()[0][0]
    logger.info(f"Deduplicated row count: {post_dedup_row_count}")
except Exception as e:
    # Log the error and halt execution if deduplication fails
    # This is critical as downstream processes require unique account_number entries.
    logger.error("Error during deduplication of Account_Holder_Locations", exc_info=True)
    sys.exit(1)

# Extract deduplicated DataFrame for further processing (optional, for interactive use)
deduplicated_df = spark.sql("SELECT * FROM Account_Holder_Locations")
# display(deduplicated_df)  # Uncomment to display the deduplicated DataFrame

# COMMAND ----------

# DBTITLE 1,Reading the TYPELIST table
logger = get_etl_logger('Account_Holders_Locations')
# Cell Purpose: Read the TYPELIST lookup table from the framework database for code mappings.
# Business Context: The typelist table provides code mappings (e.g., organization types, SOC types) used for enriching account and related tables in the Guidewire migration.
# This code fetches the typelist data, creates a temporary view for further processing, and handles any errors that may occur during the data retrieval.

typelist_query = """
SELECT *
FROM typelist"""

try:
    # Execute the query to fetch typelist data for code lookups (used in joins for enrichment)
    typelist = eval(exec_select_framework)(typelist_query)  # Fetching data from the typelist table
    typelist.createOrReplaceTempView("typelist")  # Creating a temporary view for further processing
    display(typelist)  # Display for validation (remove/comment for production)
except Exception as e:
    # Log and halt if typelist cannot be loaded, as downstream enrichment depends on it
    logger.info("error loading typelist: {}".format(e))  # Logging the error message for debugging
    sys.exit(1)  # Exiting the program to prevent further execution, as typelist is critical for subsequent operations

# COMMAND ----------

organization_typelist=execute_select_Framework("select * from organization_typelist")
organization_typelist.createOrReplaceTempView("organization_typelist")
display( organization_typelist)

# COMMAND ----------

organization_query='''
select DISTINCT 
CONCAT('Acct:', TRIM(ahl.account_number)) AS PMT_ID,  -- Unique account identifier for PMTIN
trim(ot.Name) as name,
trim(ahl.account_number) as pmt_payloadid

from Account_Holder_Locations ahl
LEFT JOIN organization_typelist ot
ON trim(ahl.producer_code)= trim(ot.BrokerNumber_Ext)
'''
try:
    organization_df = spark.sql(organization_query)  # Execute the SQL query to transform organization data
    organization_df.createOrReplaceTempView("organization_final")  # Create a temporary view for further processing
    display(organization_df)  # Display the transformed organization data for validation
except Exception as e:
    # Error handling: log and halt if organization transformation fails
    logger.info(f"Error loading organization_final: {e}")  # Log the error message for debugging
    sys.exit(1)  # Exit the program with an error status to indicate failure


# COMMAND ----------

logger = get_etl_logger('Account_Holders_Locations')
# Cell Purpose: Write the transformed Account table to the PMTIN database.
# Business Context: This step persists the cleaned and enriched Account data for downstream insurance processing and reporting.

try:
    # Attempt to write the DataFrame to the specified table
    write_and_log_pmtin(
      organization_df,
        table_name="organization",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
    )
    # Log success message if the write operation is successful
    logger.info("Successfully wrote Account_Holder_Locations to table 'account'.")
except Exception as e:
    # Log and halt if the write operation fails, as this is a critical ETL output
    logger.error(f"Error writing Account_Holder_Locations to table 'account'", exc_info=True)
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Account table Transformation
logger = get_etl_logger('Account_Holders_Locations')
# Cell Purpose: Transform and enrich Account data for the insurance ETL pipeline.
# Business Context: Standardizes and enriches account data, applies code lookups, and prepares the Account table for loading into the Guidewire target system.
# Deduplication is ensured by using DISTINCT and code lookups from typelist.

account_query = """
SELECT DISTINCT
    CONCAT('Acct:', TRIM(account_number)) AS PMT_ID,  -- Unique account identifier for PMTIN, prefixed with 'Acct:'
    TRIM(account_number) AS accountnumber,           -- Raw account number, trimmed of whitespace
    CASE 
        WHEN org_type.typelist = 'AccountOrgType' 
             AND org_type.codevalue = Account_Holder_Locations.account_organization_type 
        THEN org_type.code 
    END AS accountorgtype,                           -- Organization type code from typelist, derived based on matching criteria
    'Active' AS accountstatus,                       -- All accounts are set to 'Active' status by default
    description_of_business AS busopsdesc,           -- Description of business operations associated with the account
    'usd' AS preferredcoveragecurrency,              -- Default currency for coverage, set to 'usd'
    'usd' AS preferredsettlementcurrency,            -- Default currency for settlement, also set to 'usd'
    'en_US' AS primarylanguage,                      -- Default language for the account, set to 'en_US'
    'en_US' AS primarylocale,                        -- Default locale for the account, set to 'en_US'
    CASE 
        WHEN soc_type.typelist = 'SOCType_Ext' 
             AND soc_type.codevalue = Account_Holder_Locations.SOC 
        THEN soc_type.code 
    END AS producingsoctype_ext,                     -- SOC type code from typelist, derived based on matching criteria
    TRIM(CONCAT('IC:', account_number)) AS industrycode,  -- Industry code, prefixed with 'IC:', serves as a placeholder
    CONCAT('Acctloc:', TRIM(account_number)) AS primarylocation, -- Primary location reference, prefixed with 'Acctloc:'
    'Company' AS accountholdercontact_type,          -- All accounts are classified as 'Company' type
    "Synced" AS appeventsyncstatus,                  -- Sync status for downstream systems, set to 'Synced'
    TRIM(account_number) AS PMT_PayloadId            -- Payload ID for tracking, same as the raw account number
FROM Account_Holder_Locations
LEFT OUTER JOIN (
    SELECT * FROM typelist WHERE typelist = 'AccountOrgType'
) AS org_type
    ON org_type.codevalue = Account_Holder_Locations.account_organization_type  -- Join to get organization type based on account organization type
LEFT OUTER JOIN (
    SELECT * FROM typelist WHERE typelist = 'SOCType_Ext'
) AS soc_type
    ON soc_type.codevalue = Account_Holder_Locations.SOC  -- Join to get SOC type based on the SOC field in Account_Holder_Locations
"""

# Execute the query and handle errors
try:
    account_df = spark.sql(account_query)  # Execute the SQL query to transform account data
    account_df.createOrReplaceTempView("account_final")  # Create a temporary view for further processing
    # display(account_df)  # Display the transformed account data for validation
except Exception as e:
    # Error handling: log and halt if account transformation fails
    logger.info(f"Error loading account_final: {e}")  # Log the error message for debugging
    sys.exit(1)  # Exit the program with an error status to indicate failure

# COMMAND ----------

# DBTITLE 1,Writing Account Table in PMTIN
logger = get_etl_logger('Account_Holders_Locations')
# Cell Purpose: Write the transformed Account table to the PMTIN database.
# Business Context: This step persists the cleaned and enriched Account data for downstream insurance processing and reporting.

try:
    # Attempt to write the DataFrame to the specified table
    write_and_log_pmtin(
        account_df,
        table_name="account",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
    )
    # Log success message if the write operation is successful
    logger.info("Successfully wrote Account_Holder_Locations to table 'account'.")
except Exception as e:
    # Log and halt if the write operation fails, as this is a critical ETL output
    logger.error(f"Error writing Account_Holder_Locations to table 'account'", exc_info=True)
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Address table Transformation
logger = get_etl_logger('Account_Holders_Locations')
# Cell Purpose: Transform and deduplicate Address data for the insurance ETL pipeline.
# Business Context: Standardizes and deduplicates address data, mapping fields to the target schema for Guidewire migration. Each address is uniquely identified by account_number and formatted for downstream consumption.

# Create the deduplicated Address DataFrame using the latest address per account_number
address_query = """
SELECT
    CONCAT('Addr:', TRIM(account_number)) AS pmt_id,         -- Unique address identifier for PMTIN, prefixed with 'Addr:'
    trim(address1) AS addressline1,                          -- Address line 1 (trimmed to remove extra spaces)
    trim(address2) AS addressline2,                          -- Address line 2 (trimmed to remove extra spaces)
    'business' AS addresstype,                               -- Address type (default: business, as all addresses are business addresses)
    FALSE AS batchgeocode,                                   -- Batch geocode flag (default: FALSE, indicating no batch geocoding applied)
    "none"  AS geocodestatus,                                -- Geocode status (default: none, indicating no geocoding has been performed)
    TRIM(city) AS city,                                      -- City (trimmed to remove extra spaces)
    'US' AS country,                                         -- Country (default: US, as all addresses are assumed to be in the US)
    TRIM(county) AS county,                                  -- County (trimmed to remove extra spaces)
    FALSE AS manualaddressind_ext,                           -- Manual address indicator (default: FALSE, indicating no manual intervention)
    TRIM(zip_code) AS postalcode,                            -- Postal code (trimmed to remove extra spaces)
    TRIM(state) AS state,                                    -- State (trimmed to remove extra spaces)
    'unverified' AS verificationstatus_gc,                   -- Address verification status (default: unverified, as addresses are not verified at this stage)
    TRIM(account_number) AS pmt_payloadid                    -- Payload ID for tracking, using the account_number for reference
FROM Account_Holder_Locations
"""

# Execute the query and handle errors
try:
    address_df = spark.sql(address_query)  # Execute the SQL query to transform address data
    address_df.createOrReplaceTempView("address_final")  # Create a temporary view for further processing
    display(address_df)  # Display the transformed address data for validation
except Exception as e:
    # Error handling: log and halt if address transformation fails
    logger.info(f"Error loading address_final: {e}")  # Log the error message for debugging
    sys.exit(1)  # Exit the program with an error status to indicate failure

# COMMAND ----------

# DBTITLE 1,Writing Address Table in PMTIN
logger = get_etl_logger('Account_Holders_Locations')
# Cell Purpose: Write the transformed Address table to the PMTIN database.
# Business Context: This step persists the cleaned and standardized Address data for downstream insurance processing and reporting.
try:
    write_and_log_pmtin(
        address_df,
        table_name="address",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
    )
    logger.info("Successfully wrote Account_Holder_Locations to table 'address'.")
except Exception as e:
    # Log and halt if the write operation fails, as this is a critical ETL output
    logger.error(f"Error writing Account_Holder_Locations to table 'address'", exc_info=True)
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Company table Transformation
logger = get_etl_logger('Account_Holders_Locations')
# Cell Purpose: Transform and enrich Company data for the insurance ETL pipeline.
# Business Context: Creates the Company table, handling both standard and DBA company names, formats tax IDs, and prepares the data for loading into the Guidewire target system.

# Create a new DataFrame for Company Table (main company records)
Company_main_query = """
SELECT DISTINCT
    TRIM(CONCAT('Com:', TRIM(account_number), ' : ', monotonically_increasing_id())) AS pmt_id,  -- Unique company identifier, prefixed with 'Com:' and includes account number and a unique ID
    1 AS accountholdercount,  -- Default account holder count (always 1 per record)
    TRIM(SUBSTR(email_address1, 1, 60)) AS emailaddress1,  -- Primary email address (max 60 chars, trimmed)
    CASE 
        WHEN INSTR(account_name, 'DBA') > 0 THEN  -- Check if 'DBA' is present in the account name
            TRIM(SUBSTR(
                REGEXP_REPLACE(
                    REGEXP_REPLACE(
                        SUBSTR(account_name, 1, INSTR(account_name, 'DBA') - 2),  -- Extract name before 'DBA'
                        '^[ :]+', ''  -- Remove leading spaces or colons
                    ), 
                    '[\r\\n]', ''  -- Remove new line characters
                ), 
                1, 60  -- Limit to 60 characters
            ))
        ELSE TRIM(SUBSTR(
                REGEXP_REPLACE(
                    REGEXP_REPLACE(account_name, '[\r\\n]', ''),  -- Clean account name by removing new lines
                    '^[ :]+', ''  -- Remove leading spaces or colons
                ), 
                1, 60  -- Limit to 60 characters
            ))
    END AS name,  -- Company name, handling DBA if present
    'usd' AS preferredcurrency,  -- Default currency set to USD
    'usd' AS preferredsettlementcurrency,  -- Default settlement currency set to USD
    SUBSTR(CONCAT(TRIM(account_number), name, ':Com'), 1, 64) AS publicid,  -- Public ID (max 64 chars) created from account number and name
    TRIM(CONCAT(SUBSTR(fein, 1, 2), '-', SUBSTR(fein, 3))) AS taxid,  -- Tax ID formatted as XX-XXXXXXX
    'unconfirmed' AS taxstatus,  -- Default tax status set to 'unconfirmed'
    'work' AS primaryphone,  -- Default primary phone type set to 'work'
    'US' AS workphonecountry,  -- Default work phone country set to 'US'
    CAST(NULL AS DECIMAL(4,1)) AS withholdingrate,  -- Placeholder for withholding rate, initialized as NULL
    TRIM(work_phone) AS workphone,  -- Work phone number, trimmed
    TRIM(CONCAT('Addr:', TRIM(account_number))) AS primaryaddress,  -- Primary address reference prefixed with 'Addr:'
    TRIM(account_number) AS pmt_payloadid,  -- Payload ID for tracking, trimmed account number
    NULL AS dbaaka_ext  -- DBA/AKA extension (null for main records)
FROM Account_Holder_Locations
ORDER BY pmt_payloadid  -- Order results by payload ID
"""

# Company table DBA insertion (for records with DBA in the name)
Company_dba_Query = """
SELECT DISTINCT
    TRIM(CONCAT('Com_DBA:', TRIM(account_number), ' : ', monotonically_increasing_id())) AS pmt_id,  -- Unique DBA company identifier, prefixed with 'Com_DBA:'
    1 AS accountholdercount,  -- Default account holder count
    TRIM(SUBSTR(email_address1, 1, 60)) AS emailaddress1,  -- Primary email address (max 60 chars)
    CASE 
        WHEN INSTR(account_name, 'DBA') > 0 THEN  -- Check if 'DBA' is present in the account name
            TRIM(SUBSTR(
                REGEXP_REPLACE(
                    REGEXP_REPLACE(
                        SUBSTR(account_name, INSTR(account_name, 'DBA') + 3),  -- Extract name after 'DBA'
                        '^[ :]+', ''  -- Remove leading spaces or colons
                    ), 
                    '[\r\\n]', ''  -- Remove new line characters
                ), 
                1, 60  -- Limit to 60 characters
            ))
        ELSE TRIM(SUBSTR(
                REGEXP_REPLACE(
                    REGEXP_REPLACE(account_name, '[\r\\n]', ''),  -- Clean account name by removing new lines
                    '^[ :]+', ''  -- Remove leading spaces or colons
                ), 
                1, 60  -- Limit to 60 characters
            ))
    END AS name,  -- DBA company name
    'usd' AS preferredcurrency,  -- Default currency set to USD
    'usd' AS preferredsettlementcurrency,  -- Default settlement currency set to USD
    SUBSTR(CONCAT(TRIM(account_number), name, ':Com_dba'), 1, 64) AS publicid,  -- Public ID for DBA (max 64 chars)
    TRIM(CONCAT(SUBSTR(fein, 1, 2), '-', SUBSTR(fein, 3))) AS taxid,  -- Tax ID formatted as XX-XXXXXXX
    'unconfirmed' AS taxstatus,  -- Default tax status set to 'unconfirmed'
    CAST(NULL AS DECIMAL(4,1)) AS withholdingrate,  -- Placeholder for withholding rate, initialized as NULL
    TRIM(work_phone) AS workphone,  -- Work phone number, trimmed
    'work' AS primaryphone,  -- Default primary phone type set to 'work'
    'US' AS workphonecountry,  -- Default work phone country set to 'US'
    TRIM(CONCAT('Addr:', TRIM(account_number))) AS primaryaddress,  -- Primary address reference prefixed with 'Addr:'
    TRIM(account_number) AS pmt_payloadid,  -- Payload ID for tracking, trimmed account number
    'dba' AS dbaaka_ext  -- DBA/AKA extension set to 'dba'
FROM Account_Holder_Locations
WHERE INSTR(account_name, 'DBA') > 0  -- Filter for records that contain 'DBA' in the account name
ORDER BY pmt_payloadid  -- Order results by payload ID
"""

try:
    # Execute queries and union results for main and DBA company records
    Company_main_df = spark.sql(Company_main_query)  # Execute main company query
    Company_dba_df = spark.sql(Company_dba_Query)  # Execute DBA company query
    Company_df = Company_main_df.unionByName(Company_dba_df)  # Combine main and DBA DataFrames
    Company_df.createOrReplaceTempView("company_df_final")  # Create temp view for downstream use
    display(Company_df)  # Display the final Company DataFrame for validation
except Exception as e:
    # Log and halt if company transformation fails, as this is a critical ETL output
    logger.info(f"Error loading company_df_final: {e}")  # Log the error message
    sys.exit(1)  # Exit the program with an error status

# COMMAND ----------

# DBTITLE 1,Writing Company Table in PMTIN
logger = get_etl_logger('Account_Holders_Locations')
# Cell Purpose: Write the transformed Company table to the PMTIN database.
# Business Context: This step persists the cleaned and enriched Company data for downstream insurance processing and reporting.
try:
    write_and_log_pmtin(
        Company_df,
        table_name="company",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
    )
    logger.info("Successfully wrote Account_Holder_Locations to table 'company'.")
except Exception as e:
    # Log and halt if the write operation fails, as this is a critical ETL output
    logger.error(f"Error writing Account_Holder_Locations to table 'company'", exc_info=True)
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Officialid table Transformation
# Cell Purpose: Transform and enrich OfficialID data for the insurance ETL pipeline.
# Business context: This step creates the OfficialID table, linking company records to their FEINs (Federal Employer Identification Numbers).
# Only main company records (not DBA) are included as parents for official IDs.

# Step 1: Read the company table from PostgreSQL (excluding DBA records for parent linkage)
company_query = """
SELECT *
FROM company
"""
try:
    company_table = eval(exec_select_pmtin)(company_query)  # Fetch company data from PMTIN
    company_table.createOrReplaceTempView("company_table")  # Create temp view for SQL joins
    # display(company_table)  # Uncomment for debugging/validation
except Exception as e:
    logger.info("error loading company_table: {}".format(e))
    sys.exit(1)

# Step 2: Build the OfficialID DataFrame by joining account and company data
officialid_query = """
SELECT DISTINCT
    TRIM(CONCAT('OI:', account_number)) AS pmt_id,  -- Unique OfficialID identifier
    c.pmt_id AS pmt_parent,                        -- Parent company PMT ID (main company only)
    'Company' AS pmt_parent_type,                  -- Parent type is always Company
    'FEIN' AS officialidtype,                      -- Official ID type is FEIN
    TRIM(CONCAT(SUBSTR(fein, 1, 2), '-', SUBSTR(fein, 3))) AS officialidvalue,  -- FEIN formatted as XX-XXXXXXX
    TRIM(account_number) AS pmt_payloadid          -- Payload ID for tracking
FROM Account_Holder_Locations
LEFT JOIN (
    SELECT * FROM company_table WHERE pmt_id NOT LIKE '%DBA%'
) c
ON TRIM(Account_Holder_Locations.account_number) = c.pmt_payloadid
"""

# Step 3: Execute the query and handle errors
try:
    officialid_df = spark.sql(officialid_query)  # Execute SQL to create OfficialID DataFrame
    officialid_df.createOrReplaceTempView("officialid_final")  # Create temp view for downstream use
    display(officialid_df)  # Display the OfficialID DataFrame for validation
except Exception as e:
    logger.info(f"Error loading officialid_final: {e}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Writing Officialid Table in PMTIN
try:
    write_and_log_pmtin(
        officialid_df,
        table_name="officialid",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
    )
    logger.info("Successfully wrote Account_Holder_Locations to table 'officialid'.")
except Exception as e:
    logger.error(f"Error writing Account_Holder_Locations to table 'officialid'", exc_info=True)
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Accountlocation table Transformation
# Cell Purpose: Transform and enrich AccountLocation data for the insurance ETL pipeline.
# Business Context: Creates the AccountLocation table, mapping each account to its primary business address for Guidewire migration.

# Create a new DataFrame for AccountLocation Table
AccountLocation_query = """
    SELECT DISTINCT
        trim(concat("Acctloc:" , account_number)) AS pmt_id,  -- Unique location identifier, prefixed with 'Acctloc:'
        trim(concat("Acct:" , account_number)) AS pmt_parent,  -- Parent account reference, prefixed with 'Acct:'
        trim(address1) AS addressline1,  -- Address line 1 (trimmed)
        trim(address2) AS addressline2,  -- Address line 2 (trimmed)
        'business' AS addresstype,  -- All addresses are business addresses
        FALSE AS batchgeocode,  -- No batch geocoding applied
        'none' AS geocodestatus,  -- Geocode status is 'none'
        FALSE AS manualaddressind_ext,  -- No manual address intervention
        FALSE AS nonspecific,  -- All locations are specific
        'unverified' AS verificationstatus_gc,  -- Address verification status is 'unverified'
        trim(city) AS city,  -- City (trimmed)
        'US' AS country,  -- Country is 'US'
        trim(county) AS county,  -- County (trimmed)
        CAST(1 AS INTEGER) AS locationnum,  -- Location number, always 1 (single location per account)
        trim(zip_code) AS postalcode,  -- Postal code (trimmed)
        trim(state) AS state,  -- State (trimmed)
        trim(account_number) AS pmt_payloadid  -- Payload ID for tracking, uses trimmed account_number
    FROM Account_Holder_Locations
"""

# Execute the query
try:
    AccountLocations_df = spark.sql(AccountLocation_query)  # Execute the SQL query to transform account location data
    AccountLocations_df.createOrReplaceTempView("AccountLocation_final")  # Create a temporary view for further processing
    display(AccountLocations_df)  # Display the transformed data for validation
except Exception as e:
    # Error handling: log and halt if transformation fails
    logger.info(f"Error loading AccontLocation_final: {e}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Writing Accountlocation Table in PMTIN
# Cell Purpose: Write the transformed AccountLocation table to the PMTIN database.
# Business Context: This step persists the cleaned and enriched AccountLocation data for downstream insurance processing and reporting.
try:
    write_and_log_pmtin(
        AccountLocations_df,
        table_name="accountlocation",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
    )
    logger.info("Successfully wrote Account_Holder_Locations to table 'accountlocation'.")
except Exception as e:
    # Log and halt if the write operation fails, as this is a critical ETL output
    logger.error(f"Error writing Account_Holder_Locations to table 'accountlocation'", exc_info=True)
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Accountcontact table Transformation
# Cell Purpose: Transform and enrich AccountContact data for the insurance ETL pipeline.
# Business Context: Creates the AccountContact table, linking each account to its company contact (main or DBA) for Guidewire migration.
# pmt_id logic: Uniquely identifies each account contact, prefixing with 'Acctcon:' for main and 'Acctcon_DBA:' for DBA records.
# pmt_payloadid logic: Uses the trimmed account_number as the payload ID for traceability and downstream joins.

# Step 1: Read the company table from PostgreSQL for contact linkage
company_query = """
SELECT *
FROM company"""
try:
    company_table = eval(exec_select_pmtin)(company_query)  # Fetch company data from PMTIN
    company_table.createOrReplaceTempView("company_table")  # Create temp view for SQL joins
    # display(company_table)  # Uncomment for debugging/validation
except Exception as e:
    logger.info("error loading company_table: {}".format(e))
    sys.exit(1)

# Step 2: Build the AccountContact DataFrame by joining account and company data
AccountContact_query = """
    SELECT DISTINCT CASE 
                        WHEN c.pmt_id like '%DBA%' THEN trim(concat("Acctcon_DBA:", trim(account_number)))  -- For DBA accounts, prefix with 'Acctcon_DBA:'
                        ELSE trim(concat("Acctcon:", trim(account_number)))  -- For main accounts, prefix with 'Acctcon:'
                    END AS pmt_id,  -- Unique contact identifier, prefixed with 'Acctcon:' or 'Acctcon_DBA:'
           trim(concat("Acct:", account_number)) AS pmt_parent,  -- Parent account reference
           c.pmt_id AS contact,  -- Company contact PMT ID
           'Company' AS contact_type,  -- All contacts are companies
           trim(account_number) AS pmt_payloadid  -- Payload ID for tracking
    FROM Account_Holder_Locations
    LEFT JOIN company_table c
    ON trim(Account_Holder_Locations.account_number) = c.pmt_payloadid  -- Join condition on trimmed account numbers
"""

# Step 3: Execute the query and handle errors
try:
    AccountContact_df = spark.sql(AccountContact_query)  # Execute SQL to create AccountContact DataFrame
    AccountContact_df.createOrReplaceTempView("AccountContact_final")  # Create temp view for downstream use
    display(AccountContact_df)  # Display the AccountContact DataFrame for validation
except Exception as e:
    logger.info(f"Error loading AccontContact_final: {e}")  # Log error if query execution fails
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Writing Accountcontact Table in PMTIN
# Cell Purpose: Write the transformed AccountContact table to the PMTIN database.
# Business Context: This step persists the cleaned and enriched AccountContact data for downstream insurance processing and reporting.
try:
    write_and_log_pmtin(
        AccountContact_df,
        table_name="accountcontact",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
    )
    logger.info("Successfully wrote Account_Holder_Locations to table 'accountcontact'.")
except Exception as e:
    # Log and halt if the write operation fails, as this is a critical ETL output
    logger.error(f"Error writing Account_Holder_Locations to table 'accountcontact'", exc_info=True)
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Accountholder table Transformation
# Cell Purpose: Transform and enrich AcctHolder data for the insurance ETL pipeline.
# Business Context: Creates the AcctHolder table, linking each account to its account contact for Guidewire migration.
# pmt_id logic: Uniquely identifies each account holder by prefixing the account_number with 'Accthol:'.
# pmt_payloadid logic: Uses the trimmed account_number as the payload ID for traceability and downstream joins.

# Step 1: Build the AcctHolder DataFrame
AcctHolder = """
    SELECT DISTINCT trim(concat("Accthol:" , trim(account_number))) AS pmt_id,  -- Unique account holder identifier, prefixed with 'Accthol:'
           trim(concat('Acctcon:', trim(account_number))) AS pmt_parent,  -- Parent account contact reference
           trim(account_number) AS pmt_payloadid  -- Payload ID for tracking
    FROM Account_Holder_Locations
"""

# Step 2: Execute the query and handle errors
try:
    AcctHolder_df = spark.sql(AcctHolder)  # Execute SQL to create AcctHolder DataFrame
    AcctHolder_df.createOrReplaceTempView("AcctHolder_final")  # Create temp view for downstream use
    display(AcctHolder_df)  # Display the AcctHolder DataFrame for validation
except Exception as e:
    logger.info(f"Error loading AcctHolder_final: {e}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Writing Accountholder Table in PMTIN
# Cell Purpose: Write the transformed AcctHolder table to the PMTIN database.
# Business Context: This step persists the cleaned and enriched AcctHolder data for downstream insurance processing and reporting.
try:
    write_and_log_pmtin(
        AcctHolder_df,
        table_name="accountholder",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
    )
    logger.info("Successfully wrote Account_Holder_Locations to table 'accountholder'.")
except Exception as e:
    # Log and halt if the write operation fails, as this is a critical ETL output
    logger.error(f"Error writing Account_Holder_Locations to table 'accountholder'", exc_info=True)
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,PMT_Payloadstatus table Transformation
#  Create a new DataFrame for PMT_PayloadStatus Table
PMT_PayloadStatus = """
    SELECT DISTINCT trim(account_number) AS pmt_payloadid,
            trim(account_number) AS pmt_groupid,
           'NEW' AS pmt_status
  
    FROM Account_Holder_Locations
"""

try:
    PMT_PayloadStatus_df = spark.sql(PMT_PayloadStatus)
    PMT_PayloadStatus_df.createOrReplaceTempView("PMT_PayloadStatus_final")
    display(PMT_PayloadStatus_df)
except Exception as e:
    logger.info(f"Error loading PMT_PayloadStatus_final: {e}")

# COMMAND ----------

# DBTITLE 1,Writing PMT_Payloadstatus Table in PMTIN

try:
      write_and_log_pmtin(
      PMT_PayloadStatus_df,
      table_name="pmt_payloadstatus",
      job_id=job_id,
      job_run_id=job_run_id,
      notebook_name=notebook_name
    )
      logger.info("Successfully wrote Account_Holder_Locations to table 'pmt_payloadstatus'.")
except Exception as e:
        logger.error(f"Error writing Account_Holder_Locations to table 'pmt_payloadstatus'", exc_info=True)
        sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Producercode table Transformation
# Create a new DataFrame for ProducerCode Table
ProducerCode = """
    SELECT DISTINCT trim(concat('PC:', trim(account_number))) AS pmt_id,
           CASE WHEN groupcode IS NULL THEN '100-002541' ELSE groupcode END AS code,
           trim(account_number) AS pmt_payloadid
    FROM Account_Holder_Locations
"""

try:
    ProducerCode_df = spark.sql(ProducerCode)
    ProducerCode_df.createOrReplaceTempView("ProducerCode_final")
    display(ProducerCode_df)
except Exception as e:
    logger.info(f"Error loading ProducerCode_final: {e}")

# COMMAND ----------

# DBTITLE 1,Writing Producercode Table in PMTIN
try:
    write_and_log_pmtin(
        ProducerCode_df,
        table_name="producercode",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
    )
    logger.info("Successfully wrote Account_Holder_Locations to table 'producercode'.")
except Exception as e:
    logger.error(f"Error writing Account_Holder_Locations to table 'producercode'", exc_info=True)
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Accountproducercode table Transformation
# Create a new DataFrame for AccountProducerCode Table
AccountProducerCode = """
    SELECT DISTINCT concat("APC:", trim(account_number)) AS pmt_id,
           concat("Acct:", trim(account_number)) AS pmt_parent,
           concat("PC:", trim(account_number)) AS producercode,
           trim(account_number) AS pmt_payloadid
    FROM Account_Holder_Locations
"""

try:
    AccountProducerCode_df = spark.sql(AccountProducerCode)
    AccountProducerCode_df.createOrReplaceTempView("AccountProducerCode_final")
    display(AccountProducerCode_df)
except Exception as e:
    logger.info(f"Error loading AccountProducerCode_final: {e}")

# COMMAND ----------

# DBTITLE 1,Writing Accountproducercode Table in PMTIN
try:
    write_and_log_pmtin(
        AccountProducerCode_df,
        table_name="accountproducercode",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
    )
    logger.info("Successfully wrote Account_Holder_Locations to table 'accountproducercode'.")
except Exception as e:
    logger.error(f"Error writing Account_Holder_Locations to table 'accountproducercode'", exc_info=True)
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Industrycode table Transformation
# Create a new DataFrame for IndustryCode Table
IndustryCode = """
    SELECT DISTINCT concat("IC:", trim(account_number)) AS pmt_id,
           case when IndustryCode is null then '0782' else IndustryCode end AS code,
           trim(account_number) AS pmt_payloadid
    FROM Account_Holder_Locations
"""

try:
    IndustryCode_df = spark.sql(IndustryCode)
    IndustryCode_df.createOrReplaceTempView("IndustryCode_final")
    display(IndustryCode_df)
except Exception as e:
    logger.info(f"Error loading IndustryCode_final: {e}")

# COMMAND ----------

# DBTITLE 1,Writing Industrycode Table in PMTIN
try:
    write_and_log_pmtin(
        IndustryCode_df,
        table_name="industrycode",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name,
        
    )
    logger.info("Successfully wrote Account_Holder_Locations to table 'industrycode'.")
except Exception as e:
    logger.error(f"Error writing Account_Holder_Locations to table 'industrycode'", exc_info=True)
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,dbarole_sp table Transformation for account_level

#reading company table from postgre sql
accountcontact_query="""
SELECT *
FROM accountcontact"""
try:
  accountcontact_table=eval(exec_select_pmtin)(accountcontact_query)
  accountcontact_table.createOrReplaceTempView("accountcontact_table")
#   display(accountcontact_table)
except Exception as e:
  logger.info("error loading accountcontact_table: {}".format(e)) 
  sys.exit(1) 

#  Create a new DataFrame for dbarole_sp Table
dbarole_sp = """
    SELECT DISTINCT
        CASE WHEN z.pmt_id LIKE '%DBA%' THEN concat("DRSP_DBA:" , trim(account_number))
            ELSE concat("DRSP:" , trim(account_number))
        END AS pmt_id,
        z.pmt_id AS pmt_parent,
        FALSE AS primarydba,
        trim(account_number) AS pmt_payloadid 
    FROM Account_Holder_Locations
    INNER JOIN (select * from accountcontact_table where pmt_id like '%DBA%') z ON trim(Account_Holder_Locations.account_number) = z.pmt_payloadid
"""

try:
    dbarole_sp_df = spark.sql(dbarole_sp)
    dbarole_sp_df.createOrReplaceTempView("dbarole_sp_final")
    display(dbarole_sp_df)
except Exception as e:
    logger.info(f"Error loading dbarole_sp_final: {e}")

# COMMAND ----------

# DBTITLE 1,Writing dbarole_sp in PMTIN
try:
    write_and_log_pmtin(
        dbarole_sp_df,
        table_name="dbarole_sp",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
    )
    logger.info("Successfully wrote Account_Holder_Locations to table 'dbarole_sp'.")
except Exception as e:
    logger.error(f"Error writing Account_Holder_Locations to table 'dbarole_sp'", exc_info=True)
    sys.exit(1)

# COMMAND ----------

