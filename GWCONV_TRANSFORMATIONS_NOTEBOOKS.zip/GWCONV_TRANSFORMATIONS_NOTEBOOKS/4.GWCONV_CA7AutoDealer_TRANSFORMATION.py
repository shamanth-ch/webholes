# Databricks notebook source
# Cell 1: Initialize Logging
"""
- Introduced more granular log levels (e.g., `logger.error`, `logger.debug`).
- Logs are written to both the notebook console and to 'etl_logfile.log' in append mode.
"""
import logging
import sys

logger = logging.getLogger('ca7autodealer')
logger.setLevel(logging.INFO)  # Keep as INFO for general logs; use DEBUG for debugging

# Remove all handlers if already set (to avoid duplicate logs in notebook reruns)
if logger.hasHandlers():
    logger.handlers.clear()

# Console handler
handler = logging.StreamHandler()
handler.setLevel(logging.DEBUG)  # Allow for detailed debugging at runtime
formatter = logging.Formatter('%(asctime)s %(levelname)s: %(message)s')  # Add consistent logging format
handler.setFormatter(formatter)
logger.addHandler(handler)

# File handler in append mode
log_file_handler = logging.FileHandler('etl_logfile.log', mode='a')
log_file_handler.setLevel(logging.INFO)
log_file_handler.setFormatter(formatter)
logger.addHandler(log_file_handler)

logger.info("Logging initialized in append mode. All log levels will be written to etl_logfile.log.")

# Function to log info messages to file
def log_info_to_file(message):
    logger.info(message)

# COMMAND ----------

# DBTITLE 1,Setup Job Context and Widgets

# Create widgets for job_id and job_run_id
dbutils.widgets.text("job_id", "")
dbutils.widgets.text("job_run_id", "")

# Get the current notebook context
context = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
job_id_obj = context.jobId()          # Fetch jobId
job_run_id_obj = context.jobRunId()   # Fetch jobRunId
notebook_path = context.notebookPath().get() # Fetch the notebook path
notebook_name = notebook_path.split('/')[-1]   # Extract the notebook name from the path

def safe_get_option(option_obj):
    try:
        if option_obj.isDefined():
            return option_obj.get()
        else:
            return None
    except Exception:
        return None

# Use the safe_get_option to retrieve the values
job_id = safe_get_option(job_id_obj) or "Manual"    # Default to "Manual" if not found
job_run_id = safe_get_option(job_run_id_obj) or "Manual"

# Output the retrieved IDs
print(f"Job ID: {job_id}, Job Run ID: {job_run_id}")
logger.info(f"Job context: job_id={job_id}, job_run_id={job_run_id}, notebook={notebook_name}")
log_info_to_file(f"Job context: job_id={job_id}, job_run_id={job_run_id}, notebook={notebook_name}")

# Define widgets for job_id and job_run_id
dbutils.widgets.text("job_id", str(job_id)) 
dbutils.widgets.text("job_run_id", str(job_run_id))

# COMMAND ----------

# DBTITLE 1,Run the configuration Notebook
# MAGIC %run ../configuration/configs

# COMMAND ----------

# DBTITLE 1,Run the configuration Notebook
# MAGIC %run ../configuration/postgres

# COMMAND ----------

# DBTITLE 1,ETL query for Auto Dealer Data
log_info_to_file("[START] Extraction for AutoDealer_data...")
logger.info("[START] Extraction for AutoDealer_data...")
try:
    AutoDealer_query = fetch_query_from_table("ca7autodealer")
    logger.info(f"Fetched query for ca7autodealer: {AutoDealer_query}")
    log_info_to_file(f"Fetched query for ca7autodealer: {AutoDealer_query}")
    AutoDealer_data = eval(exec_select_landing)(AutoDealer_query)
    AutoDealer_data.createOrReplaceTempView("AutoDealer_data")
    row_count = AutoDealer_data.count()
    logger.info(f"AutoDealer_data loaded with {row_count} rows.")
    log_info_to_file(f"AutoDealer_data loaded with {row_count} rows.")
    logger.info(f"AutoDealer_data schema: {AutoDealer_data.schema}")
    log_info_to_file(f"AutoDealer_data schema: {AutoDealer_data.schema}")
    display(AutoDealer_data)
    logger.info("[END] Extraction for AutoDealer_data.")
    log_info_to_file("[END] Extraction for AutoDealer_data.")
except Exception as e:
    logger.error("Error loading AutoDealer_data:", exc_info=True)
    log_info_to_file(f"Error loading AutoDealer_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Reading class_codes table
log_info_to_file("[START] Extraction for classcodes...")
logger.info("[START] Extraction for classcodes...")
classcodes_query = """
SELECT *
FROM class_codes"""
try:
    classcodes = eval(exec_select_framework)(classcodes_query)
    classcodes.createOrReplaceTempView("classcodes")
    row_count = classcodes.count()
    logger.info(f"classcodes loaded with {row_count} rows.")
    log_info_to_file(f"classcodes loaded with {row_count} rows.")
    logger.info(f"classcodes schema: {classcodes.schema}")
    log_info_to_file(f"classcodes schema: {classcodes.schema}")
    display(classcodes)
    logger.info("[END] Extraction for classcodes.")
    log_info_to_file("[END] Extraction for classcodes.")
except Exception as e:
    logger.error("Error loading classcodes:", exc_info=True)
    log_info_to_file(f"Error loading classcodes: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,CA7AutoDelaer table Transformation
log_info_to_file("[START] Transformation for CA7AutoDealer_final...")
logger.info("[START] Transformation for CA7AutoDealer_final...")
# Create a new DataFrame for the CA7Truck schema
CA7AutoDealer_final = """
    SELECT DISTINCT
           concat('CA7AD:',trim(PolicyNumber),'-',trim(StateCode),':', trim(LocationNumber)) AS pmt_id,
           concat('CA7CAL_',trim(PolicyNumber)) AS pmt_parent,
           CAST(CASE WHEN FranchiseAutoDealers IS NULL THEN 0 ELSE 1 END AS INTEGER) AS autodealersnumber,
           trim(ClassCode) AS classcode,
           classcodes.class_codes_classification AS clazz,
           CASE WHEN ClassCode = '7314' THEN 'Yes'
               WHEN ClassCode = '7357' THEN 'No' 
           END AS franchise,
           classcodes.class_codes_cov_type AS coveragetype,
           CAST(trim(NumberOfOfficersAndOperatorsFullTime) AS INTEGER) AS numberofofficersandoperatorsfulltime,
           CAST(trim(NumberOfOfficersAndOperatorsPartTime) AS INTEGER) AS numberofofficersandoperatorspartTime,
           CAST(trim(NumberOfOtherEmployeesFullTime) AS INTEGER) AS numberofotheremployeesfulltime,
           CAST(trim(NumberOfOtherEmployeesPartTime) AS INTEGER) AS numberofotheremployeesparttime,
           CAST(trim(NumberOfNonEmployeesUnderAge25) AS INTEGER) AS numberofnonemployeesunderage25,
           CAST(trim(NumberOfNonEmployeesAge25OrOver) AS INTEGER) AS numberofnonemployeesoverage25,
           CAST(trim(TotalSetOfDealerPlates) AS INTEGER) AS totalsetsofdealerplates,
           CAST(trim(TotalNumberOfTransporterPlates) AS INTEGER) AS totaltransporterplates,
           trim(GaragingLocation) AS garaginglocation,
           trim(Territory) AS Territory,
           --TerritoryGroup,
           trim(ZipCode) AS zipcode,
           concat('PL:',trim(PolicyNumber)) AS locationinternal,
           StateCode,
           CityHelpKeyCd,
           CityCntyCd,
           trim(PolicyNumber) AS pmt_payloadid,

           'Not Applicable' AS ratingbase,
           'usd' AS preferredcoveragecurrency,
           'usd' AS preferredsettlementcurrency,
           'No' AS vehicleoverweightindicator,
           0 AS unitnumber

    FROM AutoDealer_data
    LEFT JOIN classcodes
      ON AutoDealer_data.classcode = classcodes.value
"""

try:
    CA7AutoDealer_final = spark.sql(CA7AutoDealer_final)
    CA7AutoDealer_final.createOrReplaceTempView("CA7AutoDealer_final")
    row_count = CA7AutoDealer_final.count()
    logger.info(f"CA7AutoDealer_final loaded with {row_count} rows.")
    log_info_to_file(f"CA7AutoDealer_final loaded with {row_count} rows.")
    logger.info(f"CA7AutoDealer_final schema: {CA7AutoDealer_final.schema}")
    log_info_to_file(f"CA7AutoDealer_final schema: {CA7AutoDealer_final.schema}")
    display(CA7AutoDealer_final)
    logger.info("[END] Transformation for CA7AutoDealer_final.")
    log_info_to_file("[END] Transformation for CA7AutoDealer_final.")
except Exception as e:
    logger.error("Error loading CA7AutoDealer_final:", exc_info=True)
    log_info_to_file(f"Error loading CA7AutoDealer_final: {str(e)}")
    sys.exit(1)

# COMMAND ----------

log_info_to_file("[START] Extraction for location_basic...")
logger.info("[START] Extraction for location_basic...")
location_query = """select * from account_location"""
try:
    location_basic = eval(exec_select_framework)(location_query)
    location_basic.createOrReplaceTempView("location_basic")
    row_count = location_basic.count()
    logger.info(f"location_basic loaded with {row_count} rows.")
    log_info_to_file(f"location_basic loaded with {row_count} rows.")
    logger.info(f"location_basic schema: {location_basic.schema}")
    log_info_to_file(f"location_basic schema: {location_basic.schema}")
    display(location_basic)
    logger.info("[END] Extraction for location_basic.")
    log_info_to_file("[END] Extraction for location_basic.")
except Exception as e:
    logger.error("Error loading location_basic:", exc_info=True)
    log_info_to_file(f"Error loading location_basic: {str(e)}")
    sys.exit(1)

# COMMAND ----------

log_info_to_file("[START] Transformation for Auto_final...")
logger.info("[START] Transformation for Auto_final...")
Auto_final = """
select distinct
    a.pmt_id, 
    a.pmt_parent, 
    autodealersnumber, 
    classcode, 
    clazz, 
    franchise, 
    coveragetype, 
    numberofofficersandoperatorsfulltime, 
    numberofofficersandoperatorspartTime, 
    numberofotheremployeesfulltime, 
    numberofotheremployeesparttime, 
    numberofnonemployeesunderage25, 
    numberofnonemployeesoverage25, 
    totalsetsofdealerplates, 
    totaltransporterplates, 
    ratingbase, 
    garaginglocation, 
    preferredcoveragecurrency, 
    preferredsettlementcurrency, 
    Territory, 
    unitnumber, 
    vehicleoverweightindicator, 
    zipcode, 
    case when trim(b.vin) is not null then concat("PL:",substring(b.pmt_id,9)) else null end as  locationinternal,  
    a.pmt_payloadid 
from CA7AutoDealer_final a 
left outer join location_basic b 
    on a.pmt_payloadid = b.pmt_payloadid 
    and a.StateCode=b.state 
    and trim(a.Territory)=trim(b.vin) 
    and trim(a.CityHelpKeyCd)=coalesce(b.city,'') 
    and trim(coalesce(a.CityCntyCd,''))=coalesce(b.county,'')
"""
try:
    Auto_final = spark.sql(Auto_final)
    Auto_final.createOrReplaceTempView("Auto_final")
    row_count = Auto_final.count()
    logger.info(f"Auto_final loaded with {row_count} rows.")
    log_info_to_file(f"Auto_final loaded with {row_count} rows.")
    logger.info(f"Auto_final schema: {Auto_final.schema}")
    log_info_to_file(f"Auto_final schema: {Auto_final.schema}")
    display(Auto_final)
    logger.info("[END] Transformation for Auto_final.")
    log_info_to_file("[END] Transformation for Auto_final.")
except Exception as e:
    logger.error("Error loading Auto_final:", exc_info=True)
    log_info_to_file(f"Error loading Auto_final: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Writing table in PMTIN
try:
    row_count = Auto_final.count()
    logger.info(f"[START] Writing {row_count} rows to table 'ca7autodealer' in PMTIN.")
    log_info_to_file(f"[START] Writing {row_count} rows to table 'ca7autodealer' in PMTIN.")
    logger.info(f"CA7AutoDealer_final schema: {Auto_final.schema}")
    log_info_to_file(f"CA7AutoDealer_final schema: {CA7AutoDealer_final.schema}")
    write_and_log_pmtin(
        Auto_final,
        table_name="ca7autodealer",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
    )
    logger.info("[END] Successfully wrote CA7AutoDealer_final to table 'ca7autodealer'.")
    log_info_to_file("[END] Successfully wrote CA7AutoDealer_final to table 'ca7autodealer'.")
except Exception as e:
    logger.error(f"Error writing CA7AutoDealer_final to table 'ca7autodealer'", exc_info=True)
    log_info_to_file(f"Error writing CA7AutoDealer_final to table 'ca7autodealer': {str(e)}")
    sys.exit(1)

# COMMAND ----------

