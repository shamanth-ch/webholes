# Databricks notebook source
# Cell Purpose: Set up Databricks widgets and retrieve job context for tracking ETL runs.
# Business Context: Enables parameterization and job tracking for the ETL pipeline, supporting both interactive and scheduled job runs in Databricks.
"""
This cell creates widgets for job_id and job_run_id, retrieves the current notebook context, and extracts job and run IDs for logging and audit purposes.
"""
# Create widgets for job_id and job_run_id for parameterization and job tracking
# These widgets allow passing parameters when running as a Databricks job
# The job_id is used to identify the specific job, while job_run_id is used to track the execution of that job.

dbutils.widgets.text("job_id", "")
dbutils.widgets.text("job_run_id", "")

# Get the current notebook context for extracting job and run metadata
# This context provides information about the job execution environment, including job IDs and notebook path.
context = dbutils.notebook.entry_point.getDbutils().notebook().getContext()

# Extract jobId and jobRunId objects from context (may be Option types)
# These IDs are crucial for tracking the execution of the ETL process.
job_id_obj = context.jobId()          # Option type: may or may not be defined
job_run_id_obj = context.jobRunId()   # Option type: may or may not be defined

# Retrieve the full path to the current notebook for logging purposes
notebook_path = context.notebookPath().get() # Full path to the current notebook
# Extract the notebook name from the path for easier identification in logs
notebook_name = notebook_path.split('/')[-1]   # Extract the notebook name from the path

def safe_get_option(option_obj):
    """
    Safely extract a value from a Databricks Option object.
    Parameters:
        option_obj: Option (Databricks Java/Scala Option type)
            The object to extract the value from.
    Returns:
        value or None: The value if defined, else None.
    Exceptions:
        Catches all exceptions to avoid breaking job context extraction.
        This ensures that even if an error occurs, the job can continue running without interruption.
    """
    try:
        if option_obj.isDefined():
            return option_obj.get()  # Return the value if defined
        else:
            return None  # Return None if not defined
    except Exception:
        return None  # Return None in case of any exception

# Use the safe_get_option to retrieve the values, defaulting to 'Manual' if not found
# This provides a fallback mechanism for logging and auditing purposes.
job_id = safe_get_option(job_id_obj) or "Manual"    # Used for logging and audit
job_run_id = safe_get_option(job_run_id_obj) or "Manual"

# Output the retrieved IDs for debugging and traceability
# This print statement helps in verifying that the correct IDs are being used in the ETL process.
print(f"Job ID: {job_id}, Job Run ID: {job_run_id}")

# Redefine widgets with resolved values for downstream cells (ensures consistency)
# This step ensures that the widgets reflect the actual job and run IDs for any subsequent operations.
dbutils.widgets.text("job_id", str(job_id)) 
dbutils.widgets.text("job_run_id", str(job_run_id))

# COMMAND ----------

# DBTITLE 1,Run the configuration Notebook
# MAGIC %run ../configuration/configs

# COMMAND ----------

# DBTITLE 1,Run the configuration Notebook
# MAGIC %run ../configuration/postgres

# COMMAND ----------

# DBTITLE 1,Run the parameters
import logging
import sys
import os

LOG_FILE = 'etl_logfile.log'
LOG_FORMAT = '%(asctime)s %(levelname)s: %(message)s'

def get_etl_logger(name):
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    if logger.hasHandlers():
        logger.handlers.clear()
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.INFO)
    formatter = logging.Formatter(LOG_FORMAT)
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)
    file_handler = logging.FileHandler(LOG_FILE, mode='a')
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    return logger

logger = get_etl_logger('Vehicle_data')
logger.info(f"Logging initialized. Log file location: {os.path.abspath(LOG_FILE)}")

def log_info_to_file(message):
    with open(LOG_FILE, 'a') as f:
        import datetime
        timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        f.write(f"{timestamp} INFO: {message}\n")

# COMMAND ----------

# Cell Purpose: Set up Databricks widgets and retrieve job context for tracking ETL runs.
# Business Context: Enables parameterization and job tracking for the ETL pipeline, supporting both interactive and scheduled job runs in Databricks.
"""
This cell creates widgets for job_id and job_run_id, retrieves the current notebook context, and extracts job and run IDs for logging and audit purposes.
"""
# Create widgets for job_id and job_run_id for parameterization and job tracking
# These widgets allow passing parameters when running as a Databricks job
# The job_id is used to identify the specific job, while job_run_id is used to track the execution of that job.

dbutils.widgets.text("job_id", "")
dbutils.widgets.text("job_run_id", "")

# Get the current notebook context for extracting job and run metadata
# This context provides information about the job execution environment, including job IDs and notebook path.
context = dbutils.notebook.entry_point.getDbutils().notebook().getContext()

# Extract jobId and jobRunId objects from context (may be Option types)
# These IDs are crucial for tracking the execution of the ETL process.
job_id_obj = context.jobId()          # Option type: may or may not be defined
job_run_id_obj = context.jobRunId()   # Option type: may or may not be defined

# Retrieve the full path to the current notebook for logging purposes
notebook_path = context.notebookPath().get() # Full path to the current notebook
# Extract the notebook name from the path for easier identification in logs
notebook_name = notebook_path.split('/')[-1]   # Extract the notebook name from the path

def safe_get_option(option_obj):
    """
    Safely extract a value from a Databricks Option object.
    Parameters:
        option_obj: Option (Databricks Java/Scala Option type)
            The object to extract the value from.
    Returns:
        value or None: The value if defined, else None.
    Exceptions:
        Catches all exceptions to avoid breaking job context extraction.
        This ensures that even if an error occurs, the job can continue running without interruption.
    """
    try:
        if option_obj.isDefined():
            return option_obj.get()  # Return the value if defined
        else:
            return None  # Return None if not defined
    except Exception:
        return None  # Return None in case of any exception

# Use the safe_get_option to retrieve the values, defaulting to 'Manual' if not found
# This provides a fallback mechanism for logging and auditing purposes.
job_id = safe_get_option(job_id_obj) or "Manual"    # Used for logging and audit
job_run_id = safe_get_option(job_run_id_obj) or "Manual"

# Output the retrieved IDs for debugging and traceability
# This print statement helps in verifying that the correct IDs are being used in the ETL process.
print(f"Job ID: {job_id}, Job Run ID: {job_run_id}")

# Redefine widgets with resolved values for downstream cells (ensures consistency)
# This step ensures that the widgets reflect the actual job and run IDs for any subsequent operations.
dbutils.widgets.text("job_id", str(job_id)) 
dbutils.widgets.text("job_run_id", str(job_run_id))

# COMMAND ----------

# DBTITLE 1,ETL query for Special Type Vehicle Data
log_info_to_file("[START] Extraction for SpecialType_data...")
logger.info("[START] Extraction for SpecialType_data...")
try:
    SpecialType_query = fetch_query_from_table('ca7specialtype')
    logger.info(f"SpecialType_query: {SpecialType_query}")
    log_info_to_file(f"SpecialType_query: {SpecialType_query}")
    SpecialType_data = eval(exec_select_landing)(SpecialType_query)
    SpecialType_data.createOrReplaceTempView("SpecialType_data")
    row_count = SpecialType_data.count()
    logger.info(f"SpecialType_data loaded with {row_count} rows.")
    log_info_to_file(f"SpecialType_data loaded with {row_count} rows.")
    logger.info(f"SpecialType_data schema: {SpecialType_data.schema}")
    log_info_to_file(f"SpecialType_data schema: {SpecialType_data.schema}")
    display(SpecialType_data)
    logger.info("[END] Extraction for SpecialType_data.")
    log_info_to_file("[END] Extraction for SpecialType_data.")
except Exception as e:
    logger.error(f"Error loading SpecialType_data: {e}", exc_info=True)
    log_info_to_file(f"Error loading SpecialType_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Transformation of CA7SpecialType data
log_info_to_file("[START] Transformation for ca7specialtype_final...")
logger.info("[START] Transformation for ca7specialtype_final...")
ca7specialtype_final_query = """
    SELECT DISTINCT 
        concat('CA7SPL_', trim(PolicyNumber), '_', trim(VIN)) AS pmt_id,
        concat('CA7CAL_', trim(PolicyNumber)) AS pmt_parent,
        trim(CustomerVehId) AS agentvehiclenumber_ext,
        trim(VIN) AS vin,
        trim(Make) AS make,
        trim(model) AS model,
        CAST(trim(Year) AS INTEGER) AS Year,
        CAST(trim(OriginalCostNew) AS INTEGER) AS originalcostnew,
        CAST(trim(StatedAmount) AS INTEGER) AS statedamount,
        substring(trim(PrimaryClassCode), 0, 4) AS classcode,
        --classcodes.class_codes_classification AS clazz,
        trim(VehicleType) AS type,
        trim(AutoHackingCoverage) AS autohackingexpensecoverage,
        CASE WHEN trim(VehicleSizeCode) IN ('1','2') THEN 'Yes' 
            WHEN trim(VehicleSizeCode) IN ('3','4') THEN 'No' 
            ELSE NULL 
        END AS lightmediumtruck,
        CASE WHEN trim(EngineSize) = '1' THEN '0-100'
             WHEN trim(EngineSize) = '2' THEN '101-200'
             WHEN trim(EngineSize) = '3' THEN '201-360'
             WHEN trim(EngineSize) = '4' THEN '361-500'
             WHEN trim(EngineSize) = '5' THEN '501-800'
             WHEN trim(EngineSize) = '6' THEN 'Over 800'
             ELSE NULL 
        END AS enginesize,
        CASE WHEN trim(PrimaryClassCode) = '962500' AND trim(VehicleType) = 'ANTIQUE AUTO' THEN 'Yes' ELSE 'No' END AS antiqueautoprivatepassenger,
        CASE WHEN trim(VehicleNumber) = '1' THEN 'Y' ELSE 'N' END AS firstauto,
        trim(GaragingLocation) AS garaginglocation,
        CAST(trim(GrossVehicleWeight) AS INTEGER) AS grossvehicleweight,
        CASE WHEN CAST(trim(GrossVehicleWeight) AS INT) > 10000 THEN 'Yes'
             WHEN CAST(trim(GrossVehicleWeight) AS INT) <= 10000 THEN 'No'
        END AS grossvehicleweightover10000,
        CASE WHEN CAST(trim(GrossVehicleWeight) AS INT) > 20000 THEN 'Yes'
             WHEN CAST(trim(GrossVehicleWeight) AS INT) <= 20000 THEN 'No'
        END AS grossvehicleweightover20000,
        CASE WHEN trim(MatureDriverDt) IS NULL THEN 'No'
             ELSE 'Yes' END AS MatureDriverImprovementCourseDiscount,
        CASE WHEN SchoolBusProration IS NOT NULL THEN 'Yes' ELSE 'No' END AS MotorcycleTrainingCourse,
        trim(State) AS registrationstate_Ext,
        trim(TerritoryCode) AS territory,
        CAST(trim(VehicleNumber) AS INTEGER) AS vehiclenumber,
        trim(ZipCode) AS zipcode,
        concat('PL:',trim(PolicyNumber)) AS location,
        trim(PolicyNumber) AS pmt_payloadid,
        CASE WHEN trim(PassiveRestType) = '1' THEN 'Vehicle Equipped with Air Bags in ront outboard seat postiions(driver & pax)'
             WHEN trim(PassiveRestType) = '2' THEN 'Vehicle Equipped with Air Bags  in only the driver side position'
             ELSE NULL 
        END AS PassiveRestraintDiscount,
        AntiTheftDevice,
        'Yes' AS selfpropelledvehicle,
        'None' AS antitheftdevicediscount,
        'No' AS auxillaryrunninglampsdiscount,
        'No' AS defensivedrivingcoursecredit,
        'No' AS firstoradditionalauto,
        'No' AS ownedbythegovernmentstateorpoliticalsubdivision,
        'usd' AS preferredcoveragecurrency,
        'usd' AS preferredsettlementcurrency,
        'No' AS registeredhistoricvehicle,
        'No' AS replacementcostcoverage,
        'No' AS snowmobileauxiliarylightingsystemdiscount,
        'No' AS stateownedvehicle,
        'No' AS vehicleoverweightindicator,
        'No' AS AccidentPreventionRefresherDiscount,
        'No Safety features' AS SafetyFeatures
        
    FROM SpecialType_data
"""
try:
    ca7specialtype_final = spark.sql(ca7specialtype_final_query)
    ca7specialtype_final.createOrReplaceTempView("ca7specialtype_final")
    row_count = ca7specialtype_final.count()
    logger.info(f"ca7specialtype_final loaded with {row_count} rows.")
    log_info_to_file(f"ca7specialtype_final loaded with {row_count} rows.")
    logger.info(f"ca7specialtype_final schema: {ca7specialtype_final.schema}")
    log_info_to_file(f"ca7specialtype_final schema: {ca7specialtype_final.schema}")
    display(ca7specialtype_final)
    logger.info("[END] Transformation for ca7specialtype_final.")
    log_info_to_file("[END] Transformation for ca7specialtype_final.")
except Exception as e:
    logger.error(f"Error loading ca7specialtype_final: {e}", exc_info=True)
    log_info_to_file(f"Error loading ca7specialtype_final: {str(e)}")
    sys.exit(1)

# COMMAND ----------

log_info_to_file("[START] Extraction for location_basic...")
logger.info("[START] Extraction for location_basic...")
location_query = """select * from account_location"""
try:
    logger.info(f"Executing query: {location_query}")
    log_info_to_file(f"Executing query: {location_query}")
    
    location_basic = eval(exec_select_framework)(location_query)
    location_basic.createOrReplaceTempView("location_basic")
    
    row_count = location_basic.count()
    logger.info(f"location_basic loaded with {row_count} rows.")
    log_info_to_file(f"location_basic loaded with {row_count} rows.")
    
    logger.info(f"location_basic schema: {location_basic.schema}")
    log_info_to_file(f"location_basic schema: {location_basic.schema}")
    
    display(location_basic)
    
    logger.info("[END] Extraction for location_basic.")
    log_info_to_file("[END] Extraction for location_basic.")
except Exception as e:
    logger.error(f"Error loading location_basic: {e}", exc_info=True)
    log_info_to_file(f"Error loading location_basic: {str(e)}")
    sys.exit(1)

# COMMAND ----------

log_info_to_file("[START] Deduplication for location_basic...")
logger.info("[START] Deduplication for location_basic...")
location_basic_deduped = spark.sql("select distinct * from location_basic")
location_basic_deduped.createOrReplaceTempView("location_basic")
row_count = location_basic_deduped.count()
logger.info(f"location_basic_deduped loaded with {row_count} rows.")
log_info_to_file(f"location_basic_deduped loaded with {row_count} rows.")
logger.info(f"location_basic_deduped schema: {location_basic_deduped.schema}")
log_info_to_file(f"location_basic_deduped schema: {location_basic_deduped.schema}")
display(location_basic_deduped)
logger.info("[END] Deduplication for location_basic.")
log_info_to_file("[END] Deduplication for location_basic.")

# COMMAND ----------

# DBTITLE 1,Adding Location in Specialtype
log_info_to_file("[START] Transformation for vehical_final...")
logger.info("[START] Transformation for vehical_final...")
vehical_final_query = """
SELECT DISTINCT
    a.pmt_id, 
    a.pmt_parent, 
    agentvehiclenumber_ext, 
    a.vin, 
    make, 
    model, 
    Year, 
    originalcostnew, 
    statedamount, 
    classcode, 
    type, 
    autohackingexpensecoverage, 
    lightmediumtruck, 
    selfpropelledvehicle, 
    enginesize,
    AntiTheftDevice, 
    antitheftdevicediscount, 
    antiqueautoprivatepassenger, 
    auxillaryrunninglampsdiscount, 
    defensivedrivingcoursecredit, 
    firstauto, 
    firstoradditionalauto, 
    garaginglocation, 
    grossvehicleweight, 
    grossvehicleweightover10000, 
    grossvehicleweightover20000, 
    MotorcycleTrainingCourse, 
    ownedbythegovernmentstateorpoliticalsubdivision, 
    preferredcoveragecurrency, 
    preferredsettlementcurrency, 
    registeredhistoricvehicle, 
    registrationstate_Ext, 
    replacementcostcoverage, 
    snowmobileauxiliarylightingsystemdiscount, 
    stateownedvehicle, 
    territory, 
    vehiclenumber, 
    vehicleoverweightindicator, 
    zipcode, 
    maturedriverimprovementcoursediscount,
    SafetyFeatures,
    PassiveRestraintDiscount,
    CASE WHEN TRIM(b.vin) IS NOT NULL THEN CONCAT('PL:', SUBSTRING(b.pmt_id, 9)) ELSE NULL END AS location, 
    a.pmt_payloadid, 
    AccidentPreventionRefresherDiscount
FROM ca7specialtype_final a
LEFT OUTER JOIN location_basic b 
    ON a.pmt_payloadid = b.pmt_payloadid AND TRIM(a.vin) = TRIM(b.vin)
"""
try:
    vehical_final = spark.sql(vehical_final_query)
    vehical_final.createOrReplaceTempView("vehical_final")
    row_count = vehical_final.count()
    logger.info(f"vehical_final loaded with {row_count} rows.")
    log_info_to_file(f"vehical_final loaded with {row_count} rows.")
    logger.info(f"vehical_final schema: {vehical_final.schema}")
    log_info_to_file(f"vehical_final schema: {vehical_final.schema}")
    display(vehical_final)
    logger.info("[END] Transformation for vehical_final.")
    log_info_to_file("[END] Transformation for vehical_final.")
except Exception as e:
    logger.error(f"Error loading vehical_final: {e}", exc_info=True)
    log_info_to_file(f"Error loading vehical_final: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Writing table in PMTIN
try:
    row_count = vehical_final.count()
    logger.info(f"[START] Writing {row_count} rows to table 'ca7specialtype' in PMTIN.")
    log_info_to_file(f"[START] Writing {row_count} rows to table 'ca7specialtype' in PMTIN.")
    logger.info(f"vehical_final schema: {vehical_final.schema}")
    log_info_to_file(f"vehical_final schema: {vehical_final.schema}")
    write_and_log_pmtin(
        vehical_final,
        table_name="ca7specialtype",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
    )
    logger.info("[END] Successfully wrote vehical_final to table 'ca7specialtype'.")
    log_info_to_file("[END] Successfully wrote vehical_final to table 'ca7specialtype'.")
except Exception as e:
    logger.error(f"Error writing vehical_final to table 'ca7specialtype'", exc_info=True)
    log_info_to_file(f"Error writing vehical_final to table 'ca7specialtype': {str(e)}")
    sys.exit(1)