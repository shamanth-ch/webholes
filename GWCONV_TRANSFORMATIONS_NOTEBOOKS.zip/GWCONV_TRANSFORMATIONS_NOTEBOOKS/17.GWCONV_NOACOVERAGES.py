# Databricks notebook source
import logging
import sys
import os

LOG_FILE = 'etl_logfile.log'
LOG_FORMAT = '%(asctime)s %(levelname)s: %(message)s'

def get_etl_logger(name):
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    if logger.hasHandlers():
        logger.handlers.clear()
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.INFO)
    formatter = logging.Formatter(LOG_FORMAT)
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)
    file_handler = logging.FileHandler(LOG_FILE, mode='a')
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    return logger

logger = get_etl_logger('ca7noacov')
logger.info(f"Logging initialized. Log file location: {os.path.abspath(LOG_FILE)}")

def log_info_to_file(message):
    with open(LOG_FILE, 'a') as f:
        import datetime
        timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        f.write(f"{timestamp} INFO: {message}\n")

# COMMAND ----------

# Cell Purpose: Set up Databricks widgets and retrieve job context for tracking ETL runs.
# Business Context: Enables parameterization and job tracking for the ETL pipeline, supporting both interactive and scheduled job runs in Databricks.
"""
This cell creates widgets for job_id and job_run_id, retrieves the current notebook context, and extracts job and run IDs for logging and audit purposes.
"""
# Create widgets for job_id and job_run_id for parameterization and job tracking
# These widgets allow passing parameters when running as a Databricks job
# The job_id is used to identify the specific job, while job_run_id is used to track the execution of that job.

dbutils.widgets.text("job_id", "")
dbutils.widgets.text("job_run_id", "")

# Get the current notebook context for extracting job and run metadata
# This context provides information about the job execution environment, including job IDs and notebook path.
context = dbutils.notebook.entry_point.getDbutils().notebook().getContext()

# Extract jobId and jobRunId objects from context (may be Option types)
# These IDs are crucial for tracking the execution of the ETL process.
job_id_obj = context.jobId()          # Option type: may or may not be defined
job_run_id_obj = context.jobRunId()   # Option type: may or may not be defined

# Retrieve the full path to the current notebook for logging purposes
notebook_path = context.notebookPath().get() # Full path to the current notebook
# Extract the notebook name from the path for easier identification in logs
notebook_name = notebook_path.split('/')[-1]   # Extract the notebook name from the path

def safe_get_option(option_obj):
    """
    Safely extract a value from a Databricks Option object.
    Parameters:
        option_obj: Option (Databricks Java/Scala Option type)
            The object to extract the value from.
    Returns:
        value or None: The value if defined, else None.
    Exceptions:
        Catches all exceptions to avoid breaking job context extraction.
        This ensures that even if an error occurs, the job can continue running without interruption.
    """
    try:
        if option_obj.isDefined():
            return option_obj.get()  # Return the value if defined
        else:
            return None  # Return None if not defined
    except Exception:
        return None  # Return None in case of any exception

# Use the safe_get_option to retrieve the values, defaulting to 'Manual' if not found
# This provides a fallback mechanism for logging and auditing purposes.
job_id = safe_get_option(job_id_obj) or "Manual"    # Used for logging and audit
job_run_id = safe_get_option(job_run_id_obj) or "Manual"

# Output the retrieved IDs for debugging and traceability
# This print statement helps in verifying that the correct IDs are being used in the ETL process.
print(f"Job ID: {job_id}, Job Run ID: {job_run_id}")

# Redefine widgets with resolved values for downstream cells (ensures consistency)
# This step ensures that the widgets reflect the actual job and run IDs for any subsequent operations.
dbutils.widgets.text("job_id", str(job_id)) 
dbutils.widgets.text("job_run_id", str(job_run_id))

# COMMAND ----------

# MAGIC %run ../configuration/configs

# COMMAND ----------

# MAGIC %run ../configuration/postgres

# COMMAND ----------

# MAGIC %md
# MAGIC Load PMTIN parent tables for refrential integrity CHECks

# COMMAND ----------

def load_table(query, table_name):
    try:
        df = execute_select_PMTIN(query)  # Replace with your actual data loading function
        df.createOrReplaceTempView(table_name)
        logger.info(f"Successfully loaded {table_name}.")
        return df
    except Exception as e:
        logger.error(f"Failed to load {table_name}: {str(e)}")
        # Optionally raise an exception if you want to stop execution
        raise RuntimeError(f"Error loading {table_name}: {str(e)}")

# Load ca7noa table
ca7noa = load_table("select * from ca7noa", "ca7noa")

# Load ca7commautoline table
ca7commautoline = load_table("select * from ca7commautoline", "ca7commautoline")

# COMMAND ----------

# MAGIC %md
# MAGIC # Source Query for ca7noacov
# MAGIC
# MAGIC

# COMMAND ----------

log_info_to_file("[START] Extraction for ca7noacov...")
logger.info("[START] Extraction for ca7noacov...")
try:
  # Execute the query and create a temp view for downstream use
  ca7noacov_query = fetch_query_from_table('ca7noa_query')
  logger.info(f"ca7noacov_query: {ca7noacov_query}")
  log_info_to_file(f"ca7noacov_query: {ca7noacov_query}")
  ca7noacov_df = eval(exec_select_landing)(ca7noacov_query)
  ca7noacov_df.createOrReplaceTempView("ca7noacov_df")  # Create a temporary view for further processing
  row_count = ca7noacov_df.count()
  logger.info(f"ca7noacov_df loaded with {row_count} rows.")
  log_info_to_file(f"ca7noacov_df loaded with {row_count} rows.")
  logger.info(f"ca7noacov_df schema: {ca7noacov_df.schema}")
  log_info_to_file(f"ca7noacov_df schema: {ca7noacov_df.schema}")
  logger.info("[END] Extraction for ca7noacov.")
  log_info_to_file("[END] Extraction for ca7noacov.")
except Exception as e:
  logger.error(f"Error loading ca7noacov: {e}", exc_info=True)
  log_info_to_file(f"Error loading ca7noacov: {str(e)}")
  sys.exit(1)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Transformations for Codeidentifiers

# COMMAND ----------

ca7noacov_ca7nonownedautoliabnoa_query = '''
SELECT DISTINCT
    concat('CA7noaCov:',trim(PolicyNumber),'-',"CA7NonOwnedAutoLiabNOA",'-',trim(StateCode)) AS pmt_id,
    concat('CA7NOA:',trim(PolicyNumber),'-',trim(StateCode)) AS pmt_parent,
    'CA7NonOwnedAutoLiabNOA' AS CodeIdentifier,
    'usd' AS currency,
    trim(PolicyNumber) AS pmt_payloadid
FROM ca7noacov_df WHERE liabilitysymbol is not null
'''

log_info_to_file("[START] Transformation for ca7noacov_ca7nonownedautoliabnoa_data...")
logger.info("[START] Transformation for ca7noacov_ca7nonownedautoliabnoa_data...")
try:
    logger.info(f"ca7noacov_ca7nonownedautoliabnoa_query: {ca7noacov_ca7nonownedautoliabnoa_query}")
    log_info_to_file(f"ca7noacov_ca7nonownedautoliabnoa_query: {ca7noacov_ca7nonownedautoliabnoa_query}")
    ca7noacov_ca7nonownedautoliabnoa_data = spark.sql(ca7noacov_ca7nonownedautoliabnoa_query)
    ca7noacov_ca7nonownedautoliabnoa_data.createOrReplaceTempView("ca7noacov_ca7nonownedautoliabnoa_data")
    row_count = ca7noacov_ca7nonownedautoliabnoa_data.count()
    logger.info(f"ca7noacov_ca7nonownedautoliabnoa_data loaded with {row_count} rows.")
    log_info_to_file(f"ca7noacov_ca7nonownedautoliabnoa_data loaded with {row_count} rows.")
    logger.info(f"ca7noacov_ca7nonownedautoliabnoa_data schema: {ca7noacov_ca7nonownedautoliabnoa_data.schema}")
    log_info_to_file(f"ca7noacov_ca7nonownedautoliabnoa_data schema: {ca7noacov_ca7nonownedautoliabnoa_data.schema}")
    logger.info("[END] Transformation for ca7noacov_ca7nonownedautoliabnoa_data.")
    log_info_to_file("[END] Transformation for ca7noacov_ca7nonownedautoliabnoa_data.")
    
except Exception as e:
    logger.error(f"error loading ca7noacov_ca7nonownedautoliabnoa_data: {e}", exc_info=True)
    log_info_to_file(f"error loading ca7noacov_ca7nonownedautoliabnoa_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Refrential integrity,Not null and duplicate checks

# COMMAND ----------

# Validate the Proprietary Coverage Data
logger.info("Starting validation for ca7noacov_ca7nonownedautoliabnoa_data...")
validation_result = validate_data(data_name="ca7noacov_ca7nonownedautoliabnoa_data", parent_table="ca7noa")

if validation_result is None:
    validation_result = {
        "status": False,
        "errors": [{"type": "internal_error", "details": "Validation function returned None."}],
        "warnings": []
    }

if validation_result["status"]:  # Validation passed
    logger.info("Validation passed for ca7noacov_ca7nonownedautoliabnoa_data.")
    try:
        row_count = ca7noacov_ca7nonownedautoliabnoa_data.count()
        logger.info(f"[START] Writing {row_count} rows to table 'ca7noacov' in PMTIN.")
        log_info_to_file(f"[START] Writing {row_count} rows to table 'ca7noacov' in PMTIN.")
        logger.info(f"ca7noacov_ca7nonownedautoliabnoa_data schema: {ca7noacov_ca7nonownedautoliabnoa_data.schema}")
        log_info_to_file(f"ca7noacov_ca7nonownedautoliabnoa_data schema: {ca7noacov_ca7nonownedautoliabnoa_data.schema}")
        write_and_log_pmtin(
            df=ca7noacov_ca7nonownedautoliabnoa_data,
            table_name="ca7noacov",
            job_id=job_id,
            job_run_id=job_run_id,
            notebook_name=notebook_name
        )
        logger.info("[END] Successfully wrote ca7noacov_ca7nonownedautoliabnoa_data to table 'ca7noacov'.")
        log_info_to_file("[END] Successfully wrote ca7noacov_ca7nonownedautoliabnoa_data to table 'ca7noacov'.")
    except Exception as e:
        logger.error(f"Error writing ca7noacov_ca7nonownedautoliabnoa_data to table 'ca7noacov'", exc_info=True)
        log_info_to_file(f"Error writing ca7noacov_ca7nonownedautoliabnoa_data to table 'ca7noacov': {str(e)}")
        log_dataload_event(
            job_id=job_id,
            job_run_id=job_run_id,
            notebook_name=notebook_name,
            log_message=f"Error writing ca7noacov_ca7nonownedautoliabnoa_data to table: {str(e)}"
        )
        sys.exit(1)
else:
    logger.error("Validation failed for ca7noacov_ca7nonownedautoliabnoa_data.")
    error_messages = []
    for error in validation_result["errors"]:
        error_message = f"Validation Error: {error['type']} - {error.get('details', '')}"
        logger.error(error_message)
        log_info_to_file(error_message)
        error_messages.append(error_message)
    full_error_message = "; ".join(error_messages)
    log_dataload_event(
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name,
        log_message=f"Validation failed for ca7noacov_ca7nonownedautoliabnoa_data: {full_error_message}"
    )
    raise ValueError(
        f"Validation failed for ca7noacov_ca7nonownedautoliabnoa_data. Validation errors logged: {full_error_message}."
    )

# COMMAND ----------

# MAGIC %skip
# MAGIC CA7Covterm_CA7LiabCovType2_query = '''
# MAGIC SELECT DISTINCT
# MAGIC     concat('CA7NonOwnedAutoLiabNOA:',trim(PolicyNumber),'-','CA7LiabCovType2','-',trim(StateCode)) AS pmt_id,
# MAGIC      concat('CA7noaCov:',trim(PolicyNumber),'-',"CA7NonOwnedAutoLiabNOA",'-',trim(StateCode)) AS pmt_parent,
# MAGIC     
# MAGIC     'CA7NOACov' AS pmt_parent_type,
# MAGIC     'CA7LiabCovType2' AS codeidentifier,
# MAGIC     CASE 
# MAGIC         -- 1 maps to CombinedSingleLimit,2 maps to SplitLimit
# MAGIC         WHEN LiabilityLimitTypeCode = '1' THEN 'CombinedSingleLimit'
# MAGIC         WHEN LiabilityLimitTypeCode = '2' THEN 'SplitLimit'
# MAGIC     END  AS value,
# MAGIC     trim(PolicyNumber) AS pmt_payloadid
# MAGIC FROM ca7noacov_df
# MAGIC '''
# MAGIC try:
# MAGIC   CA7Covterm_CA7LiabCovType2_data = spark.sql(CA7Covterm_CA7LiabCovType2_query)
# MAGIC   CA7Covterm_CA7LiabCovType2_data.createOrReplaceTempView("CA7Covterm_CA7LiabCovType2_data")
# MAGIC   print(CA7Covterm_CA7LiabCovType2_data.count())
# MAGIC   display(CA7Covterm_CA7LiabCovType2_data)
# MAGIC except Exception as e:
# MAGIC   logger.info("error loading CA7Covterm_CA7LiabCovType2_data: {}".format(e)) 
# MAGIC   sys.exit(1)

# COMMAND ----------

# MAGIC %skip
# MAGIC # SQL to find mismatching pmt_parent, count null pmt_id, and check for duplicates
# MAGIC invalid_refs_sql = """
# MAGIC SELECT DISTINCT pmt_parent
# MAGIC FROM CA7Covterm_CA7LiabCovType2_data
# MAGIC WHERE pmt_parent NOT IN (
# MAGIC   SELECT DISTINCT pmt_id FROM ca7noacov_ca7nonownedautoliabnoa_data
# MAGIC )
# MAGIC """
# MAGIC
# MAGIC null_pmt_id_sql = """
# MAGIC SELECT COUNT(*) as null_count
# MAGIC FROM CA7Covterm_CA7LiabCovType2_data
# MAGIC WHERE pmt_id IS NULL
# MAGIC """
# MAGIC
# MAGIC # SQL to check for duplicate pmt_id
# MAGIC duplicate_pmt_id_sql = """
# MAGIC SELECT pmt_id, COUNT(*) as cnt
# MAGIC FROM CA7Covterm_CA7LiabCovType2_data
# MAGIC GROUP BY pmt_id
# MAGIC HAVING COUNT(*) > 1
# MAGIC """
# MAGIC
# MAGIC # Execute the SQL queries
# MAGIC invalid_refs = spark.sql(invalid_refs_sql)
# MAGIC null_pmt_id_count = spark.sql(null_pmt_id_sql).collect()[0]['null_count']
# MAGIC duplicate_pmt_ids = spark.sql(duplicate_pmt_id_sql)
# MAGIC
# MAGIC # Check conditions and log details
# MAGIC if invalid_refs.count() == 0 and null_pmt_id_count == 0 and duplicate_pmt_ids.count() == 0:
# MAGIC     CA7Covterm_CA7LiabCovType2_data.write.jdbc(url=jdbc_url_pmtin, table='covterm', mode='append', properties=properties)
# MAGIC else:
# MAGIC     if invalid_refs.count() > 0:
# MAGIC         logger.error("Referential integrity issue: Some pmt_parent values do not exist in ca7noacov_ca7nonownedautoliabnoa_data.")
# MAGIC         missing_parents = invalid_refs.collect()
# MAGIC         for row in missing_parents:
# MAGIC             logger.error(f"Invalid pmt_parent: {row.pmt_parent}")
# MAGIC     
# MAGIC     if null_pmt_id_count > 0:
# MAGIC         logger.error(f"Null pmt_id values found in CA7Covterm_CA7LiabCovType2_data: {null_pmt_id_count}")
# MAGIC     
# MAGIC     if duplicate_pmt_ids.count() > 0:
# MAGIC         logger.error("Duplicate pmt_id values found in CA7Covterm_CA7LiabCovType2_data.")
# MAGIC         # Log duplicate pmt_id values
# MAGIC         for row in duplicate_pmt_ids.collect():
# MAGIC             logger.error(f"Duplicate pmt_id: {row.pmt_id} with count: {row.cnt}")

# COMMAND ----------

# MAGIC %skip
# MAGIC CA7Covterm_CA7LiabLimit_query = '''
# MAGIC SELECT DISTINCT
# MAGIC     concat('CA7NonOwnedAutoLiabNOA:',trim(PolicyNumber),'-','CA7LiabLimit','-',trim(StateCode)) AS pmt_id,
# MAGIC     concat('CA7noaCov:',trim(PolicyNumber),'-','CA7NonOwnedAutoLiabNOA','-',trim(StateCode)) AS pmt_parent,
# MAGIC     'CA7NOACov' AS pmt_parent_type,
# MAGIC     'CA7LiabLimit' AS codeidentifier,
# MAGIC     CASE 
# MAGIC         WHEN LiabilitySymbol IS NULL THEN 'NotApplicable'
# MAGIC         WHEN LiabilityLimitTypeCode = '1' AND trim(LiabilityLimit) in (
# MAGIC             '15000','110000','25000','50000','55000','30000','90000','85000','70000','60000','75000','65000','35000',
# MAGIC             '100000','125000','150000','200000','250000','300000','350000','400000','500000','510000','600000','750000',
# MAGIC             '1000000','1500000','2000000','2500000','3000000','5000000','7500000','10000000',
# MAGIC             '20000/40000','25000/50000','35000/70000','50000/100000','75000/150000','100000/200000','100000/300000',
# MAGIC             '200000/200000','200000/400000','250000/500000','300000/300000','300000/600000','500000/1000000',
# MAGIC             '1000000/1000000','2000000/2000000','2500000/2500000','5000000/5000000','10000000/10000000'
# MAGIC         ) THEN trim(LiabilityLimit)
# MAGIC         WHEN LiabilityLimitTypeCode = '2' AND trim(PDLimit) in (
# MAGIC             '15000','110000','25000','50000','55000','30000','90000','85000','70000','60000','75000','65000','35000',
# MAGIC             '100000','125000','150000','200000','250000','300000','350000','400000','500000','510000','600000','750000',
# MAGIC             '1000000','1500000','2000000','2500000','3000000','5000000','7500000','10000000',
# MAGIC             '20000/40000','25000/50000','35000/70000','50000/100000','75000/150000','100000/200000','100000/300000',
# MAGIC             '200000/200000','200000/400000','250000/500000','300000/300000','300000/600000','500000/1000000',
# MAGIC             '1000000/1000000','2000000/2000000','2500000/2500000','5000000/5000000','10000000/10000000'
# MAGIC         ) THEN trim(PDLimit)
# MAGIC     END AS value,
# MAGIC     trim(PolicyNumber) AS pmt_payloadid
# MAGIC FROM ca7noacov_df
# MAGIC '''
# MAGIC try:
# MAGIC   CA7Covterm_CA7LiabLimit_data = spark.sql(CA7Covterm_CA7LiabLimit_query)
# MAGIC   CA7Covterm_CA7LiabLimit_data.createOrReplaceTempView("CA7Covterm_CA7LiabLimit_data")
# MAGIC   print(CA7Covterm_CA7LiabLimit_data.count())
# MAGIC   display(CA7Covterm_CA7LiabLimit_data)
# MAGIC except Exception as e:
# MAGIC   logger.info("error loading CA7Covterm_CA7LiabLimit_data: {}".format(e)) 
# MAGIC   sys.exit(1)

# COMMAND ----------

# MAGIC %skip
# MAGIC # SQL to find mismatching pmt_parent, count null pmt_id, and check for duplicates for CA7Covterm_CA7LiabLimit_data
# MAGIC invalid_refs_limit_sql = """
# MAGIC SELECT DISTINCT pmt_parent
# MAGIC FROM CA7Covterm_CA7LiabLimit_data
# MAGIC WHERE pmt_parent NOT IN (
# MAGIC   SELECT DISTINCT pmt_id FROM ca7noacov_ca7nonownedautoliabnoa_data
# MAGIC )
# MAGIC """
# MAGIC
# MAGIC null_pmt_id_limit_sql = """
# MAGIC SELECT COUNT(*) as null_count
# MAGIC FROM CA7Covterm_CA7LiabLimit_data
# MAGIC WHERE pmt_id IS NULL
# MAGIC """
# MAGIC
# MAGIC duplicate_pmt_id_limit_sql = """
# MAGIC SELECT pmt_id, COUNT(*) as cnt
# MAGIC FROM CA7Covterm_CA7LiabLimit_data
# MAGIC GROUP BY pmt_id
# MAGIC HAVING COUNT(*) > 1
# MAGIC """
# MAGIC
# MAGIC invalid_refs_limit = spark.sql(invalid_refs_limit_sql)
# MAGIC null_pmt_id_limit_count = spark.sql(null_pmt_id_limit_sql).collect()[0]['null_count']
# MAGIC duplicate_pmt_ids_limit = spark.sql(duplicate_pmt_id_limit_sql)
# MAGIC
# MAGIC if invalid_refs_limit.count() == 0 and null_pmt_id_limit_count == 0 and duplicate_pmt_ids_limit.count() == 0:
# MAGIC     CA7Covterm_CA7LiabLimit_data.write.jdbc(url=jdbc_url_pmtin, table='covterm', mode='append', properties=properties)
# MAGIC else:
# MAGIC     if invalid_refs_limit.count() > 0:
# MAGIC         logger.error("Referential integrity issue: Some pmt_parent values do not exist in ca7noacov_ca7nonownedautoliabnoa_data.")
# MAGIC         for row in invalid_refs_limit.collect():
# MAGIC             logger.error(f"Invalid pmt_parent: {row.pmt_parent}")
# MAGIC     if null_pmt_id_limit_count > 0:
# MAGIC         logger.error(f"Null pmt_id values found in CA7Covterm_CA7LiabLimit_data: {null_pmt_id_limit_count}")
# MAGIC     if duplicate_pmt_ids_limit.count() > 0:
# MAGIC         logger.error("Duplicate pmt_id values found in CA7Covterm_CA7LiabLimit_data.")
# MAGIC         for row in duplicate_pmt_ids_limit.collect():
# MAGIC             logger.error(f"Duplicate pmt_id: {row.pmt_id} with count: {row.cnt}")
# MAGIC
# MAGIC

# COMMAND ----------

#CA7NonOwnedAutoLiabExtendedEmplsNOA

ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_query = '''
SELECT DISTINCT
    concat('CA7noaCov:',trim(PolicyNumber),'-',"CA7NonOwnedAutoLiabExtendedEmplsNOA",'-',trim(StateCode)) AS pmt_id,
    concat('CA7NOA:',trim(PolicyNumber),'-',trim(StateCode)) AS pmt_parent,
    'CA7NonOwnedAutoLiabExtendedEmplsNOA' AS CodeIdentifier,
    'usd' AS currency,
    trim(PolicyNumber) AS pmt_payloadid
FROM ca7noacov_df
WHERE liabilitysymbol is not null
'''

log_info_to_file("[START] Transformation for ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data...")
logger.info("[START] Transformation for ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data...")
try:
    logger.info(f"ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_query: {ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_query}")
    log_info_to_file(f"ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_query: {ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_query}")
    ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data = spark.sql(ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_query)
    ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data.createOrReplaceTempView("ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data")
    row_count = ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data.count()
    logger.info(f"ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data loaded with {row_count} rows.")
    log_info_to_file(f"ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data loaded with {row_count} rows.")
    logger.info(f"ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data schema: {ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data.schema}")
    log_info_to_file(f"ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data schema: {ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data.schema}")
    logger.info("[END] Transformation for ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data.")
    log_info_to_file("[END] Transformation for ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data.")
except Exception as e:
    logger.error(f"error loading ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data: {e}", exc_info=True)
    log_info_to_file(f"error loading ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# Validate ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data before writing
logger.info("Starting validation for ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data...")
validation_result = validate_data(data_name="ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data", parent_table="ca7noa")

if validation_result is None:
    validation_result = {
        "status": False,
        "errors": [{"type": "internal_error", "details": "Validation function returned None."}],
        "warnings": []
    }

if validation_result["status"]:
    logger.info("Validation passed for ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data.")
    try:
        row_count = ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data.count()
        logger.info(f"[START] Writing {row_count} rows to table 'ca7noacov' in PMTIN.")
        log_info_to_file(f"[START] Writing {row_count} rows to table 'ca7noacov' in PMTIN.")
        logger.info(f"ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data schema: {ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data.schema}")
        log_info_to_file(f"ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data schema: {ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data.schema}")
        write_and_log_pmtin(
            df=ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data,
            table_name="ca7noacov",
            job_id=job_id,
            job_run_id=job_run_id,
            notebook_name=notebook_name,
            truncate=False
        )
        logger.info("[END] Successfully wrote ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data to table 'ca7noacov'.")
        log_info_to_file("[END] Successfully wrote ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data to table 'ca7noacov'.")
    except Exception as e:
        logger.error(f"Error writing ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data to table 'ca7noacov'", exc_info=True)
        log_info_to_file(f"Error writing ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data to table 'ca7noacov': {str(e)}")
        log_dataload_event(
            job_id=job_id,
            job_run_id=job_run_id,
            notebook_name=notebook_name,
            log_message=f"Error writing ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data to table: {str(e)}"
        )
        sys.exit(1)
else:
    logger.error("Validation failed for ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data.")
    error_messages = []
    for error in validation_result["errors"]:
        error_message = f"Validation Error: {error['type']} - {error.get('details', '')}"
        logger.error(error_message)
        log_info_to_file(error_message)
        error_messages.append(error_message)
    full_error_message = "; ".join(error_messages)
    log_dataload_event(
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name,
        log_message=f"Validation failed for ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data: {full_error_message}"
    )
    raise ValueError(
        f"Validation failed for ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data. Validation errors logged: {full_error_message}."
    )

# COMMAND ----------

# MAGIC %skip
# MAGIC CA7Covterm_CA7ExtendedCovForEmpls_query = '''
# MAGIC SELECT DISTINCT
# MAGIC     concat('CA7NonOwnedAutoLiabNOA:',trim(PolicyNumber),'-','CA7ExtendedCovForEmpls','-',trim(StateCode)) AS pmt_id,
# MAGIC     concat('CA7noaCov:',trim(PolicyNumber),'-',"CA7NonOwnedAutoLiabExtendedEmplsNOA",'-',trim(StateCode)) AS pmt_parent,
# MAGIC     'CA7NOACov' AS pmt_parent_type,
# MAGIC     'CA7ExtendedCovForEmpls' AS codeidentifier,
# MAGIC     CASE 
# MAGIC         WHEN EmpAddinsd= 'Y' THEN 'Yes'
# MAGIC         ELSE 'No'
# MAGIC     END  AS value,
# MAGIC     trim(PolicyNumber) AS pmt_payloadid
# MAGIC FROM ca7noacov_df
# MAGIC '''
# MAGIC try:
# MAGIC   CA7Covterm_CA7ExtendedCovForEmpls_data = spark.sql(CA7Covterm_CA7ExtendedCovForEmpls_query)
# MAGIC   CA7Covterm_CA7ExtendedCovForEmpls_data.createOrReplaceTempView("CA7Covterm_CA7ExtendedCovForEmpls_data")
# MAGIC   print(CA7Covterm_CA7ExtendedCovForEmpls_data.count())
# MAGIC   display(CA7Covterm_CA7ExtendedCovForEmpls_data)
# MAGIC except Exception as e:
# MAGIC   logger.info("error loading CA7Covterm_CA7ExtendedCovForEmpls_data: {}".format(e)) 
# MAGIC   sys.exit(1) 

# COMMAND ----------

# MAGIC %skip
# MAGIC # SQL to find mismatching pmt_parent, count null pmt_id, and check for duplicates for CA7Covterm_CA7ExtendedCovForEmpls_data
# MAGIC invalid_refs_sql = """
# MAGIC SELECT DISTINCT pmt_parent
# MAGIC FROM CA7Covterm_CA7ExtendedCovForEmpls_data 
# MAGIC WHERE pmt_parent NOT IN (
# MAGIC   SELECT DISTINCT pmt_id FROM ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data
# MAGIC )
# MAGIC """
# MAGIC
# MAGIC null_pmt_id_sql = """
# MAGIC SELECT COUNT(*) as null_count
# MAGIC FROM CA7Covterm_CA7ExtendedCovForEmpls_data
# MAGIC WHERE pmt_id IS NULL
# MAGIC """
# MAGIC
# MAGIC duplicate_pmt_id_sql = """
# MAGIC SELECT pmt_id, COUNT(*) as cnt
# MAGIC FROM CA7Covterm_CA7ExtendedCovForEmpls_data
# MAGIC GROUP BY pmt_id
# MAGIC HAVING COUNT(*) > 1
# MAGIC """
# MAGIC
# MAGIC invalid_refs = spark.sql(invalid_refs_sql)
# MAGIC null_pmt_id_count = spark.sql(null_pmt_id_sql).collect()[0]['null_count']
# MAGIC duplicate_pmt_ids = spark.sql(duplicate_pmt_id_sql)
# MAGIC
# MAGIC if invalid_refs.count() == 0 and null_pmt_id_count == 0 and duplicate_pmt_ids.count() == 0:
# MAGIC     CA7Covterm_CA7ExtendedCovForEmpls_data.write.jdbc(url=jdbc_url_pmtin, table='covterm', mode='append', properties=properties)
# MAGIC     #print('No issues found in CA7Covterm_CA7ExtendedCovForEmpls_data')
# MAGIC else:
# MAGIC     if invalid_refs.count() > 0:
# MAGIC         logger.error("Referential integrity issue: Some pmt_parent values do not exist in ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data.")
# MAGIC         for row in invalid_refs.collect():
# MAGIC             logger.error(f"Invalid pmt_parent: {row.pmt_parent}")
# MAGIC     if null_pmt_id_count > 0:
# MAGIC         logger.error(f"Null pmt_id values found in CA7Covterm_CA7ExtendedCovForEmpls_data: {null_pmt_id_count}")
# MAGIC     if duplicate_pmt_ids.count() > 0:
# MAGIC         logger.error("Duplicate pmt_id values found in CA7Covterm_CA7ExtendedCovForEmpls_data.")
# MAGIC         for row in duplicate_pmt_ids.collect():
# MAGIC             logger.error(f"Duplicate pmt_id: {row.pmt_id} with count: {row.cnt}")

# COMMAND ----------

#CA7NonOwnedAutoLiabExtendedPartnersNOA

ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_query = '''
SELECT DISTINCT
    concat('CA7noaCov:',trim(PolicyNumber),'-',"CA7NonOwnedAutoLiabExtendedPartnersNOA",'-',trim(StateCode)) AS pmt_id,
    concat('CA7NOA:',trim(PolicyNumber),'-',trim(StateCode)) AS pmt_parent,
    'CA7NonOwnedAutoLiabExtendedPartnersNOA' AS CodeIdentifier,
    'usd' AS currency,
    trim(PolicyNumber) AS pmt_payloadid
FROM ca7noacov_df
WHERE liabilitysymbol is not null
'''

log_info_to_file("[START] Transformation for ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data...")
logger.info("[START] Transformation for ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data...")
try:
    logger.info(f"ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_query: {ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_query}")
    log_info_to_file(f"ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_query: {ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_query}")
    ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data = spark.sql(ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_query)
    ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data.createOrReplaceTempView("ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data")
    row_count = ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data.count()
    logger.info(f"ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data loaded with {row_count} rows.")
    log_info_to_file(f"ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data loaded with {row_count} rows.")
    logger.info(f"ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data schema: {ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data.schema}")
    log_info_to_file(f"ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data schema: {ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data.schema}")
    logger.info("[END] Transformation for ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data.")
    log_info_to_file("[END] Transformation for ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data.")
    display(ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data)
except Exception as e:
    logger.error(f"error loading ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data: {e}", exc_info=True)
    log_info_to_file(f"error loading ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# Validate ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data before writing
logger.info("Starting validation for ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data...")
validation_result = validate_data(data_name="ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data", parent_table="ca7noa")

if validation_result is None:
    validation_result = {
        "status": False,
        "errors": [{"type": "internal_error", "details": "Validation function returned None."}],
        "warnings": []
    }

if validation_result["status"]:
    logger.info("Validation passed for ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data.")
    try:
        row_count = ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data.count()
        logger.info(f"[START] Writing {row_count} rows to table 'ca7noacov' in PMTIN.")
        log_info_to_file(f"[START] Writing {row_count} rows to table 'ca7noacov' in PMTIN.")
        logger.info(f"ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data schema: {ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data.schema}")
        log_info_to_file(f"ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data schema: {ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data.schema}")
        write_and_log_pmtin(
            df=ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data,
            table_name="ca7noacov",
            job_id=job_id,
            job_run_id=job_run_id,
            notebook_name=notebook_name,
            truncate=False
        )
        logger.info("[END] Successfully wrote ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data to table 'ca7noacov'.")
        log_info_to_file("[END] Successfully wrote ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data  to table 'ca7noacov'.")
    except Exception as e:
        logger.error(f"Error writing ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data  to table 'ca7noacov'", exc_info=True)
        log_info_to_file(f"Error writing ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data to table 'ca7noacov': {str(e)}")
        log_dataload_event(
            job_id=job_id,
            job_run_id=job_run_id,
            notebook_name=notebook_name,
            log_message=f"Error writing ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data  to table: {str(e)}"
        )
        sys.exit(1)
else:
    logger.error("Validation failed for ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data a.")
    error_messages = []
    for error in validation_result["errors"]:
        error_message = f"Validation Error: {error['type']} - {error.get('details', '')}"
        logger.error(error_message)
        log_info_to_file(error_message)
        error_messages.append(error_message)
    full_error_message = "; ".join(error_messages)
    log_dataload_event(
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name,
        log_message=f"Validation failed for ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data : {full_error_message}"
    )
    raise ValueError(
        f"Validation failed for ca7noacov_CA7NonOwnedAutoLiabExtendedPartnersNOA_data . Validation errors logged: {full_error_message}."
    )

# COMMAND ----------

# MAGIC %skip
# MAGIC CA7Covterm_CA7ExtendedCovForPartners_query = '''
# MAGIC SELECT DISTINCT
# MAGIC     concat('CA7NonOwnedAutoLiabNOA:',trim(PolicyNumber),'-','CA7ExtendedCovForPartners','-',trim(StateCode)) AS pmt_id,
# MAGIC     concat('CA7noaCov:',trim(PolicyNumber),'-',"CA7NonOwnedAutoLiabExtendedEmplsNOA",'-',trim(StateCode)) AS pmt_parent,
# MAGIC     'CA7NOACov' AS pmt_parent_type,
# MAGIC     'CA7ExtendedCovForPartners' AS codeidentifier,
# MAGIC     CASE 
# MAGIC         WHEN ExtendedCoverageForPartners= 'Y' THEN 'Yes'
# MAGIC         ELSE 'No'
# MAGIC     END  AS value,
# MAGIC     trim(PolicyNumber) AS pmt_payloadid
# MAGIC FROM ca7noacov_df
# MAGIC '''
# MAGIC try:
# MAGIC   CA7Covterm_CA7ExtendedCovForPartners_data = spark.sql(CA7Covterm_CA7ExtendedCovForPartners_query)
# MAGIC   CA7Covterm_CA7ExtendedCovForPartners_data.createOrReplaceTempView("CA7Covterm_CA7ExtendedCovForPartners_data")
# MAGIC   print(CA7Covterm_CA7ExtendedCovForPartners_data.count())
# MAGIC   display(CA7Covterm_CA7ExtendedCovForPartners_data)
# MAGIC except Exception as e:
# MAGIC   logger.info("error loading CA7Covterm_CA7ExtendedCovForPartners_data: {}".format(e)) 
# MAGIC   sys.exit(1) 

# COMMAND ----------

# MAGIC %skip
# MAGIC # SQL to find mismatching pmt_parent, count null pmt_id, and check for duplicates for CA7Covterm_CA7ExtendedCovForPartners_data
# MAGIC invalid_refs_sql = """
# MAGIC SELECT DISTINCT pmt_parent
# MAGIC FROM CA7Covterm_CA7ExtendedCovForPartners_data 
# MAGIC WHERE pmt_parent NOT IN (
# MAGIC   SELECT DISTINCT pmt_id FROM ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data
# MAGIC )
# MAGIC """
# MAGIC
# MAGIC null_pmt_id_sql = """
# MAGIC SELECT COUNT(*) as null_count
# MAGIC FROM CA7Covterm_CA7ExtendedCovForPartners_data
# MAGIC WHERE pmt_id IS NULL
# MAGIC """
# MAGIC
# MAGIC duplicate_pmt_id_sql = """
# MAGIC SELECT pmt_id, COUNT(*) as cnt
# MAGIC FROM CA7Covterm_CA7ExtendedCovForPartners_data
# MAGIC GROUP BY pmt_id
# MAGIC HAVING COUNT(*) > 1
# MAGIC """
# MAGIC
# MAGIC invalid_refs = spark.sql(invalid_refs_sql)
# MAGIC null_pmt_id_count = spark.sql(null_pmt_id_sql).collect()[0]['null_count']
# MAGIC duplicate_pmt_ids = spark.sql(duplicate_pmt_id_sql)
# MAGIC
# MAGIC if invalid_refs.count() == 0 and null_pmt_id_count == 0 and duplicate_pmt_ids.count() == 0:
# MAGIC     CA7Covterm_CA7ExtendedCovForPartners_data.write.jdbc(url=jdbc_url_pmtin, table='covterm', mode='append', properties=properties)
# MAGIC     #print('No issues found in CA7Covterm_CA7ExtendedCovForPartners_data')
# MAGIC else:
# MAGIC     if invalid_refs.count() > 0:
# MAGIC         logger.error("Referential integrity issue: Some pmt_parent values do not exist in ca7noacov_CA7NonOwnedAutoLiabExtendedEmplsNOA_data.")
# MAGIC         for row in invalid_refs.collect():
# MAGIC             logger.error(f"Invalid pmt_parent: {row.pmt_parent}")
# MAGIC     if null_pmt_id_count > 0:
# MAGIC         logger.error(f"Null pmt_id values found in CA7Covterm_CA7ExtendedCovForPartners_data: {null_pmt_id_count}")
# MAGIC     if duplicate_pmt_ids.count() > 0:
# MAGIC         logger.error("Duplicate pmt_id values found in CA7Covterm_CA7ExtendedCovForPartners_data.")
# MAGIC         for row in duplicate_pmt_ids.collect():
# MAGIC             logger.error(f"Duplicate pmt_id: {row.pmt_id} with count: {row.cnt}")

# COMMAND ----------

#CA7NonOwnedAutoMedPayNOA

ca7noacov_CA7NonOwnedAutoMedPayNOA_query = '''
SELECT DISTINCT
    concat('CA7noaCov:',trim(PolicyNumber),'-',"CA7NonOwnedAutoMedPayNOA",'-',trim(StateCode)) AS pmt_id,
    concat('CA7NOA:',trim(PolicyNumber),'-',trim(StateCode)) AS pmt_parent,
    'CA7NonOwnedAutoMedPayNOA' AS CodeIdentifier,
    'usd' AS currency,
    trim(PolicyNumber) AS pmt_payloadid
FROM ca7noacov_df
WHERE liabilitysymbol is not null
'''

log_info_to_file("[START] Transformation for ca7noacov_CA7NonOwnedAutoMedPayNOA_data...")
logger.info("[START] Transformation for ca7noacov_CA7NonOwnedAutoMedPayNOA_data...")
try:
    logger.info(f"ca7noacov_CA7NonOwnedAutoMedPayNOA_query: {ca7noacov_CA7NonOwnedAutoMedPayNOA_query}")
    log_info_to_file(f"ca7noacov_CA7NonOwnedAutoMedPayNOA_query: {ca7noacov_CA7NonOwnedAutoMedPayNOA_query}")
    ca7noacov_CA7NonOwnedAutoMedPayNOA_data = spark.sql(ca7noacov_CA7NonOwnedAutoMedPayNOA_query)
    ca7noacov_CA7NonOwnedAutoMedPayNOA_data.createOrReplaceTempView("ca7noacov_CA7NonOwnedAutoMedPayNOA_data")
    row_count = ca7noacov_CA7NonOwnedAutoMedPayNOA_data.count()
    logger.info(f"ca7noacov_CA7NonOwnedAutoMedPayNOA_data loaded with {row_count} rows.")
    log_info_to_file(f"ca7noacov_CA7NonOwnedAutoMedPayNOA_data loaded with {row_count} rows.")
    logger.info(f"ca7noacov_CA7NonOwnedAutoMedPayNOA_data schema: {ca7noacov_CA7NonOwnedAutoMedPayNOA_data.schema}")
    log_info_to_file(f"ca7noacov_CA7NonOwnedAutoMedPayNOA_data schema: {ca7noacov_CA7NonOwnedAutoMedPayNOA_data.schema}")
    logger.info("[END] Transformation for ca7noacov_CA7NonOwnedAutoMedPayNOA_data.")
    log_info_to_file("[END] Transformation for ca7noacov_CA7NonOwnedAutoMedPayNOA_data.")
    display(ca7noacov_CA7NonOwnedAutoMedPayNOA_data)
except Exception as e:
    logger.error(f"error loading ca7noacov_CA7NonOwnedAutoMedPayNOA_data: {e}", exc_info=True)
    log_info_to_file(f"error loading ca7noacov_CA7NonOwnedAutoMedPayNOA_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------

logger.info("Starting validation for ca7noacov_CA7NonOwnedAutoMedPayNOA_data...")
validation_result = validate_data(data_name="ca7noacov_CA7NonOwnedAutoMedPayNOA_data", parent_table="ca7noa")

if validation_result is None:
    validation_result = {
        "status": False,
        "errors": [{"type": "internal_error", "details": "Validation function returned None."}],
        "warnings": []
    }

if validation_result["status"]:
    logger.info("Validation passed for ca7noacov_CA7NonOwnedAutoMedPayNOA_data.")
    try:
        row_count = ca7noacov_CA7NonOwnedAutoMedPayNOA_data.count()
        logger.info(f"[START] Writing {row_count} rows to table 'ca7noacov' in PMTIN.")
        log_info_to_file(f"[START] Writing {row_count} rows to table 'ca7noacov' in PMTIN.")
        logger.info(f"ca7noacov_CA7NonOwnedAutoMedPayNOA_data schema: {ca7noacov_CA7NonOwnedAutoMedPayNOA_data.schema}")
        log_info_to_file(f"ca7noacov_CA7NonOwnedAutoMedPayNOA_data schema: {ca7noacov_CA7NonOwnedAutoMedPayNOA_data.schema}")
        write_and_log_pmtin(
            df=ca7noacov_CA7NonOwnedAutoMedPayNOA_data,
            table_name="ca7noacov",
            job_id=job_id,
            job_run_id=job_run_id,
            notebook_name=notebook_name,
            truncate=False
        )
        logger.info("[END] Successfully wrote ca7noacov_CA7NonOwnedAutoMedPayNOA_data to table 'ca7noacov'.")
        log_info_to_file("[END] Successfully wrote ca7noacov_CA7NonOwnedAutoMedPayNOA_data to table 'ca7noacov'.")
    except Exception as e:
        logger.error(f"Error writing ca7noacov_CA7NonOwnedAutoMedPayNOA_data to table 'ca7noacov'", exc_info=True)
        log_info_to_file(f"Error writing ca7noacov_CA7NonOwnedAutoMedPayNOA_data to table 'ca7noacov': {str(e)}")
        log_dataload_event(
            job_id=job_id,
            job_run_id=job_run_id,
            notebook_name=notebook_name,
            log_message=f"Error writing ca7noacov_CA7NonOwnedAutoMedPayNOA_data to table: {str(e)}"
        )
        sys.exit(1)
else:
    logger.error("Validation failed for ca7noacov_CA7NonOwnedAutoMedPayNOA_data.")
    error_messages = []
    for error in validation_result["errors"]:
        error_message = f"Validation Error: {error['type']} - {error.get('details', '')}"
        logger.error(error_message)
        log_info_to_file(error_message)
        error_messages.append(error_message)
    full_error_message = "; ".join(error_messages)
    log_dataload_event(
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name,
        log_message=f"Validation failed for ca7noacov_CA7NonOwnedAutoMedPayNOA_data: {full_error_message}"
    )
    raise ValueError(
        f"Validation failed for ca7noacov_CA7NonOwnedAutoMedPayNOA_data. Validation errors logged: {full_error_message}."
    )

# COMMAND ----------

#CA7NonOwnedAutoLiabExtendedVolunteersNOA

ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_query = '''
SELECT DISTINCT
    concat('CA7noaCov:',trim(PolicyNumber),'-',"CA7NonOwnedAutoLiabExtendedVolunteersNOA",'-',trim(StateCode)) AS pmt_id,
    concat('CA7NOA:',trim(PolicyNumber),'-',trim(StateCode)) AS pmt_parent,
    'CA7NonOwnedAutoLiabExtendedVolunteersNOA' AS CodeIdentifier,
    'usd' AS currency,
    trim(PolicyNumber) AS pmt_payloadid
FROM ca7noacov_df
WHERE trim(ExtendedCoverageForVolunteers) = 'Y'
'''

log_info_to_file("[START] Transformation for ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data...")
logger.info("[START] Transformation for ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data...")
try:
    logger.info(f"ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_query: {ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_query}")
    log_info_to_file(f"ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_query: {ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_query}")
    ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data = spark.sql(ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_query)
    ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data.createOrReplaceTempView("ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data")
    row_count = ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data.count()
    logger.info(f"ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data loaded with {row_count} rows.")
    log_info_to_file(f"ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data loaded with {row_count} rows.")
    logger.info(f"ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data schema: {ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data.schema}")
    log_info_to_file(f"ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data schema: {ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data.schema}")
    logger.info("[END] Transformation for ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data.")
    log_info_to_file("[END] Transformation for ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data.")
    display(ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data)
except Exception as e:
    logger.error(f"error loading ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data: {e}", exc_info=True)
    log_info_to_file(f"error loading ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------

logger.info("Starting validation for ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data...")
validation_result = validate_data(data_name="ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data", parent_table="ca7noa")

if validation_result is None:
    validation_result = {
        "status": False,
        "errors": [{"type": "internal_error", "details": "Validation function returned None."}],
        "warnings": []
    }

if validation_result["status"]:
    logger.info("Validation passed for ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data.")
    try:
        row_count = ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data.count()
        logger.info(f"[START] Writing {row_count} rows to table 'ca7noacov' in PMTIN.")
        log_info_to_file(f"[START] Writing {row_count} rows to table 'ca7noacov' in PMTIN.")
        logger.info(f"ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data schema: {ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data.schema}")
        log_info_to_file(f"ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data schema: {ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data.schema}")
        write_and_log_pmtin(
            df=ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data,
            table_name="ca7noacov",
            job_id=job_id,
            job_run_id=job_run_id,
            notebook_name=notebook_name,
            truncate=False
        )
        logger.info("[END] Successfully wrote ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data to table 'ca7noacov'.")
        log_info_to_file("[END] Successfully wrote ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data to table 'ca7noacov'.")
    except Exception as e:
        logger.error(f"Error writing ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data to table 'ca7noacov'", exc_info=True)
        log_info_to_file(f"Error writing ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data to table 'ca7noacov': {str(e)}")
        log_dataload_event(
            job_id=job_id,
            job_run_id=job_run_id,
            notebook_name=notebook_name,
            log_message=f"Error writing ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data to table: {str(e)}"
        )
        sys.exit(1)
else:
    logger.error("Validation failed for ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data.")
    error_messages = []
    for error in validation_result["errors"]:
        error_message = f"Validation Error: {error['type']} - {error.get('details', '')}"
        logger.error(error_message)
        log_info_to_file(error_message)
        error_messages.append(error_message)
    full_error_message = "; ".join(error_messages)
    log_dataload_event(
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name,
        log_message=f"Validation failed for ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data: {full_error_message}"
    )
    raise ValueError(
        f"Validation failed for ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data. Validation errors logged: {full_error_message}."
    )

# COMMAND ----------

# MAGIC %skip
# MAGIC #CA7ExtendedCovForVolunteers
# MAGIC CA7Covterm_CA7ExtendedCovForVolunteers_query = '''
# MAGIC SELECT DISTINCT
# MAGIC     concat('CA7NonOwnedAutoLiabNOA:',trim(PolicyNumber),'-','CA7ExtendedCovForVolunteers','-',trim(StateCode)) AS pmt_id,
# MAGIC     concat('CA7noaCov:',trim(PolicyNumber),'-',"CA7NonOwnedAutoLiabExtendedVolunteersNOA",'-',trim(StateCode)) AS pmt_parent,
# MAGIC     'CA7NOACov' AS pmt_parent_type,
# MAGIC     'CA7ExtendedCovForVolunteers' AS codeidentifier,
# MAGIC     CASE 
# MAGIC         WHEN ExtendedCoverageForVolunteers = 'Y' THEN 'Yes'
# MAGIC        ELSE 'No'
# MAGIC     END AS value,
# MAGIC     trim(PolicyNumber) AS pmt_payloadid
# MAGIC FROM ca7noacov_df
# MAGIC '''
# MAGIC try:
# MAGIC   CA7Covterm_CA7ExtendedCovForVolunteers_data = spark.sql(CA7Covterm_CA7ExtendedCovForVolunteers_query)
# MAGIC   CA7Covterm_CA7ExtendedCovForVolunteers_data.createOrReplaceTempView("CA7Covterm_CA7ExtendedCovForVolunteers_data")
# MAGIC   print(CA7Covterm_CA7ExtendedCovForVolunteers_data.count())
# MAGIC   display(CA7Covterm_CA7ExtendedCovForVolunteers_data)
# MAGIC except Exception as e:
# MAGIC   logger.info("error loading CA7Covterm_CA7ExtendedCovForVolunteers_data: {}".format(e)) 
# MAGIC   sys.exit(1)

# COMMAND ----------

# MAGIC %skip
# MAGIC # SQL to find mismatching pmt_parent, count null pmt_id, and check for duplicates for CA7Covterm_CA7ExtendedCovForVolunteers_data
# MAGIC invalid_refs_sql = """
# MAGIC SELECT DISTINCT pmt_parent
# MAGIC FROM CA7Covterm_CA7ExtendedCovForVolunteers_data 
# MAGIC WHERE pmt_parent NOT IN (
# MAGIC   SELECT DISTINCT pmt_id FROM ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data
# MAGIC )
# MAGIC """
# MAGIC
# MAGIC null_pmt_id_sql = """
# MAGIC SELECT COUNT(*) as null_count
# MAGIC FROM CA7Covterm_CA7ExtendedCovForVolunteers_data
# MAGIC WHERE pmt_id IS NULL
# MAGIC """
# MAGIC
# MAGIC duplicate_pmt_id_sql = """
# MAGIC SELECT pmt_id, COUNT(*) as cnt
# MAGIC FROM CA7Covterm_CA7ExtendedCovForVolunteers_data
# MAGIC GROUP BY pmt_id
# MAGIC HAVING COUNT(*) > 1
# MAGIC """
# MAGIC
# MAGIC invalid_refs = spark.sql(invalid_refs_sql)
# MAGIC null_pmt_id_count = spark.sql(null_pmt_id_sql).collect()[0]['null_count']
# MAGIC duplicate_pmt_ids = spark.sql(duplicate_pmt_id_sql)
# MAGIC
# MAGIC if invalid_refs.count() == 0 and null_pmt_id_count == 0 and duplicate_pmt_ids.count() == 0:
# MAGIC     CA7Covterm_CA7ExtendedCovForVolunteers_data.write.jdbc(url=jdbc_url_pmtin, table='covterm', mode='append', properties=properties)
# MAGIC     #print('No issues found in CA7Covterm_CA7ExtendedCovForVolunteers_data')
# MAGIC else:
# MAGIC     if invalid_refs.count() > 0:
# MAGIC         logger.error("Referential integrity issue: Some pmt_parent values do not exist in ca7noacov_CA7NonOwnedAutoLiabExtendedVolunteersNOA_data.")
# MAGIC         for row in invalid_refs.collect():
# MAGIC             logger.error(f"Invalid pmt_parent: {row.pmt_parent}")
# MAGIC     if null_pmt_id_count > 0:
# MAGIC         logger.error(f"Null pmt_id values found in CA7Covterm_CA7ExtendedCovForVolunteers_data: {null_pmt_id_count}")
# MAGIC     if duplicate_pmt_ids.count() > 0:
# MAGIC         logger.error("Duplicate pmt_id values found in CA7Covterm_CA7ExtendedCovForVolunteers_data.")
# MAGIC         for row in duplicate_pmt_ids.collect():
# MAGIC             logger.error(f"Duplicate pmt_id: {row.pmt_id} with count: {row.cnt}")

# COMMAND ----------

# MAGIC %skip
# MAGIC #CA7Limit32
# MAGIC CA7Covterm_CA7Limit32_query = '''
# MAGIC SELECT DISTINCT
# MAGIC     concat('CA7NonOwnedAutoLiabNOA:',trim(PolicyNumber),'-','CA7Limit32','-',trim(StateCode)) AS pmt_id,
# MAGIC    concat('CA7noaCov:',trim(PolicyNumber),'-',"CA7NonOwnedAutoMedPayNOA",'-',trim(StateCode)) AS pmt_parent,
# MAGIC     'CA7NOACov' AS pmt_parent_type,
# MAGIC     'CA7Limit32' AS codeidentifier,
# MAGIC     case when trim(MedPayLimit) is null then 'NoCoverage' else trim(MedPayLimit) end as value,
# MAGIC    
# MAGIC     trim(PolicyNumber) AS pmt_payloadid
# MAGIC FROM ca7noacov_df
# MAGIC '''
# MAGIC try:
# MAGIC   CA7Covterm_CA7Limit32_data = spark.sql(CA7Covterm_CA7Limit32_query)
# MAGIC   CA7Covterm_CA7Limit32_data.createOrReplaceTempView("CA7Covterm_CA7Limit32_data")
# MAGIC   print(CA7Covterm_CA7Limit32_data.count())
# MAGIC   display(CA7Covterm_CA7Limit32_data)
# MAGIC except Exception as e:
# MAGIC   logger.info("error loading CA7Covterm_CA7Limit32_data: {}".format(e)) 
# MAGIC   sys.exit(1)

# COMMAND ----------

# MAGIC %skip
# MAGIC # SQL to find mismatching pmt_parent, count null pmt_id, and check for duplicates for CA7Covterm_CA7Limit32_data
# MAGIC invalid_refs_sql = """
# MAGIC SELECT DISTINCT pmt_parent
# MAGIC FROM CA7Covterm_CA7Limit32_data
# MAGIC WHERE pmt_parent NOT IN (
# MAGIC   SELECT DISTINCT pmt_id FROM ca7noacov_CA7NonOwnedAutoMedPayNOA_data
# MAGIC )
# MAGIC """
# MAGIC
# MAGIC null_pmt_id_sql = """
# MAGIC SELECT COUNT(*) as null_count
# MAGIC FROM CA7Covterm_CA7Limit32_data
# MAGIC WHERE pmt_id IS NULL
# MAGIC """
# MAGIC
# MAGIC duplicate_pmt_id_sql = """
# MAGIC SELECT pmt_id, COUNT(*) as cnt
# MAGIC FROM CA7Covterm_CA7Limit32_data
# MAGIC GROUP BY pmt_id
# MAGIC HAVING COUNT(*) > 1
# MAGIC """
# MAGIC
# MAGIC invalid_refs = spark.sql(invalid_refs_sql)
# MAGIC null_pmt_id_count = spark.sql(null_pmt_id_sql).collect()[0]['null_count']
# MAGIC duplicate_pmt_ids = spark.sql(duplicate_pmt_id_sql)
# MAGIC
# MAGIC if invalid_refs.count() == 0 and null_pmt_id_count == 0 and duplicate_pmt_ids.count() == 0:
# MAGIC     CA7Covterm_CA7Limit32_data.write.jdbc(url=jdbc_url_pmtin, table='covterm', mode='append', properties=properties)
# MAGIC     #print('No issues found in CA7Covterm_CA7Limit32_data')
# MAGIC else:
# MAGIC     if invalid_refs.count() > 0:
# MAGIC         logger.error("Referential integrity issue: Some pmt_parent values do not exist in ca7noacov_CA7NonOwnedAutoMedPayNOA_data.")
# MAGIC         for row in invalid_refs.collect():
# MAGIC             logger.error(f"Invalid pmt_parent: {row.pmt_parent}")
# MAGIC     if null_pmt_id_count > 0:
# MAGIC         logger.error(f"Null pmt_id values found in CA7Covterm_CA7Limit32_data: {null_pmt_id_count}")
# MAGIC     if duplicate_pmt_ids.count() > 0:
# MAGIC         logger.error("Duplicate pmt_id values found in CA7Covterm_CA7Limit32_data.")
# MAGIC         for row in duplicate_pmt_ids.collect():
# MAGIC             logger.error(f"Duplicate pmt_id: {row.pmt_id} with count: {row.cnt}")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Non-Owned Auto Additional Coverages

# COMMAND ----------

# DBTITLE 1,Transformation of CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA for CA7NOACov table
CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_query = '''
SELECT DISTINCT
    concat('CA7noaCov:',trim(PolicyNumber),'-',"CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA",'-',trim(StateCode)) AS pmt_id,
    concat('CA7NOA:',trim(PolicyNumber),'-',trim(StateCode)) AS pmt_parent,
    'CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA' AS CodeIdentifier,
    'usd' AS currency,
    trim(PolicyNumber) AS pmt_payloadid
FROM ca7noacov_df
WHERE trim(ExtendedCoverageForVolunteers) = 'Y'
'''

log_info_to_file("[START] Transformation for CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data...")
logger.info("[START] Transformation for CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data...")
try:
    logger.info(f"CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_query: {CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_query}")
    log_info_to_file(f"CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_query: {CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_query}")
    CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data = spark.sql(CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_query)
    CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data.createOrReplaceTempView("CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data")
    row_count = CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data.count()
    logger.info(f"CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data loaded with {row_count} rows.")
    log_info_to_file(f"CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data loaded with {row_count} rows.")
    logger.info(f"CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data schema: {CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data.schema}")
    log_info_to_file(f"CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data schema: {CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data.schema}")
    logger.info("[END] Transformation for CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data.")
    log_info_to_file("[END] Transformation for CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data.")
    display(CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data)
except Exception as e:
    logger.error(f"error loading CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data: {e}", exc_info=True)
    log_info_to_file(f"error loading CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------

logger.info("Starting validation for CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data...")
validation_result = validate_data(data_name="CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data", parent_table="ca7noa")

if validation_result is None:
    validation_result = {
        "status": False,
        "errors": [{"type": "internal_error", "details": "Validation function returned None."}],
        "warnings": []
    }

if validation_result["status"]:
    logger.info("Validation passed for CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data.")
    try:
        row_count = CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data.count()
        logger.info(f"[START] Writing {row_count} rows to table 'ca7noacov' in PMTIN.")
        log_info_to_file(f"[START] Writing {row_count} rows to table 'ca7noacov' in PMTIN.")
        logger.info(f"CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data schema: {CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data.schema}")
        log_info_to_file(f"CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data schema: {CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data.schema}")
        write_and_log_pmtin(
            df=CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data,
            table_name="ca7noacov",
            job_id=job_id,
            job_run_id=job_run_id,
            notebook_name=notebook_name,
            truncate=False
        )
        logger.info("[END] Successfully wrote CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data to table 'ca7noacov'.")
        log_info_to_file("[END] Successfully wrote CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data to table 'ca7noacov'.")
    except Exception as e:
        logger.error(f"Error writing CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data to table 'ca7noacov'", exc_info=True)
        log_info_to_file(f"Error writing CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data to table 'ca7noacov': {str(e)}")
        log_dataload_event(
            job_id=job_id,
            job_run_id=job_run_id,
            notebook_name=notebook_name,
            log_message=f"Error writing CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data to table: {str(e)}"
        )
        sys.exit(1)
else:
    logger.error("Validation failed for CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data.")
    error_messages = []
    for error in validation_result["errors"]:
        error_message = f"Validation Error: {error['type']} - {error.get('details', '')}"
        logger.error(error_message)
        log_info_to_file(error_message)
        error_messages.append(error_message)
    full_error_message = "; ".join(error_messages)
    log_dataload_event(
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name,
        log_message=f"Validation failed for CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data: {full_error_message}"
    )
    raise ValueError(
        f"Validation failed for CA7NOACov_CA7NonOwnedAutoNonOwnershipLiabCovForVolunteersNOA_data. Validation errors logged: {full_error_message}."
    )

# COMMAND ----------

