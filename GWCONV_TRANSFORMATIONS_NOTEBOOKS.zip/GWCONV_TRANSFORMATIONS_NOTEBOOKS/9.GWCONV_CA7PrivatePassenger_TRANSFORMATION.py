# Databricks notebook source
import logging
import sys
import os

LOG_FILE = 'etl_logfile.log'
LOG_FORMAT = '%(asctime)s %(levelname)s: %(message)s'

def get_etl_logger(name):
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    if logger.hasHandlers():
        logger.handlers.clear()
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.INFO)
    formatter = logging.Formatter(LOG_FORMAT)
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)
    file_handler = logging.FileHandler(LOG_FILE, mode='a')
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    return logger

logger = get_etl_logger('ca7noa_data')
logger.info(f"Logging initialized. Log file location: {os.path.abspath(LOG_FILE)}")

def log_info_to_file(message):
    with open(LOG_FILE, 'a') as f:
        import datetime
        timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        f.write(f"{timestamp} INFO: {message}\n")

# COMMAND ----------

# Cell Purpose: Set up Databricks widgets and retrieve job context for tracking ETL runs.
# Business Context: Enables parameterization and job tracking for the ETL pipeline, supporting both interactive and scheduled job runs in Databricks.
"""
This cell creates widgets for job_id and job_run_id, retrieves the current notebook context, and extracts job and run IDs for logging and audit purposes.
"""
# Create widgets for job_id and job_run_id for parameterization and job tracking
# These widgets allow passing parameters when running as a Databricks job
# The job_id is used to identify the specific job, while job_run_id is used to track the execution of that job.

dbutils.widgets.text("job_id", "")
dbutils.widgets.text("job_run_id", "")

# Get the current notebook context for extracting job and run metadata
# This context provides information about the job execution environment, including job IDs and notebook path.
context = dbutils.notebook.entry_point.getDbutils().notebook().getContext()

# Extract jobId and jobRunId objects from context (may be Option types)
# These IDs are crucial for tracking the execution of the ETL process.
job_id_obj = context.jobId()          # Option type: may or may not be defined
job_run_id_obj = context.jobRunId()   # Option type: may or may not be defined

# Retrieve the full path to the current notebook for logging purposes
notebook_path = context.notebookPath().get() # Full path to the current notebook
# Extract the notebook name from the path for easier identification in logs
notebook_name = notebook_path.split('/')[-1]   # Extract the notebook name from the path

def safe_get_option(option_obj):
    """
    Safely extract a value from a Databricks Option object.
    Parameters:
        option_obj: Option (Databricks Java/Scala Option type)
            The object to extract the value from.
    Returns:
        value or None: The value if defined, else None.
    Exceptions:
        Catches all exceptions to avoid breaking job context extraction.
        This ensures that even if an error occurs, the job can continue running without interruption.
    """
    try:
        if option_obj.isDefined():
            return option_obj.get()  # Return the value if defined
        else:
            return None  # Return None if not defined
    except Exception:
        return None  # Return None in case of any exception

# Use the safe_get_option to retrieve the values, defaulting to 'Manual' if not found
# This provides a fallback mechanism for logging and auditing purposes.
job_id = safe_get_option(job_id_obj) or "Manual"    # Used for logging and audit
job_run_id = safe_get_option(job_run_id_obj) or "Manual"

# Output the retrieved IDs for debugging and traceability
# This print statement helps in verifying that the correct IDs are being used in the ETL process.
print(f"Job ID: {job_id}, Job Run ID: {job_run_id}")

# Redefine widgets with resolved values for downstream cells (ensures consistency)
# This step ensures that the widgets reflect the actual job and run IDs for any subsequent operations.
dbutils.widgets.text("job_id", str(job_id)) 
dbutils.widgets.text("job_run_id", str(job_run_id))

# COMMAND ----------

# DBTITLE 1,Run the configuration Notebook
# MAGIC %run ../configuration/configs

# COMMAND ----------

# DBTITLE 1,Run the configuration Notebook
# MAGIC %run ../configuration/postgres

# COMMAND ----------

# DBTITLE 1,ETL query for Vehicle Data
log_info_to_file("[START] Extraction for Vehicle_data...")
logger.info("[START] Extraction for Vehicle_data...")
try:
    Vehicle_query = fetch_query_from_table('ca7privatepassenger')
    logger.info(f"Vehicle_query: {Vehicle_query}")
    log_info_to_file(f"Vehicle_query: {Vehicle_query}")
    Vehicle_data = eval(exec_select_landing)(Vehicle_query)
    Vehicle_data.createOrReplaceTempView("Vehicle_data")
    row_count = Vehicle_data.count()
    logger.info(f"Vehicle_data loaded with {row_count} rows.")
    log_info_to_file(f"Vehicle_data loaded with {row_count} rows.")
    logger.info(f"Vehicle_data schema: {Vehicle_data.schema}")
    log_info_to_file(f"Vehicle_data schema: {Vehicle_data.schema}")
    display(Vehicle_data)
    logger.info("[END] Extraction for Vehicle_data.")
    log_info_to_file("[END] Extraction for Vehicle_data.")
except Exception as e:
    logger.error(f"Error loading Vehicle_data: {e}", exc_info=True)
    log_info_to_file(f"Error loading Vehicle_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Transformation of CA7PrivatePassenger Data
# Create a new DataFrame for the CA7PrivatePassenger schema

log_info_to_file("[START] Transformation for CA7PrivatePassenger_final...")
logger.info("[START] Transformation for CA7PrivatePassenger_final...")
CA7PrivatePassenger_final = """
        SELECT DISTINCT
           trim(concat("CA7PPT_", trim(PolicyNumber),"_", trim(VIN))) AS pmt_id,
           trim(concat("CA7CAL_", trim(PolicyNumber))) AS pmt_parent,
           trim(StateCode) AS registrationstate_ext,
           trim(CustomerVehId) AS agentvehiclenumber_ext,
           trim(VIN) AS vin,
           trim(Make) AS make,
           trim(model) AS model,
           CAST(trim(Year) AS INTEGER) AS Year,
           CAST(trim(OriginalCostNew) AS INTEGER) AS originalcostnew,
           CAST(trim(StatedAmount) AS INTEGER) AS statedamount,
           substr(trim(ClassCd), 0, 4) AS classcode,
           trim(FleetCode) AS fleet,
           trim(VehicleType) AS type,
          trim(GaragingLocation) AS GaragingLocation,
           CASE WHEN RideSharingTypeCode='4' THEN 'Used as both Transportation Network Company and On-Demand' 
                ELSE 'Not used as Transportation Network Company Or On-Demand Capacity' END AS usedastncorondemand,
           'No' AS autohackingexpensecoverage,
           'No' AS RansomCoverage,
           'usd' AS preferredcoveragecurrency,
           'usd' AS preferredsettlementcurrency,
           trim(TerritoryCode) AS territory,
           CAST(trim(VehicleNumber) AS INTEGER) AS vehiclenumber,
           trim(ZipCode) AS zipcode,
           concat("PL:" , trim(PolicyNumber)) AS location,
           trim(policynumber) AS pmt_payloadid ,  
          CASE WHEN vehicleNumber = 1 then 'Y' ELSE 'N' END AS firstauto,   

          'NO' AS replacementcostcoverage,
           CAST('No' AS STRING) AS usedtocarryfreightandmerchandise,
           CAST('No' AS STRING) AS transportationofemployees ,
           CAST('No' AS STRING) AS stateownedvehicle,
           CAST('No' AS STRING) AS safetyscorediscountapplies,
           CAST('No' AS STRING) AS ownedbythegovernmentstateorpoliticalsubdivision,
           CAST('No' AS STRING) AS greenzonediscountapplies,
           CAST('No' AS STRING) AS firstoradditionalauto,

          CAST('No' AS STRING) AS defensivedrivingcoursecredit,
          CAST('No Safety features' AS STRING) AS safetyfeatures,
          CAST('None' AS STRING) AS antitheftdevicediscount,
          CAST('No' AS STRING) AS accidentpreventionrefresherdiscount,
         CAST('Yes' AS STRING) AS equippedwithautomaticoccupantrestraint,
         
          CAST('No' AS STRING) AS auxillaryrunninglampsdiscount,

          CASE  WHEN MatureDriverDt IS NOT NULL AND TRIM(MatureDriverDt) != '' THEN 'Yes' ELSE 'No'
          END AS maturedriverimprovementcoursediscount,
          CASE WHEN  GrossVehicleWeight > 10000 THEN 'Yes' ELSE 'No'
          END AS GrossVehicleWeightOver10000
          
    FROM Vehicle_data
"""
try:
    CA7PrivatePassenger_final = spark.sql(CA7PrivatePassenger_final)
    CA7PrivatePassenger_final.createOrReplaceTempView("CA7PrivatePassenger_final")
    row_count = CA7PrivatePassenger_final.count()
    logger.info(f"CA7PrivatePassenger_final loaded with {row_count} rows.")
    log_info_to_file(f"CA7PrivatePassenger_final loaded with {row_count} rows.")
    logger.info(f"CA7PrivatePassenger_final schema: {CA7PrivatePassenger_final.schema}")
    log_info_to_file(f"CA7PrivatePassenger_final schema: {CA7PrivatePassenger_final.schema}")
    display(CA7PrivatePassenger_final)
    logger.info("[END] Transformation for CA7PrivatePassenger_final.")
    log_info_to_file("[END] Transformation for CA7PrivatePassenger_final.")
except Exception as e:
    logger.error(f"Error loading CA7PrivatePassenger_final: {e}", exc_info=True)
    log_info_to_file(f"Error loading CA7PrivatePassenger_final: {str(e)}")
    sys.exit(1)

# COMMAND ----------

log_info_to_file("[START] Extraction for location_basic...")
logger.info("[START] Extraction for location_basic...")
location_query = """select * from account_location"""
try:
    logger.info(f"Executing query: {location_query}")
    log_info_to_file(f"Executing query: {location_query}")
    
    location_basic = eval(exec_select_framework)(location_query)
    location_basic.createOrReplaceTempView("location_basic")
    
    row_count = location_basic.count()
    logger.info(f"location_basic loaded with {row_count} rows.")
    log_info_to_file(f"location_basic loaded with {row_count} rows.")
    
    logger.info(f"location_basic schema: {location_basic.schema}")
    log_info_to_file(f"location_basic schema: {location_basic.schema}")
    
    display(location_basic)
    logger.info("[END] Extraction for location_basic.")
    log_info_to_file("[END] Extraction for location_basic.")
except Exception as e:
    logger.error(f"Error loading location_basic: {e}", exc_info=True)
    log_info_to_file(f"Error loading location_basic: {str(e)}")
    sys.exit(1)

# COMMAND ----------

log_info_to_file("[START] Transformation for vehical_final...")
logger.info("[START] Transformation for vehical_final...")
vehical_final = """
 select DISTINCT
a.pmt_id, 
a.pmt_parent, 
registrationstate_ext, 
agentvehiclenumber_ext, 
a.vin, 
make, 
model, 
Year, 
originalcostnew, 
statedamount, 
classcode, 
fleet, 
type, 
usedastncorondemand, 
autohackingexpensecoverage, 
preferredcoveragecurrency, 
preferredsettlementcurrency, 
territory, 
vehiclenumber, 
zipcode, 
case when trim(b.vin) is not null then concat("PL:",substring(b.pmt_id,9)) else null end as  location, 
a.pmt_payloadid, 
firstauto, 
replacementcostcoverage, 
usedtocarryfreightandmerchandise, 
transportationofemployees, 
stateownedvehicle, 
safetyscorediscountapplies, 
ownedbythegovernmentstateorpoliticalsubdivision, 
greenzonediscountapplies, 
firstoradditionalauto, 
defensivedrivingcoursecredit, 
safetyfeatures, 
antitheftdevicediscount, 
accidentpreventionrefresherdiscount, 
equippedwithautomaticoccupantrestraint, 
auxillaryrunninglampsdiscount, 
maturedriverimprovementcoursediscount, 
GrossVehicleWeightOver10000,
RansomCoverage,
GaragingLocation
 from CA7PrivatePassenger_final a left outer join location_basic b on a.pmt_payloadid = b.pmt_payloadid and  trim(a.vin) = trim(b.vin)"""
 
try:
    vehical_final = spark.sql(vehical_final)
    vehical_final.createOrReplaceTempView("vehical_final")
    row_count = vehical_final.count()
    logger.info(f"vehical_final loaded with {row_count} rows.")
    log_info_to_file(f"vehical_final loaded with {row_count} rows.")
    logger.info(f"vehical_final schema: {vehical_final.schema}")
    log_info_to_file(f"vehical_final schema: {vehical_final.schema}")
    display(vehical_final)
    logger.info("[END] Transformation for vehical_final.")
    log_info_to_file("[END] Transformation for vehical_final.")
except Exception as e:
    logger.error(f"Error loading vehical_final: {e}", exc_info=True)
    log_info_to_file(f"Error loading vehical_final: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Writing table to PMTIN
try:
    row_count = vehical_final.count()
    logger.info(f"[START] Writing {row_count} rows to table 'ca7noa' in PMTIN.")
    log_info_to_file(f"[START] Writing {row_count} rows to table 'ca7noa' in PMTIN.")
    logger.info(f"CA7NOA_final schema: {vehical_final.schema}")
    log_info_to_file(f"CA7NOA_final schema: {vehical_final.schema}")
    write_and_log_pmtin(
        vehical_final,
        table_name="ca7privatepassenger",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
    )
    logger.info("[END] Successfully wrote vehical_final to table 'ca7privatepassenger'.")
    log_info_to_file("[END] Successfully wrote vehical_final to table 'ca7privatepassenger'.")
except Exception as e:
    logger.error(f"Error writing vehicle_final to table 'ca7privatepassenger'", exc_info=True)
    log_info_to_file(f"Error writing vehicle_final to table 'ca7privatepassenger': {str(e)}")
    sys.exit(1)

# COMMAND ----------

