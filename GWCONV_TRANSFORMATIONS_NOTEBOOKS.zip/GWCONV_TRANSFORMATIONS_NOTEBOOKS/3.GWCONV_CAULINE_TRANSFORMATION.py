# Databricks notebook source
# Cell 1: Initialize Logging
"""
- Introduced more granular log levels (e.g., `logger.error`, `logger.debug`).
- Logs are written to both the notebook console and to 'etl_logfile.log' in append mode.
"""
import logging
import sys

logger = logging.getLogger('CA7CommAutoLine')
logger.setLevel(logging.INFO)  # Keep as INFO for general logs; use DEBUG for debugging

# Remove all handlers if already set (to avoid duplicate logs in notebook reruns)
if logger.hasHandlers():
    logger.handlers.clear()

# Console handler
handler = logging.StreamHandler()
handler.setLevel(logging.DEBUG)  # Allow for detailed debugging at runtime
formatter = logging.Formatter('%(asctime)s %(levelname)s: %(message)s')  # Add consistent logging format
handler.setFormatter(formatter)
logger.addHandler(handler)

# File handler in append mode
log_file_handler = logging.FileHandler('etl_logfile.log', mode='a')
log_file_handler.setLevel(logging.INFO)
log_file_handler.setFormatter(formatter)
logger.addHandler(log_file_handler)

logger.info("Logging initialized in append mode. All log levels will be written to etl_logfile.log.")

# Function to log info messages to file
def log_info_to_file(message):
    logger.info(message)

# COMMAND ----------

# DBTITLE 1,Setup Job Context and Widgets

# Create widgets for job_id and job_run_id
dbutils.widgets.text("job_id", "")
dbutils.widgets.text("job_run_id", "")


# Get the current notebook context
context = dbutils.notebook.entry_point.getDbutils().notebook().getContext()



# Get the current notebook context
context = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
job_id_obj = context.jobId()          # Fetch jobId
job_run_id_obj = context.jobRunId()   # Fetch jobRunId

notebook_path = context.notebookPath().get() # Fetch the notebook path


notebook_name = notebook_path.split('/')[-1]   # Extract the notebook name from the path

def safe_get_option(option_obj):
    try:
        if option_obj.isDefined():
            return option_obj.get()
        else:
            return None
    except Exception:
        return None

# Use the safe_get_option to retrieve the values
job_id = safe_get_option(job_id_obj) or "Manual"    # Default to "Manual" if not found
job_run_id = safe_get_option(job_run_id_obj) or "Manual"

# Output the retrieved IDs
print(f"Job ID: {job_id}, Job Run ID: {job_run_id}")

# Define widgets for job_id and job_run_id
dbutils.widgets.text("job_id", str(job_id)) 
dbutils.widgets.text("job_run_id", str(job_run_id))

# COMMAND ----------

# DBTITLE 1,Run the Configuration
# MAGIC %run ../configuration/configs

# COMMAND ----------

# DBTITLE 1,Run the Configuration
# MAGIC %run ../configuration/postgres

# COMMAND ----------

# DBTITLE 1,ETL query for Policy Basic




try:
  policy_query=fetch_query_from_table("ca7commautoline")
  policy_basic=eval(exec_select_landing)(policy_query)
  display(policy_basic)
  policy_basic.createOrReplaceTempView("policy_basic")
  row_count = policy_basic.count()
  logger.info(f"policy_basic loaded with {row_count} rows")
  
except Exception as e:
  logger.info("error loading policy_basic: {}".format(e)) 
  sys.exit(1) 

# COMMAND ----------

# DBTITLE 1,Typelist query

typelist_query="""
SELECT *
FROM typelist"""
try:
  typelist=eval(exec_select_framework)(typelist_query)
  typelist.createOrReplaceTempView("typelist")
  display(typelist)
except Exception as e:
  logger.info("error loading typelist: {}".format(e)) 
  sys.exit(1) 

# COMMAND ----------

# DBTITLE 1,Transformation for CAU_Line table
cau_line_final="""
select distinct concat('CA7CAL_',trim(policynumber)) as PMT_ID,
concat("PP:",trim(policynumber)) as PMT_Parent,
CAST('2024-08-01 00:00:00' AS TIMESTAMP) as ca7autosymbolsmanualeditdate,    --to handle PC UI render issue
'No' as CA7LineExperienceRatingModificationApplies,
'No' as CA7LineGrossReceiptsRatingBasis,
b.name as  CA7LineLegalEntity,
trim(IndustryCode) as CA7LineNAICSCode,
--CA7LineNAICSDefinition,
'No' as CA7LineNamedInsuredIndividual,
case when LOB = 'AU' Then 'Business Auto Coverage Form'
when LOB = 'GR' Then 'Auto Dealers Coverage Form'
when LOB = 'TU' Then 'Motor Carrier Coverage Form'
Else 'Reject' end as  CA7LinePolicyType,
'Not Applicable' as CA7LineRideSharingEndorsementIndicator,
CASE WHEN trim(State) IN ('CA','HI','MA') THEN 'No' ELSE 'Yes' END AS ca7lineoptionalclassplan,
'No' as CA7LineTerrorismCoverage,
'usd' as PreferredCoverageCurrency,
'usd' as PreferredSettlementCurrency,
'CA7Line' as patterncode,
CASE WHEN PIPSymbolLst is null then 'No' Else 'Yes' end as ca7lineaddedpersonalinjuryprotection,
trim(policynumber) as PMT_PayloadId
from  policy_basic a
left outer join (select * from typelist where typelist = 'AccountOrgType') b on a.BusTypeCd = b.codevalue"""

try:
  cau_line_final=spark.sql(cau_line_final)
  cau_line_final.createOrReplaceTempView("cau_line_final")
  display(cau_line_final)
  logger.info(f"policy_basic loaded with {cau_line_final.count()} rows")
except Exception as e:
  logger.info("error loading cau_line_final: {}".format(e)) 
  sys.exit(1) 

# COMMAND ----------

# DBTITLE 1,Write table in PMTIN
try:
        write_and_log_pmtin(
            cau_line_final,
            table_name="ca7commautoline",
            job_id=job_id,
            job_run_id=job_run_id,
            notebook_name=notebook_name
       
        )
        logger.info("Successfully wrote Account_Holder_Locations to table 'ca7commautoline'.")
except Exception as e:
        logger.error(f"Error writing Account_Holder_Locations to table 'commautoline'", exc_info=True)
        sys.exit(1)

# COMMAND ----------

