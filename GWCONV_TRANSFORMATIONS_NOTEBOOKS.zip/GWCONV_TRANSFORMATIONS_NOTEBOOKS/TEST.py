# Databricks notebook source
account_df = spark.read.format('jdbc').options(
    url='jdbc:postgresql://psql-gwconv-data-dev-eus-001.postgres.database.azure.com:5432/PMTIN',
    dbtable='account',
    user='pgsqldevsa',
    password='PqSQ1#$19272H!',
    driver='org.postgresql.Driver'
).load()
account_df.createOrReplaceTempView("account_df")
display(account_df)

# COMMAND ----------

account_df.write.format('jdbc').options(
    url='jdbc:postgresql://psql-gwconv-data-dev-eus-01.postgres.database.azure.com:5432/PMT_IN_local',
    dbtable='account',
    user='pgsqldevuser',
    password='PqSQ1#$19272H!',
    driver='org.postgresql.Driver'
).mode('append').save()