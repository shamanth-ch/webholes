# Databricks notebook source
import logging
import sys
import os

LOG_FILE = 'etl_logfile.log'
LOG_FORMAT = '%(asctime)s %(levelname)s: %(message)s'

def get_etl_logger(name):
    logger = logging.getLogger(name)
    
    logger.setLevel(logging.INFO)
    if logger.hasHandlers():
        logger.handlers.clear()
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.INFO)
    formatter = logging.Formatter(LOG_FORMAT)
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)
    file_handler = logging.FileHandler(LOG_FILE, mode='a')
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    return logger

logger = get_etl_logger('ca7commautolinecov')
logger.info(f"Logging initialized. Log file location: {os.path.abspath(LOG_FILE)}")

def log_info_to_file(message):
    with open(LOG_FILE, 'a') as f:
        import datetime
        timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        f.write(f"{timestamp} INFO: {message}\n")

# COMMAND ----------

# Cell Purpose: Set up Databricks widgets and retrieve job context for tracking ETL runs.
# Business Context: Enables parameterization and job tracking for the ETL pipeline, supporting both interactive and scheduled job runs in Databricks.
"""
This cell creates widgets for job_id and job_run_id, retrieves the current notebook context, and extracts job and run IDs for logging and audit purposes.
"""
# Create widgets for job_id and job_run_id for parameterization and job tracking
# These widgets allow passing parameters when running as a Databricks job
# The job_id is used to identify the specific job, while job_run_id is used to track the execution of that job.

dbutils.widgets.text("job_id", "")
dbutils.widgets.text("job_run_id", "")

# Get the current notebook context for extracting job and run metadata
# This context provides information about the job execution environment, including job IDs and notebook path.
context = dbutils.notebook.entry_point.getDbutils().notebook().getContext()

# Extract jobId and jobRunId objects from context (may be Option types)
# These IDs are crucial for tracking the execution of the ETL process.
job_id_obj = context.jobId()          # Option type: may or may not be defined
job_run_id_obj = context.jobRunId()   # Option type: may or may not be defined

# Retrieve the full path to the current notebook for logging purposes
notebook_path = context.notebookPath().get() # Full path to the current notebook
# Extract the notebook name from the path for easier identification in logs
notebook_name = notebook_path.split('/')[-1]   # Extract the notebook name from the path

def safe_get_option(option_obj):
    """
    Safely extract a value from a Databricks Option object.
    Parameters:
        option_obj: Option (Databricks Java/Scala Option type)
            The object to extract the value from.
    Returns:
        value or None: The value if defined, else None.
    Exceptions:
        Catches all exceptions to avoid breaking job context extraction.
        This ensures that even if an error occurs, the job can continue running without interruption.
    """
    try:
        if option_obj.isDefined():
            return option_obj.get()  # Return the value if defined
        else:
            return None  # Return None if not defined
    except Exception:
        return None  # Return None in case of any exception

# Use the safe_get_option to retrieve the values, defaulting to 'Manual' if not found
# This provides a fallback mechanism for logging and auditing purposes.
job_id = safe_get_option(job_id_obj) or "Manual"    # Used for logging and audit
job_run_id = safe_get_option(job_run_id_obj) or "Manual"

# Output the retrieved IDs for debugging and traceability
# This print statement helps in verifying that the correct IDs are being used in the ETL process.
print(f"Job ID: {job_id}, Job Run ID: {job_run_id}")

# Redefine widgets with resolved values for downstream cells (ensures consistency)
# This step ensures that the widgets reflect the actual job and run IDs for any subsequent operations.
dbutils.widgets.text("job_id", str(job_id)) 
dbutils.widgets.text("job_run_id", str(job_run_id))

# COMMAND ----------

# DBTITLE 1,Configuration
# MAGIC
# MAGIC %run ../configuration/configs
# MAGIC

# COMMAND ----------

# DBTITLE 1,Configuration
# MAGIC %run ../configuration/postgres

# COMMAND ----------

# MAGIC %md
# MAGIC ##Additional ISO  Coverage

# COMMAND ----------

# DBTITLE 1,ETL query for additional_ISO_coverage
try:
    additional_ISO_Coverages_query = fetch_query_from_table("additional_iso_coverages2")
    logger.info("[START] Extraction for additional_ISO_Coverages_data...")
    log_info_to_file("[START] Extraction for additional_ISO_Coverages_data...")
    logger.info(f"additional_ISO_Coverages_query: {additional_ISO_Coverages_query}")
    log_info_to_file(f"additional_ISO_Coverages_query: {additional_ISO_Coverages_query}")
    additional_ISO_Coverages_data = eval(exec_select_landing)(additional_ISO_Coverages_query)
    additional_ISO_Coverages_data.createOrReplaceTempView("additional_ISO_Coverages_data")
    row_count = additional_ISO_Coverages_data.count()
    logger.info(f"additional_ISO_Coverages_data loaded with {row_count} rows.")
    log_info_to_file(f"additional_ISO_Coverages_data loaded with {row_count} rows.")
    logger.info(f"additional_ISO_Coverages_data schema: {additional_ISO_Coverages_data.schema}")
    log_info_to_file(f"additional_ISO_Coverages_data schema: {additional_ISO_Coverages_data.schema}")
    logger.info("[END] Extraction for additional_ISO_Coverages_data.")
    log_info_to_file("[END] Extraction for additional_ISO_Coverages_data.")
    
except Exception as e:
    logger.error(f"Error loading additional_ISO_Coverages_data: {e}", exc_info=True)
    log_info_to_file(f"Error loading additional_ISO_Coverages_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------

form_codeidentifier=eval(exec_select_framework)("select * from form_codeidentifier")
form_codeidentifier.createOrReplaceTempView("form_codeidentifier")

# COMMAND ----------

additional_iso_cov_trans_query = '''
    SELECT DISTINCT
        concat('CA7CommAutoLineCov:', trim(a.PolicyNumber), '_', b.codeidentifier) AS pmt_id,
        concat('CA7CAL_', trim(a.PolicyNumber)) AS pmt_parent,
        b.codeidentifier,
        'usd' AS Currency,
        a.dealerdrivewayindblanket,
        a.dealerdrivewaypricenew,
        a.dealerdrivewaymilage,
        a.dealerdrivewaydeductible,
        a.dealerdrivewaynumberofautos,
        a.dealerdrivewaynumberoftrips,
        max(a.employeebenefitsliabilityaggregatelimit) over (partition by trim(a.PolicyNumber)) as employeebenefitsliabilityaggregatelimit,
        max(a.pollutionminimumpremiumamount) over (partition by trim(a.PolicyNumber)) as pollutionminimumpremiumamount,
        trim(a.PolicyNumber) AS pmt_payloadid
    FROM additional_ISO_Coverages_data a
    INNER JOIN form_codeidentifier b ON trim(a.FormId) = b.pc_form_number
    WHERE b.codeidentifier IS NOT NULL
      AND trim(a.FormId) IN (
            'PCA 99 55','PCA 25 59','CA 23 30','CA 23 07 VA','CA 23 29 HI','CA 23 31 AK','CA 23 40 MN','CA 05 29 WA','CA 23 3',
            'CA 20 56','CA 20 09','CA 20 55','CA 20 70','CA 20 75 NY','CA 25 02','CA 99 17','CA 04 25 CA','CA 23 04',
            'CA 99 90','CA 04 28 VA','CA 25 48 VA','CA 26 32 NC','CA 27 01 MI','CA 25 48. (IL)','CA 25 68 MT','CA 25 70 CO',
            'CA 25 71 WY','CA 25 72 NH','CA 25 78 CT','CA 25 82 NM','CA 25 86 IL','CA 23 08'
        )
'''

log_info_to_file("[START] Transformation for additional_iso_cov_trans_data...")
logger.info("[START] Transformation for additional_iso_cov_trans_data...")
try:
    logger.info(f"additional_iso_cov_trans_query: {additional_iso_cov_trans_query}")
    log_info_to_file(f"additional_iso_cov_trans_query: {additional_iso_cov_trans_query}")
    additional_iso_cov_trans_data = spark.sql(additional_iso_cov_trans_query)
    additional_iso_cov_trans_data.createOrReplaceTempView("additional_iso_cov_trans_data")
    row_count = additional_iso_cov_trans_data.count()
    logger.info(f"additional_iso_cov_trans_data loaded with {row_count} rows.")
    log_info_to_file(f"additional_iso_cov_trans_data loaded with {row_count} rows.")
    logger.info(f"additional_iso_cov_trans_data schema: {additional_iso_cov_trans_data.schema}")
    log_info_to_file(f"additional_iso_cov_trans_data schema: {additional_iso_cov_trans_data.schema}")
    logger.info("[END] Transformation for additional_iso_cov_trans_data.")
    log_info_to_file("[END] Transformation for additional_iso_cov_trans_data.")
    display(additional_iso_cov_trans_data)
except Exception as e:
    logger.error(f"error loading additional_iso_cov_trans_data: {e}", exc_info=True)
    log_info_to_file(f"error loading additional_iso_cov_trans_data: {str(e)}")
    sys.exit(1)


# COMMAND ----------

additional_iso_cov_trans_query_final = '''
    SELECT DISTINCT
         pmt_id,
        pmt_parent,
        codeidentifier,
        Currency,
        pmt_payloadid
        from additional_iso_cov_trans_data'''
log_info_to_file("[START] Transformation for additional_iso_cov_trans_query_final...")
logger.info("[START] Transformation for additional_iso_cov_trans_query_final...")
try:
    logger.info(f"additional_iso_cov_trans_query_final: {additional_iso_cov_trans_query_final}")
    log_info_to_file(f"additional_iso_cov_trans_query_final: {additional_iso_cov_trans_query_final}")
    additional_iso_cov_trans_query_final = spark.sql(additional_iso_cov_trans_query_final)
    additional_iso_cov_trans_query_final.createOrReplaceTempView("additional_iso_cov_trans_query_final")
    row_count = additional_iso_cov_trans_query_final.count()
    logger.info(f"additional_iso_cov_trans_query_final loaded with {row_count} rows.")
    log_info_to_file(f"additional_iso_cov_trans_query_final loaded with {row_count} rows.")
    logger.info(f"additional_iso_cov_trans_query_final schema: {additional_iso_cov_trans_query_final.schema}")
    log_info_to_file(f"additional_iso_cov_trans_query_final schema: {additional_iso_cov_trans_query_final.schema}")
    logger.info("[END] Transformation for additional_iso_cov_trans_query_final.")
    log_info_to_file("[END] Transformation for additional_iso_cov_trans_query_final.")
    display(additional_iso_cov_trans_query_final)
except Exception as e:
    logger.info("error loading additional_iso_cov_trans_query_final: {}".format(e)) 
    log_info_to_file(f"error loading additional_iso_cov_trans_query_final: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Writing CA7HAUSchedCov in PMTIN
from pyspark.sql.functions import col, when

special_patterns = [
    'CA7FellowEmplCovForDesignatedEmplsPoss',
    'CA7CovForCertainOpsInConnectionWithRailroads',
    'CA7LeasingOrRentalConcernsContingent1'
]

try:
    # Insert rows with special patterncode into CA7CommAutoLineSchedCov
    special_df = additional_iso_cov_trans_query_final \
        .filter(col("codeidentifier").isin(special_patterns)) \
        .withColumnRenamed("codeidentifier", "patterncode")
    special_row_count = special_df.count()
    logger.info(f"[START] Writing {special_row_count} rows to table 'CA7CommAutoLineSchedCov' in PMTIN.")
    log_info_to_file(f"[START] Writing {special_row_count} rows to table 'CA7CommAutoLineSchedCov' in PMTIN.")
    logger.info(f"special_df schema: {special_df.schema}")
    log_info_to_file(f"special_df schema: {special_df.schema}")
    write_and_log_pmtin(
        df=special_df,
        table_name="CA7CommAutoLineSchedCov",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
    )
    logger.info("[END] Successfully wrote special_df to table 'CA7CommAutoLineSchedCov'.")
    log_info_to_file("[END] Successfully wrote special_df to table 'CA7CommAutoLineSchedCov'.")

    # Insert all other rows into CA7CommAutoLineCov
    other_df = additional_iso_cov_trans_query_final \
        .filter(~col("codeidentifier").isin(special_patterns))
    other_row_count = other_df.count()
    logger.info(f"[START] Writing {other_row_count} rows to table 'CA7CommAutoLineCov' in PMTIN.")
    log_info_to_file(f"[START] Writing {other_row_count} rows to table 'CA7CommAutoLineCov' in PMTIN.")
    logger.info(f"other_df schema: {other_df.schema}")
    log_info_to_file(f"other_df schema: {other_df.schema}")
    write_and_log_pmtin(
        df=other_df,
        table_name="CA7CommAutoLineCov",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
    )
    logger.info("[END] Successfully wrote other_df to table 'CA7CommAutoLineCov'.")
    log_info_to_file("[END] Successfully wrote other_df to table 'CA7CommAutoLineCov'.")
except Exception as e:
    logger.error("Error writing to CA7CommAutoLineSchedCov or CA7CommAutoLineCov", exc_info=True)
    log_info_to_file(f"Error writing to CA7CommAutoLineSchedCov or CA7CommAutoLineCov: {str(e)}")
    log_dataload_event(
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name,
        log_message=f"Error writing to CA7CommAutoLineSchedCov or CA7CommAutoLineCov: {str(e)}"
    )
    sys.exit(1)

# COMMAND ----------

additional_iso_cov_covterm = '''
select  concat(pmt_id,'-','CA7CollisionCovType15') as pmt_id,
pmt_id as PMT_Parent,
'CA7CommAutoLineCov' as PMT_Parent_Type,
'CA7CollisionCovType15' as CodeIdentifier,
CAST('StandardCollisionCoverage_IndividualCoverage' AS STRING) as Value,
pmt_payloadid as PMT_PayloadId
from additional_iso_cov_trans_data where codeidentifier = 'CA7DealersDriveAwayCollision'

union all

select  concat(pmt_id,'-','CA7Ded') as pmt_id,
pmt_id as PMT_Parent,
'CA7CommAutoLineCov' as PMT_Parent_Type,
'CA7Ded' as CodeIdentifier,
CAST(dealerdrivewaydeductible AS STRING) as Value,
pmt_payloadid as PMT_PayloadId
from additional_iso_cov_trans_data where codeidentifier = 'CA7DealersDriveAwayCollision'

union all

select  concat(pmt_id,'-','CA7Mileage') as pmt_id,
pmt_id as PMT_Parent,
'CA7CommAutoLineCov' as PMT_Parent_Type,
'CA7Mileage' as CodeIdentifier,
case when dealerdrivewaymilage < 501 then '0_500Miles'
     when dealerdrivewaymilage >= 501 and dealerdrivewaymilage < 1001 then '501_1000Miles'
     when dealerdrivewaymilage >= 1001 and dealerdrivewaymilage < 1501 then '1001_1500Miles'
     when dealerdrivewaymilage >= 1501 then 'Over1500Miles' end as Value,
pmt_payloadid as PMT_PayloadId
from additional_iso_cov_trans_data where codeidentifier = 'CA7DealersDriveAwayCollision'

union all

select  concat(pmt_id,'-','CA7PriceNew') as pmt_id,
pmt_id as PMT_Parent,
'CA7CommAutoLineCov' as PMT_Parent_Type,
'CA7PriceNew' as CodeIdentifier,
case when dealerdrivewaypricenew < 7501 then '0_7500'
     when dealerdrivewaypricenew >= 7501 and dealerdrivewaypricenew < 15001 then '7501_15000'
     when dealerdrivewaypricenew >= 15001 and dealerdrivewaypricenew < 25001 then '15001_25000'
     when dealerdrivewaypricenew >= 25001 and dealerdrivewaypricenew < 40001 then '25001_40000'
     when dealerdrivewaypricenew >= 40001 and dealerdrivewaypricenew <= 65000 then '40001_65000'
     when dealerdrivewaypricenew > 65000 then 'Over65000' end as Value,
pmt_payloadid as PMT_PayloadId
from additional_iso_cov_trans_data where codeidentifier = 'CA7DealersDriveAwayCollision'

union all

select  concat(pmt_id,'-','CA7Number') as pmt_id,
pmt_id as PMT_Parent,
'CA7CommAutoLineCov' as PMT_Parent_Type,
'CA7Number' as CodeIdentifier,
CAST(dealerdrivewaynumberoftrips AS STRING) as Value,
pmt_payloadid as PMT_PayloadId
from additional_iso_cov_trans_data where codeidentifier = 'CA7DealersDriveAwayCollision'

union all

select  concat(pmt_id,'-','CA7CovType40') as pmt_id,
pmt_id as PMT_Parent,
'CA7CommAutoLineCov' as PMT_Parent_Type,
'CA7CovType40' as CodeIdentifier,
'EmployeeBenefitsPrograms' as Value,
pmt_payloadid as PMT_PayloadId
from additional_iso_cov_trans_data where codeidentifier = 'CA7EmplBenefitsLiab'

union all

select  concat(pmt_id,'-','CA7Ded26') as pmt_id,
pmt_id as PMT_Parent,
'CA7CommAutoLineCov' as PMT_Parent_Type,
'CA7Ded26' as CodeIdentifier,
null as Value,
pmt_payloadid as PMT_PayloadId
from additional_iso_cov_trans_data where codeidentifier = 'CA7EmplBenefitsLiab'

union all

select  concat(pmt_id,'-','CA7AggLimit') as pmt_id,
pmt_id as PMT_Parent,
'CA7CommAutoLineCov' as PMT_Parent_Type,
'CA7AggLimit' as CodeIdentifier,
CAST(employeebenefitsliabilityaggregatelimit AS STRING) as Value,
pmt_payloadid as PMT_PayloadId
from additional_iso_cov_trans_data where codeidentifier = 'CA7EmplBenefitsLiab'

union all

select  concat(pmt_id,'-','CA7ManualPremium11') as pmt_id,
pmt_id as PMT_Parent,
'CA7CommAutoLineCov' as PMT_Parent_Type,
'CA7ManualPremium11' as CodeIdentifier,
null as Value,
pmt_payloadid as PMT_PayloadId
from additional_iso_cov_trans_data where codeidentifier = 'CA7EmplBenefitsLiab'

union all

select  concat(pmt_id,'-','CA7RetroactiveDate2') as pmt_id,
pmt_id as PMT_Parent,
'CA7CommAutoLineCov' as PMT_Parent_Type,
'CA7RetroactiveDate2' as CodeIdentifier,
null as Value,
pmt_payloadid as PMT_PayloadId
from additional_iso_cov_trans_data where codeidentifier = 'CA7EmplBenefitsLiab'

union all

select  concat(pmt_id,'-','CA7ManualPremium8') as pmt_id,
pmt_id as PMT_Parent,
'CA7CommAutoLineCov' as PMT_Parent_Type,
'CA7ManualPremium8' as CodeIdentifier,
CAST(pollutionminimumpremiumamount AS STRING) as Value,
pmt_payloadid as PMT_PayloadId
from additional_iso_cov_trans_data where codeidentifier = 'CA7PollutionLiabBroadCovForCovrdAutosGarageCovForm'
'''

log_info_to_file("[START] Transformation for additional_iso_cov_covterm...")
logger.info("[START] Transformation for additional_iso_cov_covterm...")
try:
    logger.info(f"additional_iso_cov_covterm query: {additional_iso_cov_covterm}")
    log_info_to_file(f"additional_iso_cov_covterm query: {additional_iso_cov_covterm}")
    additional_iso_cov_covterm = spark.sql(additional_iso_cov_covterm)
    additional_iso_cov_covterm.createOrReplaceTempView("additional_iso_cov_covterm")
    row_count = additional_iso_cov_covterm.count()
    logger.info(f"additional_iso_cov_covterm loaded with {row_count} rows.")
    log_info_to_file(f"additional_iso_cov_covterm loaded with {row_count} rows.")
    logger.info(f"additional_iso_cov_covterm schema: {additional_iso_cov_covterm.schema}")
    log_info_to_file(f"additional_iso_cov_covterm schema: {additional_iso_cov_covterm.schema}")
    logger.info("[END] Transformation for additional_iso_cov_covterm.")
    log_info_to_file("[END] Transformation for additional_iso_cov_covterm.")
    
except Exception as e:
    logger.info("error loading additional_iso_cov_covterm: {}".format(e)) 
    log_info_to_file(f"error loading additional_iso_cov_covterm: {str(e)}")
    sys.exit(1)

# COMMAND ----------

try:
    row_count = additional_iso_cov_covterm.count()
    logger.info(f"[START] Writing {row_count} rows to table 'covterm' in PMTIN.")
    log_info_to_file(f"[START] Writing {row_count} rows to table 'covterm' in PMTIN.")
    logger.info(f"additional_iso_cov_covterm schema: {additional_iso_cov_covterm.schema}")
    log_info_to_file(f"additional_iso_cov_covterm schema: {additional_iso_cov_covterm.schema}")
    write_and_log_pmtin(
        df=additional_iso_cov_covterm,
        table_name="covterm",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
    )
    logger.info("[END] Successfully wrote additional_iso_cov_covterm to table 'covterm'.")
    log_info_to_file("[END] Successfully wrote additional_iso_cov_covterm to table 'covterm'.")
except Exception as e:
    logger.error("Error writing to covterm", exc_info=True)
    log_info_to_file(f"Error writing to covterm: {str(e)}")
    log_dataload_event(
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name,
        log_message=f"Error writing to covterm: {str(e)}"
    )
    sys.exit(1)

# COMMAND ----------

CA7CommAutoLineSchedCov_query = '''
select distinct 
    concat('CA7CommAutoLineSchedCov:', trim(a.PolicyNumber), '_', b.codeidentifier) AS pmt_id,
    concat('CA7CAL_', trim(a.PolicyNumber)) AS pmt_parent,
    'usd' as preferredsettlementcurrency,
    'usd' as currency,
    b.codeidentifier as patterncode,
    trim(a.PolicyNumber) AS pmt_payloadid 
from additional_ISO_Coverages_data a
left join form_codeidentifier b 
    on trim(a.FormId) = b.pc_form_number
where trim(a.FormId) in ('CA 20 48','CA 20 47')
'''

try:
    CA7CommAutoLineSchedCov_query = spark.sql(CA7CommAutoLineSchedCov_query)
    CA7CommAutoLineSchedCov_query.createOrReplaceTempView("CA7CommAutoLineSchedCov_query")
    print(CA7CommAutoLineSchedCov_query.count())
    display(CA7CommAutoLineSchedCov_query)
except Exception as e:
    logger.info("error loading CA7CommAutoLineSchedCov_query: {}".format(e)) 
    sys.exit(1)

# COMMAND ----------

try:
    row_count = CA7CommAutoLineSchedCov_query.count()
    logger.info(f"[START] Writing {row_count} rows to table 'ca7commautolineschedcov' in PMTIN.")
    log_info_to_file(f"[START] Writing {row_count} rows to table 'ca7commautolineschedcov' in PMTIN.")
    logger.info(f"CA7CommAutoLineSchedCov_query schema: {CA7CommAutoLineSchedCov_query.schema}")
    log_info_to_file(f"CA7CommAutoLineSchedCov_query schema: {CA7CommAutoLineSchedCov_query.schema}")
    write_and_log_pmtin(
        df=CA7CommAutoLineSchedCov_query,
        table_name="ca7commautolineschedcov",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
    )
    logger.info("[END] Successfully wrote CA7CommAutoLineSchedCov_query to table 'ca7commautolineschedcov'.")
    log_info_to_file("[END] Successfully wrote CA7CommAutoLineSchedCov_query to table 'ca7commautolineschedcov'.")
except Exception as e:
    logger.error("Error writing to ca7commautolineschedcov", exc_info=True)
    log_info_to_file(f"Error writing to ca7commautolineschedcov: {str(e)}")
    log_dataload_event(
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name,
        log_message=f"Error writing to ca7commautolineschedcov: {str(e)}"
    )
    sys.exit(1)

# COMMAND ----------

