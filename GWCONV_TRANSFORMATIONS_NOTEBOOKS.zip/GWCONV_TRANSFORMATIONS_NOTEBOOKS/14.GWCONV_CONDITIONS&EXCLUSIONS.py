# Databricks notebook source
# MAGIC %md
# MAGIC # Notebook for Conditions and Exclusions

# COMMAND ----------

# DBTITLE 1,configs
# MAGIC %run ../configuration/configs
# MAGIC

# COMMAND ----------

# DBTITLE 1,configs
# MAGIC %run ../configuration/postgres

# COMMAND ----------

# DBTITLE 1,loggers
# Logger setup for tracking errors and process info in this notebook
import logging
import sys

logger = logging.getLogger('Line_level_exclusions')
logger.setLevel(logging.INFO)

# COMMAND ----------

# DBTITLE 1,iso exclusion standard query
line_level_exclusions_query = '''
-- Query to extract line-level exclusions for Commercial Auto Line Proprietary Coverages

SELECT 
    -- CoPolicyPointer fields
    P."SystemAssignId",
    P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
    CAST(RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",
    P."PolicyEffDt",
    -- ViewCurPic_AuStInput fields
    AuStInput."StateCd",
    -- ViewCurPic_AUSelectedForm fields
    AUSelectedForm."FormId",
    AUSelectedForm."FormDescTx" AS "FormDescription"
FROM policy P1
INNER JOIN "copolicypointer" P
   ON P."SystemAssignId" = P1."SourceSystemId"
INNER JOIN "viewcurpic_austinput" AuStInput
   ON P."SystemAssignId" = AuStInput."SystemAssignId"
LEFT JOIN "viewcurpic_auselectedform" AUSelectedForm
   ON P."SystemAssignId" = AUSelectedForm."SystemAssignId"
   AND trim(AuStInput."StateCd") = trim(AUSelectedForm."StateCd")
WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
  AND P1."LOB" IN ('AU', 'GR', 'TU')
  AND trim(AUSelectedForm."FormId") IN (
      'PCA 05 04','PCA 05 50','PCA 05 55','PCA 05 56','PCA 05 57','PCA 50 40',
      'PCA 20 65','PCA 51 08','PCA 04 01','PCA 04 14','PCA 04 23','PCA 04 27'
  )

UNION ALL

SELECT 
    -- CoPolicyPointer fields
    P."SystemAssignId",
    P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
    CAST(RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",
    P."PolicyEffDt",
    -- ViewCurPic_AUSelectedForm fields
    AUSelectedForm."StateCd",
    AUSelectedForm."FormId",
    AUSelectedForm."FormDescTx" AS "FormDescription"
FROM policy P1
INNER JOIN copolicypointer P
   ON P."SystemAssignId" = P1."SourceSystemId"
INNER JOIN viewcurpic_aupolinput AuPolInput
   ON P."SystemAssignId" = AuPolInput."SystemAssignId"
LEFT JOIN viewcurpic_auselectedform AUSelectedForm
   ON P."SystemAssignId" = AUSelectedForm."SystemAssignId"
   AND trim(AUSelectedForm."StateCd") = 'CW'
WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
  AND P1."LOB" IN ('AU', 'GR', 'TU')
  AND trim(AUSelectedForm."FormId") IN (
      'PCA 05 04','PCA 05 50','PCA 05 55','PCA 05 56','PCA 05 57','PCA 50 40',
      'PCA 20 65','PCA 51 08','PCA 04 01','PCA 04 14','PCA 04 23','PCA 04 27'
  )

ORDER BY "PolicyNumber", "StateCd", "FormId"
'''


try:
  # Execute the query and create a temp view for downstream use
  Line_level_exclusions = eval(exec_select_landing)(line_level_exclusions_query)
  Line_level_exclusions.createOrReplaceTempView("Line_level_exclusions")  # Create a temporary view for further processing
  print(Line_level_exclusions.count())  # Print the count of records retrieved
  display(Line_level_exclusions)  # Display the results
except Exception as e:
  logger.info(f"error loading Line_level_exclusions: {e}")
  print(f"error loading Line_level_exclusions: {e}")

# COMMAND ----------

pp_activity=execute_select_PMTIN("select * from policyperiod")
display(pp_activity)

# COMMAND ----------

# DBTITLE 1,CA7commautoline query
# ---------------------------------------------
# Extract Line Level Exclusions (Other/Exclusion Coverages)
# ---------------------------------------------
ca7commautolineexcl_query = '''
-- Query to extract line-level exclusions for other and exclusion coverages
SELECT DISTINCT
    P."SystemAssignId",
    P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
    CAST(RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",
    P."PolicyEffDt",
    AuStInput."StateCd",
    AUSelectedForm."FormId",
    AUSelectedForm."FormDescTx" AS "FormDescription"
FROM policy P1
INNER JOIN copolicypointer P
   ON P."SystemAssignId" = P1."SourceSystemId"  -- Join to get policy details
INNER JOIN viewcurpic_austinput AuStInput
   ON P."SystemAssignId" = AuStInput."SystemAssignId"  -- Join to get state information
LEFT JOIN viewcurpic_auselectedform AUSelectedForm
   ON P."SystemAssignId" = AUSelectedForm."SystemAssignId"
   AND AuStInput."StateCd" = AUSelectedForm."StateCd"  -- Join to get selected form details
WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')  -- Filter for active policies
  AND P1."LOB" IN ('AU', 'GR', 'TU')  -- Filter for specific lines of business
  AND AUSelectedForm."FormId" IN (  -- Filter for specific form IDs
      'CA 25 55', 'CA 25 50', 'CA 25 62', 'CA 04 55', 'CA 27 05', 'CA 27 16', 
      'CA 27 14', 'CA 25 51', 'CA 23 85', 'CA 25 54', 'CA 27 13', 'CA 23 94', 
      'CA 25 37', 'CA 25 24', 'CA 25 56', 'CA 27 07', 'CA 04 42', 'CA 25 19', 
      'CA 25 53', 'CA 25 39', 'CA 26 04', 'CA 25 65', 'CA 25 64', 'CA 25 57', 
      'CA 23 84', 'CA 27 12', 'CA 28 03', 'PCA 20 27', 'PCA 20 21', 'PCA 06 02', 
      'PCA 06 13', 'PCA 05 12', 'PCA 20 07', 'CA 25 16', 'CA 23 86', 'CA 25 36', 
      'CA 23 87', 'CA 27 19', 'CA 20 11', 'CA 25 25', 'CA 27 21', 'CA 27 22', 
      'CA 27 06', 'CA 20 30', 'CA 25 18', 'CA 23 01', 'CA 27 10', 'CA 27 08', 
      'CA 27 09', 'CA 99 13', 'CA 23 05',
      'PCA 20 27', 'PCA 20 21', 'PCA 06 13', 'PCA 05 12', 'PCA 20 07'  -- Added as requested
  )
UNION ALL
SELECT DISTINCT
    P."SystemAssignId",
    P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
    CAST(RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",
    P."PolicyEffDt",
    AUSelectedForm."StateCd" AS "StateCd",
    AUSelectedForm."FormId",
    AUSelectedForm."FormDescTx" AS "FormDescription"
FROM policy P1
INNER JOIN copolicypointer P
   ON P."SystemAssignId" = P1."SourceSystemId"  -- Join to get policy details
INNER JOIN viewcurpic_aupolinput AuPolInput
   ON P."SystemAssignId" = AuPolInput."SystemAssignId"  -- Join to get policy input details
LEFT JOIN viewcurpic_auselectedform AUSelectedForm
   ON P."SystemAssignId" = AUSelectedForm."SystemAssignId"
   AND trim(AUSelectedForm."StateCd") = 'CW'  -- Join to get selected form details for 'CW' state
WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')  -- Filter for active policies
  AND P1."LOB" IN ('AU', 'GR', 'TU')  -- Filter for specific lines of business
  AND trim(AUSelectedForm."FormId") IN (  -- Filter for specific form IDs
      'CA 25 55', 'CA 25 50', 'CA 25 62', 'CA 04 55', 'CA 27 05', 'CA 27 16', 
      'CA 27 14', 'CA 25 51', 'CA 23 85', 'CA 25 54', 'CA 27 13', 'CA 23 94', 
      'CA 25 37', 'CA 25 24', 'CA 25 56', 'CA 27 07', 'CA 04 42', 'CA 25 19', 
      'CA 25 53', 'CA 25 39', 'CA 26 04', 'CA 25 65', 'CA 25 64', 'CA 25 57', 
      'CA 23 84', 'CA 27 12', 'CA 28 03', 'PCA 20 27', 'PCA 20 21', 'PCA 06 02', 
      'PCA 06 13', 'PCA 05 12', 'PCA 20 07', 'CA 25 16', 'CA 23 86', 'CA 25 36', 
      'CA 23 87', 'CA 27 19', 'CA 20 11', 'CA 25 25', 'CA 27 21', 'CA 27 22', 
      'CA 27 06', 'CA 20 30', 'CA 25 18', 'CA 23 01', 'CA 27 10', 'CA 27 08', 
      'CA 27 09', 'CA 99 13', 'CA 23 05',
      'PCA 20 27', 'PCA 20 21', 'PCA 06 13', 'PCA 05 12', 'PCA 20 07'  -- Added as requested
  )
ORDER BY "PolicyNumber", "StateCd", "FormId"  -- Order the results for better readability
'''
try:
  # Execute the query and create a temp view for downstream use
  Line_level_exclusions_CA = eval(exec_select_landing)(ca7commautolineexcl_query)
  Line_level_exclusions_CA.createOrReplaceTempView("Line_level_exclusions_CA")  # Create a temporary view
  print(Line_level_exclusions_CA.count())  # Print the count of records
  display(Line_level_exclusions_CA)  # Display the results
except Exception as e:
  logger.info("error loading Line_level_exclusions: {}".format(e))  # Log any errors encountered
  sys.exit(1)  # Exit the program with an error status

# COMMAND ----------

# DBTITLE 1,test
query = '''
SELECT PolicyNumber,FormId, formdescription
FROM Line_level_exclusions_CA
where policynumber='132401 1262518M'

'''

result_df = spark.sql(query)
display(result_df)

# COMMAND ----------

# DBTITLE 1,ca7commautolineexcl transformatoion query
CA7CommAutoLineexcl_trans_query = '''
SELECT 
    left(concat('CA7CommAutoLineexcl:', trim(PolicyNumber), '_', 
           CASE
               WHEN trim(FormId) = 'CA 25 55' THEN 'CA7ExclProdsAndWorkYouPerformed'
               WHEN trim(FormId) = 'CA 25 50' THEN 'CA7ExclDamageToRentedPremises'
               WHEN trim(FormId) = 'CA 25 62' THEN 'CA7ChangesToTheBankruptcyOrInsolvencyExclForActsE3'
               WHEN trim(FormId) = 'CA 04 55' THEN 'CA7CommunicableDiseaseExclForCovrdAutosLiabExposur'
               WHEN trim(FormId) = 'CA 27 05' THEN 'CA7UnmannedAircraftExclForGeneralLiabCovs'
               WHEN trim(FormId) = 'CA 27 16' THEN 'CA7ExclCrossSuitsLiabForGeneralLiabCovs'
               WHEN trim(FormId) = 'CA 27 14' THEN 'CA7CannabisExclWithHempAndLessorRiskExceptionForGe'
               WHEN trim(FormId) = 'CA 25 51' THEN 'CA7ExclDesignatedProds1'
               WHEN trim(FormId) = 'CA 23 85' THEN 'CA7ExclOfTerrNuclearBiologicalChemicalTerr'
               WHEN trim(FormId) = 'CA 25 54' THEN 'CA7ExclPersonalAndAdvertisingInjuryLiab'
               WHEN trim(FormId) = 'CA 27 13' THEN 'CA7CannabisExclWithHempExceptionForGeneralLiabCovs'
               WHEN trim(FormId) = 'CA 23 94' THEN 'CA7SilicaOrSilicaReltdDustExclForCovrdAutosExposur'
               WHEN trim(FormId) = 'CA 25 37' THEN 'CA7FungiOrBacteriaExclGarageOpsOthThanCovrdAutos'
               WHEN trim(FormId) = 'CA 25 24' THEN 'CA7ExclY2KCompReltdElectrProbExceptionBIPremises'
               WHEN trim(FormId) = 'CA 25 56' THEN 'CA7ExclDesignatedWorkYouPerformed1'
               WHEN trim(FormId) = 'CA 27 07' THEN 'CA7UnmannedAircraftExclForGeneralLiabCovsPersonalA'
               WHEN trim(FormId) = 'CA 04 42' THEN 'CA7ExclOfFedEmplsUsingAutosInGovBusiness'
               WHEN trim(FormId) = 'CA 25 19' THEN 'CA7ExclY2KCompReltdElectrProbProdsWork'
               WHEN trim(FormId) = 'CA 25 53' THEN 'CA7ExclNewlyAcquiredOrFormedAutoDealership'
               WHEN trim(FormId) = 'CA 25 39' THEN 'CA7SilicaOrSilicaReltdDustExclForOthThanCovrdAutos'
               WHEN trim(FormId) = 'CA 26 04' THEN 'CA7AmendmentOfSingleInterestPolicyProvisionsPublic'
               WHEN trim(FormId) = 'CA 25 65' THEN 'CA7TotalBankruptcyOrInsolvencyExclForActsErrorsOrO'
               WHEN trim(FormId) = 'CA 25 64' THEN 'CA7ExclOfSpecifiedActsErrorsOrOmissionsLiabCovs'
               WHEN trim(FormId) = 'CA 25 57' THEN 'CA7CommunicableDiseaseExclForGeneralLiabCovs'
               WHEN trim(FormId) = 'CA 23 84' THEN 'CA7ExclOfTerr'
               WHEN trim(FormId) = 'CA 27 12' THEN 'CA7CannabisExclForGeneralLiabCovs'
               WHEN trim(FormId) = 'CA 28 03' THEN 'CA7AbuseOrMolestationExclForCovrdAutosLiabExposure'
               WHEN trim(FormId) = 'PCA 20 27' THEN 'CA7TotPollExcl_Ext'
               WHEN trim(FormId) = 'PCA 20 21' THEN 'CA7AssltBttryExcl_Ext'
         --      WHEN trim(FormId) = 'PCA 06 02' THEN 'CA7LmtdExclOfNmdDrvr_Ext'
               WHEN trim(FormId) = 'PCA 06 13' THEN 'CA7EmployersLiabExclTemporaryWorker_Ext'
               WHEN trim(FormId) = 'PCA 05 12' THEN 'CA7HrdNOwndRtlFdDlvry_Ext'
               WHEN trim(FormId) = 'PCA 20 07' THEN 'CA7AbsMolestnSxlMscndtExcl_Ext'
               WHEN trim(FormId) = 'CA 25 16' THEN 'CA7GarageCovFormOthThanCovrdAutosExposureTotalPoll'
               WHEN trim(FormId) = 'CA 23 86' THEN 'CA7ExclOfTerrAboveMinStatutoryLmts'
               WHEN trim(FormId) = 'CA 25 36' THEN 'CA7GarageCovOthThanCovrdAutosExposureTotPolltnExcl'
               WHEN trim(FormId) = 'CA 23 87' THEN 'CA7ExclOfTerrNuclearBiologicalChemicalTerrAboveMin'
               WHEN trim(FormId) = 'CA 27 19' THEN 'CA7PFASExclForGeneralLiabCovs'
               WHEN trim(FormId) = 'CA 20 11' THEN 'CA7LeasingOrRentalConcernsExclOfCertainLeasedAuto1'
               WHEN trim(FormId) = 'CA 25 25' THEN 'CA7Y2KCompReltdElectrncPrblsExclOfSpecnCovForDesin'
               WHEN trim(FormId) = 'CA 27 21' THEN 'CA7AbuseOrMolestationExclForGeneralLiabAndActsErro'
               WHEN trim(FormId) = 'CA 27 22' THEN 'CA7SexualAbuseOrSexualMolestationExclForGeneralLia'
               WHEN trim(FormId) = 'CA 27 06' THEN 'CA7UnmannedAircraftExclForGeneralLiabCovsBIAndProp'
               WHEN trim(FormId) = 'CA 20 30' THEN 'CA7EmergencyVehiclesVolunteerFirefightersAndWorker'
               WHEN trim(FormId) = 'CA 25 18' THEN 'CA7ExclY2KCompReltdElectrProb'
               WHEN trim(FormId) = 'CA 23 01' THEN 'CA7Explosives'
               WHEN trim(FormId) = 'CA 27 10' THEN 'CA7LmtdGeneralLiabCovForDesignatedUnmannedAircraf1'
               WHEN trim(FormId) = 'CA 27 08' THEN 'CA7LmtdGeneralLiabCovForDesignatedUnmannedAircraf2'
               WHEN trim(FormId) = 'CA 27 09' THEN 'CA7LmtdGeneralLiabCovForDesignatedUnmannedAircraft'
               WHEN trim(FormId) = 'CA 99 13' THEN 'CA7FiduciaryLiabOfBanks'
               WHEN trim(FormId) = 'CA 23 05' THEN 'CA7WrongDeliveryOfLiquidProds'
           END), 100) AS pmt_id,
    left(concat('CA7CAL_', trim(PolicyNumber)), 100) AS pmt_parent,
    CASE
        WHEN trim(FormId) = 'CA 25 55' THEN 'CA7ExclProdsAndWorkYouPerformed'
        WHEN trim(FormId) = 'CA 25 50' THEN 'CA7ExclDamageToRentedPremises'
        WHEN trim(FormId) = 'CA 25 62' THEN 'CA7ChangesToTheBankruptcyOrInsolvencyExclForActsE3'
        WHEN trim(FormId) = 'CA 04 55' THEN 'CA7CommunicableDiseaseExclForCovrdAutosLiabExposur'
        WHEN trim(FormId) = 'CA 27 05' THEN 'CA7UnmannedAircraftExclForGeneralLiabCovs'
        WHEN trim(FormId) = 'CA 27 16' THEN 'CA7ExclCrossSuitsLiabForGeneralLiabCovs'
        WHEN trim(FormId) = 'CA 27 14' THEN 'CA7CannabisExclWithHempAndLessorRiskExceptionForGe'
        WHEN trim(FormId) = 'CA 25 51' THEN 'CA7ExclDesignatedProds1'
        WHEN trim(FormId) = 'CA 23 85' THEN 'CA7ExclOfTerrNuclearBiologicalChemicalTerr'
        WHEN trim(FormId) = 'CA 25 54' THEN 'CA7ExclPersonalAndAdvertisingInjuryLiab'
        WHEN trim(FormId) = 'CA 27 13' THEN 'CA7CannabisExclWithHempExceptionForGeneralLiabCovs'
        WHEN trim(FormId) = 'CA 23 94' THEN 'CA7SilicaOrSilicaReltdDustExclForCovrdAutosExposur'
        WHEN trim(FormId) = 'CA 25 37' THEN 'CA7FungiOrBacteriaExclGarageOpsOthThanCovrdAutos'
        WHEN trim(FormId) = 'CA 25 24' THEN 'CA7ExclY2KCompReltdElectrProbExceptionBIPremises'
        WHEN trim(FormId) = 'CA 25 56' THEN 'CA7ExclDesignatedWorkYouPerformed1'
        WHEN trim(FormId) = 'CA 27 07' THEN 'CA7UnmannedAircraftExclForGeneralLiabCovsPersonalA'
        WHEN trim(FormId) = 'CA 04 42' THEN 'CA7ExclOfFedEmplsUsingAutosInGovBusiness'
        WHEN trim(FormId) = 'CA 25 19' THEN 'CA7ExclY2KCompReltdElectrProbProdsWork'
        WHEN trim(FormId) = 'CA 25 53' THEN 'CA7ExclNewlyAcquiredOrFormedAutoDealership'
        WHEN trim(FormId) = 'CA 25 39' THEN 'CA7SilicaOrSilicaReltdDustExclForOthThanCovrdAutos'
        WHEN trim(FormId) = 'CA 26 04' THEN 'CA7AmendmentOfSingleInterestPolicyProvisionsPublic'
        WHEN trim(FormId) = 'CA 25 65' THEN 'CA7TotalBankruptcyOrInsolvencyExclForActsErrorsOrO'
        WHEN trim(FormId) = 'CA 25 64' THEN 'CA7ExclOfSpecifiedActsErrorsOrOmissionsLiabCovs'
        WHEN trim(FormId) = 'CA 25 57' THEN 'CA7CommunicableDiseaseExclForGeneralLiabCovs'
        WHEN trim(FormId) = 'CA 23 84' THEN 'CA7ExclOfTerr'
        WHEN trim(FormId) = 'CA 27 12' THEN 'CA7CannabisExclForGeneralLiabCovs'
        WHEN trim(FormId) = 'CA 28 03' THEN 'CA7AbuseOrMolestationExclForCovrdAutosLiabExposure'
        WHEN trim(FormId) = 'PCA 20 27' THEN 'CA7TotPollExcl_Ext'
        WHEN trim(FormId) = 'PCA 20 21' THEN 'CA7AssltBttryExcl_Ext'
   --     WHEN trim(FormId) = 'PCA 06 02' THEN 'CA7LmtdExclOfNmdDrvr_Ext'
        WHEN trim(FormId) = 'PCA 06 13' THEN 'CA7EmployersLiabExclTemporaryWorker_Ext'
        WHEN trim(FormId) = 'PCA 05 12' THEN 'CA7HrdNOwndRtlFdDlvry_Ext'
        WHEN trim(FormId) = 'PCA 20 07' THEN 'CA7AbsMolestnSxlMscndtExcl_Ext'
        WHEN trim(FormId) = 'CA 25 16' THEN 'CA7GarageCovFormOthThanCovrdAutosExposureTotalPoll'
        WHEN trim(FormId) = 'CA 23 86' THEN 'CA7ExclOfTerrAboveMinStatutoryLmts'
        WHEN trim(FormId) = 'CA 25 36' THEN 'CA7GarageCovOthThanCovrdAutosExposureTotPolltnExcl'
        WHEN trim(FormId) = 'CA 23 87' THEN 'CA7ExclOfTerrNuclearBiologicalChemicalTerrAboveMin'
        WHEN trim(FormId) = 'CA 27 19' THEN 'CA7PFASExclForGeneralLiabCovs'
        WHEN trim(FormId) = 'CA 20 11' THEN 'CA7LeasingOrRentalConcernsExclOfCertainLeasedAuto1'
        WHEN trim(FormId) = 'CA 25 25' THEN 'CA7Y2KCompReltdElectrncPrblsExclOfSpecnCovForDesin'
        WHEN trim(FormId) = 'CA 27 21' THEN 'CA7AbuseOrMolestationExclForGeneralLiabAndActsErro'
        WHEN trim(FormId) = 'CA 27 22' THEN 'CA7SexualAbuseOrSexualMolestationExclForGeneralLia'
        WHEN trim(FormId) = 'CA 27 06' THEN 'CA7UnmannedAircraftExclForGeneralLiabCovsBIAndProp'
        WHEN trim(FormId) = 'CA 20 30' THEN 'CA7EmergencyVehiclesVolunteerFirefightersAndWorker'
        WHEN trim(FormId) = 'CA 25 18' THEN 'CA7ExclY2KCompReltdElectrProb'
        WHEN trim(FormId) = 'CA 23 01' THEN 'CA7Explosives'
        WHEN trim(FormId) = 'CA 27 10' THEN 'CA7LmtdGeneralLiabCovForDesignatedUnmannedAircraf1'
        WHEN trim(FormId) = 'CA 27 08' THEN 'CA7LmtdGeneralLiabCovForDesignatedUnmannedAircraf2'
        WHEN trim(FormId) = 'CA 27 09' THEN 'CA7LmtdGeneralLiabCovForDesignatedUnmannedAircraft'
        WHEN trim(FormId) = 'CA 99 13' THEN 'CA7FiduciaryLiabOfBanks'
        WHEN trim(FormId) = 'CA 23 05' THEN 'CA7WrongDeliveryOfLiquidProds'

    END AS CodeIdentifier,
    'usd' AS currency,
    trim(PolicyNumber) AS pmt_payloadid
FROM line_level_exclusions_CA
'''
try:
  CA7excl_final = spark.sql(CA7CommAutoLineexcl_trans_query)
  CA7excl_final.createOrReplaceTempView("CA7excl_final")
  print(CA7excl_final.count())
  display(CA7excl_final)
except Exception as e:
  logger.info("error loading CA7excl_final: {}".format(e)) 
  sys.exit(1)

# COMMAND ----------


CA7excl_final = CA7excl_final.filter((CA7excl_final.pmt_id.isNotNull()) & (CA7excl_final.pmt_id != ""))
null_pmt_id_count = CA7excl_final.filter(CA7excl_final.pmt_id.isNull() | (CA7excl_final.pmt_id == "")).count()
print(f"Number of null pmt_id values: {null_pmt_id_count}")

# COMMAND ----------

code_identifiers = [
    "CA7BIAndPropertyDamageUnmannedAircraftLiabAggLimit",
    "CA7DescriptionOfOpsOrProjects2",
    "CA7DescriptionOfOpsOrProjects",
    "CA7DescriptionOfUnmannedAircraft2",
    "CA7DescriptionOfUnmannedAircraft",
    "CA7UnmannedAircraftLiabAggLimit"
 #"CA7ExclOfTerr"
]

manualactivity_df = CA7excl_final.filter(CA7excl_final.CodeIdentifier.isin(code_identifiers))
display(manualactivity_df)

# COMMAND ----------


pp_activity = execute_select_PMTIN("select * from policyperiod")
display(pp_activity)

# COMMAND ----------

pp_activity.createOrReplaceTempView("pp_activity")
manualactivity_df.createOrReplaceTempView("manualactivity_df")

sql_query = """
SELECT
    pp.pmt_id,
    pp.pmt_parent,

    CASE
        WHEN ma.pmt_payloadid IS NOT NULL THEN
            CASE
                WHEN pp.activitynotification_ext IS NULL OR trim(pp.activitynotification_ext) = ''
                THEN 'Please create an activity for line standard exclusion'
                ELSE concat(pp.activitynotification_ext, '\\nPlease create an activity for line standard exclusion')
            END
        ELSE pp.activitynotification_ext
    END AS activitynotification_ext,
    pp.appeventsyncstatus,
    pp.basestate,
    pp.claimhandlingentity_ext,
    pp.depositamount_cur,
    pp.editeffectivedate,
    pp.estimatedpremium_amt,
    pp.estimatedpremium_cur,

    pp.inputsource_ext,
    pp.invoicingmethod,

      pp.periodend,
        pp.periodstart,

pp.producingsoc_ext,

         pp.renewalconversionflag_ext,

        pp.totpremiumincovcurrencyrpt_cur,
        pp.totalcostincovcurrencyrpt_cur,
        pp.trancostincovcurrencyrpt_cur,
         pp.profitcenter_ext,

        pp.producercodeofrecord,
       pp.uwcompany,
      pp.pmt_payloadid,

 pp.specialdigits_ext,

  pp.subaccountnumber_ext

FROM pp_activity pp
LEFT JOIN manualactivity_df ma
    ON upper(trim(pp.pmt_payloadid)) = upper(trim(ma.pmt_payloadid))
"""
 
pp_activity_updated = spark.sql(sql_query)
display(pp_activity_updated)
pp_activity_updated.createOrReplaceTempView("pp_activity_updated")

# COMMAND ----------

eval(exec_cmd_framework)('truncate table public.policyperiod')
pp_activity_updated.write.jdbc(url=jdbc_url_framework, table='policyperiod', mode='append', properties=properties)
eval(exec_cmd_pmtin)('truncate table public.policyperiod')
pp_manual_excl=execute_select_Framework('select * from policyperiod')
pp_manual_excl.write.jdbc(url=jdbc_url_pmtin, table='policyperiod', mode='append', properties=properties)


# COMMAND ----------



# COMMAND ----------

# DBTITLE 1,ca7commautoline pmtin
eval(exec_cmd_pmtin)('truncate table public.ca7commautolineexcl')

CA7excl_final.write.jdbc(url=jdbc_url_pmtin, table='ca7commautolineexcl', mode='append', properties=properties)

# COMMAND ----------

# DBTITLE 1,ca7commautolineschedexcl transformation query
CA7CommAutoLineschedexcl_trans_query = '''
SELECT 
    left(concat('ca7commautolineschedexcl:', trim(PolicyNumber), '_', 
           CASE
               WHEN trim(FormId) = 'CA 25 62' THEN 'CA7ChangesToTheBankruptcyOrInsolvencyExclForActsE3'
               WHEN trim(FormId) = 'CA 25 51' THEN 'CA7ExclDesignatedProds1'
               WHEN trim(FormId) = 'PCA 06 02' THEN 'CA7LmtdExclOfNmdDrvr_Ext'
              
           END), 100) AS pmt_id,
    left(concat('CA7CAL_', trim(PolicyNumber)), 100) AS pmt_parent,
    CASE
        WHEN trim(FormId) = 'CA 25 62' THEN 'CA7ChangesToTheBankruptcyOrInsolvencyExclForActsE3'
        WHEN trim(FormId) = 'CA 25 51' THEN 'CA7ExclDesignatedProds1'
        WHEN trim(FormId) = 'PCA 06 02' THEN 'CA7LmtdExclOfNmdDrvr_Ext'
      
    END AS patterncode,
    'usd' AS currency,
    trim(PolicyNumber) AS pmt_payloadid
FROM line_level_exclusions_CA
'''
try:
  CA7schedexcl_final = spark.sql(CA7CommAutoLineschedexcl_trans_query)
  CA7schedexcl_final.createOrReplaceTempView("CA7schedexcl_final")
  print(CA7schedexcl_final.count())
  display(CA7schedexcl_final)
except Exception as e:
  logger.info("error loading ca7commautolineschedexcl: {}".format(e)) 
  sys.exit(1)

# COMMAND ----------

# DBTITLE 1,filtering out unknown patterncode or codeidentifier
CA7schedexcl_final_filtered =  CA7schedexcl_final.filter("patterncode IS NOT NULL")
display( CA7schedexcl_final_filtered)

# COMMAND ----------

CA7schedexcl_final_filtered.createOrReplaceTempView("CA7schedexcl_final_filtered")

pp_activity.createOrReplaceTempView("pp_activity")

sql_query = """
SELECT
    pp.pmt_id,
    pp.pmt_parent,

    CASE
        WHEN ma.pmt_payloadid IS NOT NULL THEN
            CASE
                WHEN pp.activitynotification_ext IS NULL OR trim(pp.activitynotification_ext) = ''
                THEN 'Please create an activity for scheduled exclusion'
                ELSE concat(pp.activitynotification_ext, '\\nPlease create an activity for scheduled exclusion')
            END
        ELSE pp.activitynotification_ext
    END AS activitynotification_ext,
    pp.appeventsyncstatus,
    pp.basestate,
    pp.claimhandlingentity_ext,
    pp.depositamount_cur,
    pp.editeffectivedate,
    pp.estimatedpremium_amt,
    pp.estimatedpremium_cur,

    pp.inputsource_ext,
    pp.invoicingmethod,

      pp.periodend,
        pp.periodstart,

pp.producingsoc_ext,

         pp.renewalconversionflag_ext,

        pp.totpremiumincovcurrencyrpt_cur,
        pp.totalcostincovcurrencyrpt_cur,
        pp.trancostincovcurrencyrpt_cur,
         pp.profitcenter_ext,

        pp.producercodeofrecord,
       pp.uwcompany,
      pp.pmt_payloadid,

 pp.specialdigits_ext,

  pp.subaccountnumber_ext

FROM pp_activity pp
LEFT JOIN CA7schedexcl_final_filtered ma
    ON upper(trim(pp.pmt_payloadid)) = upper(trim(ma.pmt_payloadid))
"""

pp_activity_schedexcl_updated = spark.sql(sql_query)
display(pp_activity_schedexcl_updated)

# COMMAND ----------

eval(exec_cmd_framework)('truncate table public.policyperiod')
pp_activity_updated.write.jdbc(url=jdbc_url_framework, table='policyperiod', mode='append', properties=properties)
eval(exec_cmd_pmtin)('truncate table public.policyperiod')
pp_manual_excl=execute_select_Framework('select * from policyperiod')
pp_manual_excl.write.jdbc(url=jdbc_url_pmtin, table='policyperiod', mode='append', properties=properties)


# COMMAND ----------

# DBTITLE 1,insertion into ca7commautolineschedexcl

eval(exec_cmd_pmtin)('truncate table public.CA7CommAutoLineSchedExcl')

CA7schedexcl_final_filtered.write.jdbc(url=jdbc_url_pmtin, table=' CA7CommAutoLineSchedExcl', mode='append', properties=properties)

# COMMAND ----------

# DBTITLE 1,ca7commautoline query
ca7commautolinecond_query = '''
/* ------------------------------------------------------------------------------------------------------------------------ */
/* Sprint5_Line – Standard - Other and Exclusion Coverages (PostgreSQL Version)                                             */
/* ------------------------------------------------------------------------------------------------------------------------ */

SELECT DISTINCT
    -- CoPolicyPointer fields
    P."SystemAssignId",
    P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
    CAST(RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",
    P."PolicyEffDt",

    -- ViewCurPic_AuStInput fields
    AuStInput."StateCd",

    -- ViewCurPic_AUSelectedForm fields
    AUSelectedForm."FormId",
    AUSelectedForm."FormDescTx" AS "FormDescription"

    -- ViewCurPic_AUFormFillin fields (commented out: not used in this query)
    -- AUFormFillin."FillinTx" AS "PersonOrOrganization"
    -- AUFormFillin."PageNo" AS "PageNumber",
    -- AUFormFillin."OccurrenceNo" AS "OccurenceNumber"

FROM policy P1
INNER JOIN copolicypointer P
   ON P."SystemAssignId" = P1."SourceSystemId"
INNER JOIN viewcurpic_austinput AuStInput
   ON P."SystemAssignId" = AuStInput."SystemAssignId"
LEFT JOIN viewcurpic_auselectedform AUSelectedForm
   ON P."SystemAssignId" = AUSelectedForm."SystemAssignId"
   AND AuStInput."StateCd" = AUSelectedForm."StateCd"
-- LEFT JOIN viewcurpic_auformfillin AUFormFillin
   -- ON P."SystemAssignId" = AUFormFillin."SystemAssignId"
   -- AND AUSelectedForm."FormId" = AUFormFillin."FormId"
   -- AUFormFillin join commented out: not used in this query

WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
  AND P1."LOB" IN ('AU', 'GR', 'TU')
  AND AUSelectedForm."FormId" IN (
     'CA 27 18', 'CA 23 97', 'CA 25 58', 'CA 04 43', 'CA 99 15', 'CA 23 25', 'CA 01 21', 'CA 25 61', 'PCA0518', 'PCA0527', 'CA 04 22', 'CA 04 49', 'IL 09 17', 'CA 25 67', 'CA 27 15','CA 04 44', 'PCA 05 04'
  )

UNION ALL

SELECT DISTINCT
    -- CoPolicyPointer fields
    P."SystemAssignId",
    P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
    CAST(RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",
    P."PolicyEffDt",

    -- ViewCurPic_AUSelectedForm fields for 'CW'
    AUSelectedForm."StateCd" AS "StateCd",
    AUSelectedForm."FormId",
    AUSelectedForm."FormDescTx" AS "FormDescription"

    -- ViewCurPic_AUFormFillin fields (commented out: not used in this query)
    -- AUFormFillin."FillinTx" AS "PersonOrOrganization"
    -- AUFormFillin."PageNo" AS "PageNumber",
    -- AUFormFillin."OccurrenceNo" AS "OccurenceNumber"

FROM policy P1
INNER JOIN copolicypointer P
   ON P."SystemAssignId" = P1."SourceSystemId"
INNER JOIN viewcurpic_aupolinput AuPolInput
   ON P."SystemAssignId" = AuPolInput."SystemAssignId"
LEFT JOIN viewcurpic_auselectedform AUSelectedForm
   ON P."SystemAssignId" = AUSelectedForm."SystemAssignId"
   AND trim(AUSelectedForm."StateCd") = 'CW'
-- LEFT JOIN viewcurpic_auformfillin AUFormFillin
   -- ON P."SystemAssignId" = AUFormFillin."SystemAssignId"
   -- AND AUSelectedForm."FormId" = AUFormFillin."FormId"
   -- AUFormFillin join commented out: not used in this query

WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
  AND P1."LOB" IN ('AU', 'GR', 'TU')
  AND trim(AUSelectedForm."FormId") IN (
      'CA 27 18', 'CA 23 97', 'CA 25 58', 'CA 04 43', 'CA 99 15', 'CA 23 25', 'CA 01 21', 'CA 25 61', 'PCA0518', 'PCA0527', 'CA 04 22', 'CA 04 49', 'IL 09 17', 'CA 25 67', 'CA 27 15','CA 04 44', 'PCA 05 04'
  )

ORDER BY "PolicyNumber", "StateCd", "FormId"
-- "PageNumber", "OccurenceNumber"
'''
try:
  Line_level_cond_CA = eval(exec_select_landing)(ca7commautolinecond_query)
  Line_level_cond_CA.createOrReplaceTempView("Line_level_cond_CA")
  print(Line_level_cond_CA.count())
  display(Line_level_cond_CA)
except Exception as e:
 # logger.info("error loading Line_level_exclusions: {}".format(e)) 
  sys.exit(1)
 # logger.info("error loading Line_level_exclusions: {}".format(e)) 
  sys.exit(1)

# COMMAND ----------

# DBTITLE 1,ca7commautoline transformation query
CA7CommAutoLinecond_trans_query_updated = '''
SELECT 
   left(concat('CA7CommAutoLinecond:', trim(PolicyNumber), '_', 
       CASE
           WHEN trim(FormId) = 'CA 27 18' THEN 'CA7AutomaticInsuredStatusForNewlyAcquiredOrFormedLl'
           WHEN trim(FormId) = 'CA 23 97' THEN 'CA7AmphibiousVehicles'
           WHEN trim(FormId) = 'CA 25 58' THEN 'CA7AmendmentOfLmtsOfInsGeneralLiabCovs'
           WHEN trim(FormId) = 'CA 04 43' THEN 'CA7WaiverOfTransferOfRightsOfRecoveryAgainstOther1'
           WHEN trim(FormId) = 'CA 99 15' THEN 'CA7GovBodiesAmendatoryEndorsement'
           WHEN trim(FormId) = 'CA 23 25' THEN 'CA7CovForInjuryToLeasedWorkers'
           WHEN trim(FormId) = 'CA 01 21' THEN 'CA7LmtdMexico'
           WHEN trim(FormId) = 'CA 25 61' THEN 'CA7ExpandedCovTerritoryForGeneralLiabCovsAddition2'
           WHEN trim(FormId) IN ('PCA0518', 'PCA0527', 'CA 04 22') THEN 'CA7EarlierNoticeOfCancellationProvidedByUs'
           WHEN trim(FormId) = 'CA 04 49' THEN 'CA7PrimaryAndNoncontributoryOtherInsuranceConditio'
           WHEN trim(FormId) = 'IL 09 17' THEN 'CA7ResidentAgentCountersignature'
           WHEN trim(FormId) = 'CA 25 67' THEN 'CA7AmendmentOfPersonalAndAdvertisingInjuryDefiniti'
           WHEN trim(FormId) = 'CA 27 15' THEN 'CA7AmendmentOfPersonalAndAdvertisingInjuryDefiniti'
           
       END
   ), 99) AS pmt_id,
   concat('CA7CAL_', trim(PolicyNumber)) AS pmt_parent,
   CASE
       WHEN trim(FormId) = 'CA 27 18' THEN 'CA7AutomaticInsuredStatusForNewlyAcquiredOrFormedLl'
       WHEN trim(FormId) = 'CA 23 97' THEN 'CA7AmphibiousVehicles'
       WHEN trim(FormId) = 'CA 25 58' THEN 'CA7AmendmentOfLmtsOfInsGeneralLiabCovs'
       WHEN trim(FormId) = 'CA 04 43' THEN 'CA7WaiverOfTransferOfRightsOfRecoveryAgainstOther1'
       WHEN trim(FormId) = 'CA 99 15' THEN 'CA7GovBodiesAmendatoryEndorsement'
       WHEN trim(FormId) = 'CA 23 25' THEN 'CA7CovForInjuryToLeasedWorkers'
       WHEN trim(FormId) = 'CA 01 21' THEN 'CA7LmtdMexico'
       WHEN trim(FormId) = 'CA 25 61' THEN 'CA7ExpandedCovTerritoryForGeneralLiabCovsAddition2'
       WHEN trim(FormId) IN ('PCA0518', 'PCA0527', 'CA 04 22') THEN 'CA7EarlierNoticeOfCancellationProvidedByUs'
       WHEN trim(FormId) = 'CA 04 49' THEN 'CA7PrimaryAndNoncontributoryOtherInsuranceConditio'
       WHEN trim(FormId) = 'IL 09 17' THEN 'CA7ResidentAgentCountersignature'
       WHEN trim(FormId) = 'CA 25 67' THEN 'CA7AmendmentOfPersonalAndAdvertisingInjuryDefiniti'
       WHEN trim(FormId) = 'CA 27 15' THEN 'CA7AmendmentOfPersonalAndAdvertisingInjuryDefiniti'
     
   END AS CodeIdentifier,
   'usd' AS currency,
   trim(PolicyNumber) AS pmt_payloadid
FROM Line_level_cond_CA
'''
try:
  CA7cond_final_updated = spark.sql(CA7CommAutoLinecond_trans_query_updated)
  CA7cond_final_updated.createOrReplaceTempView("CA7cond_final_updated")
  print(CA7cond_final_updated.count())
  display(CA7cond_final_updated)
except Exception as e:
  #logger.info("error loading CA7HAU_final_updated: {}".format(e)) 
  sys.exit(1)

# COMMAND ----------

# DBTITLE 1,removing null values
CA7cond_final_updated = CA7cond_final_updated.filter(CA7cond_final_updated.pmt_id.isNotNull())
display(CA7cond_final_updated)

# COMMAND ----------

# DBTITLE 1,insert ca7commautolinecond into pmtin
eval(exec_cmd_pmtin)('truncate table public.ca7commautolinecond')

CA7cond_final_updated .write.jdbc(url=jdbc_url_pmtin, table='ca7commautolinecond', mode='append', properties=properties)

# COMMAND ----------

# DBTITLE 1,Covtrms for conditions
manual_premium_queries = [
    ("CA7ManualPremium105", "CA7AutomaticInsuredStatusForNewlyAcquiredOrFormedL_CA7ManualPremium105_query", "CA 27 18"),
    ("CA7ManualPremium3", "CA7CovForInjuryToLeasedWorkers_CA7ManualPremium3_query", "CA 23 25"),
    ("CA7ManualPremium5", "CA7LmtdMexico_CA7ManualPremium5_query", "CA 01 21"),
    ("CA7ManualPremium180", "CA7ExpandedCovTerritoryForGeneralLiabCovsAddition2_CA7ManualPremium180_query", "CA 25 61"),
    ("CA7ManualPremium18", "CA7ExtendedReportingPeriodEndorsementForEmplBenefi_CA7ManualPremium18_query", "IL 09 17"),
]

for view_name, _, form_id in manual_premium_queries:
    query = f'''
    WITH parent_ids AS (
        SELECT 
            left(concat('CA7CommAutoLinecond:', trim(PolicyNumber), '_', 
                CASE
                    WHEN trim(FormId) = 'CA 27 18' THEN 'CA7AutomaticInsuredStatusForNewlyAcquiredOrFormedLl'
                    WHEN trim(FormId) = 'CA 23 97' THEN 'CA7AmphibiousVehicles'
                    WHEN trim(FormId) = 'CA 25 58' THEN 'CA7AmendmentOfLmtsOfInsGeneralLiabCovs'
                    WHEN trim(FormId) = 'CA 04 43' THEN 'CA7WaiverOfTransferOfRightsOfRecoveryAgainstOther1'
                    WHEN trim(FormId) = 'CA 99 15' THEN 'CA7GovBodiesAmendatoryEndorsement'
                    WHEN trim(FormId) = 'CA 23 25' THEN 'CA7CovForInjuryToLeasedWorkers'
                    WHEN trim(FormId) = 'CA 01 21' THEN 'CA7LmtdMexico'
                    WHEN trim(FormId) = 'CA 25 61' THEN 'CA7ExpandedCovTerritoryForGeneralLiabCovsAddition2'
                    WHEN trim(FormId) IN ('PCA0518', 'PCA0527', 'CA 04 22') THEN 'CA7EarlierNoticeOfCancellationProvidedByUs'
                    WHEN trim(FormId) = 'CA 04 49' THEN 'CA7PrimaryAndNoncontributoryOtherInsuranceConditio'
                    WHEN trim(FormId) = 'IL 09 17' THEN 'CA7ResidentAgentCountersignature'
                    WHEN trim(FormId) = 'CA 25 67' THEN 'CA7AmendmentOfPersonalAndAdvertisingInjuryDefiniti'
                    WHEN trim(FormId) = 'CA 27 15' THEN 'CA7AmendmentOfPersonalAndAdvertisingInjuryDefiniti'
                    ELSE 'UnKnownCodeIdentifier'
                END
            ), 99) AS parent_pmt_id,
            PolicyNumber
        FROM Line_level_cond_CA
        WHERE trim(FormId) = '{form_id}'
    )
    SELECT 
        concat('{view_name}', trim(PolicyNumber), '_', ROW_NUMBER() OVER (PARTITION BY trim(PolicyNumber) ORDER BY trim(PolicyNumber))) AS pmt_id,
        parent_pmt_id AS pmt_parent,
        'CA7CommAutoLineCond' AS pmt_parent_type,
        '{view_name}' AS codeidentifier,
        '0' AS value,
        trim(PolicyNumber) AS pmt_payloadid
    FROM parent_ids
    '''
    try:
        df = spark.sql(query)
        df.createOrReplaceTempView(view_name)
        print(df.count())
        display(df)
    except Exception as e:
        #logger.info(f"error loading {view_name}: {e}")
        sys.exit(1)

# COMMAND ----------

#eval(exec_cmd_pmtin)('truncate table public.covterm')

view_names = [
  "CA7ManualPremium105", 
    "CA7ManualPremium3",
    "CA7ManualPremium5",
    "CA7ManualPremium180",
"CA7ManualPremium18"
]

union_df = None
for view in view_names:
    df = spark.table(view)
    if union_df is None:
        union_df = df
    else:
        union_df = union_df.unionByName(df)

union_df.write.jdbc(url=jdbc_url_pmtin, table='covterm', mode='append', properties=properties)

# COMMAND ----------

CA7CommAutoLinecondsched_trans_query_updated = '''
SELECT DISTINCT
   left(concat('CA7CommAutoLinecondsched:', trim(PolicyNumber), '_', 
       'CA7WaiverOfTransferOfRightsOfRecoveryAgainstOthers'
   ), 99) AS pmt_id,
   concat('CA7CAL_', trim(PolicyNumber)) AS pmt_parent,
   'CA7WaiverOfTransferOfRightsOfRecoveryAgainstOthers' AS patterncode,
   'usd' AS currency,
   trim(PolicyNumber) AS pmt_payloadid
FROM Line_level_cond_CA
WHERE trim(FormId) in ('CA 04 44', 'PCA 05 04')
'''
try:
  CA7condsched_final_updated = spark.sql(CA7CommAutoLinecondsched_trans_query_updated)
  CA7condsched_final_updated = CA7condsched_final_updated.withColumn("pmt_id", CA7condsched_final_updated.pmt_id.substr(1, 99))
  CA7condsched_final_updated.createOrReplaceTempView("CA7condsched_final_updated")
  print(CA7condsched_final_updated.count())
  display(CA7condsched_final_updated)
except Exception as e:
  #logger.info("error loading CA7HAU_final_updated: {}".format(e)) 
  sys.exit(1)

# COMMAND ----------

CA7condsched_final_updated.createOrReplaceTempView("CA7condsched_final_updated")

pp_activity.createOrReplaceTempView("pp_activity")

sql_query = """
SELECT
    pp.pmt_id,
    pp.pmt_parent,

    CASE
        WHEN ma.pmt_payloadid IS NOT NULL THEN
            CASE
                WHEN pp.activitynotification_ext IS NULL OR trim(pp.activitynotification_ext) = ''
                THEN 'Please create an activity for scheduled condition'
                ELSE concat(pp.activitynotification_ext, '\\nPlease create an activity for scheduled condition')
            END
        ELSE pp.activitynotification_ext
    END AS activitynotification_ext,
    pp.appeventsyncstatus,
    pp.basestate,
    pp.claimhandlingentity_ext,
    pp.depositamount_cur,
    pp.editeffectivedate,
    pp.estimatedpremium_amt,
    pp.estimatedpremium_cur,

    pp.inputsource_ext,
    pp.invoicingmethod,

      pp.periodend,
        pp.periodstart,

pp.producingsoc_ext,

         pp.renewalconversionflag_ext,

        pp.totpremiumincovcurrencyrpt_cur,
        pp.totalcostincovcurrencyrpt_cur,
        pp.trancostincovcurrencyrpt_cur,
         pp.profitcenter_ext,

        pp.producercodeofrecord,
       pp.uwcompany,
      pp.pmt_payloadid,

 pp.specialdigits_ext,

  pp.subaccountnumber_ext

FROM pp_activity pp
LEFT JOIN CA7condsched_final_updated ma
    ON upper(trim(pp.pmt_payloadid)) = upper(trim(ma.pmt_payloadid))
"""

pp_activity_schedcond_updated = spark.sql(sql_query)
display(pp_activity_schedcond_updated)

# COMMAND ----------

eval(exec_cmd_framework)('truncate table public.policyperiod')
pp_activity_updated.write.jdbc(url=jdbc_url_framework, table='policyperiod', mode='append', properties=properties)
eval(exec_cmd_pmtin)('truncate table public.policyperiod')
pp_manual_excl=execute_select_Framework('select * from policyperiod')
pp_manual_excl.write.jdbc(url=jdbc_url_pmtin, table='policyperiod', mode='append', properties=properties)


# COMMAND ----------

eval(exec_cmd_pmtin)('truncate table public.CA7CommAutoLineSchedCond')

CA7condsched_final_updated.write.jdbc(url=jdbc_url_pmtin, table= 'CA7CommAutoLineSchedCond', mode='append', properties=properties)

# COMMAND ----------

