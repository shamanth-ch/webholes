# Databricks notebook source
# DBTITLE 1,Run the configuration Notebook
# MAGIC %run ../configuration/configs

# COMMAND ----------

# DBTITLE 1,Run the configuration Notebook
# MAGIC %run ../configuration/postgres

# COMMAND ----------

# DBTITLE 1,Run the parameters
import logging
import sys
import os

LOG_FILE = 'etl_logfile.log'
LOG_FORMAT = '%(asctime)s %(levelname)s: %(message)s'

def get_etl_logger(name):
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    if logger.hasHandlers():
        logger.handlers.clear()
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.INFO)
    formatter = logging.Formatter(LOG_FORMAT)
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)
    file_handler = logging.FileHandler(LOG_FILE, mode='a')
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    return logger

logger = get_etl_logger('CA7HAU')
logger.info(f"Logging initialized. Log file location: {os.path.abspath(LOG_FILE)}")

def log_info_to_file(message):
    with open(LOG_FILE, 'a') as f:
        import datetime
        timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        f.write(f"{timestamp} INFO: {message}\n")

# COMMAND ----------

# Cell Purpose: Set up Databricks widgets and retrieve job context for tracking ETL runs.
# Business Context: Enables parameterization and job tracking for the ETL pipeline, supporting both interactive and scheduled job runs in Databricks.
"""
This cell creates widgets for job_id and job_run_id, retrieves the current notebook context, and extracts job and run IDs for logging and audit purposes.
"""
# Create widgets for job_id and job_run_id for parameterization and job tracking
# These widgets allow passing parameters when running as a Databricks job
# The job_id is used to identify the specific job, while job_run_id is used to track the execution of that job.

dbutils.widgets.text("job_id", "")
dbutils.widgets.text("job_run_id", "")

# Get the current notebook context for extracting job and run metadata
# This context provides information about the job execution environment, including job IDs and notebook path.
context = dbutils.notebook.entry_point.getDbutils().notebook().getContext()

# Extract jobId and jobRunId objects from context (may be Option types)
# These IDs are crucial for tracking the execution of the ETL process.
job_id_obj = context.jobId()          # Option type: may or may not be defined
job_run_id_obj = context.jobRunId()   # Option type: may or may not be defined

# Retrieve the full path to the current notebook for logging purposes
notebook_path = context.notebookPath().get() # Full path to the current notebook
# Extract the notebook name from the path for easier identification in logs
notebook_name = notebook_path.split('/')[-1]   # Extract the notebook name from the path

def safe_get_option(option_obj):
    """
    Safely extract a value from a Databricks Option object.
    Parameters:
        option_obj: Option (Databricks Java/Scala Option type)
            The object to extract the value from.
    Returns:
        value or None: The value if defined, else None.
    Exceptions:
        Catches all exceptions to avoid breaking job context extraction.
        This ensures that even if an error occurs, the job can continue running without interruption.
    """
    try:
        if option_obj.isDefined():
            return option_obj.get()  # Return the value if defined
        else:
            return None  # Return None if not defined
    except Exception:
        return None  # Return None in case of any exception

# Use the safe_get_option to retrieve the values, defaulting to 'Manual' if not found
# This provides a fallback mechanism for logging and auditing purposes.
job_id = safe_get_option(job_id_obj) or "Manual"    # Used for logging and audit
job_run_id = safe_get_option(job_run_id_obj) or "Manual"

# Output the retrieved IDs for debugging and traceability
# This print statement helps in verifying that the correct IDs are being used in the ETL process.
print(f"Job ID: {job_id}, Job Run ID: {job_run_id}")
logger.info(f"Job context: job_id={job_id}, job_run_id={job_run_id}, notebook={notebook_name}")
log_info_to_file(f"Job context: job_id={job_id}, job_run_id={job_run_id}, notebook={notebook_name}")

# Redefine widgets with resolved values for downstream cells (ensures consistency)
# This step ensures that the widgets reflect the actual job and run IDs for any subsequent operations.
dbutils.widgets.text("job_id", str(job_id)) 
dbutils.widgets.text("job_run_id", str(job_run_id))

# COMMAND ----------

# DBTITLE 1,ETL query for Hired Auto Data
log_info_to_file("[START] Extraction for HAU_data...")
logger.info("[START] Extraction for HAU_data...")
try:
  HAU_query = fetch_query_from_table('ca7hau')
  logger.info(f"HAU_query: {HAU_query}")
  log_info_to_file(f"HAU_query: {HAU_query}")
  HAU_data = eval(exec_select_landing)(HAU_query)
  HAU_data.createOrReplaceTempView("HAU_data")
  row_count = HAU_data.count()
  logger.info(f"HAU_data loaded with {row_count} rows.")
  log_info_to_file(f"HAU_data loaded with {row_count} rows.")
  logger.info(f"HAU_data schema: {HAU_data.schema}")
  log_info_to_file(f"HAU_data schema: {HAU_data.schema}")
  display(HAU_data)
  logger.info("[END] Extraction for HAU_data.")
  log_info_to_file("[END] Extraction for HAU_data.")
except Exception as e:
  logger.error(f"Error loading HAU_data: {e}", exc_info=True)
  log_info_to_file(f"Error loading HAU_data: {str(e)}")
  sys.exit(1)

# COMMAND ----------

ca7jurisdiction_view = execute_select_PMTIN("select * from ca7jurisdiction")
ca7jurisdiction_view.createOrReplaceTempView("ca7jurisdiction_view")

# COMMAND ----------

# DBTITLE 1,CA7HAU table Transformation
log_info_to_file("[START] Transformation for CA7HAU_final...")
logger.info("[START] Transformation for CA7HAU_final...")
CA7HAU_final_query = """
    SELECT DISTINCT
           concat('CA7HAU:',trim(PolicyNumber), '-',trim(StateCode)) AS pmt_id,
           concat('CA7CAL_',trim(PolicyNumber)) AS pmt_parent,
           'usd' AS preferredcoveragecurrency,
           'usd' AS preferredsettlementcurrency,
           trim(HAU_data.StateCode) AS state,
           trim(HAU_data.ZipCode) AS zipcode,
           trim(PolicyNumber) AS pmt_payloadid
    FROM HAU_data
     INNER JOIN ca7jurisdiction_view
      ON trim(HAU_data.PolicyNumber) = trim(ca7jurisdiction_view.pmt_payloadid)
      AND ca7jurisdiction_view.hiredauto = 'Yes'
      AND trim(HAU_data.StateCode) = trim(ca7jurisdiction_view.state)
"""
try:
  CA7HAU_final = spark.sql(CA7HAU_final_query)
  CA7HAU_final.createOrReplaceTempView("CA7HAU_final")
  row_count = CA7HAU_final.count()
  logger.info(f"CA7HAU_final loaded with {row_count} rows.")
  log_info_to_file(f"CA7HAU_final loaded with {row_count} rows.")
  logger.info(f"CA7HAU_final schema: {CA7HAU_final.schema}")
  log_info_to_file(f"CA7HAU_final schema: {CA7HAU_final.schema}")
  display(CA7HAU_final)
  logger.info("[END] Transformation for CA7HAU_final.")
  log_info_to_file("[END] Transformation for CA7HAU_final.")
except Exception as e:
  logger.error(f"Error loading CA7HAU_final: {e}", exc_info=True)
  log_info_to_file(f"Error loading CA7HAU_final: {str(e)}")
  sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Writing CA7HUA Table in PMTIN
try:
    row_count = CA7HAU_final.count()
    logger.info(f"[START] Writing {row_count} rows to table 'ca7hau' in PMTIN.")
    log_info_to_file(f"[START] Writing {row_count} rows to table 'ca7hau' in PMTIN.")
    logger.info(f"CA7HAU_final schema: {CA7HAU_final.schema}")
    log_info_to_file(f"CA7HAU_final schema: {CA7HAU_final.schema}")
    write_and_log_pmtin(
        CA7HAU_final,
        table_name="ca7hau",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
    )
    logger.info("[END] Successfully wrote CA7HAU_final to table 'ca7hau'.")
    log_info_to_file("[END] Successfully wrote CA7HAU_final to table 'ca7hau'.")
except Exception as e:
    logger.error(f"Error writing CA7HAU_final to table 'ca7hau'", exc_info=True)
    log_info_to_file(f"Error writing CA7HAU_final to table 'ca7hau': {str(e)}")
    sys.exit(1)

# COMMAND ----------

