# Databricks notebook source
# MAGIC %run ../configuration/configs

# COMMAND ----------

# MAGIC %run ../configuration/postgres

# COMMAND ----------

# Logger setup for tracking errors and process info in this notebook
import logging
import sys

logger = logging.getLogger('ca7jurcov_df')
logger.setLevel(logging.INFO)

# COMMAND ----------

eval(exec_cmd_pmtin)('truncate table public.CA7StateExcl')
eval(exec_cmd_pmtin)('truncate table public.CA7StateSchedExcl')

# COMMAND ----------

# DBTITLE 1,ETL query for Jurisdiction Exclusion
ca7jurexcl_query="""
/* -------------------------------------------------------------------------------------------------------------- */
/* Sprint_6_Form PCA 06 05 - Florida Limited Exclusiong of Named Driver                                           */
/* 10/15/2025 (pstemp)                                                                                            */
/* Views used:                                                                                                    */
/* ViewCurPic_AUFormFillin                                                                                        */
/* NOTE: This is 1 to many due to multiple pages in AuFormFillin                                                  */
/* -------------------------------------------------------------------------------------------------------------- */

/* -------------------------------------------------------------------------------------------------------------- */
/* First SQL returns all states for the forms needed                                                              */
/* -------------------------------------------------------------------------------------------------------------- */
SELECT DISTINCT
/* ---------------------- */
/* CoPolicyPointer fields */
/* ---------------------- */
P."SystemAssignId",
P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
CAST(RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",
P."PolicyEffDt",

/* -------------------------------- */
/* ViewCurPic_CoPolicyDetail Fields */
/* -------------------------------- */
CoPolicyDetail."PredStateCd" AS "PredominantStateCode",

/* --------------------------- */
/* ViewCurPic_AuStInput fields */
/* --------------------------- */
AuStInput."StateCd",
/* ------------------------------------- */
/* ViewCurPic_AUSelectedForm fields      */
/* ------------------------------------- */
RTRIM(AUSelectedForm."FormId") AS "FormId",
AUSelectedForm."FormEdCd" AS "FormEditionCode",
AUSelectedForm."FormDescTx" AS "FormDescription",

/* ------------------------------------- */
/* ViewCurPic_AUFormFillin fields        */
/* ------------------------------------- */
AUFormFillin."FillinTx" AS "PersonOrOrganization",
AUFormFillin."PageNo" AS "PageNumber",
AUFormFillin."OccurrenceNo" AS "OccurenceNumber",
AUFormFillin."FillinTx" AS "NameOfExcludedDriver"

FROM Policy P1
INNER JOIN CoPolicyPointer P
   ON P."SystemAssignId" = P1."SourceSystemId"
INNER JOIN ViewCurPic_CoPolicyDetail CoPolicyDetail
   ON P."SystemAssignId" = CoPolicyDetail."SystemAssignId"
LEFT JOIN ViewCurPic_AuPolFreeformInput AuPolFreeformInput
   ON P."SystemAssignId" = AuPolFreeformInput."SystemAssignId"
INNER JOIN ViewCurPic_AuStInput AuStInput
   ON P."SystemAssignId" = AuStInput."SystemAssignId"
LEFT JOIN ViewCurPic_AUSelectedForm AUSelectedForm
   ON P."SystemAssignId" = AUSelectedForm."SystemAssignId"
   AND AuStInput."StateCd" = AUSelectedForm."StateCd"
LEFT JOIN ViewCurPic_AUFormFillin AUFormFillin
   ON P."SystemAssignId" = AUFormFillin."SystemAssignId"
   AND AUSelectedForm."FormId" = AUFormFillin."FormId"
   AND AUSelectedForm."FormEdCd" = AUFormFillin."FormEdCd"

WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
--AND P1."LOB" IN ('AU', 'GR', 'TU')
AND RTRIM(AUSelectedForm."FormId") IN (
  'PCA 06 05','PCA 20 25','CA 05 31','PCA 20 54','CA 04 33','PCA 20 55','PCA 20 26','PCA 20 30',
  'CA 05 14','CA 99 11','CA 26 33','PCA 20 33','PCA 06 08','PCA 06 03','PCA 06 13 VA',
  'PCA 20 36','PCA 06 06','PCA 06 07','PCA 06 09','PCA 20 56','PCA 51 07','PCA 06 05','PCA 06 04',
  'PCA 06 12','PCA 06 10'
)

ORDER BY "PolicyNumber", "StateCd", "FormId", "PageNumber", "OccurrenceNo"
"""
try:
  # Execute the query and create a temp view for downstream use
  ca7jurexcl_df = eval(exec_select_landing)(ca7jurexcl_query)
  ca7jurexcl_df.createOrReplaceTempView("ca7jurexcl_df")  # Create a temporary view for further processing
  print(ca7jurexcl_df.count())  # Print the count of records retrieved
  display(ca7jurexcl_df)  # Display the results
except Exception as e:
  # Log the error and exit if there is an issue loading the data
  logger.info("error ca7jurexcl_df: {}".format(e)) 
  sys.exit(1)

# COMMAND ----------

jur_parent = execute_select_PMTIN("select * from ca7jurisdiction")
jur_parent.createOrReplaceTempView("jur_parent")
display(jur_parent)

# COMMAND ----------

# DBTITLE 1,transformation of CA7StateExcl for IL 01 93 FormId
COSelectedForm_FormId_query = """
SELECT CONCAT('CA7StateExcl:', TRIM("PolicyNumber"), '_',
	CASE WHEN TRIM("FormId") = 'IL 01 93' THEN 'CA7OKExclOfTrustorAsNamedInsured' END,'-', TRIM("StateCd")) AS pmt_id,
	CONCAT('Jur:', TRIM("PolicyNumber"), '-', TRIM("StateCd")) AS pmt_parent,
	CASE WHEN TRIM("FormId") = 'IL 01 93' THEN 'CA7OKExclOfTrustorAsNamedInsured' END AS codeidentifier,
	'usd' AS currency,
    TRIM("PolicyNumber") AS pmt_payloadid
    FROM(
	
SELECT DISTINCT 
  P."SystemAssignId",
  P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
  CAST(RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",
  P."PolicyEffDt",
  CoPolicyDetail."PredStateCd" AS "PredominantStateCode",
  AuStInput."StateCd",
  RTRIM(COSelectedForm."FormId") AS "FormId",
  AUFormFillin."FillinTx" AS "PersonOrOrganization",
  AUFormFillin."PageNo" AS "PageNumber",
  AUFormFillin."OccurrenceNo" AS "OccurenceNumber",
  AUFormFillin."FillinTx" AS "NameOfExcludedDriver"
FROM Policy P1
INNER JOIN CoPolicyPointer P
   ON P."SystemAssignId" = P1."SourceSystemId"
INNER JOIN ViewCurPic_CoPolicyDetail CoPolicyDetail
   ON P."SystemAssignId" = CoPolicyDetail."SystemAssignId"
LEFT JOIN ViewCurPic_AuPolFreeformInput AuPolFreeformInput
   ON P."SystemAssignId" = AuPolFreeformInput."SystemAssignId"
INNER JOIN ViewCurPic_AuStInput AuStInput
   ON P."SystemAssignId" = AuStInput."SystemAssignId"
LEFT JOIN ViewCurPic_COSelectedForm COSelectedForm
   ON P."SystemAssignId" = COSelectedForm."SystemAssignId"
   AND AuStInput."StateCd" = COSelectedForm."StateCd"
LEFT JOIN ViewCurPic_AUFormFillin AUFormFillin
   ON P."SystemAssignId" = AUFormFillin."SystemAssignId"
   AND COSelectedForm."FormId" = AUFormFillin."FormId"
   AND COSelectedForm."FormEdCd" = AUFormFillin."FormEdCd"
WHERE RTRIM(COSelectedForm."FormId") IN ('IL 01 93')
ORDER BY "PolicyNumber", "StateCd", "FormId", "PageNumber", "OccurenceNumber"
)
"""
try:
  # Execute the query and create a temp view for downstream use
  COSelectedForm_FormId_data = eval(exec_select_landing)(COSelectedForm_FormId_query)
  COSelectedForm_FormId_data.createOrReplaceTempView("COSelectedForm_FormId_data")  # Create a temporary view for further processing
  print(COSelectedForm_FormId_data.count())  # Print the count of records retrieved
  display(COSelectedForm_FormId_data)  # Display the results
except Exception as e:
  # Log the error and exit if there is an issue loading the data
  logger.info("error COSelectedForm_FormId_data: {}".format(e)) 
  sys.exit(1)

# COMMAND ----------

# DBTITLE 1,CA7StateExcl codeidentifier's for Jurisdiction Exclusion
CA7StateExcl_query="""
SELECT * FROM (
SELECT DISTINCT
    CONCAT('CA7StateExcl:', TRIM(PolicyNumber), '_',
        CASE 
            WHEN TRIM(FormId) = 'PCA 20 25' THEN 'CA7ILTotPolExcl_Ext'
            WHEN TRIM(FormId) = 'CA 05 31' THEN 'CA7ViralOrBacterialInfectionsExclForCovrdAutosLiab'
            WHEN TRIM(FormId) = 'PCA 20 54' THEN 'CA7ILAbsMlstnSxlMscndt_Ext'
            WHEN TRIM(FormId) = 'CA 04 33' THEN 'CA7PollutionExcl'
            WHEN TRIM(FormId) = 'PCA 20 55' THEN 'CA7TXAbsMlstnSxlMscndt_Ext'
            WHEN TRIM(FormId) = 'PCA 20 26' THEN 'CA7TxDsclsrAsbsts_Ext'
            WHEN TRIM(FormId) = 'PCA 20 30' THEN 'CA7AsbestosExclFL_Ext'
            WHEN TRIM(FormId) = 'CA 05 14' THEN 'CA7TransportationNetworkServicesExcl'
            WHEN TRIM(FormId) = 'CA 26 33' THEN 'CA7AmendmentOfSingleInterestPolicyProvisionsTransp'
            WHEN TRIM(FormId) = 'PCA 20 33' THEN 'CA7AssaultOrBatteryExclusionFL_Ext'
            WHEN TRIM(FormId) = 'PCA 06 13' THEN 'CA7EmployersLiabExclTemporaryWorkerVA_Ext'
            WHEN TRIM(FormId) = 'PCA 20 36' THEN 'CA7InsrdAmndmntCA_Ext'
            WHEN TRIM(FormId) = 'PCA 06 09' THEN 'CA7ALPntvDmgExcl_Ext'
            WHEN TRIM(FormId) = 'PCA 20 56' THEN 'CA7VTAbsMlstnSxlMscndt_Ext'
            WHEN TRIM(FormId) = 'CA 99 11' THEN 'CA7ChangesDriverExcl'
        END,
        '-', TRIM(StateCd)
    ) AS pmt_id,
    CONCAT('Jur:', TRIM(PolicyNumber), '-', TRIM(StateCd)) AS pmt_parent,
    CASE 
        WHEN TRIM(FormId) = 'PCA 20 25' THEN 'CA7ILTotPolExcl_Ext'
        WHEN TRIM(FormId) = 'CA 05 31' THEN 'CA7ViralOrBacterialInfectionsExclForCovrdAutosLiab'
        WHEN TRIM(FormId) = 'PCA 20 54' THEN 'CA7ILAbsMlstnSxlMscndt_Ext'
        WHEN TRIM(FormId) = 'CA 04 33' THEN 'CA7PollutionExcl'
        WHEN TRIM(FormId) = 'PCA 20 55' THEN 'CA7TXAbsMlstnSxlMscndt_Ext'
        WHEN TRIM(FormId) = 'PCA 20 26' THEN 'CA7TxDsclsrAsbsts_Ext'
        WHEN TRIM(FormId) = 'PCA 20 30' THEN 'CA7AsbestosExclFL_Ext'
        WHEN TRIM(FormId) = 'CA 05 14' THEN 'CA7TransportationNetworkServicesExcl'
        WHEN TRIM(FormId) = 'CA 26 33' THEN 'CA7AmendmentOfSingleInterestPolicyProvisionsTransp'
        WHEN TRIM(FormId) = 'PCA 20 33' THEN 'CA7AssaultOrBatteryExclusionFL_Ext'
        WHEN TRIM(FormId) = 'PCA 06 13' THEN 'CA7EmployersLiabExclTemporaryWorkerVA_Ext'
        WHEN TRIM(FormId) = 'PCA 20 36' THEN 'CA7InsrdAmndmntCA_Ext'
        WHEN TRIM(FormId) = 'PCA 06 09' THEN 'CA7ALPntvDmgExcl_Ext'
        WHEN TRIM(FormId) = 'PCA 20 56' THEN 'CA7VTAbsMlstnSxlMscndt_Ext'
        WHEN TRIM(FormId) = 'CA 99 11' THEN 'CA7ChangesDriverExcl'
    END AS codeidentifier,
    'usd' AS currency,
    TRIM(PolicyNumber) AS pmt_payloadid
    FROM ca7jurexcl_df
    )
    WHERE codeidentifier IS NOT NULL
    UNION ALL
SELECT * FROM COSelectedForm_FormId_data

"""
try:
  # Execute the query and create a temp view for downstream use
  CA7StateExcl_data = spark.sql(CA7StateExcl_query)
  CA7StateExcl_data.createOrReplaceTempView("CA7StateExcl_data")  # Create a temporary view for further processing
  print(CA7StateExcl_data.count())  # Print the count of records retrieved
  display(CA7StateExcl_data)  # Display the results
except Exception as e:
  # Log the error and exit if there is an issue loading the data
  logger.info("error CA7StateExcl_data: {}".format(e)) 
  sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Writing data into PMTIN
# SQL to find mismatching pmt_parent, count null pmt_id, and check for duplicates for ca7statecov_ca7statecov_data
invalid_refs_sql = """
SELECT DISTINCT pmt_parent
FROM CA7StateExcl_data
WHERE pmt_parent NOT IN (
  SELECT DISTINCT pmt_id FROM jur_parent
)
"""

null_pmt_id_sql = """
SELECT COUNT(*) as null_count
FROM CA7StateExcl_data
WHERE pmt_id IS NULL
"""

duplicate_pmt_id_sql = """
SELECT pmt_id,pmt_parent,codeidentifier, COUNT(*) as cnt
FROM CA7StateExcl_data
GROUP BY pmt_id,pmt_parent,codeidentifier
HAVING COUNT(*) > 1
"""

invalid_refs = spark.sql(invalid_refs_sql)
null_pmt_id_count = spark.sql(null_pmt_id_sql).collect()[0]['null_count']
duplicate_pmt_ids = spark.sql(duplicate_pmt_id_sql)

if invalid_refs.count() == 0 and null_pmt_id_count == 0 and duplicate_pmt_ids.count() == 0:
    logger.info('referential integrity checks passed')
    logger.info('No Null pmt_id values found')
    logger.info('No duplicate pmt_id values found')

    CA7StateExcl_data.write.jdbc(url=jdbc_url_pmtin, table='CA7StateExcl', mode='append', properties=properties)
else:
    if invalid_refs.count() > 0:
        logger.error("Referential integrity issue: Some pmt_parent values do not exist in jur_parent.")
        for row in invalid_refs.collect():
            logger.error(f"Invalid pmt_parent: {row.pmt_parent}")
    if null_pmt_id_count > 0:
        logger.error(f"Null pmt_id values found in CA7StateExcl_data: {null_pmt_id_count}")
    if duplicate_pmt_ids.count() > 0:
        logger.error("Duplicate pmt_id values found in CA7StateExcl_data.")
        for row in duplicate_pmt_ids.collect():
            logger.error(f"Duplicate pmt_id: {row.pmt_id} with count: {row.cnt}")

# COMMAND ----------

# DBTITLE 1,CA7StateSchedExcl patterncode for Jurisdiction Exclusion
CA7StateSchedExcl_query="""
SELECT * FROM (
SELECT DISTINCT
    CONCAT('CA7StateSchedExcl:', TRIM(PolicyNumber),'_',
        CASE 
            WHEN TRIM(FormId) = 'CA 99 11' THEN 'CA7ChangesDriverExcl'
            WHEN TRIM(FormId) = 'PCA 06 08' THEN 'ziigq2r01rhlm7pdeda1uckk7a8'
            WHEN TRIM(FormId) = 'PCA 06 03' THEN 'zf7icd2t6fn8c01s187qtm5qn2a'
            WHEN TRIM(FormId) = 'PCA 06 06' THEN 'zv3gklq0hck27bg16bpa69kfrb9'
            WHEN TRIM(FormId) = 'PCA 06 07' THEN 'z5njug6nuashle0oekdmuo6vjua'
            WHEN TRIM(FormId) = 'PCA 51 07' THEN 'za9i415mslnvq6bk9u3ckgt67ja'
            WHEN TRIM(FormId) = 'PCA 06 05' THEN 'zp1gc6ig22p3o03snr05bj4v6ub'
            WHEN TRIM(FormId) = 'PCA 06 04' THEN 'zoahg61lkc5cc7ilfhjrv0hflu9'
            WHEN TRIM(FormId) = 'PCA 06 12' THEN 'ztfgue7lrrj312k500k81kmtrib'
            WHEN TRIM(FormId) = 'PCA 06 10' THEN 'zkkievkqf8g7gdv3r10s6srtuvb'
        END,
        '-', TRIM(StateCd)
    ) AS pmt_id,
    CONCAT('Jur:', TRIM(PolicyNumber), '-', TRIM(StateCd)) AS pmt_parent,
    CASE 
            WHEN TRIM(FormId) = 'CA 99 11' THEN 'CA7ChangesDriverExcl'
            WHEN TRIM(FormId) = 'PCA 06 08' THEN 'ziigq2r01rhlm7pdeda1uckk7a8'
            WHEN TRIM(FormId) = 'PCA 06 03' THEN 'zf7icd2t6fn8c01s187qtm5qn2a'
            WHEN TRIM(FormId) = 'PCA 06 06' THEN 'zv3gklq0hck27bg16bpa69kfrb9'
            WHEN TRIM(FormId) = 'PCA 06 07' THEN 'z5njug6nuashle0oekdmuo6vjua'
            WHEN TRIM(FormId) = 'PCA 51 07' THEN 'za9i415mslnvq6bk9u3ckgt67ja'
            WHEN TRIM(FormId) = 'PCA 06 05' THEN 'zp1gc6ig22p3o03snr05bj4v6ub'
            WHEN TRIM(FormId) = 'PCA 06 04' THEN 'zoahg61lkc5cc7ilfhjrv0hflu9'
            WHEN TRIM(FormId) = 'PCA 06 12' THEN 'ztfgue7lrrj312k500k81kmtrib'
            WHEN TRIM(FormId) = 'PCA 06 10' THEN 'zkkievkqf8g7gdv3r10s6srtuvb'
        END AS patterncode,
    'usd' AS currency,
    'usd' AS preferredsettlementcurrency,
    TRIM(PolicyNumber) AS pmt_payloadid
    FROM ca7jurexcl_df
    )
    WHERE patterncode IS NOT NULL

"""
try:
  # Execute the query and create a temp view for downstream use
  CA7StateSchedExcl_data = spark.sql(CA7StateSchedExcl_query)
  CA7StateSchedExcl_data.createOrReplaceTempView("CA7StateSchedExcl_data")  # Create a temporary view for further processing
  print(CA7StateSchedExcl_data.count())  # Print the count of records retrieved
  display(CA7StateSchedExcl_data)  # Display the results
except Exception as e:
  # Log the error and exit if there is an issue loading the data
  logger.info("error CA7StateSchedExcl_data: {}".format(e)) 
  sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Writing CA7StateSchedExcl in PMTIN
# SQL to find mismatching pmt_parent, count null pmt_id, and check for duplicates for ca7statecov_ca7statecov_data
invalid_refs_sql = """
SELECT DISTINCT pmt_parent
FROM CA7StateSchedExcl_data
WHERE pmt_parent NOT IN (
  SELECT DISTINCT pmt_id FROM jur_parent
)
"""

null_pmt_id_sql = """
SELECT COUNT(*) as null_count
FROM CA7StateSchedExcl_data
WHERE pmt_id IS NULL
"""

duplicate_pmt_id_sql = """
SELECT pmt_id,pmt_parent,patterncode, COUNT(*) as cnt
FROM CA7StateSchedExcl_data
GROUP BY pmt_id,pmt_parent,patterncode
HAVING COUNT(*) > 1
"""

invalid_refs = spark.sql(invalid_refs_sql)
null_pmt_id_count = spark.sql(null_pmt_id_sql).collect()[0]['null_count']
duplicate_pmt_ids = spark.sql(duplicate_pmt_id_sql)

if invalid_refs.count() == 0 and null_pmt_id_count == 0 and duplicate_pmt_ids.count() == 0:
    logger.info('referential integrity checks passed')
    logger.info('No Null pmt_id values found')
    logger.info('No duplicate pmt_id values found')

    CA7StateSchedExcl_data.write.jdbc(url=jdbc_url_pmtin, table='CA7StateSchedExcl', mode='append', properties=properties)
else:
    if invalid_refs.count() > 0:
        logger.error("Referential integrity issue: Some pmt_parent values do not exist in jur_parent.")
        for row in invalid_refs.collect():
            logger.error(f"Invalid pmt_parent: {row.pmt_parent}")
    if null_pmt_id_count > 0:
        logger.error(f"Null pmt_id values found in CA7StateSchedExcl_data: {null_pmt_id_count}")
    if duplicate_pmt_ids.count() > 0:
        logger.error("Duplicate pmt_id values found in CA7StateSchedExcl_data.")
        for row in duplicate_pmt_ids.collect():
            logger.error(f"Duplicate pmt_id: {row.pmt_id} with count: {row.cnt}")

# COMMAND ----------

# DBTITLE 1,Transformation of _CA7NotLiableForAccidentsOrLossesWhileACovrdAutoIsD for CA7StateSchedExclItem table
# CA7StateSchedExclItem_query = """
#     SELECT DISTINCT
#         concat ('CA7StateSchedExclItem:', trim(PolicyNumber),'_CA7NotLiableForAccidentsOrLossesWhileACovrdAutoIsD') AS pmt_id,
#         CONCAT('CA7StateSchedExcl:', TRIM(PolicyNumber),'_','CA7ChangesDriverExcl','-',TRIM(StateCd)) AS pmt_parent,
#         'CA7NotLiableForAccidentsOrLossesWhileACovrdAutoIsD' AS stringcol1,
#         'usd' AS preferredcoveragecurrency,
#         'usd' AS preferredsettlementcurrency,
#         TRIM(PolicyNumber) AS pmt_payloadid
#     FROM ca7jurexcl_df
#     WHERE TRIM(FormId) = 'CA 99 11'
# """
# try:
#   # Execute the query and create a temp view for downstream use
#   CA7StateSchedExclItem_data = spark.sql(CA7StateSchedExclItem_query)
#   CA7StateSchedExclItem_data.createOrReplaceTempView("CA7StateSchedExclItem_data")  # Create a temporary view for further processing
#   print(CA7StateSchedExclItem_data.count())  # Print the count of records retrieved
#   display(CA7StateSchedExclItem_data)  # Display the results
# except Exception as e:
#   # Log the error and exit if there is an issue loading the data
#   logger.info("error CA7StateSchedExclItem_data: {}".format(e)) 
#   sys.exit(1)

# COMMAND ----------

# # SQL to find mismatching pmt_parent, count null pmt_id, and check for duplicates for ca7statecov_ca7statecov_data
# invalid_refs_sql = """
# SELECT DISTINCT pmt_parent
# FROM CA7StateSchedExclItem_data
# WHERE pmt_parent NOT IN (
#   SELECT DISTINCT pmt_id FROM CA7StateSchedExcl_data
# )
# """

# null_pmt_id_sql = """
# SELECT COUNT(*) as null_count
# FROM CA7StateSchedExclItem_data
# WHERE pmt_id IS NULL
# """

# duplicate_pmt_id_sql = """
# SELECT pmt_id,pmt_parent,stringcol1, COUNT(*) as cnt
# FROM CA7StateSchedExclItem_data
# GROUP BY pmt_id,pmt_parent,stringcol1
# HAVING COUNT(*) > 1
# """

# invalid_refs = spark.sql(invalid_refs_sql)
# null_pmt_id_count = spark.sql(null_pmt_id_sql).collect()[0]['null_count']
# duplicate_pmt_ids = spark.sql(duplicate_pmt_id_sql)

# if invalid_refs.count() == 0 and null_pmt_id_count == 0 and duplicate_pmt_ids.count() == 0:
#     logger.info('referential integrity checks passed')
#     logger.info('No Null pmt_id values found')
#     logger.info('No duplicate pmt_id values found')

#     CA7StateSchedExclItem_data.write.jdbc(url=jdbc_url_pmtin, table='CA7StateSchedExclItem', mode='append', properties=properties)
# else:
#     if invalid_refs.count() > 0:
#         logger.error("Referential integrity issue: Some pmt_parent values do not exist in CA7StateSchedExcl_data.")
#         for row in invalid_refs.collect():
#             logger.error(f"Invalid pmt_parent: {row.pmt_parent}")
#     if null_pmt_id_count > 0:
#         logger.error(f"Null pmt_id values found in CA7StateSchedExclItem_data: {null_pmt_id_count}")
#     if duplicate_pmt_ids.count() > 0:
#         logger.error("Duplicate pmt_id values found in CA7StateSchedExclItem_data.")
#         for row in duplicate_pmt_ids.collect():
#             logger.error(f"Duplicate pmt_id: {row.pmt_id} with count: {row.cnt}")