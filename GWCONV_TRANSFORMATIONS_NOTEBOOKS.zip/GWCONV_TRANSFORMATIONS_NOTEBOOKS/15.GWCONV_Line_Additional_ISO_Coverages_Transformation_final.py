# Databricks notebook source
import logging
import sys
import os

LOG_FILE = 'etl_logfile.log'
LOG_FORMAT = '%(asctime)s %(levelname)s: %(message)s'

def get_etl_logger(name):
    logger = logging.getLogger(name)
    
    logger.setLevel(logging.INFO)
    if logger.hasHandlers():
        logger.handlers.clear()
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.INFO)
    formatter = logging.Formatter(LOG_FORMAT)
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)
    file_handler = logging.FileHandler(LOG_FILE, mode='a')
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    return logger

logger = get_etl_logger('ca7commautolinecov')
logger.info(f"Logging initialized. Log file location: {os.path.abspath(LOG_FILE)}")

def log_info_to_file(message):
    with open(LOG_FILE, 'a') as f:
        import datetime
        timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        f.write(f"{timestamp} INFO: {message}\n")

# COMMAND ----------

# Cell Purpose: Set up Databricks widgets and retrieve job context for tracking ETL runs.
# Business Context: Enables parameterization and job tracking for the ETL pipeline, supporting both interactive and scheduled job runs in Databricks.
"""
This cell creates widgets for job_id and job_run_id, retrieves the current notebook context, and extracts job and run IDs for logging and audit purposes.
"""
# Create widgets for job_id and job_run_id for parameterization and job tracking
# These widgets allow passing parameters when running as a Databricks job
# The job_id is used to identify the specific job, while job_run_id is used to track the execution of that job.

dbutils.widgets.text("job_id", "")
dbutils.widgets.text("job_run_id", "")

# Get the current notebook context for extracting job and run metadata
# This context provides information about the job execution environment, including job IDs and notebook path.
context = dbutils.notebook.entry_point.getDbutils().notebook().getContext()

# Extract jobId and jobRunId objects from context (may be Option types)
# These IDs are crucial for tracking the execution of the ETL process.
job_id_obj = context.jobId()          # Option type: may or may not be defined
job_run_id_obj = context.jobRunId()   # Option type: may or may not be defined

# Retrieve the full path to the current notebook for logging purposes
notebook_path = context.notebookPath().get() # Full path to the current notebook
# Extract the notebook name from the path for easier identification in logs
notebook_name = notebook_path.split('/')[-1]   # Extract the notebook name from the path

def safe_get_option(option_obj):
    """
    Safely extract a value from a Databricks Option object.
    Parameters:
        option_obj: Option (Databricks Java/Scala Option type)
            The object to extract the value from.
    Returns:
        value or None: The value if defined, else None.
    Exceptions:
        Catches all exceptions to avoid breaking job context extraction.
        This ensures that even if an error occurs, the job can continue running without interruption.
    """
    try:
        if option_obj.isDefined():
            return option_obj.get()  # Return the value if defined
        else:
            return None  # Return None if not defined
    except Exception:
        return None  # Return None in case of any exception

# Use the safe_get_option to retrieve the values, defaulting to 'Manual' if not found
# This provides a fallback mechanism for logging and auditing purposes.
job_id = safe_get_option(job_id_obj) or "Manual"    # Used for logging and audit
job_run_id = safe_get_option(job_run_id_obj) or "Manual"

# Output the retrieved IDs for debugging and traceability
# This print statement helps in verifying that the correct IDs are being used in the ETL process.
print(f"Job ID: {job_id}, Job Run ID: {job_run_id}")

# Redefine widgets with resolved values for downstream cells (ensures consistency)
# This step ensures that the widgets reflect the actual job and run IDs for any subsequent operations.
dbutils.widgets.text("job_id", str(job_id)) 
dbutils.widgets.text("job_run_id", str(job_run_id))

# COMMAND ----------

# DBTITLE 1,Run the Configuration
# MAGIC %run ../configuration/configs
# MAGIC

# COMMAND ----------

# DBTITLE 1,Run the Configuration
# MAGIC %run ../configuration/postgres

# COMMAND ----------

# MAGIC %md
# MAGIC ##Commercial Auto Line Additional ISO Coverages

# COMMAND ----------

# DBTITLE 1,ETL Query for Commercial Auto Line Additional ISO Coverages

try:
  Additional_ISO_Coverage_query = fetch_query_from_table('additionalcommautoline_query')
  logger.info("[START] Extraction for Additional_ISO_Coverage_data...")
  log_info_to_file("[START] Extraction for Additional_ISO_Coverage_data...")
  logger.info(f"Additional_ISO_Coverage_query: {Additional_ISO_Coverage_query}")
  log_info_to_file(f"Additional_ISO_Coverage_query: {Additional_ISO_Coverage_query}")
  Additional_ISO_Coverage_data = eval(exec_select_landing)(Additional_ISO_Coverage_query)
  Additional_ISO_Coverage_data.createOrReplaceTempView("Additional_ISO_Coverage_data")
  row_count = Additional_ISO_Coverage_data.count()
  logger.info(f"Additional_ISO_Coverage_data loaded with {row_count} rows.")
  log_info_to_file(f"Additional_ISO_Coverage_data loaded with {row_count} rows.")
  logger.info(f"Additional_ISO_Coverage_data schema: {Additional_ISO_Coverage_data.schema}")
  log_info_to_file(f"Additional_ISO_Coverage_data schema: {Additional_ISO_Coverage_data.schema}")
  logger.info("[END] Extraction for Additional_ISO_Coverage_data.")
  log_info_to_file("[END] Extraction for Additional_ISO_Coverage_data.")
except Exception as e:
  logger.error(f"Error loading Additional_ISO_Coverage_data: {e}", exc_info=True)
  log_info_to_file(f"Error loading Additional_ISO_Coverage_data: {str(e)}")
  sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Transformation of CA7DOCCovBroadCovForNamedIndivs CA7CommAutoLineSchedCov
CA7CommAutoLineSchedCov_CA7DOCCovBroadCovForNamedIndivs_trans_query = '''
    SELECT DISTINCT
        concat('CA7CommAutoLineSchedCov:',trim(PolicyNumber),'_','CA7DOCCovBroadCovForNamedIndivs') AS pmt_id,
        concat('CA7CAL_',trim(PolicyNumber)) AS pmt_parent,
        'CA7DOCCovBroadCovForNamedIndivs' AS patterncode,
        'usd' AS Currency,
        'usd' AS PreferredSettlementCurrency,
        trim(PolicyNumber) AS pmt_payloadid
    FROM Additional_ISO_Coverage_data
    WHERE trim(PredominantStateCode) IS NOT NULL AND trim(CoveragesApplicable) IS NOT NULL
'''

log_info_to_file("[START] Transformation for CA7CommAutoLineSchedCov_CA7DOCCovBroadCovForNamedIndivs_trans_data...")
logger.info("[START] Transformation for CA7CommAutoLineSchedCov_CA7DOCCovBroadCovForNamedIndivs_trans_data...")
try:
    logger.info(f"CA7CommAutoLineSchedCov_CA7DOCCovBroadCovForNamedIndivs_trans_query: {CA7CommAutoLineSchedCov_CA7DOCCovBroadCovForNamedIndivs_trans_query}")
    log_info_to_file(f"CA7CommAutoLineSchedCov_CA7DOCCovBroadCovForNamedIndivs_trans_query: {CA7CommAutoLineSchedCov_CA7DOCCovBroadCovForNamedIndivs_trans_query}")
    CA7CommAutoLineSchedCov_CA7DOCCovBroadCovForNamedIndivs_trans_data = spark.sql(CA7CommAutoLineSchedCov_CA7DOCCovBroadCovForNamedIndivs_trans_query)
    CA7CommAutoLineSchedCov_CA7DOCCovBroadCovForNamedIndivs_trans_data.createOrReplaceTempView("CA7CommAutoLineSchedCov_CA7DOCCovBroadCovForNamedIndivs_trans_data")
    row_count = CA7CommAutoLineSchedCov_CA7DOCCovBroadCovForNamedIndivs_trans_data.count()
    logger.info(f"CA7CommAutoLineSchedCov_CA7DOCCovBroadCovForNamedIndivs_trans_data loaded with {row_count} rows.")
    log_info_to_file(f"CA7CommAutoLineSchedCov_CA7DOCCovBroadCovForNamedIndivs_trans_data loaded with {row_count} rows.")
    logger.info(f"CA7CommAutoLineSchedCov_CA7DOCCovBroadCovForNamedIndivs_trans_data schema: {CA7CommAutoLineSchedCov_CA7DOCCovBroadCovForNamedIndivs_trans_data.schema}")
    log_info_to_file(f"CA7CommAutoLineSchedCov_CA7DOCCovBroadCovForNamedIndivs_trans_data schema: {CA7CommAutoLineSchedCov_CA7DOCCovBroadCovForNamedIndivs_trans_data.schema}")
    logger.info("[END] Transformation for CA7CommAutoLineSchedCov_CA7DOCCovBroadCovForNamedIndivs_trans_data.")
    log_info_to_file("[END] Transformation for CA7CommAutoLineSchedCov_CA7DOCCovBroadCovForNamedIndivs_trans_data.")
    display(CA7CommAutoLineSchedCov_CA7DOCCovBroadCovForNamedIndivs_trans_data)
except Exception as e:
    logger.error(f"error loading CA7CommAutoLineSchedCov_CA7DOCCovBroadCovForNamedIndivs_trans_data: {e}", exc_info=True)
    log_info_to_file(f"error loading CA7CommAutoLineSchedCov_CA7DOCCovBroadCovForNamedIndivs_trans_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Transformation of CA7LineSchedCovItem
CA7LineSchedCovItem_Drive_Other_Car_Coverage_trans_query = '''
    SELECT DISTINCT
        concat('CA7LineSchedCovItem:',trim(PolicyNumber),'_Drive_Other_Car_Coverage') AS pmt_id,
        concat('CA7CommAutoLineSchedCov:',trim(PolicyNumber),'_','CA7DOCCovBroadCovForNamedIndivs') AS pmt_parent,
        'usd' AS PreferredCoverageCurrency,
        'usd' AS PreferredSettlementCurrency,
        NULL AS optioncol4,
        NULL AS optioncol1,
        NULL AS optioncol5,
        NULL AS optioncol6,
        NULL AS optioncol2,
        NULL AS nonnegativeintcol1,
        NULL AS nonnegativeintcol2,
        NULL AS optioncol3,
        --ROW_NUMBER() OVER (PARTITION BY trim(PolicyNumber) ORDER BY trim(PolicyNumber)) AS ScheduleNumber,
        1 AS ScheduleNumber,
        trim(PolicyNumber) AS pmt_payloadid
    FROM Additional_ISO_Coverage_data
    WHERE trim(PredominantStateCode) IS NOT NULL AND trim(CoveragesApplicable) IS NOT NULL
'''

log_info_to_file("[START] Transformation for CA7LineSchedCovItem_Drive_Other_Car_Coverage_trans_data...")
logger.info("[START] Transformation for CA7LineSchedCovItem_Drive_Other_Car_Coverage_trans_data...")
try:
    logger.info(f"CA7LineSchedCovItem_Drive_Other_Car_Coverage_trans_query: {CA7LineSchedCovItem_Drive_Other_Car_Coverage_trans_query}")
    log_info_to_file(f"CA7LineSchedCovItem_Drive_Other_Car_Coverage_trans_query: {CA7LineSchedCovItem_Drive_Other_Car_Coverage_trans_query}")
    CA7LineSchedCovItem_Drive_Other_Car_Coverage_trans_data = spark.sql(CA7LineSchedCovItem_Drive_Other_Car_Coverage_trans_query)
    CA7LineSchedCovItem_Drive_Other_Car_Coverage_trans_data.createOrReplaceTempView("CA7LineSchedCovItem_Drive_Other_Car_Coverage_trans_data")
    row_count = CA7LineSchedCovItem_Drive_Other_Car_Coverage_trans_data.count()
    logger.info(f"CA7LineSchedCovItem_Drive_Other_Car_Coverage_trans_data loaded with {row_count} rows.")
    log_info_to_file(f"CA7LineSchedCovItem_Drive_Other_Car_Coverage_trans_data loaded with {row_count} rows.")
    logger.info(f"CA7LineSchedCovItem_Drive_Other_Car_Coverage_trans_data schema: {CA7LineSchedCovItem_Drive_Other_Car_Coverage_trans_data.schema}")
    log_info_to_file(f"CA7LineSchedCovItem_Drive_Other_Car_Coverage_trans_data schema: {CA7LineSchedCovItem_Drive_Other_Car_Coverage_trans_data.schema}")
    logger.info("[END] Transformation for CA7LineSchedCovItem_Drive_Other_Car_Coverage_trans_data.")
    log_info_to_file("[END] Transformation for CA7LineSchedCovItem_Drive_Other_Car_Coverage_trans_data.")
    display(CA7LineSchedCovItem_Drive_Other_Car_Coverage_trans_data)
except Exception as e:
    logger.error(f"error loading CA7LineSchedCovItem_Drive_Other_Car_Coverage_trans_data: {e}", exc_info=True)
    log_info_to_file(f"error loading CA7LineSchedCovItem_Drive_Other_Car_Coverage_trans_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Transformation of Liab,Medpay,OthColl,Coll,Uninsd CA7LineSchedCovItemCov
CA7LineSchedCovItemCov_Liab_Medpay_OthColl_Coll_Uninsd_trans_query = '''
    SELECT DISTINCT
        concat('CA7LineSchedCovItemCov:',trim(PolicyNumber),'_',
        CASE 
          WHEN trim(PredominantStateCode) IS NOT NULL AND trim(CoveragesApplicable) = '1' THEN 'CA7DOCCovBroadCovForNamedIndivsLiab'
          WHEN trim(PredominantStateCode) IS NOT NULL AND trim(CoveragesApplicable) = '2' THEN 'CA7DOCCovBroadCovForNamedIndivsMedPay'
          WHEN trim(PredominantStateCode) IS NOT NULL AND trim(CoveragesApplicable) = '4' THEN 'CA7DOCCovBroadCovForNamedIndivsOthThanCollision'
          WHEN trim(PredominantStateCode) IS NOT NULL AND trim(CoveragesApplicable) = '5' THEN 'CA7DOCCovBroadCovForNamedIndivsCollision'
          --WHEN trim(PredominantStateCode) IS NOT NULL AND trim(CoveragesApplicable) = '3' THEN 'CA7DOCCovBroadCovForNamedIndivsUninsuredMotorists'        
          END) AS pmt_id,
        concat('CA7LineSchedCovItem:',trim(PolicyNumber),'_Drive_Other_Car_Coverage') AS pmt_parent,
        CASE
          WHEN trim(PredominantStateCode) IS NOT NULL AND trim(CoveragesApplicable) = '1' THEN 'CA7DOCCovBroadCovForNamedIndivsLiab'
          WHEN trim(PredominantStateCode) IS NOT NULL AND trim(CoveragesApplicable) = '2' THEN 'CA7DOCCovBroadCovForNamedIndivsMedPay'
          WHEN trim(PredominantStateCode) IS NOT NULL AND trim(CoveragesApplicable) = '4' THEN 'CA7DOCCovBroadCovForNamedIndivsOthThanCollision'
          WHEN trim(PredominantStateCode) IS NOT NULL AND trim(CoveragesApplicable) = '5' THEN 'CA7DOCCovBroadCovForNamedIndivsCollision'
          --WHEN trim(PredominantStateCode) IS NOT NULL AND trim(CoveragesApplicable) = '3' THEN 'CA7DOCCovBroadCovForNamedIndivsUninsuredMotorists'
        END AS CodeIdentifier,
        'usd' AS currency,
        trim(PolicyNumber) AS pmt_payloadid
    FROM Additional_ISO_Coverage_data
    WHERE trim(PredominantStateCode) IS NOT NULL AND trim(CoveragesApplicable) IN (1,2,4,5)
'''

log_info_to_file("[START] Transformation for CA7LineSchedCovItemCov_Liab_Medpay_OthColl_Coll_Uninsd_trans_data...")
logger.info("[START] Transformation for CA7LineSchedCovItemCov_Liab_Medpay_OthColl_Coll_Uninsd_trans_data...")
try:
    logger.info(f"CA7LineSchedCovItemCov_Liab_Medpay_OthColl_Coll_Uninsd_trans_query: {CA7LineSchedCovItemCov_Liab_Medpay_OthColl_Coll_Uninsd_trans_query}")
    log_info_to_file(f"CA7LineSchedCovItemCov_Liab_Medpay_OthColl_Coll_Uninsd_trans_query: {CA7LineSchedCovItemCov_Liab_Medpay_OthColl_Coll_Uninsd_trans_query}")
    CA7LineSchedCovItemCov_Liab_Medpay_OthColl_Coll_Uninsd_trans_data = spark.sql(CA7LineSchedCovItemCov_Liab_Medpay_OthColl_Coll_Uninsd_trans_query)
    CA7LineSchedCovItemCov_Liab_Medpay_OthColl_Coll_Uninsd_trans_data.createOrReplaceTempView("CA7LineSchedCovItemCov_Liab_Medpay_OthColl_Coll_Uninsd_trans_data")
    row_count = CA7LineSchedCovItemCov_Liab_Medpay_OthColl_Coll_Uninsd_trans_data.count()
    logger.info(f"CA7LineSchedCovItemCov_Liab_Medpay_OthColl_Coll_Uninsd_trans_data loaded with {row_count} rows.")
    log_info_to_file(f"CA7LineSchedCovItemCov_Liab_Medpay_OthColl_Coll_Uninsd_trans_data loaded with {row_count} rows.")
    logger.info(f"CA7LineSchedCovItemCov_Liab_Medpay_OthColl_Coll_Uninsd_trans_data schema: {CA7LineSchedCovItemCov_Liab_Medpay_OthColl_Coll_Uninsd_trans_data.schema}")
    log_info_to_file(f"CA7LineSchedCovItemCov_Liab_Medpay_OthColl_Coll_Uninsd_trans_data schema: {CA7LineSchedCovItemCov_Liab_Medpay_OthColl_Coll_Uninsd_trans_data.schema}")
    logger.info("[END] Transformation for CA7LineSchedCovItemCov_Liab_Medpay_OthColl_Coll_Uninsd_trans_data.")
    log_info_to_file("[END] Transformation for CA7LineSchedCovItemCov_Liab_Medpay_OthColl_Coll_Uninsd_trans_data.")
    display(CA7LineSchedCovItemCov_Liab_Medpay_OthColl_Coll_Uninsd_trans_data)
except Exception as e:
    logger.error(f"error loading CA7LineSchedCovItemCov_Liab_Medpay_OthColl_Coll_Uninsd_trans_data: {e}", exc_info=True)
    log_info_to_file(f"error loading CA7LineSchedCovItemCov_Liab_Medpay_OthColl_Coll_Uninsd_trans_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Transformation of CA7DOCCovBroadCovForNamedIndivsUnderinsuredMotoris CA7LineSchedCovItemCov
# CA7LineSchedCovItemCov_CA7DOCCovBroadCovForNamedIndivsUnderinsuredMotoris_trans_query = '''
#     SELECT DISTINCT
#         concat('CA7LineSchedCovItemCov:',trim(PolicyNumber),'_','CA7DOCCovBroadCovForNamedIndivsUnderinsuredMotoris') AS pmt_id,
#         concat('CA7LineSchedCovItem:',trim(PolicyNumber),'_Drive_Other_Car_Coverage') AS pmt_parent,
#         CASE
#           WHEN trim(PredominantStateCode) IS NOT NULL AND trim(CoveragesApplicable) = '3' THEN 'CA7DOCCovBroadCovForNamedIndivsUnderinsuredMotoris'
#         END AS CodeIdentifier,
#         'usd' AS currency,
#         trim(PolicyNumber) AS pmt_payloadid
#     FROM Additional_ISO_Coverage_data
#     WHERE trim(PredominantStateCode) IS NOT NULL AND trim(CoveragesApplicable) = '3'
# '''

# try:
#   CA7LineSchedCovItemCov_CA7DOCCovBroadCovForNamedIndivsUnderinsuredMotoris_trans_data = spark.sql(CA7LineSchedCovItemCov_CA7DOCCovBroadCovForNamedIndivsUnderinsuredMotoris_trans_query)
#   CA7LineSchedCovItemCov_CA7DOCCovBroadCovForNamedIndivsUnderinsuredMotoris_trans_data.createOrReplaceTempView("CA7LineSchedCovItemCov_CA7DOCCovBroadCovForNamedIndivsUnderinsuredMotoris_trans_data")
#   print(CA7LineSchedCovItemCov_CA7DOCCovBroadCovForNamedIndivsUnderinsuredMotoris_trans_data.count())
#   display(CA7LineSchedCovItemCov_CA7DOCCovBroadCovForNamedIndivsUnderinsuredMotoris_trans_data)
# except Exception as e:
#   logger.info("error loading CA7LineSchedCovItemCov_CA7DOCCovBroadCovForNamedIndivsUnderinsuredMotoris_trans_data: {}".format(e)) 
#   sys.exit(1) 

# COMMAND ----------

# MAGIC %md
# MAGIC ##Trailer Interchange Additional ISO Coverages

# COMMAND ----------

# DBTITLE 1,Transformation of CA7MotorCarrierCovFormTrailerInterchange in CA7LineSchedCovItemCov
CA7CommAutoLineSchedCov_CA7MotorCarrierCovFormTrailerInterchange_trans_query = '''
    SELECT DISTINCT
        concat('CA7CommAutoLineSchedCov:',trim(PolicyNumber),'_','CA7MotorCarrierCovFormTrailerInterchange') AS pmt_id,
        concat('CA7CAL_',trim(policynumber)) AS pmt_parent,
        'CA7MotorCarrierCovFormTrailerInterchange' AS patterncode,
        'usd' AS currency,
        'usd' AS PreferredSettlementCurrency,
        trim(PolicyNumber) AS pmt_payloadid
    FROM Additional_ISO_Coverage_data
'''

log_info_to_file("[START] Transformation for CA7CommAutoLineSchedCov_CA7MotorCarrierCovFormTrailerInterchange_trans_data...")
logger.info("[START] Transformation for CA7CommAutoLineSchedCov_CA7MotorCarrierCovFormTrailerInterchange_trans_data...")
try:
    logger.info(f"CA7CommAutoLineSchedCov_CA7MotorCarrierCovFormTrailerInterchange_trans_query: {CA7CommAutoLineSchedCov_CA7MotorCarrierCovFormTrailerInterchange_trans_query}")
    log_info_to_file(f"CA7CommAutoLineSchedCov_CA7MotorCarrierCovFormTrailerInterchange_trans_query: {CA7CommAutoLineSchedCov_CA7MotorCarrierCovFormTrailerInterchange_trans_query}")
    CA7CommAutoLineSchedCov_CA7MotorCarrierCovFormTrailerInterchange_trans_data = spark.sql(CA7CommAutoLineSchedCov_CA7MotorCarrierCovFormTrailerInterchange_trans_query)
    CA7CommAutoLineSchedCov_CA7MotorCarrierCovFormTrailerInterchange_trans_data.createOrReplaceTempView("CA7CommAutoLineSchedCov_CA7MotorCarrierCovFormTrailerInterchange_trans_data")
    row_count = CA7CommAutoLineSchedCov_CA7MotorCarrierCovFormTrailerInterchange_trans_data.count()
    logger.info(f"CA7CommAutoLineSchedCov_CA7MotorCarrierCovFormTrailerInterchange_trans_data loaded with {row_count} rows.")
    log_info_to_file(f"CA7CommAutoLineSchedCov_CA7MotorCarrierCovFormTrailerInterchange_trans_data loaded with {row_count} rows.")
    logger.info(f"CA7CommAutoLineSchedCov_CA7MotorCarrierCovFormTrailerInterchange_trans_data schema: {CA7CommAutoLineSchedCov_CA7MotorCarrierCovFormTrailerInterchange_trans_data.schema}")
    log_info_to_file(f"CA7CommAutoLineSchedCov_CA7MotorCarrierCovFormTrailerInterchange_trans_data schema: {CA7CommAutoLineSchedCov_CA7MotorCarrierCovFormTrailerInterchange_trans_data.schema}")
    logger.info("[END] Transformation for CA7CommAutoLineSchedCov_CA7MotorCarrierCovFormTrailerInterchange_trans_data.")
    log_info_to_file("[END] Transformation for CA7CommAutoLineSchedCov_CA7MotorCarrierCovFormTrailerInterchange_trans_data.")
    display(CA7CommAutoLineSchedCov_CA7MotorCarrierCovFormTrailerInterchange_trans_data)
except Exception as e:
    logger.error(f"error loading CA7CommAutoLineSchedCov_CA7MotorCarrierCovFormTrailerInterchange_trans_data: {e}", exc_info=True)
    log_info_to_file(f"error loading CA7CommAutoLineSchedCov_CA7MotorCarrierCovFormTrailerInterchange_trans_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Transformation of CA7LineSchedCovItem for Trailer Interchange
CA7LineSchedCovItem_Trailer_Interchange_trans_query = '''
    SELECT DISTINCT
        concat('CA7LineSchedCovItem:',trim(PolicyNumber),'_Trailer_Interchange') AS pmt_id,
        concat('CA7CommAutoLineSchedCov:',trim(PolicyNumber),'_','CA7MotorCarrierCovFormTrailerInterchange') AS pmt_parent,
        'usd' AS PreferredCoverageCurrency,
        'usd' AS PreferredSettlementCurrency,
        CASE WHEN trim(TrailerInterchangeRadius) = '1' THEN 'Local'
             WHEN trim(TrailerInterchangeRadius) = '2' THEN 'Intermediate'
             WHEN trim(TrailerInterchangeRadius) = '3' THEN 'Long Distance'
             ELSE NULL
        END AS optioncol4,
        CASE WHEN trim(TrailerInterchangeRadius) = '1' THEN '9680'
             WHEN trim(TrailerInterchangeRadius) = '2' THEN '9681'
             WHEN trim(TrailerInterchangeRadius) = '3' THEN '9682'
             ELSE NULL
        END AS optioncol1,
        'Gulf' AS optioncol5,
        'Gulf' AS optioncol6,
        'Metropolitan To Metropolitan' AS optioncol2,
        CAST(TrailerInterchangeNumberOfDays AS INT) AS nonnegativeintcol1,
        CAST(TrailerInterchangeNumberOfTrailers AS INT) AS nonnegativeintcol2,
        CASE WHEN trim(TrailerInterchangeCoverageSCLType) = 1 THEN 'Fire'
             WHEN trim(TrailerInterchangeCoverageSCLType) = 2 THEN 'FireAndTheft'
             WHEN trim(TrailerInterchangeCoverageSCLType) = 3 THEN 'SpecifiedCausesofLoss'
             WHEN trim(TrailerInterchangeCoverageSCLType) = 4 THEN 'Comprehensive'
             ELSE 'NoCoverage' 
        END AS optioncol3,
        1 AS ScheduleNumber,
        trim(PolicyNumber) AS pmt_payloadid
    FROM Additional_ISO_Coverage_data
    --WHERE trim(PredominantStateCode) IS NOT NULL AND trim(CoveragesApplicable) IS NOT NULL
'''

log_info_to_file("[START] Transformation for CA7LineSchedCovItem_Trailer_Interchange_trans_data...")
logger.info("[START] Transformation for CA7LineSchedCovItem_Trailer_Interchange_trans_data...")
try:
    logger.info(f"CA7LineSchedCovItem_Trailer_Interchange_trans_query: {CA7LineSchedCovItem_Trailer_Interchange_trans_query}")
    log_info_to_file(f"CA7LineSchedCovItem_Trailer_Interchange_trans_query: {CA7LineSchedCovItem_Trailer_Interchange_trans_query}")
    CA7LineSchedCovItem_Trailer_Interchange_trans_data = spark.sql(CA7LineSchedCovItem_Trailer_Interchange_trans_query)
    CA7LineSchedCovItem_Trailer_Interchange_trans_data.createOrReplaceTempView("CA7LineSchedCovItem_Trailer_Interchange_trans_data")
    row_count = CA7LineSchedCovItem_Trailer_Interchange_trans_data.count()
    logger.info(f"CA7LineSchedCovItem_Trailer_Interchange_trans_data loaded with {row_count} rows.")
    log_info_to_file(f"CA7LineSchedCovItem_Trailer_Interchange_trans_data loaded with {row_count} rows.")
    logger.info(f"CA7LineSchedCovItem_Trailer_Interchange_trans_data schema: {CA7LineSchedCovItem_Trailer_Interchange_trans_data.schema}")
    log_info_to_file(f"CA7LineSchedCovItem_Trailer_Interchange_trans_data schema: {CA7LineSchedCovItem_Trailer_Interchange_trans_data.schema}")
    logger.info("[END] Transformation for CA7LineSchedCovItem_Trailer_Interchange_trans_data.")
    log_info_to_file("[END] Transformation for CA7LineSchedCovItem_Trailer_Interchange_trans_data.")
    display(CA7LineSchedCovItem_Trailer_Interchange_trans_data)
except Exception as e:
    logger.error(f"error loading CA7LineSchedCovItem_Trailer_Interchange_trans_data: {e}", exc_info=True)
    log_info_to_file(f"error loading CA7LineSchedCovItem_Trailer_Interchange_trans_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Transformation of CA7TrailerInterchangeAgreementComprehensive in CA7LineSchedCovItemCov
CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementComprehensive_trans_query = '''
    SELECT DISTINCT
        concat('CA7LineSchedCovItemCov:',trim(PolicyNumber),'_','CA7TrailerInterchangeAgreementComprehensive') AS pmt_id,
        concat('CA7LineSchedCovItem:',trim(PolicyNumber),'_Trailer_Interchange') AS pmt_parent,
        CASE
          WHEN trim(TrailerInterchangeCompValue) IS NOT NULL THEN 'CA7TrailerInterchangeAgreementComprehensive'
        END AS CodeIdentifier,
        'usd' AS currency,
        trim(PolicyNumber) AS pmt_payloadid
    FROM Additional_ISO_Coverage_data
    WHERE trim(TrailerInterchangeCompValue) IS NOT NULL
'''

log_info_to_file("[START] Transformation for CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementComprehensive_trans_data...")
logger.info("[START] Transformation for CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementComprehensive_trans_data...")
try:
    logger.info(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementComprehensive_trans_query: {CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementComprehensive_trans_query}")
    log_info_to_file(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementComprehensive_trans_query: {CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementComprehensive_trans_query}")
    CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementComprehensive_trans_data = spark.sql(CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementComprehensive_trans_query)
    CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementComprehensive_trans_data.createOrReplaceTempView("CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementComprehensive_trans_data")
    row_count = CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementComprehensive_trans_data.count()
    logger.info(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementComprehensive_trans_data loaded with {row_count} rows.")
    log_info_to_file(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementComprehensive_trans_data loaded with {row_count} rows.")
    logger.info(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementComprehensive_trans_data schema: {CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementComprehensive_trans_data.schema}")
    log_info_to_file(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementComprehensive_trans_data schema: {CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementComprehensive_trans_data.schema}")
    logger.info("[END] Transformation for CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementComprehensive_trans_data.")
    log_info_to_file("[END] Transformation for CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementComprehensive_trans_data.")
    display(CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementComprehensive_trans_data)
except Exception as e:
    logger.error(f"error loading CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementComprehensive_trans_data: {e}", exc_info=True)
    log_info_to_file(f"error loading CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementComprehensive_trans_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Transformation of CA7MotorCarrierCovFormTrailerInterchangeCovCompreh in CA7LineSchedCovItemCov
# Add start logging
log_info_to_file("[START] Transformation for CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCompreh_trans_data...")
logger.info("[START] Transformation for CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCompreh_trans_data...")

CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCompreh_trans_query = '''
    SELECT DISTINCT
        concat('CA7LineSchedCovItemCov:',trim(PolicyNumber),'_','CA7MotorCarrierCovFormTrailerInterchangeCovCompreh') AS pmt_id,
        concat('CA7LineSchedCovItem:',trim(PolicyNumber),'_Trailer_Interchange') AS pmt_parent,
        CASE
          WHEN trim(TrailerInterchangeCompValue) IS NOT NULL THEN 'CA7MotorCarrierCovFormTrailerInterchangeCovCompreh'
        END AS CodeIdentifier,
        'usd' AS currency,
        trim(PolicyNumber) AS pmt_payloadid
    FROM Additional_ISO_Coverage_data
    WHERE trim(TrailerInterchangeCompValue) IS NOT NULL
'''

try:
    # Log the query
    logger.info(f"CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCompreh_trans_query: {CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCompreh_trans_query}")
    log_info_to_file(f"CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCompreh_trans_query: {CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCompreh_trans_query}")

    # Execute query
    CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCompreh_trans_data = spark.sql(CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCompreh_trans_query)
    CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCompreh_trans_data.createOrReplaceTempView(
        "CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCompreh_trans_data"
    )

    # Log row count and schema
    row_count = CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCompreh_trans_data.count()
    logger.info(f"CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCompreh_trans_data loaded with {row_count} rows.")
    log_info_to_file(f"CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCompreh_trans_data loaded with {row_count} rows.")
    logger.info(f"CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCompreh_trans_data schema: {CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCompreh_trans_data.schema}")
    log_info_to_file(f"CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCompreh_trans_data schema: {CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCompreh_trans_data.schema}")

    # End logging
    logger.info("[END] Transformation for CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCompreh_trans_data.")
    log_info_to_file("[END] Transformation for CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCompreh_trans_data.")

    display(CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCompreh_trans_data)
except Exception as e:
    logger.error(f"error loading CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCompreh_trans_data: {e}", exc_info=True)
    log_info_to_file(f"error loading CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCompreh_trans_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Transformation of CA7TrailerInterchangeAgreementSpecifiedCausesOfLos for CA7Line SchedCovItemCov
log_info_to_file("[START] Transformation for CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementSpecifiedCausesOfLos_trans_data...")
logger.info("[START] Transformation for CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementSpecifiedCausesOfLos_trans_data...")

CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementSpecifiedCausesOfLos_trans_query = '''
    SELECT DISTINCT
        concat('CA7LineSchedCovItemCov:',trim(PolicyNumber),'_','CA7TrailerInterchangeAgreementSpecifiedCausesOfLos') AS pmt_id,
        concat('CA7LineSchedCovItem:',trim(PolicyNumber),'_Trailer_Interchange') AS pmt_parent,
        CASE
          WHEN trim(TrailerInterchangeCoverageSCLType) = '3' THEN 'CA7TrailerInterchangeAgreementSpecifiedCausesOfLos'
        END AS CodeIdentifier,
        'usd' AS currency,
        trim(PolicyNumber) AS pmt_payloadid
    FROM Additional_ISO_Coverage_data
    WHERE trim(TrailerInterchangeCoverageSCLType) = '3'
'''

try:
    logger.info(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementSpecifiedCausesOfLos_trans_query: {CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementSpecifiedCausesOfLos_trans_query}")
    log_info_to_file(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementSpecifiedCausesOfLos_trans_query: {CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementSpecifiedCausesOfLos_trans_query}")
    CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementSpecifiedCausesOfLos_trans_data = spark.sql(CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementSpecifiedCausesOfLos_trans_query)
    CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementSpecifiedCausesOfLos_trans_data.createOrReplaceTempView("CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementSpecifiedCausesOfLos_trans_data")
    row_count = CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementSpecifiedCausesOfLos_trans_data.count()
    logger.info(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementSpecifiedCausesOfLos_trans_data loaded with {row_count} rows.")
    log_info_to_file(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementSpecifiedCausesOfLos_trans_data loaded with {row_count} rows.")
    logger.info(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementSpecifiedCausesOfLos_trans_data schema: {CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementSpecifiedCausesOfLos_trans_data.schema}")
    log_info_to_file(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementSpecifiedCausesOfLos_trans_data schema: {CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementSpecifiedCausesOfLos_trans_data.schema}")
    logger.info("[END] Transformation for CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementSpecifiedCausesOfLos_trans_data.")
    log_info_to_file("[END] Transformation for CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementSpecifiedCausesOfLos_trans_data.")
    display(CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementSpecifiedCausesOfLos_trans_data)
except Exception as e:
    logger.error(f"error loading CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementSpecifiedCausesOfLos_trans_data: {e}", exc_info=True)
    log_info_to_file(f"error loading CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementSpecifiedCausesOfLos_trans_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Transformation of CA7MotorCarrierCovFormTrailerInterchangeCovSpecifi for CA7LineSchedCovItemCov
log_info_to_file("[START] Transformation for CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovSpecifi_trans_data...")
logger.info("[START] Transformation for CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovSpecifi_trans_data...")

CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovSpecifi_trans_query = '''
    SELECT DISTINCT
        concat('CA7LineSchedCovItemCov:',trim(PolicyNumber),'_','CA7MotorCarrierCovFormTrailerInterchangeCovSpecifi') AS pmt_id,
        concat('CA7LineSchedCovItem:',trim(PolicyNumber),'_Trailer_Interchange') AS pmt_parent,
        CASE
          WHEN trim(TrailerInterchangeCoverageSCLType) = '3' THEN 'CA7MotorCarrierCovFormTrailerInterchangeCovSpecifi'
        END AS CodeIdentifier,
        'usd' AS currency,
        trim(PolicyNumber) AS pmt_payloadid
    FROM Additional_ISO_Coverage_data
    WHERE trim(TrailerInterchangeCoverageSCLType) = '3'
'''

try:
    logger.info(f"CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovSpecifi_trans_query: {CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovSpecifi_trans_query}")
    log_info_to_file(f"CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovSpecifi_trans_query: {CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovSpecifi_trans_query}")
    CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovSpecifi_trans_data = spark.sql(CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovSpecifi_trans_query)
    CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovSpecifi_trans_data.createOrReplaceTempView("CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovSpecifi_trans_data")
    row_count = CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovSpecifi_trans_data.count()
    logger.info(f"CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovSpecifi_trans_data loaded with {row_count} rows.")
    log_info_to_file(f"CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovSpecifi_trans_data loaded with {row_count} rows.")
    logger.info(f"CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovSpecifi_trans_data schema: {CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovSpecifi_trans_data.schema}")
    log_info_to_file(f"CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovSpecifi_trans_data schema: {CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovSpecifi_trans_data.schema}")
    logger.info("[END] Transformation for CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovSpecifi_trans_data.")
    log_info_to_file("[END] Transformation for CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovSpecifi_trans_data.")
    display(CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovSpecifi_trans_data)
except Exception as e:
    logger.error(f"error loading CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovSpecifi_trans_data: {e}", exc_info=True)
    log_info_to_file(f"error loading CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovSpecifi_trans_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Transformation of CA7TrailerInterchangeAgreementFire for CA7LineSchedCovItemCov
log_info_to_file("[START] Transformation for CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFire_trans_data...")
logger.info("[START] Transformation for CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFire_trans_data...")

CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFire_trans_query = '''
    SELECT DISTINCT
        concat('CA7LineSchedCovItemCov:',trim(PolicyNumber),'_','CA7TrailerInterchangeAgreementFire') AS pmt_id,
        concat('CA7LineSchedCovItem:',trim(PolicyNumber),'_Trailer_Interchange') AS pmt_parent,
        CASE
          WHEN trim(TrailerInterchangeCoverageSCLType) = '1' THEN 'CA7TrailerInterchangeAgreementFire'
        END AS CodeIdentifier,
        'usd' AS currency,
        trim(PolicyNumber) AS pmt_payloadid
    FROM Additional_ISO_Coverage_data
    WHERE trim(TrailerInterchangeCoverageSCLType) = '1'
'''

try:
    logger.info(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFire_trans_query: {CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFire_trans_query}")
    log_info_to_file(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFire_trans_query: {CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFire_trans_query}")
    CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFire_trans_data = spark.sql(CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFire_trans_query)
    CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFire_trans_data.createOrReplaceTempView("CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFire_trans_data")
    row_count = CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFire_trans_data.count()
    logger.info(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFire_trans_data loaded with {row_count} rows.")
    log_info_to_file(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFire_trans_data loaded with {row_count} rows.")
    logger.info(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFire_trans_data schema: {CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFire_trans_data.schema}")
    log_info_to_file(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFire_trans_data schema: {CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFire_trans_data.schema}")
    logger.info("[END] Transformation for CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFire_trans_data.")
    log_info_to_file("[END] Transformation for CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFire_trans_data.")
    display(CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFire_trans_data)
except Exception as e:
    logger.error(f"error loading CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFire_trans_data: {e}", exc_info=True)
    log_info_to_file(f"error loading CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFire_trans_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Transformation of CA7TrailerInterchangeAgreementFireAndTheft for CA7LineSchedCovItemCov
log_info_to_file("[START] Transformation for CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFireAndTheft_trans_data...")
logger.info("[START] Transformation for CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFireAndTheft_trans_data...")

CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFireAndTheft_trans_query = '''
    SELECT DISTINCT
        concat('CA7LineSchedCovItemCov:',trim(PolicyNumber),'_','CA7TrailerInterchangeAgreementFireAndTheft') AS pmt_id,
        concat('CA7LineSchedCovItem:',trim(PolicyNumber),'_Trailer_Interchange') AS pmt_parent,
        CASE
          WHEN trim(TrailerInterchangeCoverageSCLType) = '2' THEN 'CA7TrailerInterchangeAgreementFireAndTheft'
        END AS CodeIdentifier,
        'usd' AS currency,
        trim(PolicyNumber) AS pmt_payloadid
    FROM Additional_ISO_Coverage_data
    WHERE trim(TrailerInterchangeCoverageSCLType) = '2'
'''

try:
    logger.info(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFireAndTheft_trans_query: {CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFireAndTheft_trans_query}")
    log_info_to_file(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFireAndTheft_trans_query: {CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFireAndTheft_trans_query}")
    CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFireAndTheft_trans_data = spark.sql(CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFireAndTheft_trans_query)
    CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFireAndTheft_trans_data.createOrReplaceTempView("CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFireAndTheft_trans_data")
    row_count = CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFireAndTheft_trans_data.count()
    logger.info(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFireAndTheft_trans_data loaded with {row_count} rows.")
    log_info_to_file(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFireAndTheft_trans_data loaded with {row_count} rows.")
    logger.info(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFireAndTheft_trans_data schema: {CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFireAndTheft_trans_data.schema}")
    log_info_to_file(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFireAndTheft_trans_data schema: {CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFireAndTheft_trans_data.schema}")
    logger.info("[END] Transformation for CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFireAndTheft_trans_data.")
    log_info_to_file("[END] Transformation for CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFireAndTheft_trans_data.")
    display(CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFireAndTheft_trans_data)
except Exception as e:
    logger.error(f"error loading CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFireAndTheft_trans_data: {e}", exc_info=True)
    log_info_to_file(f"error loading CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFireAndTheft_trans_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Transformation of CA7TrailerInterchangeFireAndFireAndTheftCovs for CA7CommAutoLineSchedCov
log_info_to_file("[START] Transformation for CA7CommAutoLineSchedCov_CA7TrailerInterchangeFireAndFireAndTheftCovs_trans_data...")
logger.info("[START] Transformation for CA7CommAutoLineSchedCov_CA7TrailerInterchangeFireAndFireAndTheftCovs_trans_data...")

CA7CommAutoLineSchedCov_CA7TrailerInterchangeFireAndFireAndTheftCovs_trans_query = '''
    SELECT DISTINCT
        concat('CA7CommAutoLineSchedCov:',trim(PolicyNumber),'_','CA7TrailerInterchangeFireAndFireAndTheftCovs') AS pmt_id,
        concat('CA7CAL_',trim(policynumber)) AS pmt_parent,
        'CA7TrailerInterchangeFireAndFireAndTheftCovs' AS patterncode,
        'usd' AS currency,
        'usd' AS PreferredSettlementCurrency,
        trim(PolicyNumber) AS pmt_payloadid
    FROM Additional_ISO_Coverage_data
    WHERE trim(TrailerInterchangeCoverageSCLType) IN ('1','2')
'''

try:
    logger.info(f"CA7CommAutoLineSchedCov_CA7TrailerInterchangeFireAndFireAndTheftCovs_trans_query: {CA7CommAutoLineSchedCov_CA7TrailerInterchangeFireAndFireAndTheftCovs_trans_query}")
    log_info_to_file(f"CA7CommAutoLineSchedCov_CA7TrailerInterchangeFireAndFireAndTheftCovs_trans_query: {CA7CommAutoLineSchedCov_CA7TrailerInterchangeFireAndFireAndTheftCovs_trans_query}")
    CA7CommAutoLineSchedCov_CA7TrailerInterchangeFireAndFireAndTheftCovs_trans_data = spark.sql(CA7CommAutoLineSchedCov_CA7TrailerInterchangeFireAndFireAndTheftCovs_trans_query)
    CA7CommAutoLineSchedCov_CA7TrailerInterchangeFireAndFireAndTheftCovs_trans_data.createOrReplaceTempView("CA7CommAutoLineSchedCov_CA7TrailerInterchangeFireAndFireAndTheftCovs_trans_data")
    row_count = CA7CommAutoLineSchedCov_CA7TrailerInterchangeFireAndFireAndTheftCovs_trans_data.count()
    logger.info(f"CA7CommAutoLineSchedCov_CA7TrailerInterchangeFireAndFireAndTheftCovs_trans_data loaded with {row_count} rows.")
    log_info_to_file(f"CA7CommAutoLineSchedCov_CA7TrailerInterchangeFireAndFireAndTheftCovs_trans_data loaded with {row_count} rows.")
    logger.info(f"CA7CommAutoLineSchedCov_CA7TrailerInterchangeFireAndFireAndTheftCovs_trans_data schema: {CA7CommAutoLineSchedCov_CA7TrailerInterchangeFireAndFireAndTheftCovs_trans_data.schema}")
    log_info_to_file(f"CA7CommAutoLineSchedCov_CA7TrailerInterchangeFireAndFireAndTheftCovs_trans_data schema: {CA7CommAutoLineSchedCov_CA7TrailerInterchangeFireAndFireAndTheftCovs_trans_data.schema}")
    logger.info("[END] Transformation for CA7CommAutoLineSchedCov_CA7TrailerInterchangeFireAndFireAndTheftCovs_trans_data.")
    log_info_to_file("[END] Transformation for CA7CommAutoLineSchedCov_CA7TrailerInterchangeFireAndFireAndTheftCovs_trans_data.")
    display(CA7CommAutoLineSchedCov_CA7TrailerInterchangeFireAndFireAndTheftCovs_trans_data)
except Exception as e:
    logger.error(f"error loading CA7CommAutoLineSchedCov_CA7TrailerInterchangeFireAndFireAndTheftCovs_trans_data: {e}", exc_info=True)
    log_info_to_file(f"error loading CA7CommAutoLineSchedCov_CA7TrailerInterchangeFireAndFireAndTheftCovs_trans_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------

log_info_to_file("[START] Transformation for CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFire_trans_data...")
logger.info("[START] Transformation for CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFire_trans_data...")

CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFire_trans_query = '''
    SELECT DISTINCT
        concat('CA7LineSchedCovItemCov:',trim(PolicyNumber),'_','CA7TrailerInterchangeFireAndFireAndTheftCovsFire') AS pmt_id,
        concat('CA7LineSchedCovItem:',trim(PolicyNumber),'_Trailer_Interchange') AS pmt_parent,
        CASE
          WHEN trim(TrailerInterchangeCoverageSCLType) IN ('1','2') THEN 'CA7TrailerInterchangeFireAndFireAndTheftCovsFire'
        END AS CodeIdentifier,
        'usd' AS currency,
        trim(PolicyNumber) AS pmt_payloadid
    FROM Additional_ISO_Coverage_data
    WHERE trim(TrailerInterchangeCoverageSCLType) IN ('1','2')
'''

try:
    logger.info(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFire_trans_query: {CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFire_trans_query}")
    log_info_to_file(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFire_trans_query: {CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFire_trans_query}")
    CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFire_trans_data = spark.sql(CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFire_trans_query)
    CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFire_trans_data.createOrReplaceTempView("CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFire_trans_data")
    row_count = CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFire_trans_data.count()
    logger.info(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFire_trans_data loaded with {row_count} rows.")
    log_info_to_file(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFire_trans_data loaded with {row_count} rows.")
    logger.info(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFire_trans_data schema: {CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFire_trans_data.schema}")
    log_info_to_file(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFire_trans_data schema: {CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFire_trans_data.schema}")
    logger.info("[END] Transformation for CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFire_trans_data.")
    log_info_to_file("[END] Transformation for CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFire_trans_data.")
    display(CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFire_trans_data)
except Exception as e:
    logger.error(f"error loading CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFire_trans_data: {e}", exc_info=True)
    log_info_to_file(f"error loading CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFire_trans_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------

log_info_to_file("[START] Transformation for CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFireAn_trans_data...")
logger.info("[START] Transformation for CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFireAn_trans_data...")

CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFireAn_trans_query = '''
    SELECT DISTINCT
        concat('CA7LineSchedCovItemCov:',trim(PolicyNumber),'_','CA7TrailerInterchangeFireAndFireAndTheftCovsFireAn') AS pmt_id,
        concat('CA7LineSchedCovItem:',trim(PolicyNumber),'_Trailer_Interchange') AS pmt_parent,
        CASE
          WHEN trim(TrailerInterchangeCoverageSCLType) IN ('1','2') THEN 'CA7TrailerInterchangeFireAndFireAndTheftCovsFireAn'
        END AS CodeIdentifier,
        'usd' AS currency,
        trim(PolicyNumber) AS pmt_payloadid
    FROM Additional_ISO_Coverage_data
    WHERE trim(TrailerInterchangeCoverageSCLType) IN ('1','2')
'''

try:
    logger.info(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFireAn_trans_query: {CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFireAn_trans_query}")
    log_info_to_file(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFireAn_trans_query: {CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFireAn_trans_query}")
    CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFireAn_trans_data = spark.sql(CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFireAn_trans_query)
    CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFireAn_trans_data.createOrReplaceTempView("CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFireAn_trans_data")
    row_count = CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFireAn_trans_data.count()
    logger.info(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFireAn_trans_data loaded with {row_count} rows.")
    log_info_to_file(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFireAn_trans_data loaded with {row_count} rows.")
    logger.info(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFireAn_trans_data schema: {CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFireAn_trans_data.schema}")
    log_info_to_file(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFireAn_trans_data schema: {CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFireAn_trans_data.schema}")
    logger.info("[END] Transformation for CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFireAn_trans_data.")
    log_info_to_file("[END] Transformation for CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFireAn_trans_data.")
    display(CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFireAn_trans_data)
except Exception as e:
    logger.error(f"error loading CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFireAn_trans_data: {e}", exc_info=True)
    log_info_to_file(f"error loading CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFireAn_trans_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Transformation of CA7TrailerInterchangeAgreementCollision for CA7LineSchedCovItemCov
log_info_to_file("[START] Transformation for CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementCollision_trans_data...")
logger.info("[START] Transformation for CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementCollision_trans_data...")

CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementCollision_trans_query = '''
    SELECT DISTINCT
        concat('CA7LineSchedCovItemCov:',trim(PolicyNumber),'_','CA7TrailerInterchangeAgreementCollision') AS pmt_id,
        concat('CA7LineSchedCovItem:',trim(PolicyNumber),'_Trailer_Interchange') AS pmt_parent,
        CASE
          WHEN trim(TrailerInterchangeCollisionValue) IS NOT NULL THEN 'CA7TrailerInterchangeAgreementCollision'
        END AS CodeIdentifier,
        'usd' AS currency,
        trim(PolicyNumber) AS pmt_payloadid
    FROM Additional_ISO_Coverage_data
    WHERE trim(TrailerInterchangeCollisionValue) IS NOT NULL
'''

try:
    logger.info(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementCollision_trans_query: {CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementCollision_trans_query}")
    log_info_to_file(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementCollision_trans_query: {CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementCollision_trans_query}")
    CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementCollision_trans_data = spark.sql(CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementCollision_trans_query)
    CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementCollision_trans_data.createOrReplaceTempView("CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementCollision_trans_data")
    row_count = CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementCollision_trans_data.count()
    logger.info(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementCollision_trans_data loaded with {row_count} rows.")
    log_info_to_file(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementCollision_trans_data loaded with {row_count} rows.")
    logger.info(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementCollision_trans_data schema: {CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementCollision_trans_data.schema}")
    log_info_to_file(f"CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementCollision_trans_data schema: {CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementCollision_trans_data.schema}")
    logger.info("[END] Transformation for CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementCollision_trans_data.")
    log_info_to_file("[END] Transformation for CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementCollision_trans_data.")
    display(CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementCollision_trans_data)
except Exception as e:
    logger.error(f"error loading CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementCollision_trans_data: {e}", exc_info=True)
    log_info_to_file(f"error loading CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementCollision_trans_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Transformation of CA7MotorCarrierCovFormTrailerInterchangeCovCollisi for CA7LineSchedCovItemCov
log_info_to_file("[START] Transformation for CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCollisi_trans_data...")
logger.info("[START] Transformation for CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCollisi_trans_data...")

CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCollisi_trans_query = '''
    SELECT DISTINCT
        concat('CA7LineSchedCovItemCov:',trim(PolicyNumber),'_','CA7MotorCarrierCovFormTrailerInterchangeCovCollisi') AS pmt_id,
        concat('CA7LineSchedCovItem:',trim(PolicyNumber),'_Trailer_Interchange') AS pmt_parent,
        CASE
          WHEN trim(TrailerInterchangeCollisionValue) IS NOT NULL THEN 'CA7MotorCarrierCovFormTrailerInterchangeCovCollisi'
        END AS CodeIdentifier,
        'usd' AS currency,
        trim(PolicyNumber) AS pmt_payloadid
    FROM Additional_ISO_Coverage_data
    WHERE trim(TrailerInterchangeCollisionValue) IS NOT NULL
'''

try:
    logger.info(f"CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCollisi_trans_query: {CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCollisi_trans_query}")
    log_info_to_file(f"CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCollisi_trans_query: {CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCollisi_trans_query}")
    CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCollisi_trans_data = spark.sql(CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCollisi_trans_query)
    CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCollisi_trans_data.createOrReplaceTempView("CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCollisi_trans_data")
    row_count = CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCollisi_trans_data.count()
    logger.info(f"CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCollisi_trans_data loaded with {row_count} rows.")
    log_info_to_file(f"CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCollisi_trans_data loaded with {row_count} rows.")
    logger.info(f"CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCollisi_trans_data schema: {CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCollisi_trans_data.schema}")
    log_info_to_file(f"CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCollisi_trans_data schema: {CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCollisi_trans_data.schema}")
    logger.info("[END] Transformation for CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCollisi_trans_data.")
    log_info_to_file("[END] Transformation for CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCollisi_trans_data.")
    
except Exception as e:
    logger.error(f"error loading CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCollisi_trans_data: {e}", exc_info=True)
    log_info_to_file(f"error loading CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCollisi_trans_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Union of CA7CommAutoLineSchedCov
logger.info("[START] Union for CA7CommAutoLineSchedCov_union_df...")
log_info_to_file("[START] Union for CA7CommAutoLineSchedCov_union_df...")

CA7CommAutoLineSchedCov_union_df = CA7CommAutoLineSchedCov_CA7DOCCovBroadCovForNamedIndivs_trans_data.unionAll(CA7CommAutoLineSchedCov_CA7MotorCarrierCovFormTrailerInterchange_trans_data).unionAll(CA7CommAutoLineSchedCov_CA7TrailerInterchangeFireAndFireAndTheftCovs_trans_data)
CA7CommAutoLineSchedCov_union_df.createOrReplaceTempView("CA7CommAutoLineSchedCov_union_df")

row_count = CA7CommAutoLineSchedCov_union_df.count()
logger.info(f"CA7CommAutoLineSchedCov_union_df loaded with {row_count} rows.")
log_info_to_file(f"CA7CommAutoLineSchedCov_union_df loaded with {row_count} rows.")
logger.info(f"CA7CommAutoLineSchedCov_union_df schema: {CA7CommAutoLineSchedCov_union_df.schema}")
log_info_to_file(f"CA7CommAutoLineSchedCov_union_df schema: {CA7CommAutoLineSchedCov_union_df.schema}")

logger.info("[END] Union for CA7CommAutoLineSchedCov_union_df.")
log_info_to_file("[END] Union for CA7CommAutoLineSchedCov_union_df.")


# COMMAND ----------

# DBTITLE 1,Writing CA7CommAutoLineSchedCov table in PMTIN
CA7CommAutoLineSchedCov_parent = execute_select_PMTIN("select * from CA7CommAutoLine")
display(CA7CommAutoLineSchedCov_parent)
CA7CommAutoLineSchedCov_parent.createOrReplaceTempView("CA7CommAutoLineSchedCov_parent")

# Validate the CA7CommAutoLineSchedCov_union_df Data
logger.info("Starting validation for CA7CommAutoLineSchedCov_union_df...")
validation_result = validate_data(data_name='CA7CommAutoLineSchedCov_union_df', parent_table='CA7CommAutoLineSchedCov_parent')

if validation_result is None:
    validation_result = {
        "status": False,
        "errors": [{"type": "internal_error", "details": "Validation function returned None."}],
        "warnings": []
    }

if validation_result["status"]:
    logger.info("Validation passed for CA7CommAutoLineSchedCov_union_df.")
    try:
        row_count = CA7CommAutoLineSchedCov_union_df.count()
        logger.info(f"[START] Writing {row_count} rows to table 'CA7CommAutoLineSchedCov' in PMTIN.")
        log_info_to_file(f"[START] Writing {row_count} rows to table 'CA7CommAutoLineSchedCov' in PMTIN.")
        logger.info(f"CA7CommAutoLineSchedCov_union_df schema: {CA7CommAutoLineSchedCov_union_df.schema}")
        log_info_to_file(f"CA7CommAutoLineSchedCov_union_df schema: {CA7CommAutoLineSchedCov_union_df.schema}")
        write_and_log_pmtin(
            df=CA7CommAutoLineSchedCov_union_df,
            table_name="CA7CommAutoLineSchedCov",
            job_id=job_id,
            job_run_id=job_run_id,
            notebook_name=notebook_name
        )
        logger.info("[END] Successfully wrote CA7CommAutoLineSchedCov_union_df to table 'CA7CommAutoLineSchedCov'.")
        log_info_to_file("[END] Successfully wrote CA7CommAutoLineSchedCov_union_df to table 'CA7CommAutoLineSchedCov'.")
    except Exception as e:
        logger.error(f"Error writing CA7CommAutoLineSchedCov_union_df to table 'CA7CommAutoLineSchedCov'", exc_info=True)
        log_info_to_file(f"Error writing CA7CommAutoLineSchedCov_union_df to table 'CA7CommAutoLineSchedCov': {str(e)}")
        log_dataload_event(
            job_id=job_id,
            job_run_id=job_run_id,
            notebook_name=notebook_name,
            log_message=f"Error writing CA7CommAutoLineSchedCov_union_df to table: {str(e)}"
        )
        sys.exit(1)
else:
    logger.error("Validation failed for CA7CommAutoLineSchedCov_union_df.")
    error_messages = []
    for error in validation_result["errors"]:
        error_message = f"Validation Error: {error['type']} - {error.get('details', '')}"
        logger.error(error_message)
        log_info_to_file(error_message)
        error_messages.append(error_message)
    full_error_message = "; ".join(error_messages)
    log_dataload_event(
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name,
        log_message=f"Validation failed for CA7CommAutoLineSchedCov_union_df: {full_error_message}"
    )
    raise ValueError(
        f"Validation failed for CA7CommAutoLineSchedCov_union_df. Validation errors logged: {full_error_message}."
    )


# COMMAND ----------

# DBTITLE 1,Union of CA7LineSchedCovItem
logger.info("[START] Union for CA7LineSchedCovItem_union_df...")
log_info_to_file("[START] Union for CA7LineSchedCovItem_union_df...")

CA7LineSchedCovItem_union_df = CA7LineSchedCovItem_Drive_Other_Car_Coverage_trans_data.unionAll(CA7LineSchedCovItem_Trailer_Interchange_trans_data)
row_count = CA7LineSchedCovItem_union_df.count()
logger.info(f"CA7LineSchedCovItem_union_df loaded with {row_count} rows.")
log_info_to_file(f"CA7LineSchedCovItem_union_df loaded with {row_count} rows.")
logger.info(f"CA7LineSchedCovItem_union_df schema: {CA7LineSchedCovItem_union_df.schema}")
log_info_to_file(f"CA7LineSchedCovItem_union_df schema: {CA7LineSchedCovItem_union_df.schema}")

logger.info("[END] Union for CA7LineSchedCovItem_union_df.")
log_info_to_file("[END] Union for CA7LineSchedCovItem_union_df.")

display(CA7LineSchedCovItem_union_df)

# COMMAND ----------

# DBTITLE 1,Writinf CA7LineSchedCovItem in PMTIN
CA7LineSchedCovItem_parent = execute_select_PMTIN("select * from CA7CommAutoLineSchedCov")
display(CA7LineSchedCovItem_parent)
CA7LineSchedCovItem_parent.createOrReplaceTempView("CA7LineSchedCovItem_parent")
CA7LineSchedCovItem_union_df.createOrReplaceTempView("CA7LineSchedCovItem_union_df")
logger.info("Starting validation for CA7LineSchedCovItem_union_df...")
validation_result = validate_data(data_name='CA7LineSchedCovItem_union_df', parent_table='CA7LineSchedCovItem_parent')

if validation_result is None:
    validation_result = {
        "status": False,
        "errors": [{"type": "internal_error", "details": "Validation function returned None."}],
        "warnings": []
    }

if validation_result["status"]:
    logger.info("Validation passed for CA7LineSchedCovItem_union_df.")
    try:
        row_count = CA7LineSchedCovItem_union_df.count()
        logger.info(f"[START] Writing {row_count} rows to table 'CA7LineSchedCovItem' in PMTIN.")
        log_info_to_file(f"[START] Writing {row_count} rows to table 'CA7LineSchedCovItem' in PMTIN.")
        logger.info(f"CA7LineSchedCovItem_union_df schema: {CA7LineSchedCovItem_union_df.schema}")
        log_info_to_file(f"CA7LineSchedCovItem_union_df schema: {CA7LineSchedCovItem_union_df.schema}")
        write_and_log_pmtin(
            df=CA7LineSchedCovItem_union_df,
            table_name="CA7LineSchedCovItem",
            job_id=job_id,
            job_run_id=job_run_id,
            notebook_name=notebook_name
        )
        logger.info("[END] Successfully wrote CA7LineSchedCovItem_union_df to table 'CA7LineSchedCovItem'.")
        log_info_to_file("[END] Successfully wrote CA7LineSchedCovItem_union_df to table 'CA7LineSchedCovItem'.")
    except Exception as e:
        logger.error(f"Error writing CA7LineSchedCovItem_union_df to table 'CA7LineSchedCovItem'", exc_info=True)
        log_info_to_file(f"Error writing CA7LineSchedCovItem_union_df to table 'CA7LineSchedCovItem': {str(e)}")
        log_dataload_event(
            job_id=job_id,
            job_run_id=job_run_id,
            notebook_name=notebook_name,
            log_message=f"Error writing CA7LineSchedCovItem_union_df to table: {str(e)}"
        )
        sys.exit(1)
else:
    logger.error("Validation failed for CA7LineSchedCovItem_union_df.")
    error_messages = []
    for error in validation_result["errors"]:
        error_message = f"Validation Error: {error['type']} - {error.get('details', '')}"
        logger.error(error_message)
        log_info_to_file(error_message)
        error_messages.append(error_message)
    full_error_message = "; ".join(error_messages)
    log_dataload_event(
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name,
        log_message=f"Validation failed for CA7LineSchedCovItem_union_df: {full_error_message}"
    )
    raise ValueError(
        f"Validation failed for CA7LineSchedCovItem_union_df. Validation errors logged: {full_error_message}."
    )


# COMMAND ----------

# DBTITLE 1,Union of CA7LineSchedCovItemCov
logger.info("[START] Union for CA7LineSchedCovItemCov_union_df...")
log_info_to_file("[START] Union for CA7LineSchedCovItemCov_union_df...")

CA7LineSchedCovItemCov_union_df = CA7LineSchedCovItemCov_Liab_Medpay_OthColl_Coll_Uninsd_trans_data \
    .unionAll(CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementComprehensive_trans_data) \
    .unionAll(CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCompreh_trans_data) \
    .unionAll(CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementSpecifiedCausesOfLos_trans_data) \
    .unionAll(CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovSpecifi_trans_data) \
    .unionAll(CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFire_trans_data) \
    .unionAll(CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementFireAndTheft_trans_data) \
    .unionAll(CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFire_trans_data) \
    .unionAll(CA7LineSchedCovItemCov_CA7TrailerInterchangeFireAndFireAndTheftCovsFireAn_trans_data) \
    .unionAll(CA7LineSchedCovItemCov_CA7TrailerInterchangeAgreementCollision_trans_data) \
    .unionAll(CA7LineSchedCovItemCov_CA7MotorCarrierCovFormTrailerInterchangeCovCollisi_trans_data) \
    # .unionAll(CA7LineSchedCovItemCov_CA7DOCCovBroadCovForNamedIndivsUnderinsuredMotoris_trans_data) \

row_count = CA7LineSchedCovItemCov_union_df.count()
logger.info(f"CA7LineSchedCovItemCov_union_df loaded with {row_count} rows.")
log_info_to_file(f"CA7LineSchedCovItemCov_union_df loaded with {row_count} rows.")
logger.info(f"CA7LineSchedCovItemCov_union_df schema: {CA7LineSchedCovItemCov_union_df.schema}")
log_info_to_file(f"CA7LineSchedCovItemCov_union_df schema: {CA7LineSchedCovItemCov_union_df.schema}")

logger.info("[END] Union for CA7LineSchedCovItemCov_union_df.")
log_info_to_file("[END] Union for CA7LineSchedCovItemCov_union_df.")

# COMMAND ----------

# DBTITLE 1,Writing CA7LineSchedCovItemCov in PMTIN
CA7LineSchedCovItemCov_parent = execute_select_PMTIN("select * from CA7LineSchedCovItem")
display(CA7LineSchedCovItemCov_parent)
CA7LineSchedCovItemCov_parent.createOrReplaceTempView("CA7LineSchedCovItemCov_parent")
CA7LineSchedCovItemCov_union_df.createOrReplaceTempView("CA7LineSchedCovItemCov_union_df")
logger.info("Starting validation for CA7LineSchedCovItemCov_union_df...")
validation_result = validate_data(data_name='CA7LineSchedCovItemCov_union_df', parent_table='CA7LineSchedCovItemCov_parent')

if validation_result is None:
    validation_result = {
        "status": False,
        "errors": [{"type": "internal_error", "details": "Validation function returned None."}],
        "warnings": []
    }

if validation_result["status"]:
    logger.info("Validation passed for CA7LineSchedCovItemCov_union_df.")
    try:
        row_count = CA7LineSchedCovItemCov_union_df.count()
        logger.info(f"[START] Writing {row_count} rows to table 'CA7LineSchedCovItemCov' in PMTIN.")
        log_info_to_file(f"[START] Writing {row_count} rows to table 'CA7LineSchedCovItemCov' in PMTIN.")
        logger.info(f"CA7LineSchedCovItemCov_union_df schema: {CA7LineSchedCovItemCov_union_df.schema}")
        log_info_to_file(f"CA7LineSchedCovItemCov_union_df schema: {CA7LineSchedCovItemCov_union_df.schema}")
        write_and_log_pmtin(
            df=CA7LineSchedCovItemCov_union_df,
            table_name="CA7LineSchedCovItemCov",
            job_id=job_id,
            job_run_id=job_run_id,
            notebook_name=notebook_name
        )
        logger.info("[END] Successfully wrote CA7LineSchedCovItemCov_union_df to table 'CA7LineSchedCovItemCov'.")
        log_info_to_file("[END] Successfully wrote CA7LineSchedCovItemCov_union_df to table 'CA7LineSchedCovItemCov'.")
    except Exception as e:
        logger.error(f"Error writing CA7LineSchedCovItemCov_union_df to table 'CA7LineSchedCovItemCov'", exc_info=True)
        log_info_to_file(f"Error writing CA7LineSchedCovItemCov_union_df to table 'CA7LineSchedCovItemCov': {str(e)}")
        log_dataload_event(
            job_id=job_id,
            job_run_id=job_run_id,
            notebook_name=notebook_name,
            log_message=f"Error writing CA7LineSchedCovItemCov_union_df to table: {str(e)}"
        )
        sys.exit(1)
else:
    logger.error("Validation failed for CA7LineSchedCovItemCov_union_df.")
    error_messages = []
    for error in validation_result["errors"]:
        error_message = f"Validation Error: {error['type']} - {error.get('details', '')}"
        logger.error(error_message)
        log_info_to_file(error_message)
        error_messages.append(error_message)
    full_error_message = "; ".join(error_messages)
    log_dataload_event(
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name,
        log_message=f"Validation failed for CA7LineSchedCovItemCov_union_df: {full_error_message}"
    )
    raise ValueError(
        f"Validation failed for CA7LineSchedCovItemCov_union_df. Validation errors logged: {full_error_message}."
    )

# COMMAND ----------

