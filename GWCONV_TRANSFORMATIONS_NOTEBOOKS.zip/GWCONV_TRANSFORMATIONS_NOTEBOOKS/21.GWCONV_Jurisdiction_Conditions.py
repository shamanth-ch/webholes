# Databricks notebook source
# MAGIC %run ../configuration/configs

# COMMAND ----------

# MAGIC %run ../configuration/postgres

# COMMAND ----------

# Logger setup for tracking errors and process info in this notebook
import logging
import sys

logger = logging.getLogger('ca7jurcov_df')
logger.setLevel(logging.INFO)

# COMMAND ----------

eval(exec_cmd_pmtin)('truncate table public.CA7StateCond')

# COMMAND ----------

# DBTITLE 1,Parent table
jur_parent = execute_select_PMTIN("select * from ca7jurisdiction")
jur_parent.createOrReplaceTempView("jur_parent")
display(jur_parent)

# COMMAND ----------

ca7jurcondition_manualuacti_query = """
SELECT CONCAT('CA7StateCond:', TRIM("PolicyNumber"), '_',
	CASE WHEN TRIM("FormId") = 'CA 02 03' THEN 'CA7CancellationAndNonrenewalNoticeToDesignatedPers' END,'-', TRIM("StateCd")) AS pmt_id,
	CONCAT('Jur:', TRIM("PolicyNumber"), '-', TRIM("StateCd")) AS pmt_parent,
	CASE WHEN TRIM("FormId") = 'CA 02 03' THEN 'CA7CancellationAndNonrenewalNoticeToDesignatedPers' END AS codeidentifier,
	'usd' AS currency,
    TRIM("PolicyNumber") AS pmt_payloadid
    FROM(
------------------------------------------------------------------------- */
/* Sprint_6_Form CA 22 46 - Virginia Medical Expense and Income Loss Benefit                                      */
/* 10/16/2025 (pstemp)                                                                                            */
/* Views used:                                                                                                    */
/* ViewCurPic_AUFormFillin                                                                                        */
/* ViewCurPic_AuStMPDeathBInput                                                                                   */
/* -------------------------------------------------------------------------------------------------------------- */

/* -------------------------------------------------------------------------------------------------------------- */
/* First SQL returns all states for the forms needed                                                              */
/* -------------------------------------------------------------------------------------------------------------- */
select distinct
/* ---------------------- */
/* CoPolicyPointer fields */
/* ---------------------- */
P."SystemAssignId"
,P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') as "PolicyNumber" 
,CAST (RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"),' ') AS VARCHAR(8)) AS "AccountNumber"
,P."PolicyEffDt"

/* -------------------------------- */
/* ViewCurPic_CoPolicyDetail Fields */
/* -------------------------------- */
,CoPolicyDetail."PredStateCd" AS "PredominantStateCode"


/* --------------------------- */
/* ViewCurPic_AuStInput fields */
/* --------------------------- */
,AuStInput."StateCd"

/* ------------------------------------- */
/* ViewCurPic_AUSelectedForm fields      */
/* ------------------------------------- */
,RTRIM(AUSelectedForm."FormId") AS "FormId"
,AUSelectedForm."FormEdCd" AS "FormEditionCode"
,AUSelectedForm."FormDescTx" AS "FormDescription"



FROM Policy P1
INNER JOIN CoPolicyPointer P
   ON P."SystemAssignId" = P1."SourceSystemId"
INNER JOIN ViewCurPic_CoPolicyDetail CoPolicyDetail
ON P."SystemAssignId" = CoPolicyDetail."SystemAssignId"
LEFT JOIN ViewCurPic_AuPolFreeformInput AuPolFreeformInput
ON P."SystemAssignId" = AuPolFreeformInput."SystemAssignId"
INNER JOIN ViewCurPic_AuStInput AuStInput
   ON P."SystemAssignId" = AuStInput."SystemAssignId"
LEFT JOIN ViewCurPic_AUSelectedForm AUSelectedForm
   ON P."SystemAssignId" = AUSelectedForm."SystemAssignId"
   AND AuStInput."StateCd" = AUSelectedForm."StateCd"
-- LEFT JOIN ViewCurPic_AuStMPDeathBInput AuStMPDeathBInput
   -- ON P."SystemAssignId" = AuStMPDeathBInput."SystemAssignId"
   -- AND AuStInput."StateCd" = AuStMPDeathBInput."StateCd"

WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
-- AND P1."LOB" IN ('AU', 'GR', 'TU')
AND TRIM(AuSelectedForm."FormId") IN ('CA 02 03')


Order by "PolicyNumber", "StateCd", "FormId"
)
"""
try:
  # Execute the query and create a temp view for downstream use
  ca7jurcondition_manualuacti_data = eval(exec_select_landing)(ca7jurcondition_manualuacti_query)
  ca7jurcondition_manualuacti_data.createOrReplaceTempView("ca7jurcondition_manualuacti_data")  # Create a temporary view for further processing
  print(ca7jurcondition_manualuacti_data.count())  # Print the count of records retrieved
  display(ca7jurcondition_manualuacti_data)  # Display the results
except Exception as e:
  # Log the error and exit if there is an issue loading the data
  logger.info("error ca7jurcondition_manualuacti_data: {}".format(e)) 
  sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Transformation of CA7WestVAChangesCancellationIL0281 for CA7StateCond table
ca7jurcondition_query = """
SELECT CONCAT('CA7StateCond:', TRIM("PolicyNumber"), '_',
	CASE WHEN TRIM("FormId") = 'IL 02 81' THEN 'CA7WestVAChangesCancellationIL0281' END,'-', TRIM("StateCd")) AS pmt_id,
	CONCAT('Jur:', TRIM("PolicyNumber"), '-', TRIM("StateCd")) AS pmt_parent,
	CASE WHEN TRIM("FormId") = 'IL 02 81' THEN 'CA7WestVAChangesCancellationIL0281' END AS codeidentifier,
	'usd' AS currency,
    TRIM("PolicyNumber") AS pmt_payloadid
    FROM(
	
SELECT DISTINCT 
  P."SystemAssignId",
  P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
  CAST(RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",
  P."PolicyEffDt",
  CoPolicyDetail."PredStateCd" AS "PredominantStateCode",
  AuStInput."StateCd",
  RTRIM(COSelectedForm."FormId") AS "FormId",
  AUFormFillin."FillinTx" AS "PersonOrOrganization",
  AUFormFillin."PageNo" AS "PageNumber",
  AUFormFillin."OccurrenceNo" AS "OccurenceNumber",
  AUFormFillin."FillinTx" AS "NameOfExcludedDriver"
FROM Policy P1
INNER JOIN CoPolicyPointer P
   ON P."SystemAssignId" = P1."SourceSystemId"
INNER JOIN ViewCurPic_CoPolicyDetail CoPolicyDetail
   ON P."SystemAssignId" = CoPolicyDetail."SystemAssignId"
LEFT JOIN ViewCurPic_AuPolFreeformInput AuPolFreeformInput
   ON P."SystemAssignId" = AuPolFreeformInput."SystemAssignId"
INNER JOIN ViewCurPic_AuStInput AuStInput
   ON P."SystemAssignId" = AuStInput."SystemAssignId"
LEFT JOIN ViewCurPic_COSelectedForm COSelectedForm
   ON P."SystemAssignId" = COSelectedForm."SystemAssignId"
   AND AuStInput."StateCd" = COSelectedForm."StateCd"
LEFT JOIN ViewCurPic_AUFormFillin AUFormFillin
   ON P."SystemAssignId" = AUFormFillin."SystemAssignId"
   AND COSelectedForm."FormId" = AUFormFillin."FormId"
   AND COSelectedForm."FormEdCd" = AUFormFillin."FormEdCd"
WHERE RTRIM(COSelectedForm."FormId") IN ('IL 02 81')
ORDER BY "PolicyNumber", "StateCd", "FormId", "PageNumber", "OccurenceNumber"
)

--UNION ALL

--SELECT * FROM ca7jurcondition_manualuacti_data
"""
try:
  # Execute the query and create a temp view for downstream use
  ca7jurcondition_data = eval(exec_select_landing)(ca7jurcondition_query)
  ca7jurcondition_data.createOrReplaceTempView("ca7jurcondition_data")  # Create a temporary view for further processing
  print(ca7jurcondition_data.count())  # Print the count of records retrieved
  display(ca7jurcondition_data)  # Display the results
except Exception as e:
  # Log the error and exit if there is an issue loading the data
  logger.info("error ca7jurcondition_data: {}".format(e)) 
  sys.exit(1)

# COMMAND ----------

ca7jurcondition_data_final = ca7jurcondition_manualuacti_data.unionAll(ca7jurcondition_data)
ca7jurcondition_data_final.createOrReplaceTempView("ca7jurcondition_data_final")
display(ca7jurcondition_data_final)

# COMMAND ----------

# SQL to find mismatching pmt_parent, count null pmt_id, and check for duplicates for ca7statecov_ca7statecov_data
invalid_refs_sql = """
SELECT DISTINCT pmt_parent
FROM ca7jurcondition_data_final
WHERE pmt_parent NOT IN (
  SELECT DISTINCT pmt_id FROM jur_parent
)
"""

null_pmt_id_sql = """
SELECT COUNT(*) as null_count
FROM ca7jurcondition_data_final
WHERE pmt_id IS NULL
"""

duplicate_pmt_id_sql = """
SELECT pmt_id,pmt_parent,codeidentifier, COUNT(*) as cnt
FROM ca7jurcondition_data_final
GROUP BY pmt_id,pmt_parent,codeidentifier
HAVING COUNT(*) > 1
"""

invalid_refs = spark.sql(invalid_refs_sql)
null_pmt_id_count = spark.sql(null_pmt_id_sql).collect()[0]['null_count']
duplicate_pmt_ids = spark.sql(duplicate_pmt_id_sql)

if invalid_refs.count() == 0 and null_pmt_id_count == 0 and duplicate_pmt_ids.count() == 0:
    logger.info('referential integrity checks passed')
    logger.info('No Null pmt_id values found')
    logger.info('No duplicate pmt_id values found')

    ca7jurcondition_data_final.write.jdbc(url=jdbc_url_pmtin, table='CA7StateCond', mode='append', properties=properties)
else:
    if invalid_refs.count() > 0:
        logger.error("Referential integrity issue: Some pmt_parent values do not exist in jur_parent.")
        for row in invalid_refs.collect():
            logger.error(f"Invalid pmt_parent: {row.pmt_parent}")
    if null_pmt_id_count > 0:
        logger.error(f"Null pmt_id values found in ca7jurcondition_data_final: {null_pmt_id_count}")
    if duplicate_pmt_ids.count() > 0:
        logger.error("Duplicate pmt_id values found in ca7jurcondition_data_final.")
        for row in duplicate_pmt_ids.collect():
            logger.error(f"Duplicate pmt_id: {row.pmt_id} with count: {row.cnt}")