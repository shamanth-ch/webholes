# Databricks notebook source
# MAGIC %run /Workspace/Shared/GW_Mgrtn_Nprod_Databricks/GWCONV_TRANSFORMATIONS_NOTEBOOKS/GWCONV_ACCOUNT_TRANSFORMATION

# COMMAND ----------

# MAGIC %run /Workspace/Shared/GW_Mgrtn_Nprod_Databricks/GWCONV_TRANSFORMATIONS_NOTEBOOKS/GWCONV_POLICY_TRANSFORMATION

# COMMAND ----------

# MAGIC %run /Workspace/Shared/GW_Mgrtn_Nprod_Databricks/GWCONV_TRANSFORMATIONS_NOTEBOOKS/GWCONV_CAULINE_TRANSFORMATION

# COMMAND ----------

# MAGIC %run /Workspace/Shared/GW_Mgrtn_Nprod_Databricks/GWCONV_TRANSFORMATIONS_NOTEBOOKS/GWCONV_CA7AutoDealer_TRANSFORMATION

# COMMAND ----------

# MAGIC %run /Workspace/Shared/GW_Mgrtn_Nprod_Databricks/GWCONV_TRANSFORMATIONS_NOTEBOOKS/GWCONV_CA7Jurisdiction_Transformation

# COMMAND ----------

# MAGIC %run /Workspace/Shared/GW_Mgrtn_Nprod_Databricks/GWCONV_TRANSFORMATIONS_NOTEBOOKS/GWCONV_CA7Hired_Auto_TRANSFORMATION

# COMMAND ----------

# MAGIC %run /Workspace/Shared/GW_Mgrtn_Nprod_Databricks/GWCONV_TRANSFORMATIONS_NOTEBOOKS/GWCONV_CA7Non_Owned_Auto_TRANSFORMATION

# COMMAND ----------

# MAGIC %run /Workspace/Shared/GW_Mgrtn_Nprod_Databricks/GWCONV_TRANSFORMATIONS_NOTEBOOKS/GWCONV_CA7PrivatePassenger_TRANSFORMATION

# COMMAND ----------

# MAGIC %run /Workspace/Shared/GW_Mgrtn_Nprod_Databricks/GWCONV_TRANSFORMATIONS_NOTEBOOKS/GWCONV_CA7SpecialType_Transformation

# COMMAND ----------

# MAGIC %run /Workspace/Shared/GW_Mgrtn_Nprod_Databricks/GWCONV_TRANSFORMATIONS_NOTEBOOKS/GWCONV_CA7TRUCK_TRANSFORMATION

# COMMAND ----------

# MAGIC %run /Workspace/Shared/GW_Mgrtn_Nprod_Databricks/GWCONV_TRANSFORMATIONS_NOTEBOOKS/GWCONV_PUBLICTRANSPORTVECHICLES_TRANSFORMATION

# COMMAND ----------

# MAGIC %run /Workspace/Shared/GW_Mgrtn_Nprod_Databricks/GWCONV_TRANSFORMATIONS_NOTEBOOKS/GWCONV_ZONERATEDVECHICLES_TRANSFORMATION

# COMMAND ----------

# MAGIC %run /Workspace/Shared/GW_Mgrtn_Nprod_Databricks/GWCONV_TRANSFORMATIONS_NOTEBOOKS/GWCONV_Line_Standard_ISO_Coverages_Transformation

# COMMAND ----------

# MAGIC %run /Workspace/Shared/GW_Mgrtn_Nprod_Databricks/GWCONV_TRANSFORMATIONS_NOTEBOOKS/GWCONV_Line_Standard_&_Additional_Proprietary_Coverages

# COMMAND ----------

# MAGIC %run /Workspace/Shared/GW_Mgrtn_Nprod_Databricks/GWCONV_TRANSFORMATIONS_NOTEBOOKS/GWCONV_Line_Additional_ISO_Coverages_Transformation_final

# COMMAND ----------

# MAGIC %run /Workspace/Shared/GW_Mgrtn_Nprod_Databricks/GWCONV_TRANSFORMATIONS_NOTEBOOKS/GWCONV_Additional_ISO_Coverages

# COMMAND ----------

# MAGIC %run /Workspace/Shared/GW_Mgrtn_Nprod_Databricks/GWCONV_TRANSFORMATIONS_NOTEBOOKS/GWCONV_CA7JURISDICTIONCOV

# COMMAND ----------

# MAGIC %run /Workspace/Shared/GW_Mgrtn_Nprod_Databricks/GWCONV_TRANSFORMATIONS_NOTEBOOKS/GWCONV_NOACOVERAGES

# COMMAND ----------

# MAGIC %run /Workspace/Shared/GW_Mgrtn_Nprod_Databricks/GWCONV_TRANSFORMATIONS_NOTEBOOKS/GWCONV_Hired_Auto_Additional_Standard_&_ISO_Coverages

# COMMAND ----------

# MAGIC %run /Workspace/Shared/GW_Mgrtn_Nprod_Databricks/GWCONV_TRANSFORMATIONS_NOTEBOOKS/CA7CONDEXCLCOV_COVTERM

# COMMAND ----------

