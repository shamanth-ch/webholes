# Databricks notebook source
import logging
import sys
import os

LOG_FILE = 'etl_logfile.log'
LOG_FORMAT = '%(asctime)s %(levelname)s: %(message)s'

def get_etl_logger(name):
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    if logger.hasHandlers():
        logger.handlers.clear()
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.INFO)
    formatter = logging.Formatter(LOG_FORMAT)
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)
    file_handler = logging.FileHandler(LOG_FILE, mode='a')
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    return logger

logger = get_etl_logger('ca7haucov')
logger.info(f"Logging initialized. Log file location: {os.path.abspath(LOG_FILE)}")

def log_info_to_file(message):
    with open(LOG_FILE, 'a') as f:
        import datetime
        timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        f.write(f"{timestamp} INFO: {message}\n")

# COMMAND ----------

# DBTITLE 1,Configuration
# MAGIC %run ../configuration/configs

# COMMAND ----------

# DBTITLE 1,Configuration
# MAGIC %run ../configuration/postgres

# COMMAND ----------

# DBTITLE 1,Logger
# Logger setup for tracking errors and process info in this notebook
import logging
import sys

logger = logging.getLogger('Line_level_exclusions')
logger.setLevel(logging.INFO)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Hired Auto ISO Standard Coverage(Schedule)

# COMMAND ----------

# DBTITLE 1,ETL query for Hired Auto Coverage
Hired_Auto_ISO_Coverages_query = '''
    /* -------------------------------------------------------------------------------------------------------------- */
    /* NOTE: */
    /* **** This SQL runs for 20 - 30 minutes, probably due to out of sequence transactions in Policy Decisions */
    /* **** So it does full table scans to get the results */
    /* Sprint_6_CA Hired Auto Coverages */
    /* 09/26/2025 (pstemp) */
    /* Forms to research: */
    /* CA 20 33 - Autos Leased, Hired, Rented Or Borrowed With Drivers - Physical Damage */
    /* CA 99 23 - Rental Reimbursement */
    /* CA 04 39 - Volunteer Hired Autos */
    /* CA 20 54 - Employee Hired Autos */
    /* Added view ViewCurPic_AuStHiredPDInput */
    /* 09/30/2025 (pstemp) */
    /* Added fields: */
    /* HiredAutoLiabilityExcessHiredAmount */
    /* HiredAutoLiabilityPrimaryHiredAmount */
    /* 10/01/2025 (pstemp) */
    /* Added CTE ReimbursementRentalCoverage_Dedup to get Rental Reimbursement Info at the Vehicle Level */
    /* -------------------------------------------------------------------------------------------------------------- */

    /* -------------------------------------------------------------------------------------------------------------- */
    /* CTE to pull Reimbursement Rental Coverage at the Vehicle Level */
    /* -------------------------------------------------------------------------------------------------------------- */
  /*  WITH ReimbursementRentalCoverage_Dedup AS (
        SELECT DISTINCT 
            "SystemAssignId",
            "StateCd",
            "RentalCovgCd",
            "RentalReimbMaxAmt",
            "MaxDaysNo",
            ROW_NUMBER() OVER (PARTITION BY "SystemAssignId", "StateCd" ORDER BY "VehicleNo" ASC) AS "DupNum"
        FROM ViewCurPic_AuVehRentReimInput
    )*/

    -- First SQL returns all states for the forms needed
    SELECT 
        P."SystemAssignId",
        P."PolicyPrefixCd" || ' ' || TRIM(P."PolicyId") || COALESCE(TRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
        CAST(TRIM(P."PolicyId") || COALESCE(TRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",
        P."PolicyEffDt",
        CoPolicyDetail."PredStateCd" AS "PredominantStateCode",
        AuStInput."StateCd",
        AuStInput."ExcessHiredAmt" AS "HiredAutoLiabilityExcessHiredAmount",
        AuStInput."PrimaryHiredAmt" AS "HiredAutoLiabilityPrimaryHiredAmount",
        AUSelectedForm."FormId",
        AUSelectedForm."FormEdCd" AS "FormEditionCode",
        AUSelectedForm."FormDescTx" AS "FormDescription",
        NULL AS "HiredAutoPDPremiumTypeCode",
        NULL AS "HiredAutoPDOTCCostOfHireAmount",
        NULL AS "HiredAutoPDOTCDeductibleAmt",
        NULL AS "HiredAutoPDCollCostOfHireAmount",
        NULL AS "HiredAutoPDCollDeductibleAmount"
    --    ReimbursementRentalCoverage."RentalCovgCd" AS "RentalCoverage",
    --    ReimbursementRentalCoverage."RentalReimbMaxAmt" AS "RentalMaximumAmountPerDay",
     --   ReimbursementRentalCoverage."MaxDaysNo" AS "RentalMaximumNumberOfDays"
    FROM Policy AS P1
    INNER JOIN CoPolicyPointer AS P
        ON P."SystemAssignId" = P1."SourceSystemId"
    INNER JOIN ViewCurPic_CoPolicyDetail AS CoPolicyDetail
        ON P."SystemAssignId" = CoPolicyDetail."SystemAssignId"
    INNER JOIN ViewCurPic_AuStInput AS AuStInput
        ON P."SystemAssignId" = AuStInput."SystemAssignId"
    LEFT JOIN ViewCurPic_AUSelectedForm AS AUSelectedForm
        ON P."SystemAssignId" = AUSelectedForm."SystemAssignId"
        AND AuStInput."StateCd" = AUSelectedForm."StateCd"
   -- LEFT JOIN ReimbursementRentalCoverage_Dedup AS ReimbursementRentalCoverage
   --     ON P."SystemAssignId" = ReimbursementRentalCoverage."SystemAssignId"
    --    AND AuStInput."StateCd" = ReimbursementRentalCoverage."StateCd"
   --     AND ReimbursementRentalCoverage."DupNum" = 1
    WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
      AND P1."LOB" IN ('AU', 'TU')
      AND TRIM(AUSelectedForm."FormId") IN ('CA 20 33','CA 04 39','CA 20 54')

    UNION ALL

    -- Second SQL returns 'CW' County Wide state for the forms needed
    SELECT 
        P."SystemAssignId",
        P."PolicyPrefixCd" || ' ' || TRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
        CAST(TRIM(P."PolicyId") || COALESCE(TRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",
        P."PolicyEffDt",
        CoPolicyDetail."PredStateCd" AS "PredominantStateCode",
        AUSelectedForm."StateCd" AS "StateCd",
        NULL AS "HiredAutoLiabilityExcessHiredAmount",
        NULL AS "HiredAutoLiabilityPrimaryHiredAmount",
        AUSelectedForm."FormId",
        AUSelectedForm."FormEdCd" AS "FormEditionCode",
        AUSelectedForm."FormDescTx" AS "FormDescription",
        AuStHiredPDInput."PremTypeCd" AS "HiredAutoPDPremiumTypeCode",
        AuStHiredPDInput."OTCCostHireAmt" AS "HiredAutoPDOTCCostOfHireAmount",
        AuStHiredPDInput."OTCDedAmt" AS "HiredAutoPDOTCDeductibleAmt",
        AuStHiredPDInput."CollCostHireAmt" AS "HiredAutoPDCollCostOfHireAmount",
        AuStHiredPDInput."CollHireDedAmt" AS "HiredAutoPDCollDeductibleAmount"
    --    ReimbursementRentalCoverage."RentalCovgCd" AS "RentalCoverage",
     --   ReimbursementRentalCoverage."RentalReimbMaxAmt" AS "RentalMaximumAmountPerDay",
     --   ReimbursementRentalCoverage."MaxDaysNo" AS "RentalMaximumNumberOfDays"
    FROM Policy AS P1
    INNER JOIN CoPolicyPointer AS P
        ON P."SystemAssignId" = P1."SourceSystemId"
    INNER JOIN ViewCurPic_CoPolicyDetail AS CoPolicyDetail
        ON P."SystemAssignId" = CoPolicyDetail."SystemAssignId"
    LEFT JOIN ViewCurPic_AuStHiredPDInput AS AuStHiredPDInput
        ON P."SystemAssignId" = AuStHiredPDInput."SystemAssignId"
        AND CoPolicyDetail."PredStateCd" = AuStHiredPDInput."StateCd"
    LEFT JOIN ViewCurPic_AUSelectedForm AS AUSelectedForm
        ON P."SystemAssignId" = AUSelectedForm."SystemAssignId"
       AND AUSelectedForm."StateCd" = 'CW'
   -- LEFT JOIN ReimbursementRentalCoverage_Dedup AS ReimbursementRentalCoverage
  --      ON P."SystemAssignId" = ReimbursementRentalCoverage."SystemAssignId"
  --      AND CoPolicyDetail."PredStateCd" = ReimbursementRentalCoverage."StateCd"
   --     AND ReimbursementRentalCoverage."DupNum" = 1
    WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
      AND P1."LOB" IN ('AU','TU')
      AND TRIM(AUSelectedForm."FormId") IN ('CA 20 33','CA 04 39','CA 20 54')

    ORDER BY "PolicyNumber", "StateCd", "FormId"
'''


try:
    Hired_Auto_ISO_Coverages_data = eval(exec_select_landing)(Hired_Auto_ISO_Coverages_query)
    Hired_Auto_ISO_Coverages_data.createOrReplaceTempView("Hired_Auto_ISO_Coverages_data")
    print(Hired_Auto_ISO_Coverages_data.count())
    display(Hired_Auto_ISO_Coverages_data)
except Exception as e:
    logger.info("error loading Hired_Auto_ISO_Coverages_data: {}".format(e)) 
    sys.exit(1)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Hired Auto Additional Standard Coverage

# COMMAND ----------

HAU_parent =execute_select_PMTIN("select * from ca7hau")
display(HAU_parent)
HAU_parent.createOrReplaceTempView("HAU_parent")

# COMMAND ----------

# DBTITLE 1,Transformation of CA7HiredAutoAutosLeasedHiredRentedOrBorrowedWitHAU in CA7HAUSchedCovfor
CA7HAUSchedCov_CA7HiredAutoAutosLeasedHiredRentedOrBorrowedWitHAU_trans_query = '''
    SELECT DISTINCT
        concat('CA7HAUSchedCov:',trim(PolicyNumber),'_','CA7HiredAutoAutosLeasedHiredRentedOrBorrowedWitHAU') AS pmt_id,
       
        concat('CA7HAU:', trim(PolicyNumber), '-',trim(PredominantStateCode)) AS pmt_parent,
        CASE WHEN trim(FormId) = 'CA 20 33' THEN 'CA7HiredAutoAutosLeasedHiredRentedOrBorrowedWitHAU' END AS PatternCode,
        'usd' AS Currency,
        'usd' AS PreferredSettlementCurrency,
        trim(PolicyNumber) AS pmt_payloadid
    FROM Hired_Auto_ISO_Coverages_data
    WHERE trim(FormId) = 'CA 20 33'
'''

try:
  CA7HAUSchedCov_CA7HiredAutoAutosLeasedHiredRentedOrBorrowedWitHAU_trans_data = spark.sql(CA7HAUSchedCov_CA7HiredAutoAutosLeasedHiredRentedOrBorrowedWitHAU_trans_query)
  CA7HAUSchedCov_CA7HiredAutoAutosLeasedHiredRentedOrBorrowedWitHAU_trans_data.createOrReplaceTempView("CA7HAUSchedCov_CA7HiredAutoAutosLeasedHiredRentedOrBorrowedWitHAU_trans_data")
  print(CA7HAUSchedCov_CA7HiredAutoAutosLeasedHiredRentedOrBorrowedWitHAU_trans_data.count())
  display(CA7HAUSchedCov_CA7HiredAutoAutosLeasedHiredRentedOrBorrowedWitHAU_trans_data)
except Exception as e:
  logger.info("error loading CA7HAUSchedCov_CA7HiredAutoAutosLeasedHiredRentedOrBorrowedWitHAU_trans_data: {}".format(e)) 
  sys.exit(1) 

# COMMAND ----------

# SQL to find mismatching pmt_parent, count null pmt_id, and check for duplicates for CA7HAUSchedCov data
valid_refs_sql = """
SELECT *
FROM CA7HAUSchedCov_CA7HiredAutoAutosLeasedHiredRentedOrBorrowedWitHAU_trans_data
WHERE pmt_parent IN (
  SELECT DISTINCT pmt_id FROM HAU_parent
)
"""

null_pmt_id_sql = """
SELECT COUNT(*) as null_count
FROM (
  SELECT *
  FROM CA7HAUSchedCov_CA7HiredAutoAutosLeasedHiredRentedOrBorrowedWitHAU_trans_data
  WHERE pmt_parent IN (
    SELECT DISTINCT pmt_id FROM HAU_parent
  )
) t
WHERE pmt_id IS NULL
"""

duplicate_pmt_id_sql = """
SELECT pmt_id, pmt_parent, PatternCode, COUNT(*) as cnt
FROM (
  SELECT *
  FROM CA7HAUSchedCov_CA7HiredAutoAutosLeasedHiredRentedOrBorrowedWitHAU_trans_data
  WHERE pmt_parent IN (
    SELECT DISTINCT pmt_id FROM HAU_parent
  )
) t
GROUP BY pmt_id, pmt_parent, PatternCode
HAVING COUNT(*) > 1
"""

valid_refs = spark.sql(valid_refs_sql)
null_pmt_id_count = spark.sql(null_pmt_id_sql).collect()[0]['null_count']
duplicate_pmt_ids = spark.sql(duplicate_pmt_id_sql)

if null_pmt_id_count == 0 and duplicate_pmt_ids.count() == 0:
    logger.info('referential integrity checks passed')
    logger.info('No Null pmt_id values found')
    logger.info('No duplicate pmt_id values found')

    valid_refs.write.jdbc(url=jdbc_url_pmtin, table='CA7HAUSchedCov', mode='append', properties=properties)
else:
    if null_pmt_id_count > 0:
        logger.error(f"Null pmt_id values found in filtered CA7HAUSchedCov_CA7HiredAutoAutosLeasedHiredRentedOrBorrowedWitHAU_trans_data: {null_pmt_id_count}")
    if duplicate_pmt_ids.count() > 0:
        logger.error("Duplicate pmt_id values found in filtered CA7HAUSchedCov_CA7HiredAutoAutosLeasedHiredRentedOrBorrowedWitHAU_trans_data.")
        for row in duplicate_pmt_ids.collect():
            logger.error(f"Duplicate pmt_id: {row.pmt_id} with count: {row.cnt}")

# COMMAND ----------

HAUschedcov =execute_select_PMTIN("select * from ca7hauschedcov")
display(HAUschedcov)
HAUschedcov.createOrReplaceTempView("HAUschedcov")

# COMMAND ----------

# # SQL to find mismatching pmt_parent, count null pmt_id, and check for duplicates for CA7HAUSchedCov data
# invalid_refs_sql = """
# SELECT DISTINCT pmt_parent
# FROM CA7HAUSchedCov_CA7HiredAutoAutosLeasedHiredRentedOrBorrowedWitHAU_trans_data
# WHERE pmt_parent NOT IN (
#   SELECT DISTINCT pmt_id FROM HAU_parent
# )
# """

# null_pmt_id_sql = """
# SELECT COUNT(*) as null_count
# FROM CA7HAUSchedCov_CA7HiredAutoAutosLeasedHiredRentedOrBorrowedWitHAU_trans_data
# WHERE pmt_id IS NULL
# """

# duplicate_pmt_id_sql = """
# SELECT pmt_id,pmt_parent,PatternCode, COUNT(*) as cnt
# FROM CA7HAUSchedCov_CA7HiredAutoAutosLeasedHiredRentedOrBorrowedWitHAU_trans_data
# GROUP BY pmt_id,pmt_parent,PatternCode
# HAVING COUNT(*) > 1
# """

# invalid_refs = spark.sql(invalid_refs_sql)
# null_pmt_id_count = spark.sql(null_pmt_id_sql).collect()[0]['null_count']
# duplicate_pmt_ids = spark.sql(duplicate_pmt_id_sql)

# if invalid_refs.count() == 0 and null_pmt_id_count == 0 and duplicate_pmt_ids.count() == 0:
#     logger.info('referential integrity checks passed')
#     logger.info('No Null pmt_id values found')
#     logger.info('No duplicate pmt_id values found')

#     CA7HAUSchedCov_CA7HiredAutoAutosLeasedHiredRentedOrBorrowedWitHAU_trans_data.write.jdbc(url=jdbc_url_pmtin, table='CA7HAUSchedCov', mode='append', properties=properties)
# else:
#     if invalid_refs.count() > 0:
#         logger.error("Referential integrity issue: Some pmt_parent values do not exist in HAU_parent.")
#         for row in invalid_refs.collect():
#             logger.error(f"Invalid pmt_parent: {row.pmt_parent}")
#     if null_pmt_id_count > 0:
#         logger.error(f"Null pmt_id values found in CA7HAUSchedCov_CA7HiredAutoAutosLeasedHiredRentedOrBorrowedWitHAU_trans_data: {null_pmt_id_count}")
#     if duplicate_pmt_ids.count() > 0:
#         logger.error("Duplicate pmt_id values found in CA7HAUSchedCov_CA7HiredAutoAutosLeasedHiredRentedOrBorrowedWitHAU_trans_data.")
#         for row in duplicate_pmt_ids.collect():
#             logger.error(f"Duplicate pmt_id: {row.pmt_id} with count: {row.cnt}")
            

# COMMAND ----------

# DBTITLE 1,Transformation Schedule_Number_Comprehensive_Specified_Causes_Of_Loss_CoveragesCollision Coverages in CA7HAUSchedCovItem
CA7HAUSchedCovItem_Hired_Auto_Standard_Coverages_query = '''
    SELECT DISTINCT
        concat('CA7HAUSchedCovItem:',trim(h.PolicyNumber),'Hired_Auto_Standard_Coverages') AS pmt_id,
        concat('CA7HAUSchedCov:',trim(h.PolicyNumber),'_','CA7HiredAutoAutosLeasedHiredRentedOrBorrowedWitHAU') AS pmt_parent,
        'usd' AS PreferredCoverageCurrency,
        'usd' AS PreferredSettlementCurrency,
        1 AS ScheduleNumber,
        'No' AS optioncol1,
        'No' AS optioncol2,
        'No' AS optioncol3,
        trim(h.PolicyNumber) AS pmt_payloadid
    FROM Hired_Auto_ISO_Coverages_data h
    INNER JOIN HAUschedcov s
      ON trim(h.PolicyNumber) = trim(s.pmt_payloadid)
    WHERE trim(h.FormId) = 'CA 20 33'
'''

try:
  CA7HAUSchedCovItem_Hired_Auto_Standard_Coverages_data = spark.sql(CA7HAUSchedCovItem_Hired_Auto_Standard_Coverages_query)
  CA7HAUSchedCovItem_Hired_Auto_Standard_Coverages_data.createOrReplaceTempView("CA7HAUSchedCovItem_Hired_Auto_Standard_Coverages_data")
  print(CA7HAUSchedCovItem_Hired_Auto_Standard_Coverages_data.count())
  display(CA7HAUSchedCovItem_Hired_Auto_Standard_Coverages_data)
except Exception as e:
  logger.info("error loading CA7HAUSchedCovItem_Hired_Auto_Standard_Coverages_data: {}".format(e)) 
  sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Writing CA7HAUSchedCovItem in PMTIN
# SQL to find mismatching pmt_parent, count null pmt_id, and check for duplicates for CA7HAUSchedCovItem data
invalid_refs_sql = """
SELECT DISTINCT pmt_parent
FROM CA7HAUSchedCovItem_Hired_Auto_Standard_Coverages_data
WHERE pmt_parent NOT IN (
  SELECT DISTINCT pmt_id FROM CA7HAUSchedCov_CA7HiredAutoAutosLeasedHiredRentedOrBorrowedWitHAU_trans_data
)
"""

null_pmt_id_sql = """
SELECT COUNT(*) as null_count
FROM CA7HAUSchedCovItem_Hired_Auto_Standard_Coverages_data
WHERE pmt_id IS NULL
"""

duplicate_pmt_id_sql = """
SELECT pmt_id, COUNT(*) as cnt
FROM CA7HAUSchedCovItem_Hired_Auto_Standard_Coverages_data
GROUP BY pmt_id
HAVING COUNT(*) > 1
"""

invalid_refs = spark.sql(invalid_refs_sql)
null_pmt_id_count = spark.sql(null_pmt_id_sql).collect()[0]['null_count']
duplicate_pmt_ids = spark.sql(duplicate_pmt_id_sql)

if invalid_refs.count() == 0 and null_pmt_id_count == 0 and duplicate_pmt_ids.count() == 0:
    logger.info('referential integrity checks passed')
    logger.info('No Null pmt_id values found')
    logger.info('No duplicate pmt_id values found')

    CA7HAUSchedCovItem_Hired_Auto_Standard_Coverages_data.write.jdbc(url=jdbc_url_pmtin, table='CA7HAUSchedCovItem', mode='append', properties=properties)
else:
    if invalid_refs.count() > 0:
        logger.error("Referential integrity issue: Some pmt_parent values do not exist in CA7HAUSchedCov_CA7HiredAutoAutosLeasedHiredRentedOrBorrowedWitHAU_trans_data.")
        for row in invalid_refs.collect():
            logger.error(f"Invalid pmt_parent: {row.pmt_parent}")
    if null_pmt_id_count > 0:
        logger.error(f"Null pmt_id values found in CA7HAUSchedCovItem_Hired_Auto_Standard_Coverages_data: {null_pmt_id_count}")
    if duplicate_pmt_ids.count() > 0:
        logger.error("Duplicate pmt_id values found in CA7HAUSchedCovItem_Hired_Auto_Standard_Coverages_data.")
        for row in duplicate_pmt_ids.collect():
            logger.error(f"Duplicate pmt_id: {row.pmt_id} with count: {row.cnt}")
            

# COMMAND ----------

# DBTITLE 1,Transformation of CA7HiredAutoRentalReimbursementHAU in CA7HAUCov
CA7HAUCov_HiredAuto_RentalReimbursement_Volunteer_Employee_query = '''
SELECT DISTINCT
    concat('CA7HAUCov:',trim(PolicyNumber),'_',
    CASE 
         WHEN trim(FormId) = 'CA 04 39' THEN 'CA7HiredAutoVolunteerHiredAutoHAU'
         WHEN trim(FormId) = 'CA 20 54' THEN 'CA7HiredAutoEmplHiredAutosHAU'
    END) AS pmt_id,
    concat('CA7HAU:', trim(PolicyNumber), '-',trim(PredominantStateCode)) AS pmt_parent,
    CASE
         WHEN trim(FormId) = 'CA 04 39' THEN 'CA7HiredAutoVolunteerHiredAutoHAU'
         WHEN trim(FormId) = 'CA 20 54' THEN 'CA7HiredAutoEmplHiredAutosHAU'
    END AS  CodeIdentifier,
    'usd' AS currency,
    trim(PolicyNumber) AS pmt_payloadid
FROM Hired_Auto_ISO_Coverages_data
WHERE trim(FormId) IN ('CA 04 39','CA 20 54')
'''
try:
  CA7HAUCov_HiredAuto_RentalReimbursement_Volunteer_Employee_data=spark.sql(CA7HAUCov_HiredAuto_RentalReimbursement_Volunteer_Employee_query)
  CA7HAUCov_HiredAuto_RentalReimbursement_Volunteer_Employee_data.createOrReplaceTempView("CA7HAUCov_HiredAuto_RentalReimbursement_Volunteer_Employee_data")
  print(CA7HAUCov_HiredAuto_RentalReimbursement_Volunteer_Employee_data.count())
  display(CA7HAUCov_HiredAuto_RentalReimbursement_Volunteer_Employee_data)
except Exception as e:
  logger.info("error loading CA7HAUCov_HiredAuto_RentalReimbursement_Volunteer_Employee_data: {}".format(e)) 
  sys.exit(1) 

# COMMAND ----------

# DBTITLE 1,Transformation of CA7HiredAutoOthThanCollisionHAU in CA7HAUCov
CA7HAUCov_CA7HiredAutoOthThanCollisionHAU_query = '''
SELECT DISTINCT
    concat('CA7HAUCov:',trim(PolicyNumber),'_', 'CA7HiredAutoOthThanCollisionHAU') AS pmt_id,
    concat('CA7HAU:', trim(PolicyNumber), '-',trim(PredominantStateCode)) AS pmt_parent,
    CASE WHEN trim(HiredAutoPDOTCCostOfHireAmount) IS NOT NULL THEN 'CA7HiredAutoOthThanCollisionHAU'
    END AS  CodeIdentifier,
    'usd' AS currency,
    trim(PolicyNumber) AS pmt_payloadid
FROM Hired_Auto_ISO_Coverages_data
WHERE trim(HiredAutoPDOTCCostOfHireAmount) IS NOT NULL
'''
try:
  CA7HAUCov_CA7HiredAutoOthThanCollisionHAU_data=spark.sql(CA7HAUCov_CA7HiredAutoOthThanCollisionHAU_query)
  CA7HAUCov_CA7HiredAutoOthThanCollisionHAU_data.createOrReplaceTempView("CA7HAUCov_CA7HiredAutoOthThanCollisionHAU_data")
  print(CA7HAUCov_CA7HiredAutoOthThanCollisionHAU_data.count())
  display(CA7HAUCov_CA7HiredAutoOthThanCollisionHAU_data)
except Exception as e:
  logger.info("error loading CA7HAUCov_CA7HiredAutoOthThanCollisionHAU_data: {}".format(e)) 
  sys.exit(1) 

# COMMAND ----------

CA7HAUCov_CA7HiredAutoTruckersLiabHAU_query = '''
SELECT DISTINCT
    concat('CA7HAUCov:',trim(PolicyNumber),'_', 'CA7HiredAutoTruckersLiabHAU') AS pmt_id,
    concat('CA7HAU:', trim(PolicyNumber), '-',trim(PredominantStateCode)) AS pmt_parent,
    'CA7HiredAutoTruckersLiabHAU' AS  CodeIdentifier,
    'usd' AS currency,
    trim(PolicyNumber) AS pmt_payloadid
FROM Hired_Auto_ISO_Coverages_data

'''
try:
  CA7HAUCov_CA7HiredAutoTruckersLiabHAU_data=spark.sql(CA7HAUCov_CA7HiredAutoTruckersLiabHAU_query)
  CA7HAUCov_CA7HiredAutoTruckersLiabHAU_data.createOrReplaceTempView("CA7HAUCov_CA7HiredAutoTruckersLiabHAU_data")
  print(CA7HAUCov_CA7HiredAutoTruckersLiabHAU_data.count())
  display(CA7HAUCov_CA7HiredAutoTruckersLiabHAU_data)
except Exception as e:
  logger.info("error loading CA7HAUCov_CA7HiredAutoTruckersLiabHAU_data: {}".format(e)) 
  sys.exit(1) 

# COMMAND ----------

# DBTITLE 1,Transformation of CA7HiredAutoCollisionHAU in CA7HAUCov
CA7HAUCov_CA7HiredAutoCollisionHAU_query = '''
SELECT DISTINCT
    concat('CA7HAUCov:',trim(PolicyNumber),'_','CA7HiredAutoCollisionHAU') AS pmt_id,
    concat('CA7HAU:', trim(PolicyNumber), '-',trim(PredominantStateCode)) AS pmt_parent,
    CASE  WHEN trim(HiredAutoPDCollCostOfHireAmount) IS NOT NULL THEN 'CA7HiredAutoCollisionHAU'
    END AS  CodeIdentifier,
    'usd' AS currency,
    trim(PolicyNumber) AS pmt_payloadid
FROM Hired_Auto_ISO_Coverages_data
WHERE  trim(HiredAutoPDCollCostOfHireAmount) IS NOT NULL
'''
try:
  CA7HAUCov_CA7HiredAutoCollisionHAU_data=spark.sql(CA7HAUCov_CA7HiredAutoCollisionHAU_query)
  CA7HAUCov_CA7HiredAutoCollisionHAU_data.createOrReplaceTempView("CA7HAUCov_CA7HiredAutoCollisionHAU_data")
  print(CA7HAUCov_CA7HiredAutoCollisionHAU_data.count())
  display(CA7HAUCov_CA7HiredAutoCollisionHAU_data)
except Exception as e:
  logger.info("error loading CA7HAUCov_CA7HiredAutoCollisionHAU_data: {}".format(e)) 
  sys.exit(1) 

# COMMAND ----------

# DBTITLE 1,Transformation of CA7HiredAutoRentalVehicleHAU in CA7HAUCov
CA7HAUCov_CA7HiredAutoRentalVehicleHAU_query = '''
SELECT DISTINCT
    concat('CA7HAUCov:',trim(PolicyNumber),'_', 'CA7HiredAutoRentalVehicleHAU') AS pmt_id,
    concat('CA7HAU:', trim(PolicyNumber), '-',trim(PredominantStateCode)) AS pmt_parent,
    CASE WHEN trim(PredominantStateCode) = 'NY' AND trim(HiredAutoPDOTCDeductibleAmt) IS NOT NULL AND trim(HiredAutoPDOTCCostOfHireAmount) IS NOT NULL THEN 'CA7HiredAutoRentalVehicleHAU'
    END AS CodeIdentifier,
    'usd' AS currency,
    trim(PolicyNumber) AS pmt_payloadid
FROM Hired_Auto_ISO_Coverages_data
WHERE trim(PredominantStateCode) = 'NY' AND trim(HiredAutoPDOTCDeductibleAmt) IS NOT NULL AND trim(HiredAutoPDOTCCostOfHireAmount) IS NOT NULL
'''
try:
  CA7HAUCov_CA7HiredAutoRentalVehicleHAU_data=spark.sql(CA7HAUCov_CA7HiredAutoRentalVehicleHAU_query)
  CA7HAUCov_CA7HiredAutoRentalVehicleHAU_data.createOrReplaceTempView("CA7HAUCov_CA7HiredAutoRentalVehicleHAU_data")
  print(CA7HAUCov_CA7HiredAutoRentalVehicleHAU_data.count())
  display(CA7HAUCov_CA7HiredAutoRentalVehicleHAU_data)
except Exception as e:
  logger.info("error loading CA7HAUCov_CA7HiredAutoRentalVehicleHAU_data: {}".format(e)) 
  sys.exit(1) 

# COMMAND ----------

# DBTITLE 1,Transformation of CA7HiredAutoLiabHAU for CA7HAUCov
CA7HAUCov_CA7HiredAutoLiabHAU_query = '''
SELECT DISTINCT
    concat('CA7HAUCov:',trim(PolicyNumber),'_', 'CA7HiredAutoLiabHAU') AS pmt_id,
    concat('CA7HAU:', trim(PolicyNumber), '-',trim(PredominantStateCode)) AS pmt_parent,
    CASE WHEN trim(HiredAutoLiabilityExcessHiredAmount) IS NOT NULL OR trim(HiredAutoLiabilityPrimaryHiredAmount) IS NOT NULL THEN 'CA7HiredAutoLiabHAU'
    END AS CodeIdentifier,
    'usd' AS currency,
    trim(PolicyNumber) AS pmt_payloadid
FROM Hired_Auto_ISO_Coverages_data
WHERE trim(HiredAutoLiabilityExcessHiredAmount) IS NOT NULL OR trim(HiredAutoLiabilityPrimaryHiredAmount) IS NOT NULL
'''
try:
  CA7HAUCov_CA7HiredAutoLiabHAU_data=spark.sql(CA7HAUCov_CA7HiredAutoLiabHAU_query)
  CA7HAUCov_CA7HiredAutoLiabHAU_data.createOrReplaceTempView("CA7HAUCov_CA7HiredAutoLiabHAU_data")
  print(CA7HAUCov_CA7HiredAutoLiabHAU_data.count())
  display(CA7HAUCov_CA7HiredAutoLiabHAU_data)
except Exception as e:
  logger.info("error loading CA7HAUCov_CA7HiredAutoLiabHAU_data: {}".format(e)) 
  sys.exit(1) 

# COMMAND ----------

# DBTITLE 1,CA7HAUCov unions
CA7HAUCOV_Union_df = CA7HAUCov_HiredAuto_RentalReimbursement_Volunteer_Employee_data.unionAll(CA7HAUCov_CA7HiredAutoOthThanCollisionHAU_data).unionAll(CA7HAUCov_CA7HiredAutoCollisionHAU_data).unionAll(CA7HAUCov_CA7HiredAutoLiabHAU_data).unionAll( CA7HAUCov_CA7HiredAutoTruckersLiabHAU_data)
display(CA7HAUCOV_Union_df)
CA7HAUCOV_Union_df.createOrReplaceTempView("CA7HAUCOV_Union_df")

# COMMAND ----------

query = '''select * from CA7HAUCOV_Union_df where pmt_parent  in (select pmt_id from HAU_parent)'''
df = spark.sql(query)
df.createOrReplaceTempView("CA7HAUCOV_invalid_refs")
display(df)
df.write.jdbc(url=jdbc_url_pmtin, table='CA7haucov', mode='append', properties=properties)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT   h.PolicyNumber, h.FormId
# MAGIC FROM Hired_Auto_ISO_Coverages_data h
# MAGIC WHERE TRIM(h.PolicyNumber) IN (
# MAGIC   SELECT TRIM(pmt_payloadid) as PolicyNumber
# MAGIC   FROM CA7HAUCOV_Union_df
# MAGIC   WHERE pmt_parent NOT IN (
# MAGIC     SELECT DISTINCT pmt_id FROM HAU_parent
# MAGIC   )
# MAGIC )

# COMMAND ----------



# COMMAND ----------

# DBTITLE 1,Writing CA7HAUCOV in PMTIN

# # SQL to find mismatching pmt_parent, count null pmt_id, and check for duplicates for ca7haucov data
# invalid_refs_sql = """
# SELECT DISTINCT pmt_parent
# FROM CA7HAUCOV_Union_df
# WHERE pmt_parent NOT IN (
#   SELECT DISTINCT pmt_id FROM HAU_parent
# )
# """

# null_pmt_id_sql = """
# SELECT COUNT(*) as null_count
# FROM CA7HAUCOV_Union_df
# WHERE pmt_id IS NULL
# """

# duplicate_pmt_id_sql = """
# SELECT pmt_id,pmt_parent,Codeidentifier, COUNT(*) as cnt
# FROM CA7HAUCOV_Union_df
# GROUP BY pmt_id,pmt_parent,Codeidentifier
# HAVING COUNT(*) > 1
# """

# invalid_refs = spark.sql(invalid_refs_sql)
# null_pmt_id_count = spark.sql(null_pmt_id_sql).collect()[0]['null_count']
# duplicate_pmt_ids = spark.sql(duplicate_pmt_id_sql)

# if invalid_refs.count() == 0 and null_pmt_id_count == 0 and duplicate_pmt_ids.count() == 0:
#     logger.info('referential integrity checks passed')
#     logger.info('No Null pmt_id values found')
#     logger.info('No duplicate pmt_id values found')

#     CA7HAUCOV_Union_df.write.jdbc(url=jdbc_url_pmtin, table='CA7HAUCOV', mode='append', properties=properties)
# else:
#     if invalid_refs.count() > 0:
#         logger.error("Referential integrity issue: Some pmt_parent values do not exist in HAU_parent.")
#         for row in invalid_refs.collect():
#             logger.error(f"Invalid pmt_parent: {row.pmt_parent}")
#     if null_pmt_id_count > 0:
#         logger.error(f"Null pmt_id values found in CA7HAUCOV_Union_df: {null_pmt_id_count}")
#     if duplicate_pmt_ids.count() > 0:
#         logger.error("Duplicate pmt_id values found in CA7HAUCOV_Union_df.")
#         for row in duplicate_pmt_ids.collect():
#             logger.error(f"Duplicate pmt_id: {row.pmt_id} with count: {row.cnt}")
            

# COMMAND ----------

failing_payloads_query = """
SELECT DISTINCT h.PolicyNumber, h.FormId
FROM Hired_Auto_ISO_Coverages_data h
INNER JOIN (
  SELECT DISTINCT pmt_payloadid
  FROM CA7HAUCOV_Union_df
  WHERE pmt_parent NOT IN (
    SELECT DISTINCT pmt_id FROM HAU_parent
  )
) f
ON TRIM(h.PolicyNumber) = TRIM(f.pmt_payloadid)
"""

failing_payloads = spark.sql(failing_payloads_query)
display(failing_payloads)

# COMMAND ----------

