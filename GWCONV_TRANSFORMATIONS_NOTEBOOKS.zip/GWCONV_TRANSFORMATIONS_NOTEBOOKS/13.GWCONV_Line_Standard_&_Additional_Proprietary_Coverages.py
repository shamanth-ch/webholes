# Databricks notebook source
import logging
import sys
import os

LOG_FILE = 'etl_logfile.log'
LOG_FORMAT = '%(asctime)s %(levelname)s: %(message)s'

def get_etl_logger(name):
    logger = logging.getLogger(name)
    
    logger.setLevel(logging.INFO)
    if logger.hasHandlers():
        logger.handlers.clear()
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.INFO)
    formatter = logging.Formatter(LOG_FORMAT)
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)
    file_handler = logging.FileHandler(LOG_FILE, mode='a')
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    return logger

logger = get_etl_logger('ca7commautolinecov')
logger.info(f"Logging initialized. Log file location: {os.path.abspath(LOG_FILE)}")

def log_info_to_file(message):
    with open(LOG_FILE, 'a') as f:
        import datetime
        timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        f.write(f"{timestamp} INFO: {message}\n")

# COMMAND ----------

# Cell Purpose: Set up Databricks widgets and retrieve job context for tracking ETL runs.
# Business Context: Enables parameterization and job tracking for the ETL pipeline, supporting both interactive and scheduled job runs in Databricks.
"""
This cell creates widgets for job_id and job_run_id, retrieves the current notebook context, and extracts job and run IDs for logging and audit purposes.
"""
# Create widgets for job_id and job_run_id for parameterization and job tracking
# These widgets allow passing parameters when running as a Databricks job
# The job_id is used to identify the specific job, while job_run_id is used to track the execution of that job.

dbutils.widgets.text("job_id", "")
dbutils.widgets.text("job_run_id", "")

# Get the current notebook context for extracting job and run metadata
# This context provides information about the job execution environment, including job IDs and notebook path.
context = dbutils.notebook.entry_point.getDbutils().notebook().getContext()

# Extract jobId and jobRunId objects from context (may be Option types)
# These IDs are crucial for tracking the execution of the ETL process.
job_id_obj = context.jobId()          # Option type: may or may not be defined
job_run_id_obj = context.jobRunId()   # Option type: may or may not be defined

# Retrieve the full path to the current notebook for logging purposes
notebook_path = context.notebookPath().get() # Full path to the current notebook
# Extract the notebook name from the path for easier identification in logs
notebook_name = notebook_path.split('/')[-1]   # Extract the notebook name from the path

def safe_get_option(option_obj):
    """
    Safely extract a value from a Databricks Option object.
    Parameters:
        option_obj: Option (Databricks Java/Scala Option type)
            The object to extract the value from.
    Returns:
        value or None: The value if defined, else None.
    Exceptions:
        Catches all exceptions to avoid breaking job context extraction.
        This ensures that even if an error occurs, the job can continue running without interruption.
    """
    try:
        if option_obj.isDefined():
            return option_obj.get()  # Return the value if defined
        else:
            return None  # Return None if not defined
    except Exception:
        return None  # Return None in case of any exception

# Use the safe_get_option to retrieve the values, defaulting to 'Manual' if not found
# This provides a fallback mechanism for logging and auditing purposes.
job_id = safe_get_option(job_id_obj) or "Manual"    # Used for logging and audit
job_run_id = safe_get_option(job_run_id_obj) or "Manual"

# Output the retrieved IDs for debugging and traceability
# This print statement helps in verifying that the correct IDs are being used in the ETL process.
print(f"Job ID: {job_id}, Job Run ID: {job_run_id}")

# Redefine widgets with resolved values for downstream cells (ensures consistency)
# This step ensures that the widgets reflect the actual job and run IDs for any subsequent operations.
dbutils.widgets.text("job_id", str(job_id)) 
dbutils.widgets.text("job_run_id", str(job_run_id))

# COMMAND ----------

# DBTITLE 1,Configuration
# MAGIC
# MAGIC
# MAGIC %run ../configuration/configs

# COMMAND ----------

# DBTITLE 1,Configuration
# MAGIC %run ../configuration/postgres

# COMMAND ----------

# MAGIC %md
# MAGIC ##Line Level Standard - Proprietary Coverages

# COMMAND ----------

# DBTITLE 1,Standard - Commercial Auto Line Proprietary Coverages query
log_info_to_file("[START] Extraction for Proprietary_cov_data...")
logger.info("[START] Extraction for Proprietary_cov_data...")
try:
    Proprietary_cov_query = fetch_query_from_table('standard_proprietary_query')
    logger.info(f"Proprietary_cov_query: {Proprietary_cov_query}")
    log_info_to_file(f"Proprietary_cov_query: {Proprietary_cov_query}")
    Proprietary_cov_data = eval(exec_select_landing)(Proprietary_cov_query)
    Proprietary_cov_data.createOrReplaceTempView("Proprietary_cov_data")
    row_count = Proprietary_cov_data.count()
    logger.info(f"Proprietary_cov_data loaded with {row_count} rows.")
    log_info_to_file(f"Proprietary_cov_data loaded with {row_count} rows.")
    logger.info(f"Proprietary_cov_data schema: {Proprietary_cov_data.schema}")
    log_info_to_file(f"Proprietary_cov_data schema: {Proprietary_cov_data.schema}")
    logger.info("[END] Extraction for Proprietary_cov_data.")
    log_info_to_file("[END] Extraction for Proprietary_cov_data.")

except Exception as e:
    logger.error(f"Error loading Proprietary_cov_data: {e}", exc_info=True)
    log_info_to_file(f"Error loading Proprietary_cov_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------


CommAutoLine_parent =execute_select_PMT_IN_local("select * from ca7commautoline")
display(CommAutoLine_parent)
CommAutoLine_parent.createOrReplaceTempView("CommAutoLine_parent")

# COMMAND ----------

form_codeidentifier=execute_select_Framework("select * from form_codeidentifier")
form_codeidentifier.createOrReplaceTempView("form_codeidentifier")

# COMMAND ----------

# DBTITLE 1,CA7CommAutoLineCov Proprietary Coverages Transformation
CA7CommAutoLineCov_Proprietary_cov_query = '''
SELECT DISTINCT 
    concat('CA7CommAutoLineCov:', trim(a.PolicyNumber), '_', b.codeidentifier) AS pmt_id,
    concat('CA7CAL_', trim(a.PolicyNumber)) AS pmt_parent,
    b.codeidentifier AS CodeIdentifier,
    'usd' AS currency,
    trim(a.PolicyNumber) AS pmt_payloadid
FROM 
    Proprietary_cov_data a
LEFT JOIN 
    form_codeidentifier b
ON 
    trim(a.FormId) = b.pc_form_number
WHERE 
    b.codeidentifier IS NOT NULL
    AND
    trim(a.FormId) not in ('PCA 05 04','PCA 99 08')
    ;
'''

log_info_to_file("[START] Transformation for CA7CommAutoLineCov_Proprietary_cov_data...")
logger.info("[START] Transformation for CA7CommAutoLineCov_Proprietary_cov_data...")
try:
    logger.info(f"CA7CommAutoLineCov_Proprietary_cov_query: {CA7CommAutoLineCov_Proprietary_cov_query}")
    log_info_to_file(f"CA7CommAutoLineCov_Proprietary_cov_query: {CA7CommAutoLineCov_Proprietary_cov_query}")
    CA7CommAutoLineCov_Proprietary_cov_data = spark.sql(CA7CommAutoLineCov_Proprietary_cov_query)
    CA7CommAutoLineCov_Proprietary_cov_data.createOrReplaceTempView("CA7CommAutoLineCov_Proprietary_cov_data")
    display(CA7CommAutoLineCov_Proprietary_cov_data)
    row_count = CA7CommAutoLineCov_Proprietary_cov_data.count()
    logger.info(f"CA7CommAutoLineCov_Proprietary_cov_data loaded with {row_count} rows.")
    log_info_to_file(f"CA7CommAutoLineCov_Proprietary_cov_data loaded with {row_count} rows.")
    logger.info(f"CA7CommAutoLineCov_Proprietary_cov_data schema: {CA7CommAutoLineCov_Proprietary_cov_data.schema}")
    log_info_to_file(f"CA7CommAutoLineCov_Proprietary_cov_data schema: {CA7CommAutoLineCov_Proprietary_cov_data.schema}")
    logger.info("[END] Transformation for CA7CommAutoLineCov_Proprietary_cov_data.")
    log_info_to_file("[END] Transformation for CA7CommAutoLineCov_Proprietary_cov_data.")
except Exception as e:
    logger.error(f"error loading CA7CommAutoLineCov_Proprietary_cov_data: {e}", exc_info=True)
    log_info_to_file(f"error loading CA7CommAutoLineCov_Proprietary_cov_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# Validate the Proprietary Coverage Data
logger.info("Starting validation for CA7CommAutoLineCov_Proprietary_cov_data...")
validation_result = validate_data(data_name="CA7CommAutoLineCov_Proprietary_cov_data", parent_table="CommAutoLine_parent")

if validation_result is None:
    validation_result = {
        "status": False,
        "errors": [{"type": "internal_error", "details": "Validation function returned None."}],
        "warnings": []
    }

if validation_result["status"]:  # Validation passed
    logger.info("Validation passed for CA7CommAutoLineCov_Proprietary_cov_data.")
    try:
        # Get row count for the DataFrame
        row_count = CA7CommAutoLineCov_Proprietary_cov_data.count()
        logger.info(f"[START] Writing {row_count} rows to table 'ca7commautolinecov' in PMTIN.")
        log_info_to_file(f"[START] Writing {row_count} rows to table 'ca7commautolinecov' in PMTIN.")
        
        # Log schema for debugging purposes
        logger.info(f"CA7CommAutoLineCov_Proprietary_cov_data schema: {CA7CommAutoLineCov_Proprietary_cov_data.schema}")
        log_info_to_file(f"CA7CommAutoLineCov_Proprietary_cov_data schema: {CA7CommAutoLineCov_Proprietary_cov_data.schema}")
        
        # Write to PMTIN table
        write_and_log_pmtin(
            df=CA7CommAutoLineCov_Proprietary_cov_data,
            table_name="ca7commautolinecov",
            job_id=job_id,
            job_run_id=job_run_id,
            notebook_name=notebook_name
        )
        
        logger.info("[END] Successfully wrote CA7CommAutoLineCov_Proprietary_cov_data to table 'ca7commautolinecov'.")
        log_info_to_file("[END] Successfully wrote CA7CommAutoLineCov_Proprietary_cov_data to table 'ca7commautolinecov'.")
    except Exception as e:
        logger.error(f"Error writing CA7CommAutoLineCov_Proprietary_cov_data to table 'ca7commautolinecov'", exc_info=True)
        log_info_to_file(f"Error writing CA7CommAutoLineCov_Proprietary_cov_data to table 'ca7commautolinecov': {str(e)}")
        log_dataload_event(
            job_id=job_id,
            job_run_id=job_run_id,
            notebook_name=notebook_name,
            log_message=f"Error writing CA7CommAutoLineCov_Proprietary_cov_data to table: {str(e)}"
        )
        sys.exit(1)
else:
    # Validation failed – log detailed issues and write them to `pmtin_dataloadlogs`
    logger.error("Validation failed for CA7CommAutoLineCov_Proprietary_cov_data.")
    error_messages = []

    # Collect all error messages and log them
    for error in validation_result["errors"]:
        error_message = f"Validation Error: {error['type']} - {error.get('details', '')}"
        logger.error(error_message)
        log_info_to_file(error_message)
        error_messages.append(error_message)

    # Join all error messages into a single string for logging
    full_error_message = "; ".join(error_messages)
    
    # Write validation errors to `pmtin_dataloadlogs`
    log_dataload_event(
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name,
        log_message=f"Validation failed for CA7CommAutoLineCov_Proprietary_cov_data: {full_error_message}"
    )

    # Raise an exception or exit since validation failed
    raise ValueError(
        f"Validation failed for CA7CommAutoLineCov_Proprietary_cov_data. Validation errors logged: {full_error_message}."
    )

# COMMAND ----------

# DBTITLE 1,CA7CommAutoLineSchedCov Proprietary Coverages Transformation
CA7CommAutoLineSchedCov_Proprietary_cov_query = '''
    SELECT DISTINCT 
    concat('CA7CommAutoLineSchedCov:', trim(a.PolicyNumber), '_', b.codeidentifier) AS pmt_id,
    concat('CA7CAL_', trim(a.PolicyNumber)) AS pmt_parent,
    b.codeidentifier AS patterncode,
    'usd' AS currency,
    'usd' AS PreferredSettlementCurrency,
    trim(a.PolicyNumber) AS pmt_payloadid
FROM 
    Proprietary_cov_data a
LEFT JOIN 
    form_codeidentifier b
ON 
    trim(a.FormId) = b.pc_form_number
WHERE 
    b.codeidentifier IS NOT NULL
    AND trim(a.FormId) = 'PCA 05 04'

UNION ALL
SELECT DISTINCT
    concat('CA7CommAutoLineSchedCov:', trim(a.PolicyNumber), '_', 'CA7ScheduleOfLossPayee_Ext') AS pmt_id,
    concat('CA7CAL_', trim(a.PolicyNumber)) AS pmt_parent,
    b.codeidentifier AS PatternCode,
    'usd' AS Currency,
    'usd' AS PreferredSettlementCurrency,
    trim(a.PolicyNumber) AS pmt_payloadid
FROM 
    Proprietary_cov_data a
LEFT JOIN 
    form_codeidentifier b
ON 
    trim(a.FormId) = b.pc_form_number
WHERE 
    trim(a.FormId) = 'PCA 99 08'


'''

log_info_to_file("[START] Transformation for CA7CommAutoLineSchedCov_Proprietary_cov_data...")
logger.info("[START] Transformation for CA7CommAutoLineSchedCov_Proprietary_cov_data...")
try:
    logger.info(f"CA7CommAutoLineSchedCov_Proprietary_cov_query: {CA7CommAutoLineSchedCov_Proprietary_cov_query}")
    log_info_to_file(f"CA7CommAutoLineSchedCov_Proprietary_cov_query: {CA7CommAutoLineSchedCov_Proprietary_cov_query}")
    CA7CommAutoLineSchedCov_Proprietary_cov_data = spark.sql(CA7CommAutoLineSchedCov_Proprietary_cov_query)
    CA7CommAutoLineSchedCov_Proprietary_cov_data.createOrReplaceTempView("CA7CommAutoLineSchedCov_Proprietary_cov_data")
    display(CA7CommAutoLineSchedCov_Proprietary_cov_data)
    row_count = CA7CommAutoLineSchedCov_Proprietary_cov_data.count()
    logger.info(f"CA7CommAutoLineSchedCov_Proprietary_cov_data loaded with {row_count} rows.")
    log_info_to_file(f"CA7CommAutoLineSchedCov_Proprietary_cov_data loaded with {row_count} rows.")
    logger.info(f"CA7CommAutoLineSchedCov_Proprietary_cov_data schema: {CA7CommAutoLineSchedCov_Proprietary_cov_data.schema}")
    log_info_to_file(f"CA7CommAutoLineSchedCov_Proprietary_cov_data schema: {CA7CommAutoLineSchedCov_Proprietary_cov_data.schema}")
    logger.info("[END] Transformation for CA7CommAutoLineSchedCov_Proprietary_cov_data.")
    log_info_to_file("[END] Transformation for CA7CommAutoLineSchedCov_Proprietary_cov_data.")
except Exception as e:
    logger.error(f"error loading CA7CommAutoLineSchedCov_Proprietary_cov_data: {e}", exc_info=True)
    log_info_to_file(f"error loading CA7CommAutoLineSchedCov_Proprietary_cov_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# Validate the Proprietary Coverage Data
logger.info("Starting validation for CA7CommAutoLineSchedCov_Proprietary_cov_data...")
validation_result = validate_data(data_name="CA7CommAutoLineSchedCov_Proprietary_cov_data", parent_table="CommAutoLine_parent")

if validation_result is None:
    validation_result = {
        "status": False,
        "errors": [{"type": "internal_error", "details": "Validation function returned None."}],
        "warnings": []
    }

if validation_result["status"]:  # Validation passed
    logger.info("Validation passed for CA7CommAutoLineSchedCov_Proprietary_cov_data.")
    try:
        # Get row count for the DataFrame
        row_count = CA7CommAutoLineSchedCov_Proprietary_cov_data.count()
        logger.info(f"[START] Writing {row_count} rows to table 'ca7commautolineschedcov' in PMTIN.")
        log_info_to_file(f"[START] Writing {row_count} rows to table 'ca7commautolineschedcov' in PMTIN.")
        
        # Log schema for debugging purposes
        logger.info(f"CA7CommAutoLineSchedCov_Proprietary_cov_data schema: {CA7CommAutoLineSchedCov_Proprietary_cov_data.schema}")
        log_info_to_file(f"CA7CommAutoLineSchedCov_Proprietary_cov_data schema: {CA7CommAutoLineSchedCov_Proprietary_cov_data.schema}")
        
        # Write to PMTIN table
        write_and_log_pmtin(
            df=CA7CommAutoLineSchedCov_Proprietary_cov_data,
            table_name="ca7commautolineschedcov",
            job_id=job_id,
            job_run_id=job_run_id,
            notebook_name=notebook_name,
            truncate=False
        )
        
        logger.info("[END] Successfully wrote CA7CommAutoLineSchedCov_Proprietary_cov_data to table 'ca7commautolineschedcov'.")
        log_info_to_file("[END] Successfully wrote CA7CommAutoLineSchedCov_Proprietary_cov_data to table 'ca7commautolineschedcov'.")
    except Exception as e:
        logger.error(f"Error writing CA7CommAutoLineSchedCov_Proprietary_cov_data to table 'ca7commautolineschedcov'", exc_info=True)
        log_info_to_file(f"Error writing CA7CommAutoLineSchedCov_Proprietary_cov_data to table 'ca7commautolineschedcov': {str(e)}")
        log_dataload_event(
            job_id=job_id,
            job_run_id=job_run_id,
            notebook_name=notebook_name,
            log_message=f"Error writing CA7CommAutoLineSchedCov_Proprietary_cov_data to table: {str(e)}"
        )
        sys.exit(1)
else:
    # Validation failed – log detailed issues and write them to `pmtin_dataloadlogs`
    logger.error("Validation failed for CA7CommAutoLineSchedCov_Proprietary_cov_data.")
    error_messages = []

    # Collect all error messages and log them
    for error in validation_result["errors"]:
        error_message = f"Validation Error: {error['type']} - {error.get('details', '')}"
        logger.error(error_message)
        log_info_to_file(error_message)
        error_messages.append(error_message)

    # Join all error messages into a single string for logging
    full_error_message = "; ".join(error_messages)
    
    # Write validation errors to `pmtin_dataloadlogs`
    log_dataload_event(
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name,
        log_message=f"Validation failed for CA7CommAutoLineSchedCov_Proprietary_cov_data: {full_error_message}"
    )

    # Raise an exception or exit since validation failed
    raise ValueError(
        f"Validation failed for CA7CommAutoLineSchedCov_Proprietary_cov_data. Validation errors logged: {full_error_message}."
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ##Line Level Additional -Proprietary Coverages

# COMMAND ----------

# DBTITLE 1,Schedule_of_Loss_Payee_query

try:
  # Execute the query and create a temp view for downstream use
  Schedule_of_Loss_Payee_query=fetch_query_from_table("schedule_of_loss_payee")
  Schedule_of_Loss_Payee_data = eval(exec_select_landing)(Schedule_of_Loss_Payee_query)
  Schedule_of_Loss_Payee_data.createOrReplaceTempView("Schedule_of_Loss_Payee_data")  # Create a temporary view for further processing
  print(Schedule_of_Loss_Payee_data.count())  # Print the count of records retrieved
  display(Schedule_of_Loss_Payee_data)  # Display the results
except Exception as e:
  # Log the error and exit if there is an issue loading the data
  logger.info("error loading Schedule_of_Loss_Payee_data: {}".format(e)) 
  sys.exit(1)


# COMMAND ----------

# DBTITLE 1,Transformation of _CA7ScheduleOfLossPayee_Ext for CA7LineSchedCovItem
CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_query = '''
WITH numbered_data AS (
    SELECT
        concat('CA7LineSchedCovItem:', trim(PolicyNumber), '_CA7ScheduleOfLossPayee_Ext') AS base_pmt_id,
        concat('CA7CommAutoLineSchedCov:', trim(PolicyNumber), '_', 'CA7ScheduleOfLossPayee_Ext') AS pmt_parent,
        'usd' AS PreferredCoverageCurrency,
        'usd' AS PreferredSettlementCurrency,
        1 AS ScheduleNumber,
        concat(trim(AdditionalInterestName), ' ', trim(AdditionalInterestAddress), ' ', trim(AdditionalInterestCity), ' ', trim(AdditionalInterestState), ' ', trim(AdditionalInterestZipCode)) AS longstringcol1,
        concat(trim(VehicleNumber), ' ', trim(VehicleYear), ' ', trim(VehicleMake), ' ', trim(VehicleModel), ' ', trim(VehicleDescription), ' ', trim(VehicleVIN)) AS longstringcol2,
        trim(PolicyNumber) AS pmt_payloadid,
        ROW_NUMBER() OVER (
            PARTITION BY trim(PolicyNumber)
            ORDER BY trim(PolicyNumber)
        ) AS rn
    FROM Schedule_of_Loss_Payee_data
    WHERE trim(FormId) = 'PCA 99 08'
)

SELECT 
    concat(base_pmt_id, '_', rn) AS pmt_id,
    pmt_parent,
    PreferredCoverageCurrency,
    PreferredSettlementCurrency,
    ScheduleNumber,
    longstringcol1,
    longstringcol2,
    pmt_payloadid
FROM numbered_data
'''

log_info_to_file("[START] Transformation for CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data...")
logger.info("[START] Transformation for CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data...")
try:
    logger.info(f"CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_query: {CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_query}")
    log_info_to_file(f"CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_query: {CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_query}")
    CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data = spark.sql(CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_query)
    CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data.createOrReplaceTempView("CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data")
    display(CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data)
    row_count = CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data.count()
    logger.info(f"CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data loaded with {row_count} rows.")
    log_info_to_file(f"CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data loaded with {row_count} rows.")
    logger.info(f"CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data schema: {CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data.schema}")
    log_info_to_file(f"CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data schema: {CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data.schema}")
    logger.info("[END] Transformation for CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data.")
    log_info_to_file("[END] Transformation for CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data.")
except Exception as e:
    logger.error(f"error loading CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data: {e}", exc_info=True)
    log_info_to_file(f"error loading CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# Validate the CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data
logger.info("Starting validation for CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data...")
validation_result = validate_data(data_name="CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data", parent_table="CA7CommAutoLineSchedCov_Proprietary_cov_data")

if validation_result is None:
    validation_result = {
        "status": False,
        "errors": [{"type": "internal_error", "details": "Validation function returned None."}],
        "warnings": []
    }

if validation_result["status"]:  # Validation passed
    logger.info("Validation passed for CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data.")
    try:
        # Get row count for the DataFrame
        row_count = CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data.count()
        logger.info(f"[START] Writing {row_count} rows to table 'CA7LineSchedCovItem' in PMTIN.")
        log_info_to_file(f"[START] Writing {row_count} rows to table 'CA7LineSchedCovItem' in PMTIN.")
        
        # Log schema for debugging purposes
        logger.info(f"CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data schema: {CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data.schema}")
        log_info_to_file(f"CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data schema: {CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data.schema}")
        
        # Write to PMTIN table
        write_and_log_pmtin(
            df=CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data,
            table_name="CA7LineSchedCovItem",
            job_id=job_id,
            job_run_id=job_run_id,
            notebook_name=notebook_name
        )
        
        logger.info("[END] Successfully wrote CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data to table 'CA7LineSchedCovItem'.")
        log_info_to_file("[END] Successfully wrote CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data to table 'CA7LineSchedCovItem'.")
    except Exception as e:
        logger.error(f"Error writing CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data to table 'CA7LineSchedCovItem'", exc_info=True)
        log_info_to_file(f"Error writing CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data to table 'CA7LineSchedCovItem': {str(e)}")
        log_dataload_event(
            job_id=job_id,
            job_run_id=job_run_id,
            notebook_name=notebook_name,
            log_message=f"Error writing CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data to table: {str(e)}"
        )
        sys.exit(1)
else:
    # Validation failed – log detailed issues and write them to `pmtin_dataloadlogs`
    logger.error("Validation failed for CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data.")
    error_messages = []

    # Collect all error messages and log them
    for error in validation_result["errors"]:
        error_message = f"Validation Error: {error['type']} - {error.get('details', '')}"
        logger.error(error_message)
        log_info_to_file(error_message)
        error_messages.append(error_message)

    # Join all error messages into a single string for logging
    full_error_message = "; ".join(error_messages)
    
    # Write validation errors to `pmtin_dataloadlogs`
    log_dataload_event(
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name,
        log_message=f"Validation failed for CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data: {full_error_message}"
    )

    # Raise an exception or exit since validation failed
    raise ValueError(
        f"Validation failed for CA7LineSchedCovItem_CA7ScheduleOfLossPayee_Ext_data. Validation errors logged: {full_error_message}."
    )

# COMMAND ----------

