# Databricks notebook source
# MAGIC %run ../configuration/configs

# COMMAND ----------

# MAGIC %run ../configuration/postgres

# COMMAND ----------

# Logger setup for tracking errors and process info in this notebook
import logging
import sys

logger = logging.getLogger('ca7jurcov_df')
logger.setLevel(logging.INFO)

# COMMAND ----------

eval(exec_cmd_pmtin)('truncate table public.ca7statecov')
eval(exec_cmd_pmtin)('truncate table public.ca7stateschedcov')

# COMMAND ----------

ca7jurcov_query="""
/* -------------------------------------------------------------------------------------------------------------- */
/* Sprint_6_CA Jurisdiction ISO and Proprietary Coverage                                                          */
/* 09/19/2025 (pstemp)                                                                                            */
/* Main Source ViewCurPic_AuStUMInput                                                                             */
/* Added Predomiant State                                                                                         */
/* -------------------------------------------------------------------------------------------------------------- */
WITH FormCheckPCA0301 AS (
    SELECT AUSelectedForm."SystemAssignId", AUSelectedForm."StateCd"
    FROM ViewCurPic_AUSelectedForm AUSelectedForm
    WHERE AUSelectedForm."FormId" IN ('PCA 03 01')
)
select 
/* ---------------------- */
/* CoPolicyPointer fields */
/* ---------------------- */
P."SystemAssignId"
,P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"),' ') as "PolicyNumber"
,CAST (RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"),' ') AS VARCHAR(8)) AS "AccountNumber"
,P."PolicyEffDt"

/* -------------------------------- */
/* ViewCurPic_CoPolicyDetail Fields */
/* -------------------------------- */
,CoPolicyDetail."PredStateCd" AS "PredominantStateCode"

/* --------------------------- */
/* ViewCurPic_AuStInput fields */
/* --------------------------- */
,AuStInput."StateCd",

/* -------------------------------------- */
/* ViewCurPic_AuStUMInput fields          */
/* -------------------------------------- */
 AuPolInput."LiabSymbolLst" AS "LiabilitySymbol",
     AuPolInput."LiabLimitTypeCd" AS "LiabilityLimitTypeCode",
    AuPolInput."CSLLiabLimit" AS "LiabilityLimit",
    AuPolInput."BI1Limit" AS "BI1Limit",
    AuPolInput."BI2Limit" AS "BI2Limit",
    AuPolInput."PDLimit" AS "PDLimit",
    AuPolInput."LiabDedTypeCd" AS "LiabilityDeductionTypeCode",
    AuPolInput."LiabDedAmt" AS "LiabilityDeductible"

,AuStUMInput."TypeLimit" AS "LimitTypeUMUIM"
,AuStUMInput."CombLimt" AS "UMCLSLimit"
,AuStUMInput."BI1Limit" AS "UMBILimit1"
,AuStUMInput."BI2Limit" AS "UMBILimit2"
,AuStUMInput."PDLimit" AS "UMPDLimt"
,AuStUMInput."UIMCombLimit" AS "UIMCLSLimit"
,AuStUMInput."UIMBI1Limit" AS "UIMBILimit1"
,AuStUMInput."UIMBI2Limit" AS "UIMBILimit2"
,AuStUMInput."UIMPDLimit" AS "UIMPDLimt"
,AuStUMInput."IndivCoupleInd" AS "IndividualNamedInsured"
,AuStUMInput."MiscInfoInd" AS "UMMisc",
CASE WHEN FormCheckPCA0301."SystemAssignId" IS NOT NULL THEN 'Y' ELSE 'N' END AS "DoesFormPCA0301Exist"



FROM policy P1
INNER JOIN copolicypointer P
   ON P."SystemAssignId" = P1."SourceSystemId"
   
   
INNER JOIN viewcurpic_copolicydetail CoPolicyDetail
   ON P."SystemAssignId" = CoPolicyDetail."SystemAssignId"
INNER JOIN viewcurpic_austinput AuStInput
   ON P."SystemAssignId" = AuStInput."SystemAssignId"
INNER JOIN viewcurpic_austuminput AuStUMInput
   ON P."SystemAssignId" = AuStUMInput."SystemAssignId"
   AND AuStInput."StateCd" = AuStUMInput."StateCd"
INNER JOIN ViewCurPic_AuPolInput AuPolInput
    ON P."SystemAssignId" = AuPolInput."SystemAssignId"

LEFT JOIN FormCheckPCA0301
    ON P."SystemAssignId" = FormCheckPCA0301."SystemAssignId"


WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
AND P1."LOB" IN ('AU', 'GR', 'TU')

order by "PolicyNumber", "StateCd"
--Order by LimitTypeUMUIM desc


"""
try:
  # Execute the query and create a temp view for downstream use
  ca7jurcov_df = eval(exec_select_landing)(ca7jurcov_query)
  ca7jurcov_df.createOrReplaceTempView("ca7jurcov_df")  # Create a temporary view for further processing
  print(ca7jurcov_df.count())  # Print the count of records retrieved
  display(ca7jurcov_df)  # Display the results
except Exception as e:
  # Log the error and exit if there is an issue loading the data
  logger.info("error ca7jurcov: {}".format(e)) 
  sys.exit(1)

# COMMAND ----------

jur_parent = execute_select_PMTIN("select * from ca7jurisdiction")
jur_parent.createOrReplaceTempView("jur_parent")
display(jur_parent)

# COMMAND ----------

jur_formcode_query = '''
-- Query to extract Commercial Auto Line Proprietary Coverage Forms with mapping

SELECT 
    -- CoPolicyPointer fields
    P."SystemAssignId",
    P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
    CAST(RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",
    P."PolicyEffDt",
    -- ViewCurPic_AuStInput fields
    AuStInput."StateCd",
    -- ViewCurPic_AUSelectedForm fields
    AUSelectedForm."FormId",
    AUSelectedForm."FormDescTx" AS "FormDescription",
    CASE 
        WHEN trim(AUSelectedForm."FormId") = 'PCA 05 50' THEN 'CA7MobileEquipmentAmendatoryEndorsementVA_Ext'
        WHEN trim(AUSelectedForm."FormId") = 'CA 01 90' THEN 'CA7CTChangesLiabOfMunicipalities'
        WHEN trim(AUSelectedForm."FormId") = 'P02104' THEN 'CA7SchOfUnUndrInsrdMtrCov_Ext'
        WHEN trim(AUSelectedForm."FormId") = 'PCA 0557 NY' THEN 'CA7WaiverOfDeprecationNewPrivatePassVehicleNY_Ext'
        WHEN trim(AUSelectedForm."FormId") = 'PCA 20 36' THEN 'CA7WhoIsAnInsdAmenCA_Ext'
        WHEN trim(AUSelectedForm."FormId") IN ('PCA 03 01','PCA 03 02','PCA 03 06','PCA 03 08','PCA 03 10') THEN 'CA7CommAutomblDedEnd_Ext'
        WHEN trim(AUSelectedForm."FormId") = 'CA 02 04' THEN 'CA7ChangesCancellationForOversizedVehicles'
        WHEN trim(AUSelectedForm."FormId") = 'CA 22 68' THEN 'CA7PIPOptionalWaiverOfScheduledMedicalExpenseBenef'
        WHEN trim(AUSelectedForm."FormId") = 'CA 04 05' THEN 'CA7TXRuralElectrificationCooperativeEndorsement'
        WHEN trim(AUSelectedForm."FormId") = 'CA 01 89' THEN 'CA7WestVAChangesCovExtensionForTemporarySubstitute'
        WHEN trim(AUSelectedForm."FormId") = 'CA 04 15' THEN 'CA7GaragekeepersCovForAutosAndWatercrafts'
        WHEN trim(AUSelectedForm."FormId") = 'PCA 05 25' THEN 'CA7BodilyInjuryRedefined_Ext'
        WHEN trim(AUSelectedForm."FormId") = 'PCA 20 41' THEN 'CA7ClmExpIncldCov_Ext'
        WHEN trim(AUSelectedForm."FormId") = 'PCA 20 40' THEN 'CA7DedLiabRmbrstCovFL_Ext'
        WHEN trim(AUSelectedForm."FormId") = 'PCA 20 08' THEN 'CA7DedLiabRmbrstCov_Ext'
        WHEN trim(AUSelectedForm."FormId") = 'PCA 20 37' THEN 'CA7DedLiabRmbrstKY_Ext'
        WHEN trim(AUSelectedForm."FormId") = 'PCA 05 09' THEN 'CA7ExtendedCancellationCondIL_Ext'
        WHEN trim(AUSelectedForm."FormId") = 'PCA 05 34' THEN 'CA7FLGlassRepairWaiverOfDedForOtherThanWinshield_Ext'
        WHEN trim(AUSelectedForm."FormId") = 'PCA 05 22' AND trim(AuStInput."StateCd") = 'FL' THEN 'CA7PhyDamageAddTranFL_Ext'
        WHEN trim(AUSelectedForm."FormId") = 'PCA 05 22' AND trim(AuStInput."StateCd") = 'VA' THEN 'CA7PhyDamageAddTranVA_Ext'
        WHEN trim(AUSelectedForm."FormId")= 'CA 22 01' THEN 'CA7NamedIndivsBroadenedPersonalInjuryProtection' 
        -- sprint 8 
        WHEN trim(AUSelectedForm."FormId")='CA 21 12' THEN 'CA7IAUninsuredAndUnderinsuredMotoristsCov'
        WHEN trim(AUSelectedForm."FormId")='CA 25 85' THEN 'CA7CustomerComplaintLegalDefenseCovWithNoCovForNew'
        WHEN trim(AUSelectedForm."FormId")='CA 25 87' THEN 'CA7ExtendedReportingPeriodForEmpBensLiabCovWithNoC'
        WHEN trim(AUSelectedForm."FormId")='CA 04 20' THEN 'CA7NYSupplementalSpousalBILiabCov'
        WHEN trim(AUSelectedForm."FormId")='CA 99 09' THEN 'CA7DistrictOfColumbiaEmplsUsingAutosInGovBusinessM'
        WHEN trim(AUSelectedForm."FormId")='CA 20 45' THEN 'CA7NYTowTrucks'
        WHEN trim(AUSelectedForm."FormId")='CA 01 78' THEN 'CA7LAChangesCovExtensionForRentalVehicles'
        WHEN trim(AUSelectedForm."FormId")='CA 99 89' THEN 'CA7LossPayableFormReg335'
        WHEN trim(AUSelectedForm."FormId")='CA 01 06' THEN 'CA7COAndMDChangesInPolicyCollisionCovInMexico'
        WHEN trim(AUSelectedForm."FormId") in ( 'CA 04 52', 'CA 04 64') THEN 'CA7OnHook'
    END AS "FormId_Mapped",

    NonOwnedInput."NOwnEmplCnt" AS "Nonownedemployeecount",
    austhiredpdinput."CollCostHireAmt" AS "CostOfHireInsuredProvidingPrimary",
    austhiredpdinput."OTCCostHireAmt" AS "CostOfHireInsuredProvidingExcess",
    AuStAttyFeeInput."AttyFeeLimit" AS JudgementAmount,
    AuStMPDeathBInput."WorkLossTypeCd" AS MedPayDeathWorkLossTypeCode

FROM policy P1
INNER JOIN copolicypointer P
   ON P."SystemAssignId" = P1."SourceSystemId"
INNER JOIN viewcurpic_austinput AuStInput
   ON P."SystemAssignId" = AuStInput."SystemAssignId"

LEFT JOIN viewcurpic_austhiredpdinput austhiredpdinput
  ON P."SystemAssignId" = austhiredpdinput."SystemAssignId"
  AND AuStInput."StateCd" = austhiredpdinput."StateCd"
LEFT JOIN ViewCurPic_AuStNonOwnedInput NonOwnedInput
  ON P."SystemAssignId" = NonOwnedInput."SystemAssignId"
  AND AuStInput."StateCd"= NonOwnedInput."StateCd"
LEFT JOIN viewcurpic_auselectedform AUSelectedForm
   ON P."SystemAssignId" = AUSelectedForm."SystemAssignId"
   AND trim(AuStInput."StateCd") = trim(AUSelectedForm."StateCd")
LEFT JOIN "ViewCurPic_AuStAttyFeeInput" AuStAttyFeeInput
   ON P."SystemAssignId" = AuStAttyFeeInput."SystemAssignId"
   AND AuStInput."StateCd" = AuStAttyFeeInput."StateCd"
LEFT JOIN "ViewCurPic_AuStMPDeathBInput" AuStMPDeathBInput
   ON P."SystemAssignId" = AuStMPDeathBInput."SystemAssignId"
   AND AuStInput."StateCd" = AuStMPDeathBInput."StateCd"

WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
  AND P1."LOB" IN ('AU', 'GR', 'TU')
  AND (
    trim(AUSelectedForm."FormId") IN (
      'PCA 05 50',
      'CA 01 90',
      'P02104',
      'PCA 0557 NY',
      'PCA 20 36',
      'PCA 03 01','PCA 03 02','PCA 03 06','PCA 03 08','PCA 03 10',
      'CA 02 04',
      'CA 22 68',
      'CA 04 05',
      'CA 01 89',
      'CA 04 15',
      'PCA 05 25',
      'PCA 20 41',
      'PCA 20 40',
      'PCA 20 08',
      'PCA 20 37',
      'PCA 05 09',
      'PCA 05 34',
      'PCA 05 22',
      'CA 22 01',
      'CA 21 12',
      'CA 25 85',
      'CA 25 87',
      'CA 04 20',
      'CA 99 09',
      'CA 20 45',
      'CA 01 78',
      'CA 99 89',
      'CA 01 06',
      'CA 04 52',
      'CA 04 64'
    )
  )
ORDER BY "PolicyNumber", "StateCd", "FormId"
'''

try:
  jur_formcode_df = eval(exec_select_landing)(jur_formcode_query)
  jur_formcode_df.createOrReplaceTempView("jur_formcode_df")
  print(jur_formcode_df.count())
  display(jur_formcode_df)
except Exception as e:
  logger.info("error loading jur_formcode_df: {}".format(e))
  sys.exit(1)

# COMMAND ----------

jur_formcode_VAAKND_query = '''
-- Query to extract Commercial Auto Line Proprietary Coverage Forms with mapping

SELECT 
    -- CoPolicyPointer fields
    P."SystemAssignId",
    P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
    CAST(RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",
    P."PolicyEffDt",
    -- ViewCurPic_AuStInput fields
    AuStInput."StateCd",
    -- ViewCurPic_AUSelectedForm fields
    AUSelectedForm."FormId",
    AUSelectedForm."FormDescTx" AS "FormDescription",
    CASE 
        WHEN trim(AuStInput."StateCd") = 'VA' AND AuStMPDeathBInput."WorkLossTypeCd" IS NOT NULL THEN 'CA7MedicalExpenseAndIncomeLossBenefitsEndorsement'
        WHEN trim(AuStInput."StateCd") = 'AK' AND AuStAttyFeeInput."AttyFeeLimit" IS NOT NULL THEN 'CA7AKChangesAttorneysFees'
        WHEN (austhiredpdinput."CollCostHireAmt" IS NOT NULL  
              OR austhiredpdinput."OTCCostHireAmt" IS NOT NULL  
              OR NonOwnedInput."NOwnEmplCnt" IS NOT NULL) 
             AND trim(AuStInput."StateCd") = 'ND' 
             THEN 'CA7NDChangesRentalVehicleCovPrivatePassengerAutos'
    END AS "FormId_Mapped",

    AuStAttyFeeInput."AttyFeeLimit" AS JudgementAmount,
    AuStMPDeathBInput."WorkLossTypeCd" AS MedPayDeathWorkLossTypeCode,
    austhiredpdinput."CollCostHireAmt" as collcosthireamt,
    austhiredpdinput."OTCCostHireAmt" as otcchireamt,
    NonOwnedInput."NOwnEmplCnt" as NonOwnedEmplCnt

FROM policy P1
INNER JOIN copolicypointer P
   ON P."SystemAssignId" = P1."SourceSystemId"
INNER JOIN viewcurpic_austinput AuStInput
   ON P."SystemAssignId" = AuStInput."SystemAssignId"

LEFT JOIN viewcurpic_austhiredpdinput austhiredpdinput
  ON P."SystemAssignId" = austhiredpdinput."SystemAssignId"
  AND AuStInput."StateCd" = austhiredpdinput."StateCd"
LEFT JOIN ViewCurPic_AuStNonOwnedInput NonOwnedInput
  ON P."SystemAssignId" = NonOwnedInput."SystemAssignId"
  AND AuStInput."StateCd"= NonOwnedInput."StateCd"
LEFT JOIN viewcurpic_auselectedform AUSelectedForm
   ON P."SystemAssignId" = AUSelectedForm."SystemAssignId"
   AND trim(AuStInput."StateCd") = trim(AUSelectedForm."StateCd")
LEFT JOIN "ViewCurPic_AuStAttyFeeInput" AuStAttyFeeInput
   ON P."SystemAssignId" = AuStAttyFeeInput."SystemAssignId"
   AND AuStInput."StateCd" = AuStAttyFeeInput."StateCd"
LEFT JOIN "ViewCurPic_AuStMPDeathBInput" AuStMPDeathBInput
   ON P."SystemAssignId" = AuStMPDeathBInput."SystemAssignId"
   AND AuStInput."StateCd" = AuStMPDeathBInput."StateCd"

WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
  AND P1."LOB" IN ('AU', 'GR', 'TU')
  AND (
    trim(AuStInput."StateCd") = 'VA'
    OR trim(AuStInput."StateCd") = 'AK'
    OR trim(AuStInput."StateCd") = 'ND'
  )
ORDER BY "PolicyNumber", "StateCd", "FormId"
'''

try:
  jur_formcode_VAAKND_df = eval(exec_select_landing)(jur_formcode_VAAKND_query)
  jur_formcode_VAAKND_df.createOrReplaceTempView("jur_formcode_VAKAND_df")
  print(jur_formcode_VAAKND_df.count())
  display(jur_formcode_VAAKND_df)
except Exception as e:
  logger.info("error loading jur_formcode_VAAKND_df: {}".format(e))
  sys.exit(1)

# COMMAND ----------

jur_onhookcollision_query = '''
/* -------------------------------------------------------------------------------------------------------------- */
/* Sprint 7 - On-Hook Coverage                                                                                    */
/* --------                                                                                                       */
/* Views used:                                                                                                    */
/* ViewCurPic_AuStInput, ViewCurPic_AuStGKLInput                                                                  */
/* -------------------------------------------------------------------------------------------------------------- */

SELECT 
    /* ---------------------- */
    /* CoPolicyPointer fields */
    /* ---------------------- */
    P."SystemAssignId",
    P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
    CAST(RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",
    /* ----------------- */
    /* AuPolInput fields */
    /* ----------------- */
    AuPolInput."NAICCd" AS "NAICCode",

    /* ------------------------------------ */
    /* ViewCurPic_AuStInput fields          */
    /* ------------------------------------ */
    AuStInput."StateCd" AS "StateCd",
    AuStInput."GKLAllPerDedInd" AS "AllPerilsDeductible",

    /* ------------------------------------ */
    /* ViewCurPic_AuStGKLInput fields       */
    /* ------------------------------------ */
    AuStGKLInput."CompLimit" AS "CompLimit",
    AuStGKLInput."CompDed1Amt" AS "CompDeductible",
    AuStGKLInput."SpecPerilsLimit" AS "SCLLimit",
    AuStGKLInput."SpecPerilsDed1Amt" AS "SCLDeductible",
    AuStGKLInput."CollLimit" AS "CollisionLimit",
    AuStGKLInput."CollDedAmt" AS "CollisionDeductible",
    
    /* ------------------------------------ */
    /* RatingBase info:                     */
    /* Legal Liability = 1                  */
    /* Direct Primary = 2                   */
    /* Direct Excess = 3                    */
    /* ------------------------------------ */
    AuStGKLInput."RatingBasisInd" AS "RatingBase"

FROM policy P1 
INNER JOIN copolicypointer P
    ON P."SystemAssignId" = P1."SourceSystemId"
INNER JOIN viewcurpic_aupolinput AuPolInput
    ON P."SystemAssignId" = AuPolInput."SystemAssignId"
INNER JOIN viewcurpic_austinput AuStInput
    ON P."SystemAssignId" = AuStInput."SystemAssignId"
INNER JOIN "ViewCurPic_AuStGKLInput"  AuStGKLInput
    ON P."SystemAssignId" = AuStGKLInput."SystemAssignId"
    AND AuStInput."StateCd" = AuStGKLInput."StateCd"

WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
AND P1."LOB" IN ('AU', 'GR', 'TU')

ORDER BY "PolicyNumber", "StateCd"
'''

try:
    jur_onhookcollision_df = eval(exec_select_landing)(jur_onhookcollision_query)
    jur_onhookcollision_df.createOrReplaceTempView("jur_onhookcollision_df")
    display(jur_onhookcollision_df)
except Exception as e:
    logger.info("error ca7statecov_df: {}".format(e))
    sys.exit(1)

# COMMAND ----------

jur_employeebenefits_query = '''
/* -------------------------------------------------------------------------------------------------------------- */
/* Sprint 7 - Employee Benefits Liability                                                                         */
/* --------                                                                                                       */
/* Views used:                                                                                                    */
/* ViewCurPic_AuPolInput, ViewCurPic_AuPolOthCovgInput                                                            */
/* -------------------------------------------------------------------------------------------------------------- */

SELECT 
    -- CoPolicyPointer fields
    P."SystemAssignId",
    P1."LOB",
    P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
    CAST(RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",

    -- AuPolInput fields
    AuPolInput."NAICCd" AS "NAICCode",

    AuPolOthCovgInput."CovgCd",
    AuPolOthCovgInput."Limit1" AS "AggregateLimit",
    AuPolOthCovgInput."ChargeTypeInd" AS "TypeOfCharge",
    AuPolOthCovgInput."Prem1Amt" AS "PremiumCharge",
    AuPolOthCovgInput."FlatChargeInd" AS "FlatCharge",
    AuPolOthCovgInput."FullyEarnedInd" AS "FullyEarned",
    AuPolOthCovgInput."Limit2" AS "EachEmployeeLimit",
    AuPolOthCovgInput."DedAmt" AS "Deductible",
    AuPolOthCovgInput."Prem2Amt" AS "ExtReptPremCharge",
    AuPolOthCovgInput."RetroDt" AS "RetroDate",

--AustInput fields
 AuStInput."StateCd" AS "StateCd",

 --CoPolicyDetail fields

CoPolicyDetail."PredStateCd" AS "PredominantStateCode"




    


FROM policy P1
INNER JOIN copolicypointer P
    ON P."SystemAssignId" = P1."SourceSystemId"

INNER JOIN ViewCurPic_CoPolicyDetail AS CoPolicyDetail
    ON P."SystemAssignId" = CoPolicyDetail."SystemAssignId"

INNER JOIN viewcurpic_austinput AuStInput
    ON P."SystemAssignId" = AuStInput."SystemAssignId"
     AND CoPolicyDetail."PredStateCd" = AuStInput."StateCd"

INNER JOIN viewcurpic_aupolinput AuPolInput
    ON P."SystemAssignId" = AuPolInput."SystemAssignId"
INNER JOIN viewcurpic_aupolothcovginput AuPolOthCovgInput
    ON P."SystemAssignId" = AuPolOthCovgInput."SystemAssignId"
    AND AuPolOthCovgInput."CovgCd" = 'EMBE'

WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
AND P1."LOB" IN ('AU', 'GR', 'TU')

ORDER BY "PolicyNumber", "SystemAssignId"
'''

try:
    jur_employeebenefits_df = eval(exec_select_landing)(jur_employeebenefits_query)
    jur_employeebenefits_df.createOrReplaceTempView("jur_employeebenefits_df")
    print(jur_employeebenefits_df.count())
    display(jur_employeebenefits_df)
except Exception as e:
    logger.info("error loading jur_employeebenefits_df: {}".format(e))
    sys.exit(1)

# COMMAND ----------

NoFaultPip_query = '''
/* -------------------------------------------------------------------------------------------------------------- */
/* Sprint 7 - No Fault PIP                                                                                        */
/* --------                                                                                                       */
/* Views used:                                                                                                    */
/* ViewCurPic_AuStInput, ViewCurPic_AuStNoFltPIPInput                                                             */
/* -------------------------------------------------------------------------------------------------------------- */

SELECT 
    /* ---------------------- */
    /* CoPolicyPointer fields */
    /* ---------------------- */
    P."SystemAssignId",
    P1."LOB",
    (P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ')) AS "PolicyNumber",
    CAST(RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",

    /* ----------------- */
    /* AuPolInput fields */
    /* ----------------- */
    AuPolInput."NAICCd" AS "NAICCode",
    AuPolInput."PIPSymbolLst" AS "PIPSymbollist",
    AuPolInput."AddPIPSymbolLst" AS "AddPIPSymbollist",
    
  
    /* ------------------------------------ */
    /* ViewCurPic_AuStInput fields          */
    /* ------------------------------------ */
    AuStInput."StateCd" AS "StateCd",

    /* ------------------------------------ */
    /* ViewCurPic_AuStNoFltPIPInput fields  */
    /* ------------------------------------ */
    AuStNoFltPIPInput."NoFltPIPThrshAmt" AS "PIPLimit",
    AuStNoFltPIPInput."AddlNoFltPIPInd" AS "AdditionPIP",
    AuStNoFltPIPInput."WorkLossLimit" AS "WorkLoss",
    AuStNoFltPIPInput."PIPDedLimit" AS "PIPDeductible",
    AuStNoFltPIPInput."PIPMisc1Ind" AS "PIPMisc1",
    AuStNoFltPIPInput."PIPMisc2Ind" AS "PIPMisc2",
    /* ------------------------------------- */
    /* PIPMisc4 Info:                        */
    /* Y                                     */
    /* N                                     */
    /* 1 - 100,000                           */
    /* 2 - 300,000                           */
    /* 3 - 500,000                           */
    /* 4 - 1,000,000                         */
    /* ------------------------------------- */
    AuStNoFltPIPInput."PIPMisc4Ind" AS "PIPMisc4",
    AuStNoFltPIPInput."MedExpenseLimit" AS "MedExpenseLimit"

FROM policy P1 
INNER JOIN copolicypointer P
    ON P."SystemAssignId" = P1."SourceSystemId"
INNER JOIN viewcurpic_aupolinput AuPolInput
    ON P."SystemAssignId" = AuPolInput."SystemAssignId"
INNER JOIN viewcurpic_austinput AuStInput
    ON P."SystemAssignId" = AuStInput."SystemAssignId"
INNER JOIN viewcurpic_austnofltpipinput AuStNoFltPIPInput
    ON P."SystemAssignId" = AuStNoFltPIPInput."SystemAssignId"
    AND AuStInput."StateCd" = AuStNoFltPIPInput."StateCd"

WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
AND P1."LOB" IN ('AU', 'GR', 'TU')

ORDER BY "PIPMisc1" DESC
'''

try:
    NoFaultPip_df = eval(exec_select_landing)(NoFaultPip_query)
    NoFaultPip_df.createOrReplaceTempView("NoFaultPip_df")
    print(NoFaultPip_df.count())
    display(NoFaultPip_df)
except Exception as e:
    logger.info("error loading NoFaultPip_df: {}".format(e))
    sys.exit(1)

# COMMAND ----------

ca7statecov_ca7statecov_query = '''
SELECT DISTINCT
    -- CA7UninsuredMotoristPropertyDamage1
    concat('Jur:', trim(PolicyNumber), '-CA7UninsuredMotoristPropertyDamage1-', trim(StateCd)) AS pmt_id,
    concat('Jur:', trim(PolicyNumber), '-', trim(StateCd)) AS pmt_parent,
    'CA7UninsuredMotoristPropertyDamage1' AS CodeIdentifier,
    'usd' AS currency,
    trim(PolicyNumber) AS pmt_payloadid
FROM ca7jurcov_df
WHERE LimitTypeUMUIM IS NOT NULL

UNION ALL

SELECT DISTINCT
    -- CA7UnderinsuredMotoristPropertyDamage1
    concat('Jur:', trim(PolicyNumber), '-CA7UnderinsuredMotoristPropertyDamage1-', trim(StateCd)) AS pmt_id,
    concat('Jur:', trim(PolicyNumber), '-', trim(StateCd)) AS pmt_parent,
    'CA7UnderinsuredMotoristPropertyDamage1' AS CodeIdentifier,
    'usd' AS currency,
    trim(PolicyNumber) AS pmt_payloadid
FROM ca7jurcov_df
WHERE LimitTypeUMUIM IS NOT NULL

UNION ALL

SELECT DISTINCT
    concat('Jur:', trim(PolicyNumber), '-CA7VehicleLiabJurisdiction-', trim(StateCd)) AS pmt_id,
    concat('Jur:', trim(PolicyNumber), '-', trim(StateCd)) AS pmt_parent,
    'CA7VehicleLiabJurisdiction' AS CodeIdentifier,
    'usd' AS currency,
    trim(PolicyNumber) AS pmt_payloadid
FROM ca7jurcov_df
WHERE LiabilitySymbol IS NOT NULL

UNION ALL

-- Add all mapped FormId_Mapped from jur_formcode_df
SELECT DISTINCT
    concat('Jur:', trim(PolicyNumber), '-', FormId_Mapped, '-', trim(StateCd)) AS pmt_id,
    concat('Jur:', trim(PolicyNumber), '-', trim(StateCd)) AS pmt_parent,
    FormId_Mapped AS CodeIdentifier,
    'usd' AS currency,
    trim(PolicyNumber) AS pmt_payloadid
FROM jur_formcode_df
WHERE FormId_Mapped IS NOT NULL

UNION ALL

SELECT DISTINCT
    concat('Jur:', trim(PolicyNumber), '-', FormId_Mapped, '-', trim(StateCd)) AS pmt_id,
    concat('Jur:', trim(PolicyNumber), '-', trim(StateCd)) AS pmt_parent,
    FormId_Mapped AS CodeIdentifier,
    'usd' AS currency,
    trim(PolicyNumber) AS pmt_payloadid
FROM jur_formcode_VAKAND_df
WHERE FormId_Mapped IS NOT NULL
/*
--UNION ALL

SELECT DISTINCT
    concat('Jur:', trim(PolicyNumber), '-CA7OnHook-', trim(StateCd)) AS pmt_id,
    concat('Jur:', trim(PolicyNumber), '-', trim(StateCd)) AS pmt_parent,
    'CA7OnHook' AS CodeIdentifier,
    'usd' AS currency,
    trim(PolicyNumber) AS pmt_payloadid
FROM jur_onhookcollision_df
*/
UNION ALL

SELECT DISTINCT
    concat('Jur:', trim(PolicyNumber), '-CA7EmplBenefitsLiabCovWithNoCovForNewlyAcquiredOrF-', trim(StateCd)) AS pmt_id,
    concat('Jur:', trim(PolicyNumber), '-', trim(StateCd)) AS pmt_parent,
    'CA7EmplBenefitsLiabCovWithNoCovForNewlyAcquiredOrF' AS CodeIdentifier,
    'usd' AS currency,
    trim(PolicyNumber) AS pmt_payloadid
FROM jur_employeebenefits_df
WHERE AggregateLimit IS NOT NULL OR EachEmployeeLimit IS NOT NULL

UNION ALL 

SELECT DISTINCT
    concat('Jur:', trim(PolicyNumber), '-CA7AddedAndCombinationFirstPartyBenefitsEndorsemen-', trim(StateCd)) AS pmt_id,
    concat('Jur:', trim(PolicyNumber), '-', trim(StateCd)) AS pmt_parent,
    'CA7AddedAndCombinationFirstPartyBenefitsEndorsemen' AS CodeIdentifier,
    'usd' AS currency,
    trim(PolicyNumber) as pmt_payloadid
FROM NoFaultPip_df 
WHERE trim(StateCd)='PA' AND trim(PIPSymbollist)='5' AND trim(AddPIPSymbollist)='5' AND trim(PIPLimit)='1ST PARTY'

UNION ALL

SELECT DISTINCT
    concat('Jur:', trim(PolicyNumber), '-CA7AddedPersonalInjuryProtection1-', trim(StateCd)) AS pmt_id,
    concat('Jur:', trim(PolicyNumber), '-', trim(StateCd)) AS pmt_parent,
    'CA7AddedPersonalInjuryProtection1' AS CodeIdentifier,
    'usd' AS currency,
    trim(PolicyNumber) as pmt_payloadid
FROM NoFaultPip_df 
WHERE AdditionPIP IS NOT NULL

'''

try:
    ca7statecov_ca7statecov_data = spark.sql(ca7statecov_ca7statecov_query)
    ca7statecov_ca7statecov_data.createOrReplaceTempView("ca7statecov_ca7statecov_data")
    print(ca7statecov_ca7statecov_data.count())
    display(ca7statecov_ca7statecov_data)
except Exception as e:
    logger.info("error ca7statecov_df: {}".format(e))
    sys.exit(1)

# COMMAND ----------


# SQL to find mismatching pmt_parent, count null pmt_id, and check for duplicates for ca7statecov_ca7statecov_data
invalid_refs_sql = """
SELECT DISTINCT pmt_parent
FROM ca7statecov_ca7statecov_data
WHERE pmt_parent NOT IN (
  SELECT DISTINCT pmt_id FROM jur_parent
)
"""

null_pmt_id_sql = """
SELECT COUNT(*) as null_count
FROM ca7statecov_ca7statecov_data
WHERE pmt_id IS NULL
"""

duplicate_pmt_id_sql = """
SELECT pmt_id, COUNT(*) as cnt
FROM ca7statecov_ca7statecov_data
GROUP BY pmt_id
HAVING COUNT(*) > 1
"""

invalid_refs = spark.sql(invalid_refs_sql)
null_pmt_id_count = spark.sql(null_pmt_id_sql).collect()[0]['null_count']
duplicate_pmt_ids = spark.sql(duplicate_pmt_id_sql)

if invalid_refs.count() == 0 and null_pmt_id_count == 0 and duplicate_pmt_ids.count() == 0:
    logger.info('referential integrity checks passed')
    logger.info('No Null pmt_id values found')
    logger.info('No duplicate pmt_id values found')

    ca7statecov_ca7statecov_data.write.jdbc(url=jdbc_url_pmtin, table='ca7statecov', mode='append', properties=properties)
else:
    if invalid_refs.count() > 0:
        logger.error("Referential integrity issue: Some pmt_parent values do not exist in jur_parent.")
        for row in invalid_refs.collect():
            logger.error(f"Invalid pmt_parent: {row.pmt_parent}")
    if null_pmt_id_count > 0:
        logger.error(f"Null pmt_id values found in ca7statecov_ca7statecov_data: {null_pmt_id_count}")
    if duplicate_pmt_ids.count() > 0:
        logger.error("Duplicate pmt_id values found in ca7statecov_ca7statecov_data.")
        for row in duplicate_pmt_ids.collect():
            logger.error(f"Duplicate pmt_id: {row.pmt_id} with count: {row.cnt}")

# COMMAND ----------

jur_formcodesched_query = '''
-- Query to extract Commercial Auto Line Proprietary Coverage Forms with mapping

SELECT 
    -- CoPolicyPointer fields
    P."SystemAssignId",
    P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
    CAST(RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",
    P."PolicyEffDt",
    -- ViewCurPic_AuStInput fields
    AuStInput."StateCd",
    -- ViewCurPic_AUSelectedForm fields
    AUSelectedForm."FormId",
    AUSelectedForm."FormDescTx" AS "FormDescription",
    CASE 
        WHEN trim(AUSelectedForm."FormId") = 'PIL 02 40' THEN 'CA7AlskaNtcOfCancel_Ext'
        WHEN trim(AUSelectedForm."FormId") = 'PIL 02 39' THEN 'CA7DsgntdEntyAlskaCov_Ext'
        WHEN trim(AUSelectedForm."FormId") = 'PCA 05 47' THEN 'CA7ImpoundedAutoEndorsmnt_Ext'
    END AS "FormId_Mapped",

    NonOwnedInput."NOwnEmplCnt" AS "Nonownedemployeecount",
    austhiredpdinput."CollCostHireAmt" AS "CostOfHireInsuredProvidingPrimary",
    austhiredpdinput."OTCCostHireAmt" AS "CostOfHireInsuredProvidingExcess",
    AuStAttyFeeInput."AttyFeeLimit" AS JudgementAmount,
    AuStMPDeathBInput."WorkLossTypeCd" AS MedPayDeathWorkLossTypeCode

  

FROM policy P1
INNER JOIN copolicypointer P
   ON P."SystemAssignId" = P1."SourceSystemId"
INNER JOIN viewcurpic_austinput AuStInput
   ON P."SystemAssignId" = AuStInput."SystemAssignId"

LEFT JOIN viewcurpic_austhiredpdinput austhiredpdinput
  ON P."SystemAssignId" = austhiredpdinput."SystemAssignId"
  AND AuStInput."StateCd" = austhiredpdinput."StateCd"
LEFT JOIN ViewCurPic_AuStNonOwnedInput NonOwnedInput
  ON P."SystemAssignId" = NonOwnedInput."SystemAssignId"
  AND AuStInput."StateCd"= NonOwnedInput."StateCd"
LEFT JOIN viewcurpic_auselectedform AUSelectedForm
   ON P."SystemAssignId" = AUSelectedForm."SystemAssignId"
   AND trim(AuStInput."StateCd") = trim(AUSelectedForm."StateCd")
LEFT JOIN "ViewCurPic_AuStAttyFeeInput" AuStAttyFeeInput
   ON P."SystemAssignId" = AuStAttyFeeInput."SystemAssignId"
   AND AuStInput."StateCd" = AuStAttyFeeInput."StateCd"
LEFT JOIN "ViewCurPic_AuStMPDeathBInput" AuStMPDeathBInput
   ON P."SystemAssignId" = AuStMPDeathBInput."SystemAssignId"
   AND AuStInput."StateCd" = AuStMPDeathBInput."StateCd"

WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
  AND P1."LOB" IN ('AU', 'GR', 'TU')
  AND (
    trim(AUSelectedForm."FormId") IN (
      'PIL 02 40','PIL 02 39','PCA 05 47'
    )
  )
ORDER BY "PolicyNumber", "StateCd", "FormId"
'''

try:
  jur_formcodesched_df = eval(exec_select_landing)(jur_formcodesched_query)
  jur_formcodesched_df.createOrReplaceTempView("jur_formcodesched_df")
  print(jur_formcodesched_df.count())
  display(jur_formcodesched_df)
except Exception as e:
  logger.info("error loading jur_formcode_df: {}".format(e))
  sys.exit(1)

# COMMAND ----------

jur_formcodesched_Garkeep_query = '''
SELECT 
    -- CoPolicyPointer fields
    P."SystemAssignId",
    P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
    CAST(RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",
    P."PolicyEffDt",
    AuStInput."StateCd",
    grlocgklinput."CompMaxLmt" AS CompMaxLmt,
    grlocgklinput."SpecPerilsMaxLmt" AS SpecPerilsMaxLmt,
    grlocgklinput."CollMaxLmt" AS CollMaxLmt,
    CASE 
        WHEN grlocgklinput."CompMaxLmt" IS NOT NULL 
          OR grlocgklinput."SpecPerilsMaxLmt" IS NOT NULL 
          OR grlocgklinput."CollMaxLmt" IS NOT NULL 
        THEN 'CA7Garagekeepers'
        ELSE NULL
    END AS FormId_Mapped
FROM policy P1
INNER JOIN copolicypointer P
    ON P."SystemAssignId" = P1."SourceSystemId"
INNER JOIN viewcurpic_austinput AuStInput
    ON P."SystemAssignId" = AuStInput."SystemAssignId"
LEFT JOIN viewcurpic_austhiredpdinput austhiredpdinput
    ON P."SystemAssignId" = austhiredpdinput."SystemAssignId"
    AND AuStInput."StateCd" = austhiredpdinput."StateCd"
LEFT JOIN ViewCurPic_AuStNonOwnedInput NonOwnedInput
    ON P."SystemAssignId" = NonOwnedInput."SystemAssignId"
    AND AuStInput."StateCd" = NonOwnedInput."StateCd"
LEFT JOIN viewcurpic_auselectedform AUSelectedForm
    ON P."SystemAssignId" = AUSelectedForm."SystemAssignId"
    AND trim(AuStInput."StateCd") = trim(AUSelectedForm."StateCd")
LEFT JOIN "ViewCurPic_AuStAttyFeeInput" AuStAttyFeeInput
    ON P."SystemAssignId" = AuStAttyFeeInput."SystemAssignId"
    AND AuStInput."StateCd" = AuStAttyFeeInput."StateCd"
LEFT JOIN "ViewCurPic_AuStMPDeathBInput" AuStMPDeathBInput
    ON P."SystemAssignId" = AuStMPDeathBInput."SystemAssignId"
    AND AuStInput."StateCd" = AuStMPDeathBInput."StateCd"
LEFT JOIN "viewcurpic_grlocgklinput" grlocgklinput
    ON P."SystemAssignId" = grlocgklinput."SystemAssignId"
    AND trim(AuStInput."StateCd") = grlocgklinput."StateCd"
WHERE P1."PolicyStatus" IN ('INFORCE', 'FUTURE')
    AND P1."LOB" IN ('AU', 'GR', 'TU')
ORDER BY "PolicyNumber", "StateCd"
'''

try:
  jur_formcodesched_Garkeep_df = eval(exec_select_landing)(jur_formcodesched_Garkeep_query)
  jur_formcodesched_Garkeep_df.createOrReplaceTempView("jur_formcodesched_Garkeep_df")
  print(jur_formcodesched_df.count())
  display(jur_formcodesched_Garkeep_df)
except Exception as e:
  logger.info("error loading jur_formcode_df: {}".format(e))
  sys.exit(1)

# COMMAND ----------

ca7schedcov_query = '''

-- Add all mapped FormId_Mapped from jur_formcode_df
SELECT DISTINCT
    concat('Jursched:', trim(PolicyNumber), '-', FormId_Mapped, '-', trim(StateCd)) AS pmt_id,
    concat('Jur:', trim(PolicyNumber), '-', trim(StateCd)) AS pmt_parent,
    FormId_Mapped AS patterncode,
    'usd' AS currency,
    trim(PolicyNumber) AS pmt_payloadid
FROM jur_formcodesched_df
WHERE FormId_Mapped IS NOT NULL
UNION ALL

SELECT DISTINCT
    concat('Jursched:', trim(PolicyNumber), '-', FormId_Mapped, '-', trim(StateCd)) AS pmt_id,
    concat('Jur:', trim(PolicyNumber), '-', trim(StateCd)) AS pmt_parent,
    FormId_Mapped AS patterncode,
    'usd' AS currency,
    trim(PolicyNumber) AS pmt_payloadid
FROM jur_formcodesched_Garkeep_df
WHERE FormId_Mapped IS NOT NULL
'''

try:
    ca7schedcov_data = spark.sql(ca7schedcov_query)
    ca7schedcov_data.createOrReplaceTempView("ca7schedcov_data")
    print(ca7schedcov_data.count())
    display(ca7schedcov_data)
except Exception as e:
    logger.info("error ca7statecov_df: {}".format(e))
    sys.exit(1)

# COMMAND ----------

jur_CA7PANamedIndivsBroadenedFirstPartyBenefits_query = '''
select 
      P."SystemAssignId",
    P."PolicyPrefixCd" || ' ' || RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS "PolicyNumber",
    CAST(RTRIM(P."PolicyId") || COALESCE(RTRIM(P."PolicySuffixCd"), ' ') AS VARCHAR(8)) AS "AccountNumber",
  austnofltpipinput."StateCd",
  austnofltpipinput."MedExpenseLimit",
  austnofltpipinput."WorkLossLimit",
  austnofltpipinput."FuneralExpenseInd"
from policy P1
inner join copolicypointer P
  on P."SystemAssignId" = P1."SourceSystemId"
inner join viewcurpic_austnofltpipinput austnofltpipinput
  on P."SystemAssignId" = austnofltpipinput."SystemAssignId"
where austnofltpipinput."StateCd" = 'PA'
  and austnofltpipinput."NoFltPIPThrshAmt" = '1ST PARTY'
  and austnofltpipinput."BrdAddlPIPInd" is not null
'''

try:
  jur_CA7PANamedIndivsBroadenedFirstPartyBenefits_df = eval(exec_select_landing)(jur_CA7PANamedIndivsBroadenedFirstPartyBenefits_query)
  jur_CA7PANamedIndivsBroadenedFirstPartyBenefits_df.createOrReplaceTempView("jur_CA7PANamedIndivsBroadenedFirstPartyBenefits_df")
  print(jur_CA7PANamedIndivsBroadenedFirstPartyBenefits_df.count())
  display(jur_CA7PANamedIndivsBroadenedFirstPartyBenefits_df)
except Exception as e:
  logger.info("error loading jur_formcode_df: {}".format(e))
  sys.exit(1)

# COMMAND ----------

ca7schedcov_query = '''

-- Add all mapped FormId_Mapped from jur_formcode_df
SELECT DISTINCT
    concat('Jursched:', trim(PolicyNumber), '-', FormId_Mapped, '-', trim(StateCd)) AS pmt_id,
    concat('Jur:', trim(PolicyNumber), '-', trim(StateCd)) AS pmt_parent,
    FormId_Mapped AS patterncode,
    'usd' AS currency,
    trim(PolicyNumber) AS pmt_payloadid
FROM jur_formcodesched_df
WHERE FormId_Mapped IS NOT NULL

UNION ALL

SELECT DISTINCT
    concat('Jursched:', trim(PolicyNumber), '-','CA7PANamedIndivsBroadenedFirstPartyBenefits' , '-', trim(StateCd)) AS pmt_id,
    concat('Jur:', trim(PolicyNumber), '-', trim(StateCd)) AS pmt_parent,
    'CA7PANamedIndivsBroadenedFirstPartyBenefits' AS patterncode,
    'usd' AS currency,
    trim(PolicyNumber) AS pmt_payloadid
FROM jur_CA7PANamedIndivsBroadenedFirstPartyBenefits_df

UNION ALL

SELECT DISTINCT
    concat('Jursched:', trim(PolicyNumber), '-', FormId_Mapped, '-', trim(StateCd)) AS pmt_id,
    concat('Jur:', trim(PolicyNumber), '-', trim(StateCd)) AS pmt_parent,
    FormId_Mapped AS patterncode,
    'usd' AS currency,
    trim(PolicyNumber) AS pmt_payloadid
FROM jur_formcodesched_Garkeep_df
WHERE FormId_Mapped IS NOT NULL


'''

try:
    ca7schedcov_data = spark.sql(ca7schedcov_query)
    ca7schedcov_data.createOrReplaceTempView("ca7schedcov_data")
    print(ca7schedcov_data.count())
    display(ca7schedcov_data)
except Exception as e:
    logger.info("error ca7statecov_df: {}".format(e))
    sys.exit(1)

# COMMAND ----------

# SQL to find mismatching pmt_parent, count null pmt_id, and check for duplicates for ca7schedcov_data
invalid_refs_sql = """
SELECT DISTINCT pmt_parent
FROM ca7schedcov_data
WHERE pmt_parent NOT IN (
  SELECT DISTINCT pmt_id FROM jur_parent
)
"""

null_pmt_id_sql = """
SELECT COUNT(*) as null_count
FROM ca7schedcov_data
WHERE pmt_id IS NULL
"""

duplicate_pmt_id_sql = """
SELECT pmt_id, COUNT(*) as cnt
FROM ca7schedcov_data
GROUP BY pmt_id
HAVING COUNT(*) > 1
"""

invalid_refs = spark.sql(invalid_refs_sql)
null_pmt_id_count = spark.sql(null_pmt_id_sql).collect()[0]['null_count']
duplicate_pmt_ids = spark.sql(duplicate_pmt_id_sql)

if invalid_refs.count() == 0 and null_pmt_id_count == 0 and duplicate_pmt_ids.count() == 0:
    logger.info('referential integrity checks passed')
    logger.info('No Null pmt_id values found')
    logger.info('No duplicate pmt_id values found')

    ca7schedcov_data.write.jdbc(url=jdbc_url_pmtin, table='ca7stateschedcov', mode='append', properties=properties)
else:
    if invalid_refs.count() > 0:
        logger.error("Referential integrity issue: Some pmt_parent values do not exist in jur_parent.")
        for row in invalid_refs.collect():
            logger.error(f"Invalid pmt_parent: {row.pmt_parent}")
    if null_pmt_id_count > 0:
        logger.error(f"Null pmt_id values found in ca7schedcov_data: {null_pmt_id_count}")
    if duplicate_pmt_ids.count() > 0:
        logger.error("Duplicate pmt_id values found in ca7schedcov_data.")
        for row in duplicate_pmt_ids.collect():
            logger.error(f"Duplicate pmt_id: {row.pmt_id} with count: {row.cnt}")

# COMMAND ----------



# COMMAND ----------

