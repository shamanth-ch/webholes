# Databricks notebook source
# Cell Purpose: Initialize logging for the ETL pipeline.
# Business Context: Ensures consistent, formatted logs for debugging, auditing, and monitoring the Guidewire insurance migration ETL process.
"""
This cell sets up a logger for the ETL process, configuring log levels and formatting for consistent output.
- Uses INFO for general logs and DEBUG for detailed debugging.
- StreamHandler outputs logs to the notebook console.
- FileHandler outputs logs to etl_logfile.log for persistent tracking.
- Any logger (by name) can be configured to write to this file by using the same FileHandler setup.
"""
import logging
import sys
import os
import datetime

LOG_FILE = 'etl_logfile.log'
LOG_FORMAT = '%(asctime)s %(levelname)s: %(message)s'

# Function to get a logger and ensure it logs to both console and the shared file
def get_etl_logger(name):
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    
    # Remove all handlers if already set (to avoid duplicate logs in notebook reruns)
    if logger.hasHandlers():
        logger.handlers.clear()
    
    # StreamHandler for console output
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.INFO)
    formatter = logging.Formatter(LOG_FORMAT)
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)
    
    # FileHandler for log file
    file_handler = logging.FileHandler(LOG_FILE)
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(formatter)
    
    # Ensure the FileHandler is not duplicated
    if not any(isinstance(h, logging.FileHandler) for h in logger.handlers):
        logger.addHandler(file_handler)
    
    return logger

# Function to log info messages to the ETL log file
def log_info_to_file(message):
    """
    Appends a message to the ETL log file with a timestamp (INFO level).
    """
    with open(LOG_FILE, 'a') as f:
        timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        f.write(f"{timestamp} INFO: {message}\n")

# Example: get the logger for this notebook
logger = get_etl_logger('Public transport')
logger.info(f"Logging initialized. Log file location: {os.path.abspath(LOG_FILE)}")

# COMMAND ----------

# Cell Purpose: Set up Databricks widgets and retrieve job context for tracking ETL runs.
# Business Context: Enables parameterization and job tracking for the ETL pipeline, supporting both interactive and scheduled job runs in Databricks.
"""
This cell creates widgets for job_id and job_run_id, retrieves the current notebook context, and extracts job and run IDs for logging and audit purposes.
"""
# Create widgets for job_id and job_run_id for parameterization and job tracking
# These widgets allow passing parameters when running as a Databricks job
# The job_id is used to identify the specific job, while job_run_id is used to track the execution of that job.

dbutils.widgets.text("job_id", "")
dbutils.widgets.text("job_run_id", "")

# Get the current notebook context for extracting job and run metadata
# This context provides information about the job execution environment, including job IDs and notebook path.
context = dbutils.notebook.entry_point.getDbutils().notebook().getContext()

# Extract jobId and jobRunId objects from context (may be Option types)
# These IDs are crucial for tracking the execution of the ETL process.
job_id_obj = context.jobId()          # Option type: may or may not be defined
job_run_id_obj = context.jobRunId()   # Option type: may or may not be defined

# Retrieve the full path to the current notebook for logging purposes
notebook_path = context.notebookPath().get() # Full path to the current notebook
# Extract the notebook name from the path for easier identification in logs
notebook_name = notebook_path.split('/')[-1]   # Extract the notebook name from the path

def safe_get_option(option_obj):
    """
    Safely extract a value from a Databricks Option object.
    Parameters:
        option_obj: Option (Databricks Java/Scala Option type)
            The object to extract the value from.
    Returns:
        value or None: The value if defined, else None.
    Exceptions:
        Catches all exceptions to avoid breaking job context extraction.
        This ensures that even if an error occurs, the job can continue running without interruption.
    """
    try:
        if option_obj.isDefined():
            return option_obj.get()  # Return the value if defined
        else:
            return None  # Return None if not defined
    except Exception:
        return None  # Return None in case of any exception

# Use the safe_get_option to retrieve the values, defaulting to 'Manual' if not found
# This provides a fallback mechanism for logging and auditing purposes.
job_id = safe_get_option(job_id_obj) or "Manual"    # Used for logging and audit
job_run_id = safe_get_option(job_run_id_obj) or "Manual"

# Output the retrieved IDs for debugging and traceability
# This print statement helps in verifying that the correct IDs are being used in the ETL process.
print(f"Job ID: {job_id}, Job Run ID: {job_run_id}")

# Redefine widgets with resolved values for downstream cells (ensures consistency)
# This step ensures that the widgets reflect the actual job and run IDs for any subsequent operations.
dbutils.widgets.text("job_id", str(job_id)) 
dbutils.widgets.text("job_run_id", str(job_run_id))

# COMMAND ----------

# DBTITLE 1,Run the Configuration
# MAGIC %run ../configuration/configs

# COMMAND ----------

# DBTITLE 1,Run the Configuration
# MAGIC %run ../configuration/postgres

# COMMAND ----------

# DBTITLE 1,ETL query for Public Transport table
log_info_to_file("[START] Extraction for pt_vehicles_data...")
logger.info("[START] Extraction for pt_vehicles_data...")
try:
   pt_vehicles_query = fetch_query_from_table('ca7publictransport')
   logger.info(f"Fetched query for ca7publictransport: {pt_vehicles_query}")
   log_info_to_file(f"Fetched query for ca7publictransport: {pt_vehicles_query}")
   pt_vehicles_data = eval(exec_select_landing)(pt_vehicles_query)
   pt_vehicles_data.createOrReplaceTempView("pt_vehicles_data")
   row_count = pt_vehicles_data.count()
   logger.info(f"pt_vehicles_data loaded with {row_count} rows.")
   log_info_to_file(f"pt_vehicles_data loaded with {row_count} rows.")
   logger.info(f"pt_vehicles_data schema: {pt_vehicles_data.schema}")
   log_info_to_file(f"pt_vehicles_data schema: {pt_vehicles_data.schema}")
   display(pt_vehicles_data)
   logger.info("[END] Extraction for pt_vehicles_data.")
   log_info_to_file("[END] Extraction for pt_vehicles_data.")
except Exception as e:
   logger.error(f"Error loading pt_vehicles_data: {e}", exc_info=True)
   log_info_to_file(f"Error loading pt_vehicles_data: {str(e)}")
   sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Transformation of Public Transport
log_info_to_file("[START] Transformation for ptv...")
logger.info("[START] Transformation for ptv...")
ptv_query = '''
SELECT DISTINCT 
    CONCAT('ptv_', TRIM(PolicyNumber), '_', TRIM(VIN)) AS pmt_id,  
    CONCAT('CA7CAL_', TRIM(PolicyNumber)) AS pmt_parent,  
    TRIM(GaragingLocation) AS RegistrationState_Ext,
    TRIM(CustomerVehId) AS agentvehiclenumber_ext,
    TRIM(VIN) AS VIN,
    TRIM(Make) AS make,
    TRIM(model) AS model,
    CAST(TRIM(Year) AS INTEGER) AS Year,
    trim(ZipCode) AS zipcode,
    CAST(StatedAmount AS INTEGER) AS statedamount,  

    CASE 
        WHEN VehicleTypeCode IN (26, 33, 34, 35, 36, 39) THEN SUBSTRING(TRIM(PrimaryClassCode), 0, 3)
        ELSE SUBSTRING(TRIM(PrimaryClassCode), 0, 4)
    END AS primaryclasscode,

    SUBSTRING(TRIM(SecondClassCode), 0, 2) AS secondaryclasscode,

    CASE 
        WHEN MechanicalLift = 'Y' THEN 'Yes'
        ELSE 'No'
    END AS equippedwithmechanicallift,

    TRIM(OwnedbyMuncipalityTransitAutorityorPoliticalsubdivision) AS OwnedByMunicipalityTransitAuthorityOrPoliticalSubdivision,
    TRIM(SeatingCapacity) AS seatingcapacitysixOrgreater,
    CASE WHEN SchoolBusProration IS NOT NULL THEN 'Yes' ELSE 'No' END AS schoolbusproration,
    CASE WHEN SchoolBusProration IS NOT NULL THEN 1 ELSE NULL END AS numberofdaysschoolyear,
    'usd' AS preferredcoveragecurrency,
    'usd' AS preferredsettlementcurrency,
    CONCAT('PL:', TRIM(PolicyNumber)) AS location,
    CAST(TRIM(OriginalCostNew) AS INT) AS OriginalCostNew,
    TRIM(PolicyNumber) AS pmt_payloadid,

    TRIM(AntiTheftDevice) AS antitheftdevice,
    CAST('None' AS STRING) AS AntiTheftDeviceDiscount,
    TRIM(BusesOperatedOnAnInterstateBasis) AS BusesOperatedOnAnInterstateBasis,
    CAST('No' AS STRING) AS DefensiveDrivingCourseCredit,
    CAST('No' AS STRING) AS VehicleOverWeightIndicator,
    TRIM(OwnedByEmployer) AS ValidVanPoolOperation,
    CAST('No' AS STRING) AS UsedToCarryFreightAndMerchandise,
    CAST('No' AS STRING) AS UsedInTransportatOfEmployeesWithSeatingCapacitiesOf7To16Persons,
    CAST('No' AS STRING) AS TransportationOfEmployees,
    CAST('No' AS STRING) AS TransportPublicPassengersForCompensation,
    CAST('No' AS STRING) AS StateOwnedVehicle,
    CASE WHEN SeatingCapacity > 10 then 'Yes' ELSE 'No' END AS SeatingCapacityOver10,
  
    CAST('No' AS STRING) AS SafetyScoreDiscountApplies,
    TRIM(RideSharingArrangements) AS RideSharingArrangements,
    CAST('No' AS STRING) AS OwnedByTheGovernmentStateOrPoliticalSubdivision,
    CAST('No' AS STRING) AS OwnedByNewJerseyTransitCorp,
    CAST('Employer' AS STRING) AS OwnedBy,
    CAST('No' AS STRING) AS MotorBus,
    CAST('No' AS STRING) AS Jitneys,
    CASE WHEN trim(GrossVehicleWeight) <= 10000 THEN 'Yes' ELSE 'No' END AS IndividuallyOwnedLimo,
    CAST('No' AS STRING) AS FirstOrAdditionalAuto,
    CASE WHEN vehicleNumber = 1 THEN 'Y' ELSE 'N' END AS firstauto,
    CAST('AIRPORT BUS' AS STRING) AS AirportType,
    CASE  WHEN MatureDriverDt IS NOT NULL AND TRIM(MatureDriverDt) != '' THEN 'Yes' ELSE 'No'
          END AS maturedriverimprovementcoursediscount,
          CASE WHEN  GrossVehicleWeight > 10000 THEN 'Yes' ELSE 'No'
          END AS GrossVehicleWeightOver10000,
    CAST('No' AS STRING) AS auxillaryrunninglampsdiscount,
    CASE  WHEN SeatingCapacity BETWEEN 1 AND 15 THEN 'Yes' ELSE 'No' END AS SeatingCapacitiesUpTo15Persons
    --stretchlimousine

FROM pt_vehicles_data'''
try:
    ptv = spark.sql(ptv_query)
    ptv.createOrReplaceTempView("ptv")
    row_count = ptv.count()
    logger.info(f"ptv loaded with {row_count} rows.")
    log_info_to_file(f"ptv loaded with {row_count} rows.")
    logger.info(f"ptv schema: {ptv.schema}")
    log_info_to_file(f"ptv schema: {ptv.schema}")
    display(ptv)
    logger.info("[END] Transformation for ptv.")
    log_info_to_file("[END] Transformation for ptv.")
except Exception as e:
    logger.error(f"Error loading ptv: {e}", exc_info=True)
    log_info_to_file(f"Error loading ptv: {str(e)}")
    sys.exit(1)

# COMMAND ----------

log_info_to_file("[START] Extraction for location_basic...")
logger.info("[START] Extraction for location_basic...")
location_query = """select * from account_location"""
try:
    location_basic = eval(exec_select_framework)(location_query)
    location_basic.createOrReplaceTempView("location_basic")
    row_count = location_basic.count()
    logger.info(f"location_basic loaded with {row_count} rows.")
    log_info_to_file(f"location_basic loaded with {row_count} rows.")
    logger.info(f"location_basic schema: {location_basic.schema}")
    log_info_to_file(f"location_basic schema: {location_basic.schema}")
    display(location_basic)
    logger.info("[END] Extraction for location_basic.")
    log_info_to_file("[END] Extraction for location_basic.")
except Exception as e:
    logger.error(f"Error loading location_basic: {e}", exc_info=True)
    log_info_to_file(f"Error loading location_basic: {str(e)}")
    sys.exit(1)

# COMMAND ----------

log_info_to_file("[START] Deduplication for location_basic...")
logger.info("[START] Deduplication for location_basic...")
location_basic_deduped = location_basic.dropDuplicates(["vin"])
location_basic_deduped.createOrReplaceTempView("location_basic")
row_count = location_basic_deduped.count()
logger.info(f"location_basic_deduped loaded with {row_count} rows.")
log_info_to_file(f"location_basic_deduped loaded with {row_count} rows.")
logger.info(f"location_basic_deduped schema: {location_basic_deduped.schema}")
log_info_to_file(f"location_basic_deduped schema: {location_basic_deduped.schema}")
display(location_basic_deduped)
logger.info("[END] Deduplication for location_basic.")
log_info_to_file("[END] Deduplication for location_basic.")

# COMMAND ----------

log_info_to_file("[START] Transformation for vehical_final...")
logger.info("[START] Transformation for vehical_final...")
vehical_final = """
 select 
a.pmt_id, 
a.pmt_parent, 
RegistrationState_Ext, 
agentvehiclenumber_ext, 
a.VIN, 
make, 
model, 
Year, 
zipcode, 
statedamount, 
primaryclasscode, 
secondaryclasscode, 
equippedwithmechanicallift, 
OwnedByMunicipalityTransitAuthorityOrPoliticalSubdivision, 
seatingcapacitysixOrgreater, 
schoolbusproration, 
numberofdaysschoolyear, 
preferredcoveragecurrency, 
preferredsettlementcurrency, 
case when b.vin is not null then concat("PL:",substring(b.pmt_id,9)) else null end as  location, 
OriginalCostNew, 
a.pmt_payloadid, 
antitheftdevice, 
AntiTheftDeviceDiscount, 
BusesOperatedOnAnInterstateBasis, 
DefensiveDrivingCourseCredit, 
VehicleOverWeightIndicator, 
ValidVanPoolOperation, 
UsedToCarryFreightAndMerchandise, 
UsedInTransportatOfEmployeesWithSeatingCapacitiesOf7To16Persons, 
TransportationOfEmployees, 
TransportPublicPassengersForCompensation, 
StateOwnedVehicle, 
SeatingCapacityOver10, 
SafetyScoreDiscountApplies, 
RideSharingArrangements, 
OwnedByTheGovernmentStateOrPoliticalSubdivision, 
OwnedByNewJerseyTransitCorp, 
OwnedBy, 
MotorBus, 
Jitneys, 
IndividuallyOwnedLimo, 
FirstOrAdditionalAuto, 
firstauto, 
AirportType, 
maturedriverimprovementcoursediscount, 
GrossVehicleWeightOver10000, 
auxillaryrunninglampsdiscount, 
SeatingCapacitiesUpTo15Persons
 from ptv a left outer join location_basic b on a.pmt_payloadid = b.pmt_payloadid and trim(a.vin) = trim(b.vin)"""
 
try:
    vehical_final = spark.sql(vehical_final)
    vehical_final.createOrReplaceTempView("vehical_final")
    row_count = vehical_final.count()
    logger.info(f"vehical_final loaded with {row_count} rows.")
    log_info_to_file(f"vehical_final loaded with {row_count} rows.")
    logger.info(f"vehical_final schema: {vehical_final.schema}")
    log_info_to_file(f"vehical_final schema: {vehical_final.schema}")
    display(vehical_final)
    logger.info("[END] Transformation for vehical_final.")
    log_info_to_file("[END] Transformation for vehical_final.")
except Exception as e:
    logger.error(f"error loading vehical_final: {e}", exc_info=True)
    log_info_to_file(f"error loading vehical_final: {str(e)}")
    sys.exit(1)

# COMMAND ----------

# DBTITLE 1,Writing table into PMTIN
logger = get_etl_logger('Public transport')
# Cell Purpose: Write the transformed Public Transport table to the PMTIN database.
# Business Context: This step persists the cleaned and enriched Public Transport data for downstream insurance processing and reporting.

try:
    row_count = vehical_final.count()
    logger.info(f"[START] Writing {row_count} rows to table 'ca7publictransport' in PMTIN.")
    log_info_to_file(f"[START] Writing {row_count} rows to table 'ca7publictransport' in PMTIN.")
    logger.info(f"vehical_final schema: {vehical_final.schema}")
    log_info_to_file(f"vehical_final schema: {vehical_final.schema}")
    write_and_log_pmtin(
        vehical_final,
        table_name="ca7publictransport",
        job_id=job_id,
        job_run_id=job_run_id,
        notebook_name=notebook_name
    )
    logger.info("[END] Successfully wrote vehical_final to table 'ca7publictransport'.")
    log_info_to_file("[END] Successfully wrote vehical_final to table 'ca7publictransport'.")
except Exception as e:
    logger.error(f"Error writing vehical_final to table 'ca7publictransport'", exc_info=True)
    log_info_to_file(f"Error writing vehical_final to table 'ca7publictransport': {str(e)}")
    sys.exit(1)

# COMMAND ----------

