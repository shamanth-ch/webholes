# Databricks notebook source
dbutils.secrets.get(scope="gw-conv-kv-scope", key="psql-gwconv-data-dev-eus-01-dev-password")


# COMMAND ----------

Host='psql-gwconv-data-dev-eus-01.postgres.database.azure.com'
User_main=dbutils.secrets.get(scope="gw-conv-kv-scope", key="psql-gwconv-data-dev-eus-01-dev-username")

Password_main= dbutils.secrets.get(scope="gw-conv-kv-scope", key="psql-gwconv-data-dev-eus-01-dev-password")
User=dbutils.secrets.get(scope="gw-conv-kv-scope", key="psql-gwconv-data-dev-eus-01-dev-username")

Password= dbutils.secrets.get(scope="gw-conv-kv-scope", key="psql-gwconv-data-dev-eus-01-dev-password")
#User = dbutils.secrets.get(scope="gw-conv-kv-scope", key="psql-gwconv-data-qa-eus-01-username")
#Password = dbutils.secrets.get(scope="gw-conv-kv-scope", key='psql-gwconv-data-qa-eus-01-password')
Port=5432
Landing_Database='GRACDB_Landing'
Framework_Database='Framework'
#pmt_id_database='PMTIN'
pmt_id_database='PMT_IN_local'
# pmt_id_database = 'PMTIN_QA'
Recon_database='Recon'
Driver="org.postgresql.Driver"
properties={"driver": Driver, "user":User, "password":Password }

jdbc_url_landing=f"jdbc:postgresql://{Host}:{Port}/{Landing_Database}"
jdbc_url_pmtin=f"jdbc:postgresql://{Host}:{Port}/{pmt_id_database}"
jdbc_url_framework=f"jdbc:postgresql://{Host}:{Port}/{Framework_Database}"
jdbc_url_recon=f"jdbc:postgresql://{Host}:{Port}/{Recon_database}"

exec_select_landing = '''execute_select_{}'''.format(Landing_Database)
exec_select_framework = '''execute_select_{}'''.format(Framework_Database)
exec_select_pmtin = '''execute_select_{}'''.format(pmt_id_database)
exec_cmd_pmtin = '''exec_query_{}'''.format(pmt_id_database)
# Builds a string that names the execution command (e.g., a stored procedure) for the Framework database
exec_cmd_framework = f"exec_query_{Framework_Database}"
exec_select_recon = 'execute_select_{}'.format(Recon_database)

# COMMAND ----------

