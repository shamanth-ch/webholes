# Databricks notebook source
dbutils.widgets.text("job_id", "")
dbutils.widgets.text("job_run_id", "")


# COMMAND ----------

# MAGIC %run ./configs

# COMMAND ----------

import logging
import psycopg2
import sys

# COMMAND ----------


"""
Issue:
- `sys.exit(1)` is used too liberally, and could terminate other pending jobs even when the error is transient.
- Generic message logged without distinguishing transient vs permanent errors.

Change:
- Use retry mechanisms for transient issues (network, database load).
"""
import time
from tenacity import retry, stop_after_attempt, wait_fixed

@retry(stop=stop_after_attempt(3), wait=wait_fixed(2))  # Retry 3 times with 2-second intervals
def post_cnn_pmt_in():
    try:
        conn = psycopg2.connect(host=Host, database=pmt_id_database, user=User, password=Password)
        if conn:
            logger.info("Connection to PMTIN successful.")
        return conn
    except psycopg2.OperationalError as e:
        logger.warning("Transient connection issue. Retrying...")
        raise e  # Will retry the connection
    except Exception as e:
        logger.error("Critical error connecting to PostgreSQL: %s", e, exc_info=True)
        raise SystemExit(e)  # Exit program if connection fails permanently

# COMMAND ----------

logger = logging.getLogger('postgres_notebook')
logger.setLevel(logging.INFO)
handler = logging.StreamHandler()
handler.setLevel(logging.INFO)

# COMMAND ----------

def post_cnn_pmt_in():
    try:
        conn = psycopg2.connect(host=Host, database=pmt_id_database, user=User, password=Password)
        if conn:
            logger.info("Connection successful")
        else:
            logger.info("Connection failed")
        return conn
    except Exception as e:
        logger.info("Error connecting to PostgreSQL: {}".format(e))
        sys.exit(1)

# COMMAND ----------

@retry(stop=stop_after_attempt(3), wait=wait_fixed(2))  # Retry 3 times with 2-second intervals
def post_cnn_framework():
    try:
        conn = psycopg2.connect(host=Host, database=Framework_Database, user=User_main, password=Password_main)
        if conn:
            logger.info("Connection to Framework successful.")
        return conn
    except psycopg2.OperationalError as e:
        logger.warning("Transient connection issue. Retrying...")
        raise e  # Will retry the connection
    except Exception as e:
        logger.error("Critical error connecting to PostgreSQL: %s", e, exc_info=True)

# COMMAND ----------


"""
Issue:
- The `Exception` block does not distinguish between query failures, connection errors, or incorrect query syntax.
- Lack of details about the query causing the error.

Change:
- Add query details to error logs, and ensure only expected exceptions are handled.
"""

def execute_select_GRACDB_Landing(query):
    log_prefix = "Execute_GarcDB_Query"  # For easier troubleshooting
    try:
        logger.info("%s: Starting query execution: %s", log_prefix, query)
        extract_df = spark.read.format("jdbc").option("url", jdbc_url_landing).option("query", query).option("user", User).option("password", Password).option("driver", Driver).load()
        logger.info("%s: Query executed successfully.", log_prefix)
        return extract_df
    except psycopg2.ProgrammingError as e:
        logger.error("%s: Query syntax error: %s", log_prefix, query, exc_info=True)
        sys.exit(1)
    except Exception as e:
        logger.error("%s: Unknown error executing query: %s", log_prefix, query, exc_info=True)
        sys.exit(1)

# COMMAND ----------


"""
Issue:
- The `Exception` block does not distinguish between query failures, connection errors, or incorrect query syntax.
- Lack of details about the query causing the error.

Change:
- Add query details to error logs, and ensure only expected exceptions are handled.
"""

def execute_select_recon(query):
    log_prefix = "Execute_recon_Query"  # For easier troubleshooting
    try:
        logger.info("%s: Starting query execution: %s", log_prefix, query)
        extract_df = spark.read.format("jdbc").option("url", jdbc_url_recon).option("query", query).option("user", User).option("password", Password).option("driver", Driver).load()
        logger.info("%s: Query executed successfully.", log_prefix)
        return extract_df
    except psycopg2.ProgrammingError as e:
        logger.error("%s: Query syntax error: %s", log_prefix, query, exc_info=True)
        sys.exit(1)
    except Exception as e:
        logger.error("%s: Unknown error executing query: %s", log_prefix, query, exc_info=True)
        sys.exit(1)

# COMMAND ----------


"""
Issue:
- The `Exception` block does not distinguish between query failures, connection errors, or incorrect query syntax.
- Lack of details about the query causing the error.

Change:
- Add query details to error logs, and ensure only expected exceptions are handled.
"""

def execute_select_Framework(query):
    log_prefix = "Execute_Framework_Query"  # For easier troubleshooting
    try:
        logger.info("%s: Starting query execution: %s", log_prefix, query)
        extract_df = spark.read.format("jdbc").option("url", jdbc_url_framework).option("query", query).option("user", User).option("password", Password).option("driver", Driver).load()
        logger.info("%s: Query executed successfully.", log_prefix)
        return extract_df
    except psycopg2.ProgrammingError as e:
        logger.error("%s: Query syntax error: %s", log_prefix, query, exc_info=True)
        sys.exit(1)
    except Exception as e:
        logger.error("%s: Unknown error executing query: %s", log_prefix, query, exc_info=True)
        sys.exit(1)

# COMMAND ----------

"""
Issue:
- The `Exception` block does not distinguish between query failures, connection errors, or incorrect query syntax.
- Lack of details about the query causing the error.

Change:
- Add query details to error logs, and ensure only expected exceptions are handled.
"""
def execute_select_PMTIN(query):
    log_prefix = "Execute_PMTIN_Query"  # For easier troubleshooting
    try:
        logger.info("%s: Starting query execution: %s", log_prefix, query)
        extract_df = spark.read.format("jdbc").option("url", jdbc_url_pmtin).option("query", query).option("user", User).option("password", Password).option("driver", Driver).load()
        logger.info("%s: Query executed successfully.", log_prefix)
        return extract_df
    except psycopg2.ProgrammingError as e:
        logger.error("%s: Query syntax error: %s", log_prefix, query, exc_info=True)
        sys.exit(1)
    except Exception as e:
        logger.error("%s: Unknown error executing query: %s", log_prefix, query, exc_info=True)
        sys.exit(1)

# COMMAND ----------

def execute_select_PMT_IN_local (query):
    try:
        extract_df = spark.read.format("jdbc").option("url",jdbc_url_pmtin ).option("query", query).option("user", User).option("password", Password).option("driver", Driver).load()
        return extract_df
    except Exception as e:
        logger.info("Error executing query: {}".format(e))
        sys.exit(1)

# COMMAND ----------

def execute_select_PMTIN_QA (query):
    try:
        extract_df = spark.read.format("jdbc").option("url",jdbc_url_pmtin ).option("query", query).option("user", User).option("password", Password).option("driver", Driver).load()
        return extract_df
    except Exception as e:
        logger.info("Error executing query: {}".format(e))
        sys.exit(1)

# COMMAND ----------

def exec_query_PMTIN(query):
    try:
        conn = post_cnn_pmt_in()
        cur = conn.cursor()
        cur.execute(query)
        conn.commit()
        cur.close()
        conn.close()
        logger.info("Query executed successfully")
    except Exception as e:
        logger.info("Error executing query: {}".format(e))
        sys.exit(1)


# COMMAND ----------

def exec_query_Framework(query):
    try:
        conn = post_cnn_framework()
        cur = conn.cursor()
        cur.execute(query)
        conn.commit()
        cur.close()
        conn.close()
        logger.info("Query executed successfully")
    except Exception as e:
        logger.info("Error executing query: {}".format(e))
        sys.exit(1)


# COMMAND ----------

def exec_query_PMT_IN_local(query):
    try:
        conn = post_cnn_pmt_in()
        cur = conn.cursor()
        cur.execute(query)
        conn.commit()
        cur.close()
        conn.close()
        logger.info("Query executed successfully")
    except Exception as e:
        logger.info("Error executing query: {}".format(e))
        sys.exit(1)


# COMMAND ----------

def exec_query_PMTIN_QA(query):
    try:
        conn = post_cnn_pmt_in()
        cur = conn.cursor()
        cur.execute(query)
        conn.commit()
        cur.close()
        conn.close()
        logger.info("Query executed successfully")
    except Exception as e:
        logger.info("Error executing query: {}".format(e))
        sys.exit(1)


# COMMAND ----------

def execute_select_Recon_database(query):
    try:
        extract_df = spark.read.format("jdbc").option("url", jdbc_url_recon).option("query", query).option("user", User).option("password", Password).option("driver", Driver).load()
        return extract_df
    except Exception as e:
        logger.info("Error executing query: {}".format(e))
        sys.exit(1)

# COMMAND ----------

def post_cnn_recon_database():
    try:
        conn = psycopg2.connect(host=Host, database=recon_database, user=User, password=Password)
        if conn:
            logger.info("Connection to recon_database successful")
        else:
            logger.info("Connection to recon_database failed")
        return conn
    except Exception as e:
        logger.info("Error connecting to recon_database: {}".format(e))
        sys.exit(1)

def exec_query_recon_database(query):
    try:
        conn = post_cnn_recon_database()
        cur = conn.cursor()
        cur.execute(query)
        conn.commit()
        cur.close()
        conn.close()
        logger.info("Query executed successfully on recon_database")
    except Exception as e:
        logger.info("Error executing query on recon_database: {}".format(e))
        sys.exit(1)

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# DBTITLE 1,Logging Functions for Data Load and Job Events

import time

def log_dataload_event(job_id, job_run_id, notebook_name, log_message):
    """
    INSERT a row into framework.pmtin_dataload_logs.
    """
    sanitized_msg = log_message.replace("'", "''")  # Sanitize message
    q = f"""
      INSERT INTO public.pmtin_dataload_logs
        (job_id, job_run_id, notebook_name, log_message, event_time)
      VALUES
        ('{job_id}', '{job_run_id}', '{notebook_name}', '{sanitized_msg}', NOW());
    """
    exec_query_Framework(q)  # Execute the query

def log_job_event(job_id, job_run_id, task, duration, status):
    """
    INSERT a row into framework.pmtin_job_logs.
    """
    q = f"""
      INSERT INTO public.pmtin_job_logs
        (job_id, job_run_id, task, duration, status, event_time)
      VALUES
        ('{job_id}', '{job_run_id}', '{task}', {duration}, '{status}', NOW());
    """
    exec_query_Framework(q)  # Execute the query

# COMMAND ----------

from pyspark.sql.utils import AnalysisException
import time

def write_and_log_pmtin(df, table_name, job_id, job_run_id, notebook_name, truncate=True, batch_size=1000, max_retries=3):
    """
    Function to write a DataFrame to the PMTIN database and log the operation, with error handling and logging enhancements.

    Args:
    - df (DataFrame): The Spark DataFrame to write.
    - table_name (str): The target table name in PMTIN.
    - job_id (str): Job ID for logging.
    - job_run_id (str): Job run ID for logging.
    - notebook_name (str): Notebook name for contextual logging.
    - truncate (bool): Whether to truncate the table before writing (default: True).
    - batch_size (int): Number of rows per batch for the JDBC write (default: 1000).
    - max_retries (int): The maximum number of retries for transient errors (default: 3).

    Raises:
    Exception: On unrecoverable errors during write or other steps.
    """
    # Check if DataFrame is empty (use .isEmpty() if available, else .count())
    try:
        if df.isEmpty():
            logger.warning(f"No data to write for table '{table_name}'. Skipping write.")
            log_dataload_event(job_id, job_run_id, notebook_name, f"No data to write for table '{table_name}'. Skipping write.")
            return
    except AttributeError:
        if df.count() == 0:
            logger.warning(f"No data to write for table '{table_name}'. Skipping write.")
            log_dataload_event(job_id, job_run_id, notebook_name, f"No data to write for table '{table_name}'. Skipping write.")
            return

    try:
        # Log write initiation
        logger.info(f"Starting write operation to table '{table_name}'.")

        # Truncate the table if specified
        if truncate:
            try:
                exec_query_PMTIN(f"TRUNCATE TABLE public.{table_name};")
                logger.info(f"Truncated table {table_name} before writing new data.")
            except Exception as e:
                logger.warning(f"Issue in truncating table '{table_name}': {e}. Proceeding with write operation.")
                log_dataload_event(job_id, job_run_id, notebook_name, f"Issue in truncating table '{table_name}': {e}. Proceeding with write operation.")

        row_count = df.count()
        logger.info(f"Table '{table_name}' contains {row_count} rows to write.")

        # Writing DataFrame to PostgreSQL table in batch mode
        retries = 0
        while retries < max_retries:
            try:
                start_time = time.time()

                # Use batchsize for efficient writes (option name is 'batchsize', not 'batchSize')
                df.write.format("jdbc") \
                        .option("url", jdbc_url_pmtin) \
                        .option("dbtable", f"public.{table_name}") \
                        .option("user", User) \
                        .option("password", Password) \
                        .option("driver", Driver) \
                        .option("batchsize", batch_size) \
                        .mode("append") \
                        .save()

                logger.info(f"Successfully wrote {row_count} rows to '{table_name}' in {time.time() - start_time:.2f} seconds.")
                log_dataload_event(job_id, job_run_id, notebook_name, 
                                   f"Finished writing table {table_name} with {row_count} rows")
                return
            except Exception as write_error:
                retries += 1
                logger.error(f"Attempt {retries} to write to table '{table_name}' failed. Error: {write_error}.", exc_info=True)
                log_dataload_event(job_id, job_run_id, notebook_name, f"Attempt {retries} to write to table '{table_name}' failed. Error: {write_error}.")

                # Retry after a small delay (e.g., 5 seconds)
                if retries < max_retries:
                    logger.info(f"Retrying write operation for table '{table_name}' (Attempt {retries+1}/{max_retries}).")
                    time.sleep(5)
                else:
                    # Throw the error after exhausting retries
                    logger.error(f"Write failed for table '{table_name}' after {max_retries} retries. Error: {write_error}", exc_info=True)
                    log_dataload_event(job_id, job_run_id, notebook_name, f"Write failed for table '{table_name}' after {max_retries} retries. Error: {write_error}")
                    raise

    except AnalysisException as ae:
        logger.error(f"DataFrame schema mismatch for table '{table_name}': {ae}", exc_info=True)
        log_dataload_event(job_id, job_run_id, notebook_name, f"DataFrame schema mismatch for table '{table_name}': {ae}")
        raise
    except Exception as e:
        logger.error(f"Unhandled exception for write operation to table '{table_name}': {e}", exc_info=True)
        log_dataload_event(job_id, job_run_id, notebook_name, f"Unhandled exception for write operation to table '{table_name}': {e}")
        raise

# COMMAND ----------

# Function to Fetch Queries from the Database
def fetch_query_from_table(query_name):
    try:
        conn = post_cnn_framework()  # Framework connection function
        cur = conn.cursor()
        # Fetch the active query by name
        query = f"SELECT query_text FROM source_queries WHERE query_name = '{query_name}' AND is_active = TRUE"
        cur.execute(query)
        result = cur.fetchone()  # Fetch one record
        cur.close()
        conn.close()
        if result is None:
            raise ValueError(f"Query with name '{query_name}' is not found or inactive.")
        return result[0]  # The query text
    except Exception as e:
        logger.error(f"Error fetching query '{query_name}': {e}", exc_info=True)
        raise

# COMMAND ----------

def validate_data(data_name, parent_table):
    """
    Validates a dataset against multiple criteria: nulls, duplicates, and referential integrity.
    
    Args:
    - data_name (str): The name of the table/view being validated.
    - parent_table (str): The name of the parent table/view for referential integrity checks.
    
    Returns:
    - result (dict): A dictionary containing validation status, errors, and warnings.
        {
            "status": True/False,
            "errors": [
                {"type": "referential_integrity", "details": [...]},
                {"type": "null_check", "field": "pmt_id", "count": 5},
                {"type": "duplicate_check", "field": "pmt_id", "duplicates": [...]}
            ],
            "warnings": []
        }
    """
    result = {"status": True, "errors": [], "warnings": []}

    # Referential Integrity Check
    invalid_refs_sql = f"""
    SELECT DISTINCT TRIM(pmt_parent) as pmt_parent
    FROM {data_name}
    WHERE TRIM(pmt_parent) NOT IN (
      SELECT DISTINCT TRIM(pmt_id) FROM {parent_table}
    )
    """
    invalid_refs = spark.sql(invalid_refs_sql)

    if invalid_refs.count() > 0:
        ref_errors = [{"invalid_pmt_parent": row.pmt_parent} for row in invalid_refs.collect()]
        result["errors"].append({"type": "referential_integrity", "details": ref_errors})
        result["status"] = False

    # Null Check: pmt_id
    null_pmt_id_sql = f"""
    SELECT COUNT(*) as null_count
    FROM {data_name}
    WHERE TRIM(pmt_id) IS NULL
    """
    null_pmt_id_count = spark.sql(null_pmt_id_sql).collect()[0]['null_count']
    if null_pmt_id_count > 0:
        result["errors"].append({"type": "null_check", "field": "pmt_id", "count": null_pmt_id_count})
        result["status"] = False

    
    # Duplicate Check: pmt_id
    duplicate_pmt_id_sql = f"""
    SELECT TRIM(pmt_id) as pmt_id, COUNT(*) as cnt
    FROM {data_name}
    GROUP BY TRIM(pmt_id)
    HAVING COUNT(*) > 1
    """
    duplicate_pmt_ids = spark.sql(duplicate_pmt_id_sql)
    if duplicate_pmt_ids.count() > 0:
        duplicates = [{"pmt_id": row.pmt_id, "count": row.cnt} for row in duplicate_pmt_ids.collect()]
        result["errors"].append({"type": "duplicate_check", "field": "pmt_id", "duplicates": duplicates})
        result["status"] = False

    # Log error details to help identify issues
    if not result["status"]:
        logger.error(f"Validation failed for {data_name}. Details: {result['errors']}")

    return result

# COMMAND ----------

